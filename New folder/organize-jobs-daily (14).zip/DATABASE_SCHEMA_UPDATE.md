# Database Schema Update - Add Delivered Field

## Overview
This document describes the database schema change needed to support the "delivered" status tracking for completed jobs.

## Required Change

Add a `delivered` boolean field to the `completed_jobs` table to track whether a job has been delivered to the customer.

## SQL Migration

Run the following SQL in your Supabase SQL Editor:

```sql
-- Add delivered column to completed_jobs table
ALTER TABLE public.completed_jobs 
ADD COLUMN IF NOT EXISTS delivered BOOLEAN DEFAULT false;

-- Add index for faster queries on delivered status
CREATE INDEX IF NOT EXISTS idx_completed_jobs_delivered 
ON public.completed_jobs(delivered);

-- Add index for faster queries on job_id and delivered status together
CREATE INDEX IF NOT EXISTS idx_completed_jobs_job_id_delivered 
ON public.completed_jobs(job_id, delivered);
```

## Verification

After running the migration, verify the changes:

```sql
-- Check if column was added
SELECT column_name, data_type, column_default 
FROM information_schema.columns 
WHERE table_name = 'completed_jobs' 
AND column_name = 'delivered';

-- Check if indexes were created
SELECT indexname, indexdef 
FROM pg_indexes 
WHERE tablename = 'completed_jobs' 
AND indexname LIKE '%delivered%';
```

## Feature Description

### Delivered Checkbox
- Added to the Completed Jobs preview in the Archive modal
- Allows users to mark individual jobs as delivered
- Status is saved to the database immediately when toggled
- Visual indicator: Green checkmark for delivered, gray outline for not delivered

### Archive Behavior
- When "Run Archive Now" is pressed in Settings → Manual Archive
- Only jobs marked as "delivered" will be archived
- Non-delivered jobs remain in the completed_jobs table
- This allows jobs to stay in "Done" status until they are actually delivered to customers

## Implementation Details

### Frontend Changes
1. **ArchiveModalPreview.tsx**: Added delivered checkbox with database integration
2. **JobContext.tsx**: Updated `checkAndArchiveDoneJobs()` to filter by delivered status
3. **SettingsModal.tsx**: Updated confirmation message to reflect new behavior

### Database Integration
- Checkbox state is loaded from `completed_jobs.delivered` field on component mount
- Toggle updates the database immediately using Supabase client
- Archive process queries delivered status before archiving jobs
