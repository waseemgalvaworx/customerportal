# Notification System Debugging Guide

## Issue: Not Receiving GalvXpress Notifications

### Step 1: Check Database Tables

First, verify that the necessary database tables exist:

```sql
-- Check if notifications table exists
SELECT * FROM notifications LIMIT 5;

-- Check if push_token column exists in profiles
SELECT id, username, push_token FROM profiles;
```

### Step 2: Check Push Token Registration

1. Open the app and log in
2. Check the console logs for:
   - "Push token registered successfully"
   - Or any errors related to push token registration

### Step 3: Verify Notification Creation

After creating a GalvXpress job, check:

```sql
-- Check if notification was created in database
SELECT * FROM notifications 
ORDER BY created_at DESC 
LIMIT 10;
```

### Step 4: Check Edge Function

Verify the edge function is deployed:
```bash
supabase functions list
```

Should show: `send-push-notification`

### Step 5: Test Push Notification Manually

```sql
-- Get your push token
SELECT push_token FROM profiles WHERE id = 'YOUR_USER_ID';

-- Then test via edge function
```

### Common Issues:

1. **Notifications table doesn't exist**: Run the SQL to create it (see below)
2. **push_token column missing**: Run the SQL to add it (see below)
3. **Edge function not deployed**: Deploy it using supabase CLI
4. **Push permissions not granted**: Check device settings

### SQL to Create Missing Tables/Columns:

```sql
-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  job_id UUID REFERENCES jobs(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL,
  priority TEXT DEFAULT 'normal',
  read BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add push_token column to profiles
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS push_token TEXT;

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(read);
```

### Enable RLS:

```sql
-- Enable RLS on notifications
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Policy: Users can view their own notifications
CREATE POLICY "Users can view own notifications" ON notifications
  FOR SELECT USING (auth.uid() = user_id);

-- Policy: System can insert notifications
CREATE POLICY "System can insert notifications" ON notifications
  FOR INSERT WITH CHECK (true);

-- Policy: Users can update their own notifications
CREATE POLICY "Users can update own notifications" ON notifications
  FOR UPDATE USING (auth.uid() = user_id);

-- Policy: Users can delete their own notifications
CREATE POLICY "Users can delete own notifications" ON notifications
  FOR DELETE USING (auth.uid() = user_id);
```
