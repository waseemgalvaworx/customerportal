# Fix Delivery Request Approve Button

## Issue
The "Approve" button in Delivery Requests (View Requests in Logistics screen) is not functioning properly.

## Diagnosis Steps

### 1. Check Console Logs
After the fix, when you click the Approve button, check the browser/app console for:
- "Approving delivery request: [id]"
- "Approve result: { data, error }"

If you see an error, it will tell you exactly what's wrong.

### 2. Common Issues & Solutions

**A. RLS Policy Issue**
If error says "permission denied" or "policy violation":

Run this SQL in Supabase SQL Editor:
```sql
-- Drop existing policy
DROP POLICY IF EXISTS "Allow all operations on logistics_deliveries" ON logistics_deliveries;

-- Create new permissive policy
CREATE POLICY "Enable all operations for logistics_deliveries" 
ON logistics_deliveries FOR ALL 
USING (true) 
WITH CHECK (true);
```

**B. Table Doesn't Exist**
If error says "relation does not exist":
- Run the migration file: `supabase/migrations/create_logistics_deliveries_table.sql`

**C. Status Column Issue**
If error mentions status column:
```sql
-- Verify status column exists
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'logistics_deliveries' AND column_name = 'status';
```

### 3. Test the Fix
1. Go to Logistics screen
2. Click "Request Delivery" and create a test request
3. Click "View Requests"
4. Click "Approve" on the request
5. Check console logs for any errors
6. Verify the request disappears from the list (moved to scheduled)

## What Was Changed
- Added detailed console logging to track the approve operation
- Added error display in Alert to show exact error message
- Added `.select()` to return updated data for verification
