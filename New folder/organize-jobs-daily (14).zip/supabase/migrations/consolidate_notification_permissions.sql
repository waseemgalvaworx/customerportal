-- Consolidate notification permissions to use database as single source of truth
-- This migration updates all existing users to have the comprehensive notification_permissions structure

-- Update all profiles to have the complete notification_permissions structure
UPDATE profiles
SET notification_permissions = jsonb_build_object(
  'job_created', COALESCE((notification_permissions->>'job_created')::boolean, true),
  'job_updated', COALESCE((notification_permissions->>'job_updated')::boolean, true),
  'job_completed', COALESCE((notification_permissions->>'job_completed')::boolean, true),
  'job_archived', COALESCE((notification_permissions->>'job_archived')::boolean, true),
  'messages', COALESCE((notification_permissions->>'messages')::boolean, true),
  'stock_request_created', COALESCE((notification_permissions->>'stock_request_created')::boolean, true),
  'stock_request_approved', COALESCE((notification_permissions->>'stock_request_approved')::boolean, true),
  'stock_request_acknowledged', COALESCE((notification_permissions->>'stock_request_acknowledged')::boolean, true),
  'inventory_stock_movements', COALESCE((notification_permissions->>'inventory_stock_movements')::boolean, true),
  'inventory_low_stock', COALESCE((notification_permissions->>'inventory_low_stock')::boolean, true),
  'inventory_new_items', COALESCE((notification_permissions->>'inventory_new_items')::boolean, true),
  'inventory_diesel', COALESCE((notification_permissions->>'inventory_diesel')::boolean, true),
  'daily_report', COALESCE((notification_permissions->>'daily_report')::boolean, true),
  'system_alerts', COALESCE((notification_permissions->>'system_alerts')::boolean, true)
)
WHERE notification_permissions IS NULL OR notification_permissions = '{}'::jsonb;

-- Also update profiles that have partial notification_permissions
UPDATE profiles
SET notification_permissions = notification_permissions || jsonb_build_object(
  'job_created', COALESCE((notification_permissions->>'job_created')::boolean, true),
  'job_updated', COALESCE((notification_permissions->>'job_updated')::boolean, true),
  'job_completed', COALESCE((notification_permissions->>'job_completed')::boolean, true),
  'job_archived', COALESCE((notification_permissions->>'job_archived')::boolean, true),
  'messages', COALESCE((notification_permissions->>'messages')::boolean, true),
  'stock_request_created', COALESCE((notification_permissions->>'stock_request_created')::boolean, true),
  'stock_request_approved', COALESCE((notification_permissions->>'stock_request_approved')::boolean, true),
  'stock_request_acknowledged', COALESCE((notification_permissions->>'stock_request_acknowledged')::boolean, true),
  'inventory_stock_movements', COALESCE((notification_permissions->>'inventory_stock_movements')::boolean, true),
  'inventory_low_stock', COALESCE((notification_permissions->>'inventory_low_stock')::boolean, true),
  'inventory_new_items', COALESCE((notification_permissions->>'inventory_new_items')::boolean, true),
  'inventory_diesel', COALESCE((notification_permissions->>'inventory_diesel')::boolean, true),
  'daily_report', COALESCE((notification_permissions->>'daily_report')::boolean, true),
  'system_alerts', COALESCE((notification_permissions->>'system_alerts')::boolean, true)
)
WHERE notification_permissions IS NOT NULL AND notification_permissions != '{}'::jsonb;
