-- Create email_recipients table
CREATE TABLE IF NOT EXISTS email_recipients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL UNIQUE,
  name TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE email_recipients ENABLE ROW LEVEL SECURITY;

-- Create policies - allow all authenticated users to read and write
CREATE POLICY "Allow all authenticated users to view email recipients"
  ON email_recipients
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow all authenticated users to insert email recipients"
  ON email_recipients
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Allow all authenticated users to update email recipients"
  ON email_recipients
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all authenticated users to delete email recipients"
  ON email_recipients
  FOR DELETE
  TO authenticated
  USING (true);

-- Create index on email for faster lookups
CREATE INDEX IF NOT EXISTS idx_email_recipients_email ON email_recipients(email);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_email_recipients_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER email_recipients_updated_at
  BEFORE UPDATE ON email_recipients
  FOR EACH ROW
  EXECUTE FUNCTION update_email_recipients_updated_at();
