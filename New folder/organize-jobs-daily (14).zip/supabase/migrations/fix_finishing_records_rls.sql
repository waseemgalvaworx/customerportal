-- Fix RLS policies for finishing_records table
-- The original policy may not properly allow INSERT operations

-- Drop all existing policies on finishing_records
DROP POLICY IF EXISTS "Allow all for authenticated users" ON finishing_records;
DROP POLICY IF EXISTS "Allow all select" ON finishing_records;
DROP POLICY IF EXISTS "Allow all insert" ON finishing_records;
DROP POLICY IF EXISTS "Allow all update" ON finishing_records;
DROP POLICY IF EXISTS "Allow all delete" ON finishing_records;
DROP POLICY IF EXISTS "finishing_select" ON finishing_records;
DROP POLICY IF EXISTS "finishing_insert" ON finishing_records;
DROP POLICY IF EXISTS "finishing_update" ON finishing_records;
DROP POLICY IF EXISTS "finishing_delete" ON finishing_records;

-- Ensure RLS is enabled
ALTER TABLE finishing_records ENABLE ROW LEVEL SECURITY;

-- Create proper permissive policies with explicit permissions
-- SELECT policy
CREATE POLICY "finishing_records_select" ON finishing_records 
  FOR SELECT USING (true);

-- INSERT policy (requires WITH CHECK, not USING)
CREATE POLICY "finishing_records_insert" ON finishing_records 
  FOR INSERT WITH CHECK (true);

-- UPDATE policy
CREATE POLICY "finishing_records_update" ON finishing_records 
  FOR UPDATE USING (true);

-- DELETE policy
CREATE POLICY "finishing_records_delete" ON finishing_records 
  FOR DELETE USING (true);

-- Also fix archived_finishing_reports if needed
DROP POLICY IF EXISTS "Allow all for authenticated users" ON archived_finishing_reports;
DROP POLICY IF EXISTS "archived_finishing_select" ON archived_finishing_reports;
DROP POLICY IF EXISTS "archived_finishing_insert" ON archived_finishing_reports;
DROP POLICY IF EXISTS "archived_finishing_update" ON archived_finishing_reports;
DROP POLICY IF EXISTS "archived_finishing_delete" ON archived_finishing_reports;

ALTER TABLE archived_finishing_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "archived_finishing_select" ON archived_finishing_reports 
  FOR SELECT USING (true);

CREATE POLICY "archived_finishing_insert" ON archived_finishing_reports 
  FOR INSERT WITH CHECK (true);

CREATE POLICY "archived_finishing_update" ON archived_finishing_reports 
  FOR UPDATE USING (true);

CREATE POLICY "archived_finishing_delete" ON archived_finishing_reports 
  FOR DELETE USING (true);
