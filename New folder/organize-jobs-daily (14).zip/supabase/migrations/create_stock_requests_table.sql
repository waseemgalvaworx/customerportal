-- Create stock_requests table
CREATE TABLE IF NOT EXISTS stock_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id UUID NOT NULL REFERENCES inventory_items(id) ON DELETE CASCADE,
  quantity_requested NUMERIC NOT NULL,
  reason TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'fulfilled', 'rejected')),
  requested_by TEXT NOT NULL,
  approved_by TEXT,
  fulfilled_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE stock_requests ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if any
DROP POLICY IF EXISTS "Allow all authenticated users to view stock_requests" ON stock_requests;
DROP POLICY IF EXISTS "Allow all authenticated users to insert stock_requests" ON stock_requests;
DROP POLICY IF EXISTS "Allow all authenticated users to update stock_requests" ON stock_requests;

-- Create permissive policies for all authenticated users
CREATE POLICY "Allow all authenticated users to view stock_requests"
  ON stock_requests FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow all authenticated users to insert stock_requests"
  ON stock_requests FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Allow all authenticated users to update stock_requests"
  ON stock_requests FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create index for better query performance
CREATE INDEX IF NOT EXISTS idx_stock_requests_item_id ON stock_requests(item_id);
CREATE INDEX IF NOT EXISTS idx_stock_requests_status ON stock_requests(status);
CREATE INDEX IF NOT EXISTS idx_stock_requests_created_at ON stock_requests(created_at DESC);
