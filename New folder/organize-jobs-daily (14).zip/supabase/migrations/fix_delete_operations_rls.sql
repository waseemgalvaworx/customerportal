-- Fix DELETE operations across all tables by ensuring RLS policies explicitly allow DELETE

-- Inventory tables
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON inventory_items;
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON inventory_transactions;

CREATE POLICY "Allow all for authenticated users" ON inventory_items
  FOR ALL TO authenticated
  USING (true) 
  WITH CHECK (true);

CREATE POLICY "Allow all for authenticated users" ON inventory_transactions
  FOR ALL TO authenticated
  USING (true) 
  WITH CHECK (true);

-- Jobs table
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON jobs;
CREATE POLICY "Allow all for authenticated users" ON jobs
  FOR ALL TO authenticated
  USING (true) 
  WITH CHECK (true);

-- Refresh schema cache
NOTIFY pgrst, 'reload schema';
