-- Migration: Fix vehicles status constraint
-- Ensures the CHECK constraint is properly applied and all data is valid

-- Step 1: Update any invalid status values to 'active'
UPDATE vehicles 
SET status = 'active' 
WHERE status IS NULL OR status NOT IN ('active', 'maintenance', 'inactive');

-- Step 2: Drop existing constraint if it exists
ALTER TABLE vehicles DROP CONSTRAINT IF EXISTS vehicles_status_check;

-- Step 3: Add the constraint back with explicit name
ALTER TABLE vehicles 
ADD CONSTRAINT vehicles_status_check 
CHECK (status IN ('active', 'maintenance', 'inactive'));

-- Step 4: Ensure default value is set
ALTER TABLE vehicles ALTER COLUMN status SET DEFAULT 'active';
