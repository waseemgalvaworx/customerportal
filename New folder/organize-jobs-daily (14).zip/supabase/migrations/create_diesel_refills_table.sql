-- Create diesel_refills table for tracking diesel deliveries
CREATE TABLE IF NOT EXISTS diesel_refills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  refill_date DATE NOT NULL DEFAULT CURRENT_DATE,
  quantity_received NUMERIC(10,2) NOT NULL,
  cost_per_litre NUMERIC(10,2) NOT NULL,
  total_cost NUMERIC(10,2) GENERATED ALWAYS AS (quantity_received * cost_per_litre) STORED,
  purchase_order_number TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES auth.users(id),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE diesel_refills ENABLE ROW LEVEL SECURITY;

-- Create policies for authenticated users
CREATE POLICY "Allow authenticated users to view diesel refills"
  ON diesel_refills FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to insert diesel refills"
  ON diesel_refills FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update diesel refills"
  ON diesel_refills FOR UPDATE
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to delete diesel refills"
  ON diesel_refills FOR DELETE
  TO authenticated
  USING (true);

-- Create index for faster queries
CREATE INDEX idx_diesel_refills_date ON diesel_refills(refill_date DESC);
