-- Migration: Add unique constraint on finishing_records.item_id
-- Purpose: Prevent duplicate finishing records at the database level
-- Date: 2025-12-08

-- First, clean up any existing duplicates (keep the most recent one)
DELETE FROM finishing_records a
USING finishing_records b
WHERE a.item_id = b.item_id 
  AND a.created_at < b.created_at;

-- Add unique constraint on item_id if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'finishing_records_item_id_unique'
  ) THEN
    ALTER TABLE finishing_records 
    ADD CONSTRAINT finishing_records_item_id_unique UNIQUE (item_id);
    RAISE NOTICE 'Added unique constraint finishing_records_item_id_unique';
  ELSE
    RAISE NOTICE 'Constraint finishing_records_item_id_unique already exists';
  END IF;
END $$;

-- Create index on item_id for faster lookups if not exists
CREATE INDEX IF NOT EXISTS idx_finishing_records_item_id ON finishing_records(item_id);

-- Add comment explaining the constraint
COMMENT ON CONSTRAINT finishing_records_item_id_unique ON finishing_records IS 
  'Ensures each item can only have one active finishing record. Prevents duplication issues.';
