-- Backfill ready_date from activity_logs for historical accuracy
-- This migration uses the activity_logs table to find when items were actually marked as Ready

-- First, update ready_date using activity_logs for items that have ITEM_STATUS_CHANGED logs
-- The activity_logs contain the actual timestamp when items were changed to Ready status

UPDATE item_stage_tracking ist
SET ready_date = al.created_at
FROM activity_logs al
WHERE al.action_type = 'ITEM_STATUS_CHANGED'
  AND al.action_description ILIKE '%to Ready%'
  AND al.entity_id = ist.item_id
  AND ist.current_stage = 'Ready'
  AND (ist.ready_date IS NULL OR ist.ready_date > NOW() - INTERVAL '3 days');

-- For items without activity logs, try to use job's updated_at as fallback
-- This handles items that were marked Ready before activity logging was implemented

UPDATE item_stage_tracking ist
SET ready_date = j.updated_at
FROM jobs j
WHERE ist.job_id = j.id
  AND ist.current_stage = 'Ready'
  AND (ist.ready_date IS NULL OR ist.ready_date > NOW() - INTERVAL '3 days')
  AND j.updated_at IS NOT NULL
  AND j.updated_at < NOW() - INTERVAL '3 days';

-- Alternative: Check if there are JOB_UPDATED logs that mention Ready status
UPDATE item_stage_tracking ist
SET ready_date = al.created_at
FROM activity_logs al
WHERE al.action_type = 'JOB_UPDATED'
  AND al.action_description ILIKE '%Ready%'
  AND al.entity_id = ist.job_id
  AND ist.current_stage = 'Ready'
  AND (ist.ready_date IS NULL OR ist.ready_date > NOW() - INTERVAL '3 days');

-- Verify the backfill worked
SELECT 
  DATE(ready_date) as date,
  COUNT(*) as items_count
FROM item_stage_tracking
WHERE ready_date IS NOT NULL
GROUP BY DATE(ready_date)
ORDER BY date DESC
LIMIT 30;
