-- Enable RLS on notifications table with permissive policies
-- This app uses password-based authentication (not Supabase Auth)
-- So auth.uid() is always null - we use permissive policies instead
-- Application-level authorization is handled in the app code

-- Enable RLS on notifications table
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Drop any existing policies to start fresh
DROP POLICY IF EXISTS "Allow all select" ON notifications;
DROP POLICY IF EXISTS "Allow all insert" ON notifications;
DROP POLICY IF EXISTS "Allow all update" ON notifications;
DROP POLICY IF EXISTS "Allow all delete" ON notifications;
DROP POLICY IF EXISTS "Users can view own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can view sent notifications" ON notifications;
DROP POLICY IF EXISTS "Users can update own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can delete own notifications" ON notifications;
DROP POLICY IF EXISTS "notifications_select_policy" ON notifications;
DROP POLICY IF EXISTS "notifications_insert_policy" ON notifications;
DROP POLICY IF EXISTS "notifications_update_policy" ON notifications;
DROP POLICY IF EXISTS "notifications_delete_policy" ON notifications;

-- Create permissive policies for password-based auth system

-- SELECT: Allow all reads (app filters by user_id in queries)
CREATE POLICY "notifications_select_policy" ON notifications 
  FOR SELECT 
  USING (true);

-- INSERT: Allow all inserts (app sets user_id when creating)
CREATE POLICY "notifications_insert_policy" ON notifications 
  FOR INSERT 
  WITH CHECK (true);

-- UPDATE: Allow all updates including archived and read fields
CREATE POLICY "notifications_update_policy" ON notifications 
  FOR UPDATE 
  USING (true) 
  WITH CHECK (true);

-- DELETE: Allow all deletes (app handles authorization)
CREATE POLICY "notifications_delete_policy" ON notifications 
  FOR DELETE 
  USING (true);
