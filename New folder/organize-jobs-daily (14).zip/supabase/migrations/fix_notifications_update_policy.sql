-- Fix UPDATE policy to include WITH CHECK clause
-- This is required for UPDATE operations to work properly

-- Drop existing update policy
DROP POLICY IF EXISTS "Allow all update" ON notifications;

-- Recreate with both USING and WITH CHECK
CREATE POLICY "Allow all update" ON notifications 
  FOR UPDATE 
  USING (true) 
  WITH CHECK (true);
