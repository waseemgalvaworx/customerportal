-- Re-enable RLS with permissive policies for password-based authentication
-- This allows the app to function while maintaining RLS structure

-- First, enable RLS on notifications table
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Create permissive policies that allow all authenticated app users
CREATE POLICY "Allow all select" ON notifications FOR SELECT USING (true);
CREATE POLICY "Allow all insert" ON notifications FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow all update" ON notifications FOR UPDATE USING (true);
CREATE POLICY "Allow all delete" ON notifications FOR DELETE USING (true);
