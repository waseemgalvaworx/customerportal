-- Create function to prevent duplicate notifications
CREATE OR REPLACE FUNCTION prevent_duplicate_notifications()
RETURNS TRIGGER AS $$
DECLARE
  duplicate_count INTEGER;
BEGIN
  -- Check for duplicate notification within last 5 seconds
  SELECT COUNT(*) INTO duplicate_count
  FROM notifications
  WHERE user_id = NEW.user_id
    AND title = NEW.title
    AND message = NEW.message
    AND type = NEW.type
    AND created_at >= NOW() - INTERVAL '5 seconds';
  
  -- If duplicate exists, skip insert
  IF duplicate_count > 0 THEN
    RAISE NOTICE 'Duplicate notification detected, skipping insert';
    RETURN NULL;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
DROP TRIGGER IF EXISTS check_duplicate_notifications ON notifications;
CREATE TRIGGER check_duplicate_notifications
  BEFORE INSERT ON notifications
  FOR EACH ROW
  EXECUTE FUNCTION prevent_duplicate_notifications();

-- Create index for performance
CREATE INDEX IF NOT EXISTS idx_notifications_duplicate_check 
  ON notifications(user_id, title, message, type, created_at DESC);
