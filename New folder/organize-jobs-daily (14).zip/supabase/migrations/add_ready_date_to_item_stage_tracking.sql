-- Add ready_date column to item_stage_tracking table
-- This column tracks when an item was moved to 'Ready' status (completed)

ALTER TABLE item_stage_tracking 
ADD COLUMN IF NOT EXISTS ready_date TIMESTAMPTZ;

-- Create index for faster queries on ready_date
CREATE INDEX IF NOT EXISTS idx_item_stage_tracking_ready_date 
  ON item_stage_tracking(ready_date) 
  WHERE ready_date IS NOT NULL;

-- Backfill ready_date for existing items that are already in 'Ready' status
-- Uses the entry_time as the ready_date since that's when they entered Ready status
UPDATE item_stage_tracking 
SET ready_date = entry_time 
WHERE current_stage = 'Ready' 
  AND ready_date IS NULL;

-- Also backfill from jobs table for items in Ready status that might not have tracking records
INSERT INTO item_stage_tracking (job_id, item_id, current_stage, entry_time, ready_date)
SELECT 
  j.id as job_id,
  item->>'id' as item_id,
  item->>'status' as current_stage,
  COALESCE(j.updated_at, j.created_at, NOW()) as entry_time,
  COALESCE(j.updated_at, j.created_at, NOW()) as ready_date
FROM jobs j,
LATERAL jsonb_array_elements(j.items::jsonb) as item
WHERE item->>'status' = 'Ready'
  AND NOT EXISTS (
    SELECT 1 FROM item_stage_tracking ist 
    WHERE ist.job_id = j.id 
    AND ist.item_id = item->>'id'
  )
ON CONFLICT (job_id, item_id) DO UPDATE 
SET ready_date = COALESCE(item_stage_tracking.ready_date, EXCLUDED.ready_date);
