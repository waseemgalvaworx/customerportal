-- Create logistics_deliveries table
CREATE TABLE IF NOT EXISTS logistics_deliveries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  delivery_number TEXT NOT NULL UNIQUE,
  job_id UUID REFERENCES jobs(id),
  job_items JSONB,
  client_name TEXT,
  delivery_address TEXT NOT NULL,
  contact_phone TEXT,
  scheduled_date TEXT,
  status TEXT DEFAULT 'scheduled',
  notes TEXT,
  vehicle_id UUID REFERENCES vehicles(id),
  driver_id UUID REFERENCES drivers(id),
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE logistics_deliveries ENABLE ROW LEVEL SECURITY;

-- Create policies for logistics_deliveries
CREATE POLICY "Allow all operations on logistics_deliveries" ON logistics_deliveries FOR ALL USING (true) WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_logistics_deliveries_status ON logistics_deliveries(status);
CREATE INDEX IF NOT EXISTS idx_logistics_deliveries_job_id ON logistics_deliveries(job_id);
CREATE INDEX IF NOT EXISTS idx_logistics_deliveries_vehicle ON logistics_deliveries(vehicle_id);
CREATE INDEX IF NOT EXISTS idx_logistics_deliveries_driver ON logistics_deliveries(driver_id);
