-- Final fix for vehicles status constraint
-- This migration ensures the constraint matches the code expectations

-- Step 1: Drop ALL existing constraints on status
DO $$ 
BEGIN
    ALTER TABLE vehicles DROP CONSTRAINT IF EXISTS vehicles_status_check;
    ALTER TABLE vehicles DROP CONSTRAINT IF EXISTS vehicles_status_check1;
    ALTER TABLE vehicles DROP CONSTRAINT IF EXISTS vehicles_check;
EXCEPTION
    WHEN undefined_object THEN NULL;
END $$;

-- Step 2: Update any NULL or invalid status values
UPDATE vehicles 
SET status = 'active' 
WHERE status IS NULL OR status NOT IN ('active', 'maintenance', 'inactive');

-- Step 3: Set default for status column
ALTER TABLE vehicles 
ALTER COLUMN status SET DEFAULT 'active';

-- Step 4: Add the correct constraint
ALTER TABLE vehicles 
ADD CONSTRAINT vehicles_status_check 
CHECK (status IN ('active', 'maintenance', 'inactive'));
