-- Create email_settings table to store email configuration
CREATE TABLE IF NOT EXISTS email_settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  from_email TEXT NOT NULL,
  domain TEXT NOT NULL,
  is_verified BOOLEAN DEFAULT FALSE,
  verification_checked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE email_settings ENABLE ROW LEVEL SECURITY;

-- Allow all authenticated users to read and update email settings
CREATE POLICY "Allow authenticated users to read email settings"
  ON email_settings FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to insert email settings"
  ON email_settings FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update email settings"
  ON email_settings FOR UPDATE
  TO authenticated
  USING (true);

-- Insert default settings (using Resend test domain)
INSERT INTO email_settings (from_email, domain, is_verified)
VALUES ('onboarding@resend.dev', 'resend.dev', true)
ON CONFLICT DO NOTHING;
