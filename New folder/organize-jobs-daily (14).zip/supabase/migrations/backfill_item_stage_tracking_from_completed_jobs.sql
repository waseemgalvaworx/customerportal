-- One-time migration script to backfill item_stage_tracking with ready_date from completed_jobs
-- for all historical records prior to 11/11/2025
-- This ensures data consistency and establishes item_stage_tracking as the single source of truth
-- 
-- Executed: 2025-12-05
-- Result: Successfully synchronized both tables

-- Step 1: Update existing records in item_stage_tracking that have matching completed_jobs entries
-- Sets ready_date from completed_jobs.completed_at for records prior to 2025-11-11
UPDATE item_stage_tracking ist
SET ready_date = cj.completed_at
FROM completed_jobs cj
WHERE ist.job_id = cj.job_id
  AND ist.item_id = cj.item_id
  AND cj.completed_at < '2025-11-11 00:00:00+00'
  AND (ist.ready_date IS NULL OR ist.ready_date >= '2025-11-11 00:00:00+00');

-- Step 2: Insert new records into item_stage_tracking for completed_jobs entries
-- that don't have corresponding tracking records (historical data prior to 2025-11-11)
INSERT INTO item_stage_tracking (job_id, item_id, current_stage, entry_time, ready_date, created_at, updated_at)
SELECT 
  cj.job_id,
  cj.item_id,
  'Ready' as current_stage,
  cj.completed_at as entry_time,
  cj.completed_at as ready_date,
  cj.completed_at as created_at,
  NOW() as updated_at
FROM completed_jobs cj
WHERE cj.completed_at < '2025-11-11 00:00:00+00'
  AND cj.job_id IS NOT NULL
  AND cj.item_id IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM item_stage_tracking ist 
    WHERE ist.job_id = cj.job_id 
    AND ist.item_id = cj.item_id
  )
ON CONFLICT (job_id, item_id) DO UPDATE 
SET ready_date = COALESCE(item_stage_tracking.ready_date, EXCLUDED.ready_date);

-- Verification queries (run after migration)
-- Check date distribution:
-- SELECT DATE(ready_date) as date, COUNT(*) as items_count
-- FROM item_stage_tracking WHERE ready_date IS NOT NULL
-- GROUP BY DATE(ready_date) ORDER BY date ASC;

-- Check for missing records:
-- SELECT COUNT(*) FROM completed_jobs cj
-- WHERE NOT EXISTS (SELECT 1 FROM item_stage_tracking ist 
--   WHERE ist.job_id = cj.job_id AND ist.item_id = cj.item_id);
