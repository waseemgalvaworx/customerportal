-- Fix RLS policies for stock_requests table to work with password-based authentication
-- Drop existing restrictive policies
DROP POLICY IF EXISTS "Allow all authenticated users to view stock_requests" ON stock_requests;
DROP POLICY IF EXISTS "Allow all authenticated users to insert stock_requests" ON stock_requests;
DROP POLICY IF EXISTS "Allow all authenticated users to update stock_requests" ON stock_requests;
DROP POLICY IF EXISTS "Allow all authenticated users to delete stock_requests" ON stock_requests;

-- Create permissive policies that work with password auth (no Supabase session required)
CREATE POLICY "Allow all select on stock_requests" 
  ON stock_requests FOR SELECT 
  USING (true);

CREATE POLICY "Allow all insert on stock_requests" 
  ON stock_requests FOR INSERT 
  WITH CHECK (true);

CREATE POLICY "Allow all update on stock_requests" 
  ON stock_requests FOR UPDATE 
  USING (true) 
  WITH CHECK (true);

CREATE POLICY "Allow all delete on stock_requests" 
  ON stock_requests FOR DELETE 
  USING (true);

-- Add missing timestamp columns
ALTER TABLE stock_requests 
  ADD COLUMN IF NOT EXISTS approved_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS fulfilled_at TIMESTAMPTZ;

-- Enable realtime for stock_requests
ALTER PUBLICATION supabase_realtime ADD TABLE stock_requests;
