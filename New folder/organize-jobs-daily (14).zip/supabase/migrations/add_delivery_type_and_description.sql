-- Add delivery_type and description columns to logistics_deliveries table
ALTER TABLE logistics_deliveries 
ADD COLUMN IF NOT EXISTS delivery_type TEXT DEFAULT 'delivery',
ADD COLUMN IF NOT EXISTS description TEXT;

-- Create index for delivery_type for better filtering performance
CREATE INDEX IF NOT EXISTS idx_logistics_deliveries_type ON logistics_deliveries(delivery_type);
