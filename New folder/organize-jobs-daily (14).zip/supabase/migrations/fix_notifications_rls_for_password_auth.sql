-- Fix RLS policies for password-based authentication
-- Since this app uses password auth (not Supabase Auth), auth.uid() is always null
-- We need to either disable RLS or make policies more permissive

-- Drop all existing policies
DROP POLICY IF EXISTS "Users can view own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can view sent notifications" ON notifications;
DROP POLICY IF EXISTS "Users can update own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can delete own notifications" ON notifications;

-- Disable RLS on notifications table since app uses password-based auth
ALTER TABLE notifications DISABLE ROW LEVEL SECURITY;

-- Alternative: If you want to keep RLS enabled, use these permissive policies instead:
-- CREATE POLICY "Allow all select" ON notifications FOR SELECT USING (true);
-- CREATE POLICY "Allow all insert" ON notifications FOR INSERT WITH CHECK (true);
-- CREATE POLICY "Allow all update" ON notifications FOR UPDATE USING (true);
-- CREATE POLICY "Allow all delete" ON notifications FOR DELETE USING (true);
