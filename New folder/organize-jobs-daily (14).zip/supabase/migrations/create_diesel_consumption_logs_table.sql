-- Create diesel_consumption_logs table for tracking diesel tank readings
CREATE TABLE IF NOT EXISTS diesel_consumption_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  log_type TEXT DEFAULT 'reading',
  height_cm NUMERIC NOT NULL,
  volume_liters NUMERIC NOT NULL,
  notes TEXT,
  log_date DATE DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE diesel_consumption_logs ENABLE ROW LEVEL SECURITY;

-- Create permissive policies
CREATE POLICY "Allow all to view diesel logs" ON diesel_consumption_logs FOR SELECT USING (true);
CREATE POLICY "Allow all to insert diesel logs" ON diesel_consumption_logs FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow all to update diesel logs" ON diesel_consumption_logs FOR UPDATE USING (true);
CREATE POLICY "Allow all to delete diesel logs" ON diesel_consumption_logs FOR DELETE USING (true);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_diesel_logs_date ON diesel_consumption_logs(log_date DESC);
CREATE INDEX IF NOT EXISTS idx_diesel_logs_created ON diesel_consumption_logs(created_at DESC);
