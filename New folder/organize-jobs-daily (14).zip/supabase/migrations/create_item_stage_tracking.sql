-- Create table to track when items enter each stage
CREATE TABLE IF NOT EXISTS item_stage_tracking (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  item_id TEXT NOT NULL,
  current_stage TEXT NOT NULL,
  entry_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT unique_job_item UNIQUE(job_id, item_id)
);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_item_stage_tracking_job_item 
  ON item_stage_tracking(job_id, item_id);

-- Enable RLS
ALTER TABLE item_stage_tracking ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to read and write
CREATE POLICY "Allow authenticated users full access to item_stage_tracking"
  ON item_stage_tracking
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_item_stage_tracking_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_item_stage_tracking_timestamp
  BEFORE UPDATE ON item_stage_tracking
  FOR EACH ROW
  EXECUTE FUNCTION update_item_stage_tracking_updated_at();
