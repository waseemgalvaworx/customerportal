-- Fix Opening Balances for Existing Inventory Items
-- This migration creates opening balance transactions for items that don't have them

-- Create opening balance transactions for items without them
INSERT INTO inventory_transactions (item_id, transaction_type, quantity, notes, created_at)
SELECT 
  i.id,
  'in' as transaction_type,
  i.quantity,
  'Opening Balance' as notes,
  (i.created_at - INTERVAL '1 minute') as created_at
FROM inventory_items i
WHERE i.quantity > 0
  AND NOT EXISTS (
    SELECT 1 
    FROM inventory_transactions t 
    WHERE t.item_id = i.id 
      AND t.notes = 'Opening Balance'
  );

-- Log the fix
DO $$
DECLARE
  affected_count INTEGER;
BEGIN
  GET DIAGNOSTICS affected_count = ROW_COUNT;
  RAISE NOTICE 'Created opening balance transactions for % items', affected_count;
END $$;
