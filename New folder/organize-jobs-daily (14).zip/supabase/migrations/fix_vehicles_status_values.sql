-- Migration: Fix invalid vehicle status values
-- Date: 2025-11-24
-- Description: Updates all vehicles with invalid status values (like 'available') to 'active'
--              to ensure consistency with the vehicles_status_check constraint

-- Update all vehicles with invalid status values to 'active'
UPDATE vehicles 
SET status = 'active' 
WHERE status NOT IN ('active', 'maintenance', 'inactive');

-- Add comment for documentation
COMMENT ON COLUMN vehicles.status IS 'Vehicle status: active, maintenance, or inactive';
