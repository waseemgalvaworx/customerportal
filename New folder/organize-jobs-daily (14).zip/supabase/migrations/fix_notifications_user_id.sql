-- Fix notifications table to use TEXT user_id instead of UUID
-- This allows compatibility with password-based auth system

-- Drop existing foreign key constraint
ALTER TABLE notifications DROP CONSTRAINT IF EXISTS notifications_user_id_fkey;

-- Change user_id column to TEXT
ALTER TABLE notifications ALTER COLUMN user_id TYPE TEXT;

-- Update RLS policies to work with TEXT user_id
DROP POLICY IF EXISTS "Users can view own notifications" ON notifications;
CREATE POLICY "Users can view own notifications" ON notifications
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users can update own notifications" ON notifications;
CREATE POLICY "Users can update own notifications" ON notifications
  FOR UPDATE USING (true);

DROP POLICY IF EXISTS "Users can delete own notifications" ON notifications;
CREATE POLICY "Users can delete own notifications" ON notifications
  FOR DELETE USING (true);
