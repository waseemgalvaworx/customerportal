-- Update Opening Balance transactions to include reference field
-- This ensures consistency between old and new opening balance transactions

-- Update existing opening balance transactions to include the reference field
UPDATE inventory_transactions
SET reference = 'OPENING_BALANCE'
WHERE notes = 'Opening Balance'
  AND (reference IS NULL OR reference != 'OPENING_BALANCE');

-- Log the update
DO $$
DECLARE
  affected_count INTEGER;
BEGIN
  GET DIAGNOSTICS affected_count = ROW_COUNT;
  RAISE NOTICE 'Updated % opening balance transactions with reference field', affected_count;
END $$;
