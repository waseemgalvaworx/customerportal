-- Fix notifications DELETE operation for password-based authentication
-- This migration ensures delete operations work properly

-- Drop ALL existing policies on notifications table
DROP POLICY IF EXISTS "Users can view own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can view sent notifications" ON notifications;
DROP POLICY IF EXISTS "Users can update own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can delete own notifications" ON notifications;
DROP POLICY IF EXISTS "System can insert notifications" ON notifications;
DROP POLICY IF EXISTS "Allow all select" ON notifications;
DROP POLICY IF EXISTS "Allow all insert" ON notifications;
DROP POLICY IF EXISTS "Allow all update" ON notifications;
DROP POLICY IF EXISTS "Allow all delete" ON notifications;

-- Disable RLS entirely since app uses password-based auth (not Supabase Auth)
-- auth.uid() is always null, so RLS policies don't work properly
ALTER TABLE notifications DISABLE ROW LEVEL SECURITY;
