-- Fix indexes for Finishing to Ready status update performance
-- Run this migration to ensure all required indexes exist

-- 1. item_stage_tracking - ensure unique constraint for upsert
DO $$ 
BEGIN
  -- Check if unique constraint exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'item_stage_tracking_job_item_unique'
  ) THEN
    -- Create unique constraint (also creates index)
    ALTER TABLE item_stage_tracking 
    ADD CONSTRAINT item_stage_tracking_job_item_unique 
    UNIQUE (job_id, item_id);
  END IF;
END $$;

-- 2. quality_control - index for job_id + item_name lookups
CREATE INDEX IF NOT EXISTS idx_quality_control_job_item_name 
  ON quality_control(job_id, item_name);

-- 3. completed_jobs - ensure unique constraint on item_id for upsert
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'completed_jobs_item_id_unique'
  ) THEN
    ALTER TABLE completed_jobs 
    ADD CONSTRAINT completed_jobs_item_id_unique 
    UNIQUE (item_id);
  END IF;
END $$;

-- 4. Additional performance indexes
CREATE INDEX IF NOT EXISTS idx_item_stage_tracking_current_stage 
  ON item_stage_tracking(current_stage);

CREATE INDEX IF NOT EXISTS idx_item_stage_tracking_entry_time 
  ON item_stage_tracking(entry_time DESC);

-- 5. Analyze tables to update query planner statistics
ANALYZE item_stage_tracking;
ANALYZE quality_control;
ANALYZE completed_jobs;

-- Verification query (run after migration)
-- SELECT 
--   t.relname as table_name,
--   i.relname as index_name,
--   a.attname as column_name
-- FROM pg_class t
-- JOIN pg_index ix ON t.oid = ix.indrelid
-- JOIN pg_class i ON i.oid = ix.indexrelid
-- JOIN pg_attribute a ON a.attrelid = t.oid AND a.attnum = ANY(ix.indkey)
-- WHERE t.relname IN ('item_stage_tracking', 'quality_control', 'completed_jobs')
-- ORDER BY t.relname, i.relname;
