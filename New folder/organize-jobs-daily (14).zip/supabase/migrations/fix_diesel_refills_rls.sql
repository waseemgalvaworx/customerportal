-- Fix RLS policies for diesel_refills to work with password auth
-- Drop existing policies
DROP POLICY IF EXISTS "Allow authenticated users to view diesel refills" ON diesel_refills;
DROP POLICY IF EXISTS "Allow authenticated users to insert diesel refills" ON diesel_refills;
DROP POLICY IF EXISTS "Allow authenticated users to update diesel refills" ON diesel_refills;
DROP POLICY IF EXISTS "Allow authenticated users to delete diesel refills" ON diesel_refills;

-- Create permissive policies that work with password auth
CREATE POLICY "Allow all to view diesel refills" ON diesel_refills FOR SELECT USING (true);
CREATE POLICY "Allow all to insert diesel refills" ON diesel_refills FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow all to update diesel refills" ON diesel_refills FOR UPDATE USING (true);
CREATE POLICY "Allow all to delete diesel refills" ON diesel_refills FOR DELETE USING (true);
