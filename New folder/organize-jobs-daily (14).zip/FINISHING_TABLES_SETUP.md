# Finishing Records Tables Setup

## Required Database Tables

The finishing records and archive functionality requires two additional tables in your Supabase database:

### 1. finishing_records Table

This table stores daily finishing records when items are moved to "Finishing" status.

```sql
CREATE TABLE finishing_records (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  job_id UUID REFERENCES jobs(id) ON DELETE CASCADE,
  item_id UUID,
  job_number TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  item_description TEXT NOT NULL,
  weight_kg TEXT NOT NULL,
  recorded_date DATE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add index for faster queries
CREATE INDEX idx_finishing_records_date ON finishing_records(recorded_date);
CREATE INDEX idx_finishing_records_job ON finishing_records(job_id);
```

### 2. archived_finishing_reports Table

This table stores archived finishing reports with all records as JSONB.

```sql
CREATE TABLE archived_finishing_reports (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  report_date DATE NOT NULL UNIQUE,
  archived_at TIMESTAMP WITH TIME ZONE NOT NULL,
  records JSONB NOT NULL,
  total_items INTEGER NOT NULL,
  total_weight NUMERIC(10,2) NOT NULL,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add index for faster queries
CREATE INDEX idx_archived_finishing_date ON archived_finishing_reports(report_date DESC);
```

## Row Level Security (RLS)

Enable RLS and add policies for both tables:

```sql
-- Enable RLS
ALTER TABLE finishing_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE archived_finishing_reports ENABLE ROW LEVEL SECURITY;

-- Allow all operations for authenticated users (adjust as needed)
CREATE POLICY "Allow all for authenticated users" ON finishing_records
  FOR ALL USING (true);

CREATE POLICY "Allow all for authenticated users" ON archived_finishing_reports
  FOR ALL USING (true);
```

## Setup Instructions

1. Go to your Supabase project dashboard
2. Navigate to SQL Editor
3. Copy and paste the SQL commands above
4. Run each section separately
5. Verify tables are created in the Table Editor

## Troubleshooting

If you see errors like:
- "relation 'finishing_records' does not exist"
- "relation 'archived_finishing_reports' does not exist"

This means the tables haven't been created yet. Follow the setup instructions above.

## How It Works

1. **Recording**: When an item status changes to "Finishing", a record is automatically inserted into `finishing_records`
2. **Viewing**: WIP Statistics → Finishing section shows today's records from `finishing_records`
3. **Archiving**: Archive button moves all today's records to `archived_finishing_reports` as JSONB and deletes from `finishing_records`
4. **Viewing Archive**: Archive screen → Finishing Report displays archived reports by date
