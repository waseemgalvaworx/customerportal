# Notification Settings Consolidation

## Problem
There were TWO separate systems managing notification preferences:
1. **User Preferences** (AsyncStorage) - Local device storage
2. **Admin Permissions** (Database) - Server-side permissions

This caused conflicts where:
- Settings would reset unexpectedly
- Admin changes wouldn't sync to user devices
- Different key names caused confusion
- Users could turn off settings, but they'd reappear

## Solution
Consolidated to **ONE source of truth**: Database (`profiles.notification_permissions`)

### Changes Made

#### 1. Updated `app/notification-settings.tsx`
- Removed AsyncStorage dependency
- Now reads/writes directly to database
- Uses same permission keys as admin panel

#### 2. Updated `utils/notificationHelper.ts`
- Removed AsyncStorage checks
- Only checks database permissions
- Simplified permission logic

#### 3. Updated `components/NotificationPermissionsModal.tsx`
- Added all notification types (14 total)
- Matches user settings exactly

#### 4. Created Migration
- `supabase/migrations/consolidate_notification_permissions.sql`
- Ensures all users have complete permission structure
- Defaults all permissions to `true`

### Notification Permission Keys

All 14 permission types:
- `job_created` - New jobs
- `job_updated` - Job status changes
- `job_completed` - Job completions
- `job_archived` - Archive notifications
- `messages` - Direct messages
- `stock_request_created` - New stock requests
- `stock_request_approved` - Approved requests
- `stock_request_acknowledged` - Acknowledged requests
- `inventory_stock_movements` - Stock in/out
- `inventory_low_stock` - Low stock alerts
- `inventory_new_items` - New inventory items
- `inventory_diesel` - Diesel operations
- `daily_report` - Daily reports
- `system_alerts` - System messages (overrides all if false)

### How It Works Now

1. **User changes settings**: 
   - Goes to Notifications → Notification Settings
   - Toggles switches
   - Saves to database

2. **Admin changes permissions**:
   - Goes to Settings → User Management
   - Edits user → Notification Permissions
   - Saves to database

3. **Both update the same database field**: `profiles.notification_permissions`

4. **When sending notifications**:
   - System checks ONLY database permissions
   - No more AsyncStorage conflicts
   - Changes are instant and persistent

### Migration Instructions

Run the migration:
```bash
# Apply the migration to your Supabase database
supabase db push
```

Or manually run the SQL in Supabase Dashboard → SQL Editor.

### Testing

1. Turn off a notification type in user settings
2. Verify it's saved in database
3. Check admin panel shows same setting
4. Verify notifications of that type are blocked
5. Turn it back on
6. Verify notifications work again
