# Delivery Date Setup

## Database Changes

Added `delivery_date` column to `completed_jobs` table:

```sql
ALTER TABLE completed_jobs 
ADD COLUMN IF NOT EXISTS delivery_date TIMESTAMP WITH TIME ZONE;

CREATE INDEX IF NOT EXISTS idx_completed_jobs_delivery_date 
ON completed_jobs(delivery_date);
```

## Features

1. **Automatic Date Setting**: When a job is marked as delivered, the current timestamp is automatically saved as delivery_date
2. **Display in Archive Preview**: Delivery date is shown in the completed jobs preview table
3. **Filtering/Sorting**: Jobs can be filtered and sorted by delivery date
4. **PDF Export**: Delivery date is included in all PDF exports of completed jobs

## Usage

- Mark a job as delivered by clicking the checkbox in the Archive modal
- The delivery date is automatically set to the current date/time
- Unmarking a job clears the delivery date
- Only jobs marked as delivered will be archived when "Run Archive Now" is pressed
