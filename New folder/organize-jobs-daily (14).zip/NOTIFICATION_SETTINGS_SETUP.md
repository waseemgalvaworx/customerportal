# Notification Settings Setup Guide

## Overview
The notification settings screen allows users to customize which types of notifications they receive, choose priority levels, and set quiet hours.

## Features Implemented

### 1. Database Schema
- Added `notification_preferences` JSONB column to `profiles` table
- Default preferences include:
  - `galvxpress_jobs`: true
  - `status_changes`: true
  - `messages`: true
  - `assignments`: true
  - `completions`: true
  - `priority_levels`: ["high", "medium", "low"]
  - `quiet_hours_enabled`: false
  - `quiet_hours_start`: "22:00"
  - `quiet_hours_end`: "08:00"

### 2. Notification Settings Screen
- Located at `/notification-settings`
- Toggle switches for each notification type
- Priority level selection (high, medium, low)
- Quiet hours configuration (coming soon)
- Save button to persist preferences

### 3. Smart Notification Filtering
The `notificationHelper.ts` now respects user preferences:
- Filters notifications by type (GalvXpress, status changes, etc.)
- Filters by priority level (only sends if user enabled that priority)
- Respects quiet hours (doesn't send notifications during quiet hours)
- Logs filtering results for debugging

## How to Use

### For Users
1. Navigate to the main screen
2. Tap on "Notification Settings" (teal icon with bell)
3. Toggle notification types on/off
4. Select which priority levels you want to receive
5. Tap "Save Preferences"

### For Developers
When creating notifications, the system automatically:
1. Checks each user's preferences
2. Filters out users who disabled that notification type
3. Filters out users who disabled that priority level
4. Skips users during their quiet hours
5. Only sends to users who pass all filters

## Example Usage

```typescript
// In JobContext or other contexts
import { notifyAllUsers } from '../utils/notificationHelper';

// Create a GalvXpress job notification
await notifyAllUsers({
  jobId: newJob.id,
  title: 'New GalvXpress Job',
  message: `Job ${newJob.job_number} created for ${newJob.customer_name}`,
  type: 'galvxpress',
  priority: 'high'
});
```

## Debugging
Check console logs for:
- `📢 notifyAllUsers called with:` - Shows notification details
- `✅ Found X profiles to notify` - Total users in system
- `✅ X profiles passed preference filters` - Users who will receive notification
- `⚠️ No users to notify after filtering preferences` - All users filtered out

## Future Enhancements
- Quiet hours time picker UI
- Per-customer notification preferences
- Notification sound/vibration settings
- Email notification preferences
- Notification history/archive
