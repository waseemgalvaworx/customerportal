# Admin User Setup

## Creating the Admin User

To create the admin user with username "admin" and password "1531", you can use one of these methods:

### Method 1: Using the User Management Screen

1. Open the app and navigate to the login screen
2. Click "User Management" link
3. Click "Add User" button
4. Fill in the form:
   - Username: `admin`
   - Password: `1531`
   - Full Name: `Administrator`
   - Role: Select "Admin"
5. Click "Create User"

### Method 2: Using Supabase Edge Function

Call the `create-admin-user` edge function directly:

```bash
curl -X POST https://obtmrrbajlrdnmnfhcas.supabase.co/functions/v1/create-admin-user \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "1531",
    "fullName": "Administrator"
  }'
```

### Method 3: Using Supabase Dashboard

1. Go to Authentication > Users in Supabase Dashboard
2. Create a new user with email: `admin@app.local` and password: `1531`
3. Copy the user ID
4. Go to Table Editor > profiles
5. Insert a new row:
   - id: [paste user ID]
   - username: `admin`
   - full_name: `Administrator`
   - role: `admin`
   - is_active: `true`

## Login Credentials

After setup, you can login with:
- **Username**: `admin`
- **Password**: `1531`

## User Roles

The system supports these roles:
- **Admin**: Full access including user management
- **Manager**: Jobs, customers, statistics (no user management)
- **Operator**: View/update jobs only
- **Viewer**: Read-only access
- **Data Entry Officer**: Add jobs, view WIP and completed jobs
