# Conflict Resolution for Offline Sync

## Overview
The galvanizing management system now includes automatic conflict detection and resolution when multiple users edit the same job while offline.

## How It Works

### 1. Conflict Detection
When syncing pending changes after reconnecting:
- The system checks if the server version was updated after the local change
- Compares `updated_at` timestamps to detect conflicts
- Only applies to UPDATE operations (not inserts or deletes)

### 2. Conflict Resolution Modal
When a conflict is detected:
- A modal appears showing side-by-side comparison
- Displays all fields that differ between local and server versions
- User can choose:
  - **Keep My Changes**: Apply local version to server
  - **Use Server Version**: Discard local changes, keep server data
  - **Cancel**: Skip this change and continue syncing

### 3. Automatic Sync Process
```
User goes offline → Makes changes → Changes queued
↓
Network reconnects → Sync starts
↓
For each pending change:
  - Check for conflicts
  - If conflict found → Show modal
  - User resolves → Continue sync
  - No conflict → Apply change
↓
Sync complete → Reload fresh data
```

## Technical Implementation

### Files Modified
1. **utils/offlineSync.ts** - Added conflict detection logic
2. **contexts/JobContext.tsx** - Integrated conflict handler
3. **components/ConflictResolutionModal.tsx** - UI for resolution

### Conflict Detection Logic
```typescript
// Checks if server version is newer than local change
const serverUpdatedAt = new Date(data.updated_at).getTime();
if (serverUpdatedAt > change.timestamp) {
  // Conflict detected!
}
```

### Resolution Flow
```typescript
// User makes choice in modal
onResolve('local' | 'server' | 'skip')
  ↓
'local': Apply local changes to server
'server': Keep server version, discard local
'skip': Don't apply this change, continue sync
```

## User Experience

### Scenario 1: No Conflicts
- User A goes offline, edits Job #123
- No one else edits Job #123
- User A reconnects → Changes sync automatically ✓

### Scenario 2: Conflict Detected
- User A goes offline, edits Job #123 status to "planning"
- User B (online) edits Job #123 status to "done"
- User A reconnects → Modal appears:
  ```
  Your Changes:        Server Version:
  status: planning     status: done
  ```
- User A chooses which version to keep

### Scenario 3: Multiple Conflicts
- Multiple jobs edited while offline
- Each conflict resolved one at a time
- Sync continues after each resolution

## Benefits

1. **Data Integrity**: No silent overwrites
2. **User Control**: Users decide which changes to keep
3. **Transparency**: Clear visibility of differences
4. **Audit Trail**: All resolutions logged

## Best Practices

1. **Sync Frequently**: Reconnect to network regularly
2. **Review Carefully**: Check differences before resolving
3. **Communicate**: Coordinate with team on critical changes
4. **Trust Server**: When in doubt, server version is usually most recent

## Limitations

- Only detects conflicts on UPDATE operations
- Relies on `updated_at` timestamps
- Manual resolution required (no automatic merge)
- One conflict at a time (sequential resolution)
