# Data Reconciliation Mismatch Guide

## Understanding Your 27 Mismatches

You have **27 data mismatches**:
- **25 Finishing mismatches**: Items in "Finishing" status but missing from `finishing_records` table, OR records in `finishing_records` for items no longer in "Finishing" status
- **2 Completed mismatches**: Items in "Ready" status but missing from `completed_jobs` table, OR records in `completed_jobs` for items no longer in "Ready" status

## Types of Mismatches

### 1. Missing Records (Most Common)
Items that have the correct status in the jobs table but are missing their corresponding tracking record.

**Cause**: These are likely historical items that were moved to Finishing/Ready status BEFORE the data integrity safeguards were implemented.

**Fix**: Use the `autoFixMissingRecords` function to create the missing records.

### 2. Orphan Records (Less Common)
Records that exist in `finishing_records` or `completed_jobs` but the item is no longer in that status.

**Cause**: Item status was changed but the old record wasn't cleaned up.

**Fix**: Use the `cleanupOrphanRecords` function to remove stale records.

---

## How to View the Detailed Report

### Option 1: Check Supabase Dashboard
1. Go to your Supabase Dashboard
2. Navigate to **Table Editor** → **reconciliation_reports**
3. Find the most recent report (sorted by `created_at`)
4. Look at these columns:
   - `missing_finishing_records` - JSON array of items missing finishing records
   - `orphan_finishing_records` - JSON array of stale finishing records
   - `missing_completed_records` - JSON array of items missing completed records
   - `orphan_completed_records` - JSON array of stale completed records

Each mismatch entry contains:
- `jobNumber` - The job number
- `itemId` - The item ID
- `itemDescription` - Description of the item
- `customerName` - Customer name

---

## How to Fix the Mismatches

### Option A: Automatic Fix (Recommended)

Run this in your app or via Supabase SQL Editor:

```typescript
import { getRecentReports, autoFixMissingRecords, cleanupOrphanRecords } from '@/utils/dataReconciliation';

// Get the latest report
const reports = await getRecentReports(1);
const latestReport = reports[0];

// Fix missing records
const fixResult = await autoFixMissingRecords(
  latestReport.missing_finishing_records || [],
  latestReport.missing_completed_records || []
);
console.log(`Fixed: ${fixResult.fixedFinishing} finishing, ${fixResult.fixedCompleted} completed`);

// Clean up orphan records
const cleanResult = await cleanupOrphanRecords(
  latestReport.orphan_finishing_records || [],
  latestReport.orphan_completed_records || []
);
console.log(`Cleaned: ${cleanResult.cleanedFinishing} finishing, ${cleanResult.cleanedCompleted} completed`);
```

### Option B: Manual Review First

If you want to review before fixing:

1. **View the report in Supabase**:
   ```sql
   SELECT * FROM reconciliation_reports 
   ORDER BY created_at DESC 
   LIMIT 1;
   ```

2. **Check specific items** by job number in the `missing_finishing_records` JSON

3. **Verify the items** are actually in the correct status in the jobs table

4. **Then run the auto-fix** for confirmed mismatches

---

## What the Auto-Fix Does

### For Missing Finishing Records:
- Fetches the job data
- Creates a new `finishing_records` entry with:
  - Current date as `recorded_date`
  - Item weight, description, customer name
  - Item options (galva, paint, etc.)

### For Missing Completed Records:
- Fetches the job data
- Creates a new `completed_jobs` entry with:
  - Current timestamp as `completed_at`
  - Item weight, description, customer name
  - Item options

### For Orphan Records:
- Deletes records from `finishing_records` or `completed_jobs` where the item is no longer in that status

---

## After Fixing

1. **Run reconciliation again** to verify all mismatches are resolved:
   ```typescript
   import { runReconciliation } from '@/utils/dataReconciliation';
   const result = await runReconciliation('Admin');
   console.log(`Remaining mismatches: ${result.finishingMismatches + result.completedMismatches}`);
   ```

2. **Check the notification** - You (Admin) will receive a notification if any mismatches remain

---

## Preventing Future Mismatches

The data integrity safeguards are now active:

1. **Database Constraints**: Unique constraints on `item_id` prevent duplicate records
2. **Enhanced Logging**: All operations are logged to `data_operation_logs` table
3. **Daily Reconciliation**: Runs automatically every 6 hours, alerts Admin only

---

## Alert Configuration

Data reconciliation alerts are now sent to **Admin only** (not all users).

This was updated in:
- `utils/dataReconciliation.ts` - Uses `notifyAdminOnly` instead of `notifyAllUsers`
- `utils/notificationHelper.ts` - New `notifyAdminOnly` function added
