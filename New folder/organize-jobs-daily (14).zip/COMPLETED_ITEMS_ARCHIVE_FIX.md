# Completed Items Archive - Historical Dates Fix

## Problem
The Completed Items archive only shows 2 dates (03/12/2025 and 04/12/2025) instead of all historical dates when items were marked as Ready.

## Root Cause
The `ready_date` column in `item_stage_tracking` was backfilled with recent timestamps instead of the actual historical dates when items were originally marked as Ready.

## Solution
Run the following SQL in Supabase SQL Editor to backfill `ready_date` from `activity_logs`:

```sql
-- Step 1: Check what activity logs exist for Ready status changes
SELECT 
  created_at,
  action_description,
  entity_id
FROM activity_logs 
WHERE action_type = 'ITEM_STATUS_CHANGED'
  AND action_description ILIKE '%to Ready%'
ORDER BY created_at ASC
LIMIT 50;

-- Step 2: Backfill ready_date from activity_logs
UPDATE item_stage_tracking ist
SET ready_date = al.created_at
FROM activity_logs al
WHERE al.action_type = 'ITEM_STATUS_CHANGED'
  AND al.action_description ILIKE '%to Ready%'
  AND al.entity_id = ist.item_id
  AND ist.current_stage = 'Ready';

-- Step 3: For items without activity logs, use JOB_UPDATED logs
UPDATE item_stage_tracking ist
SET ready_date = al.created_at
FROM activity_logs al
WHERE al.action_type = 'JOB_UPDATED'
  AND al.action_description ILIKE '%Ready%'
  AND al.entity_id = ist.job_id
  AND ist.current_stage = 'Ready'
  AND ist.ready_date IS NULL;

-- Step 4: Verify the dates are now spread across history
SELECT 
  DATE(ready_date) as date,
  COUNT(*) as items_count
FROM item_stage_tracking
WHERE ready_date IS NOT NULL
GROUP BY DATE(ready_date)
ORDER BY date DESC;
```

## Alternative: If activity_logs don't have historical data

If the activity_logs table was only recently implemented, you may need to use the jobs table's `updated_at` field as an approximation:

```sql
-- Use job updated_at as fallback for historical dates
UPDATE item_stage_tracking ist
SET ready_date = j.updated_at
FROM jobs j
WHERE ist.job_id = j.id
  AND ist.current_stage = 'Ready'
  AND ist.ready_date > NOW() - INTERVAL '7 days'
  AND j.updated_at < NOW() - INTERVAL '7 days';
```

## Checking Data Sources

Run these queries to understand what historical data is available:

```sql
-- Check oldest activity logs
SELECT MIN(created_at) as oldest_log FROM activity_logs;

-- Check oldest jobs
SELECT MIN(created_at) as oldest_job FROM jobs;

-- Check if jobs have historical updated_at dates
SELECT 
  DATE(updated_at) as date,
  COUNT(*) as job_count
FROM jobs
GROUP BY DATE(updated_at)
ORDER BY date ASC
LIMIT 30;
```

## After Running Migration

Refresh the Archive screen in the app. The Completed Items dropdown should now show all historical dates when items were marked as Ready.
