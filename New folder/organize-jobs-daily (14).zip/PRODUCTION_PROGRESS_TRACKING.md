# Production Progress Tracking System

## Overview
The production progress tracking system has been reworked to provide accurate, day-by-day comparison of actual production against static targets.

## Key Changes

### 1. Static Daily Targets
- **Table**: `daily_production_targets`
- Targets are set based on delivery dates in Planning
- Each date has a fixed target weight that doesn't change as jobs move through statuses
- Targets are independent per day - overdue items don't affect next day calculations

### 2. Production Movement Tracking
- **Table**: `production_movements`
- Records when items reach "Finishing" status
- Captures: job details, weight, timestamp, date
- Each day's movements are tracked separately

### 3. Daily Comparison
- **Target**: Static weight from `daily_production_targets` for selected date
- **Actual**: Sum of weights from `production_movements` for that date where `to_status = 'Finishing'`
- **Progress**: (Actual / Target) * 100%

## How It Works

### Planning Screen
1. When delivery dates are set, targets are automatically created/updated
2. Shows static target for selected date
3. Displays actual completed weight from movements for that date
4. Progress bar shows percentage completion

### WIP Statistics
1. Shows today's static target from `daily_production_targets`
2. Shows actual completions from `production_movements` for today
3. Independent calculation - doesn't include overdue items

## Benefits
- Accurate day-by-day tracking
- No carryover of overdue items
- Clear comparison of plan vs actual
- Historical data preserved in movements table
- Can analyze production trends over time
