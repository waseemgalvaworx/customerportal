# Opening Balance Setup

## Overview
Modified the inventory system to properly handle initial quantities as opening balances in inventory reports.

## Changes Made

### 1. AddInventoryItemModal.tsx
- Changed initial stock transaction note from "Initial stock - item created" to "Opening Balance"
- Set transaction timestamp to 1 minute before item creation time
- This ensures opening balance transactions are always counted as "before period" in reports

### 2. How It Works
When creating a new inventory item with an initial quantity:
1. Item is created in `inventory_items` table with the quantity
2. A transaction is created in `inventory_transactions` with:
   - `transaction_type`: 'in'
   - `quantity`: initial quantity
   - `notes`: 'Opening Balance'
   - `created_at`: 1 minute before item creation time

### 3. Report Behavior
In the Inventory Report screen:
- Opening balance transactions appear before any report period
- They are counted in the "Opening" stock calculation
- They are NOT counted as "IN" transactions during the period
- This provides accurate opening and closing balances

## Example
If you create "Gloves" with initial quantity 100 on Jan 15, 2025:
- Transaction created with timestamp: Jan 15, 2025 at 09:59:00
- Item created at: Jan 15, 2025 at 10:00:00
- Any report period starting Jan 15 or later will show 100 as opening balance
- The 100 units won't appear as an "IN" transaction during the period

## Benefits
- Accurate opening balances in all reports
- Clear distinction between opening stock and regular stock movements
- Historical accuracy maintained
- Works for all report periods (daily, weekly, monthly)
