# Hourly Production Tracking Fix

## Problem Identified

The hourly production tracking was not recording because of two critical issues:

### Issue 1: In-Memory Storage Loss
- `stageEntryTimes` Map stored in memory gets cleared on app restart
- When app reloads, all stage entry times are lost
- `initializeStageTracking()` sets entry time to current time, losing actual duration

### Issue 2: Strict Stage Matching
- Line 32 checks `previousEntry.stage === oldStatus`
- Fails when Map is empty or stage doesn't match
- No metrics get saved

## Solution

Store stage entry times in database instead of memory:

### 1. Create Database Table

```sql
CREATE TABLE IF NOT EXISTS item_stage_tracking (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  item_id TEXT NOT NULL,
  current_stage TEXT NOT NULL,
  entry_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(job_id, item_id)
);

CREATE INDEX idx_item_stage_tracking_job_item ON item_stage_tracking(job_id, item_id);
```

### 2. Updated performanceTracker.ts Logic

- When item changes status, query database for entry time
- Calculate duration from database timestamp
- Save performance metric
- Update database with new stage and entry time
- No more in-memory Map

This ensures tracking persists across app restarts and works on all devices.
