# Backup Retrieval Guide

## Automatic Backup Storage

All backups are now automatically uploaded to Supabase Storage in addition to browser downloads.

## How to Retrieve Backups from Supabase Dashboard

1. **Go to Supabase Dashboard**
   - Visit https://supabase.com
   - Log into your project

2. **Navigate to Storage**
   - Click on "Storage" in the left sidebar
   - Select the "backups" bucket

3. **Download Your Backup**
   - You'll see all backup files with timestamps (e.g., `backup_2025-10-24T06-53-12-345Z.json`)
   - Click on any backup file
   - Click the "Download" button to save it to your computer

## Backup File Format

Each backup file contains:
- Timestamp of when the backup was created
- Version information
- All data from these tables:
  - jobs
  - completed_jobs
  - notifications
  - job_templates
  - customers
  - finishing_records
  - daily_reports
  - archived_finishing_reports
  - activity_logs
  - profiles

## Managing Backups

- Backups are stored indefinitely until manually deleted
- To delete old backups, go to Storage → backups bucket → select file → Delete
- Recommended: Keep at least 3-5 recent backups

## If Browser Download Fails

Don't worry! Even if the browser download doesn't work, your backup is safely stored in Supabase Storage and can be retrieved anytime from the dashboard.
