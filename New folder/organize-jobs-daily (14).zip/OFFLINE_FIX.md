# Fix "Offline" Status Issue

## Problem
The app shows "Offline" status because the Supabase anon key is not configured.

## Solution

### Step 1: Get Your Anon Key
1. Go to: https://app.supabase.com/project/obtmrrbajlrdnmnfhcas/settings/api
2. Find the "anon public" key (starts with `eyJ...`)
3. Copy it

### Step 2: Create .env File
1. In your project root, create a file named `.env`
2. Add this line:
```
EXPO_PUBLIC_SUPABASE_ANON_KEY=paste_your_key_here
```

### Step 3: Restart App
```bash
npx expo start --clear
```

## Verify Connection
Check the console logs:
- ✅ "Supabase connected successfully" = Working
- ❌ "Supabase connection error" = Key is wrong or missing

## Still Offline?
1. Verify .env file is in project root (same folder as package.json)
2. Check that the key has no extra spaces or quotes
3. Make sure you restarted with --clear flag
4. Check console for specific error messages
