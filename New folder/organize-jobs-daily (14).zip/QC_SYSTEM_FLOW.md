# Quality Control System - Data Flow Documentation

## Overview
The Quality Control (QC) system allows users to create, save, and retrieve quality checklists for jobs.

## Data Entry Flow

### 1. Opening QC Checklist
- Navigate to a job in Job Details
- Click the "QC" button
- QualityControlModal opens with job information pre-filled

### 2. Filling Out the Checklist
The checklist has 4 main sections:

**WORKSHOP**
- Surface Condition (multi-select: Galv, Grease, Paint, Oil, Poor, Good, Excellent)
- Drilling (Yes/No + Quantity)
- Welding Quality (Poor/Good/Excellent)
- Racking (Individual/Bundle Stock)

**ACID DEPARTMENT**
- Forward to Acid in good condition (Yes/No)
- Surface Condition (multi-select: Galv, Grease, Paint, Oil)
- Immersion Time - Degrease (minutes)
- Immersion Time - Acid (minutes)

**ZINC DEPARTMENT**
- Forward to Zinc in good condition (Yes/No)
- Surface Condition (multi-select: Galv, Grease, Paint, Oil)
- Immersion Time
- Coating Condition (Rough/Smooth)

**FINISHING & DELIVERY**
- Surface Condition (multi-select: Rough, Smooth, Black spots, Ungalvanise)
- Remedial Action (Yes/No)
  - If YES: Text field appears to explain remedial action
- Coating Thickness (microns)

### 3. Saving Data
- Click "Save to QC Archive" button
- System checks if record exists for this job_id + item_name
- If exists: Updates existing record
- If new: Creates new record with created_at timestamp
- Success message shows confirmation

## Database Storage

### Table: quality_control
**Key Fields:**
- id (UUID, primary key)
- job_id (UUID, links to jobs table)
- job_number (text, for searching)
- item_name (text)
- created_at (timestamp)
- updated_at (timestamp)
- created_by (username)
- updated_by (username)

**Data Fields:** All checklist fields as described above

### RLS Policies
- SELECT: Anyone can view (public)
- INSERT: Authorized users (public)
- UPDATE: Authorized users (public)
- DELETE: Admin only (public)

## Retrieving Data

### From Job Details
- When opening QC modal for a job, system automatically loads existing QC data
- Query: SELECT * WHERE job_id = ? AND item_name = ?
- If found: Populates form with saved data
- If not found: Shows blank form

### From QC Archive
1. Navigate to Archive modal
2. Click "QC Archive" option
3. QCArchiveModal opens (separate modal)
4. Search by job number
5. Results show all QC records matching the job number
6. Click a record to view full details

## Key Features

### Auto-Load on Open
- Opening QC modal automatically loads any existing data
- Prevents duplicate entries
- Allows editing of existing records

### Conditional Fields
- Remedial Action explanation only shows when "Yes" is selected
- Ensures data is only collected when relevant

### Search by Job Number
- QC Archive uses job_number field for searching
- No date dropdown in QC Archive (unlike other archive types)
- Direct job-based retrieval

## Troubleshooting

### Save Button Not Working
Check console logs for:
- "Save button pressed - starting save..."
- "Payload prepared: {...}"
- "Insert/Update successful: {...}"

Common issues:
- Loading state stuck (check setLoading calls)
- Database connection (check Supabase client)
- RLS policies (verify permissions)
- Missing required fields (job_id, item_name, job_number)

### Data Not Loading
- Verify job_id and item_name match exactly
- Check database for existing records
- Confirm RLS policies allow SELECT

### Search Not Finding Records
- Ensure job_number field is populated when saving
- Check search query uses ILIKE for case-insensitive matching
- Verify records exist in database
