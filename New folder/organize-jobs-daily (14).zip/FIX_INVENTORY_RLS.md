# Fix Inventory RLS Policies

Run this SQL in your Supabase SQL Editor to fix the "Save Item" button issue:

```sql
-- Enable RLS on inventory tables
ALTER TABLE inventory_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_transactions ENABLE ROW LEVEL SECURITY;

-- Drop existing policies
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON inventory_items;
DROP POLICY IF EXISTS "Allow all operations on inventory_items" ON inventory_items;
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON inventory_transactions;
DROP POLICY IF EXISTS "Allow all operations on inventory_transactions" ON inventory_transactions;

-- Create new permissive policies for authenticated users
CREATE POLICY "Enable all operations for authenticated users" ON inventory_items
  FOR ALL 
  USING (true) 
  WITH CHECK (true);

CREATE POLICY "Enable all operations for authenticated users" ON inventory_transactions
  FOR ALL 
  USING (true) 
  WITH CHECK (true);
```

This will allow authenticated users to insert, update, delete, and select from both inventory tables.
