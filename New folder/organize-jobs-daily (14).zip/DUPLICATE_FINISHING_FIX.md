# Duplicate Finishing Records - Complete Fix

## Problem
Multiple duplicate entries were appearing in WIP Statistics -> Finishing for the same jobs (e.g., job #156534, #156526, #156539).

## Root Causes
1. Multiple finishing_records with different IDs but same item_id existed in the database
2. Previous duplicate checks only looked at records for the same date
3. Display logic was deduplicating by record ID instead of item_id

## Solution Implemented

### 1. Display Fix (WipStatisticsModal.tsx)
- Changed deduplication logic to group by `item_id` instead of record `id`
- Keeps only the most recent record (by created_at timestamp) for each item
- This immediately fixes the display issue even with existing duplicates

### 2. Prevention Fix (JobContext.tsx)
Both single and batch item status updates now:
- **Delete** any existing finishing_records for the item(s) before inserting new ones
- This ensures only ONE record exists per item at any time
- Works for both forward moves (to Finishing) and backward moves (to Workshop/Acid/Galva)

## How It Works

### When Item Moves TO Finishing:
```
1. Delete ALL existing finishing_records for this item_id
2. Insert new record with today's date
Result: Only one record exists per item
```

### When Item Moves FROM Finishing (backwards):
```
1. Delete ALL finishing_records for this item_id
Result: No stale records remain
```

### When Item Moves FROM Finishing TO Ready:
```
No deletion - records are preserved for archiving
```

## Cleanup Existing Duplicates (Optional)

If you want to clean up existing duplicates in the database, run this SQL:

```sql
-- Find and delete duplicate finishing records, keeping only the most recent one per item
DELETE FROM finishing_records
WHERE id NOT IN (
  SELECT DISTINCT ON (item_id) id
  FROM finishing_records
  ORDER BY item_id, created_at DESC
);
```

## Result
- ✅ No more duplicate entries in WIP Statistics -> Finishing
- ✅ Real-time updates work correctly
- ✅ Status corrections (moving backwards) properly remove records
- ✅ Moving to Ready preserves records for archiving
