# Authentication & User Permissions Setup Guide

## Overview
This app now has a complete authentication system with role-based permissions.


### Admin
- Full access to all features
- Can create, edit, and delete jobs
- Can manage customers
- Can create and manage users
- Access to User Management screen

### Manager
- Can create and edit jobs
- Can view reports
- Can manage job assignments
- Cannot delete jobs or manage users

### Operator
- Can view and edit jobs
- Can update job status
- Can add notes to jobs
- Cannot create or delete jobs

### Data Entry Officer
- Can add new jobs (open jobs modal)
- Can view work in progress
- Can view completed jobs
- Cannot edit or delete jobs
- Cannot manage users or customers

### Viewer
- Read-only access
- Can view all jobs and customers
- Cannot make any changes


## Initial Setup

### Step 1: Create First Admin User
Run this command to create your first admin user:

```bash
curl -X POST https://obtmrrbajlrdnmnfhcas.supabase.co/functions/v1/create-admin-user \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "YourSecurePassword123!",
    "fullName": "System Administrator"
  }'
```

### Step 2: Login
1. Open the app
2. You'll be redirected to the login screen
3. Enter your User ID (username) and password
4. Click "Sign In"

### Step 3: Create Additional Users
1. Login as admin
2. Navigate to "User Management" from the home screen
3. Click "+ Add User"
4. Fill in the user details and select a role
5. Click "Create"

## Login Credentials Format
- **User ID**: The username (e.g., "admin", "john123")
- **Password**: The password you set
- **Note**: The system uses username@app.local as the email internally

## Managing Users

### Creating Users
1. Only admins can create users
2. Go to User Management screen
3. Click "+ Add User"
4. Enter username, full name (optional), password, and select role
5. Click "Create"

### Viewing Users
- All users can view their own profile
- Admins can view all users in the User Management screen
- Users are displayed with their role badge

## Security Features

### Route Protection
- All routes except login require authentication
- Users are automatically redirected to login if not authenticated
- After login, users are redirected to the home screen

### Row Level Security (RLS)
- Database tables have RLS policies enabled
- Users can only access data they have permission to view
- Admins have full access to all data

### Permission Checks
The app uses the `hasPermission()` function to check user permissions:
- `hasPermission('create')` - Can create new records
- `hasPermission('edit')` - Can edit existing records
- `hasPermission('delete')` - Can delete records
- `hasPermission('view')` - Can view records

## Logout
- Click the logout icon in the top-right corner of the home screen
- You'll be redirected to the login screen

## Troubleshooting

### Can't Login
- Verify your username and password are correct
- Make sure you created the admin user using the setup command
- Check that the Supabase connection is working

### Permission Denied
- Check your user role in the User Management screen
- Contact an admin to update your permissions
- Some features are only available to certain roles

### Can't Create Users
- Only admins can create users
- Make sure you're logged in as an admin
- Check the User Management screen is accessible

## Database Schema

### profiles table
- `id` (UUID) - Links to auth.users
- `username` (TEXT) - Unique username
- `full_name` (TEXT) - Optional full name
- `role` (TEXT) - User role (admin, manager, operator, viewer, data_entry_officer)
- `created_at` (TIMESTAMP)
- `updated_at` (TIMESTAMP)

## Next Steps
1. Create your first admin user
2. Login and test the authentication
3. Create additional users with appropriate roles
4. Test permissions for each role
5. Customize permissions as needed for your workflow
