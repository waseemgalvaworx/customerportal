# Inventory System Debugging Guide

## Overview
This guide helps diagnose and fix issues with the Stock Control system, including adding items, stock movements, and database permissions.

## Common Issues

### 1. "Add New Item" Button Does Nothing

**Symptoms:**
- Clicking "+ Add Item" button has no effect
- Modal doesn't appear

**Debugging Steps:**
1. Check browser/app console for errors
2. Verify you're on Raw/By-Prod/Direct tab (not History or Reports)
3. Look for these log messages:
   - `🔵 [ADD ITEM] Starting save process...`
   - If missing, the modal isn't opening

**Solution:**
- The button only appears on inventory tabs
- Check StockControlModal state management
- Verify AddInventoryItemModal visible prop

### 2. Database Permission Errors

**Symptoms:**
- Error: "new row violates row-level security policy"
- Error code: 42501 or similar
- Modal opens but save fails

**Debugging:**
Check console for:
```
❌ [ADD ITEM] Database error: new row violates row-level security policy
Error code: 42501
```

**Solution - Fix RLS Policies:**

```sql
-- Fix inventory_items policies
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON inventory_items;
CREATE POLICY "Enable all operations for authenticated users" ON inventory_items
  FOR ALL
  USING (true)
  WITH CHECK (true);

-- Fix inventory_transactions policies
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON inventory_transactions;
CREATE POLICY "Enable all operations for authenticated users" ON inventory_transactions
  FOR ALL
  USING (true)
  WITH CHECK (true);
```

### 3. Stock Movement Fails

**Symptoms:**
- Transaction records but quantity doesn't update
- OR transaction fails completely

**Debugging:**
Look for these console logs:
```
🔵 [STOCK MOVEMENT] Starting save process...
💾 [STOCK MOVEMENT] Step 1: Recording transaction...
✅ [STOCK MOVEMENT] Step 1 complete
💾 [STOCK MOVEMENT] Step 2: Updating item quantity...
```

**Common Errors:**
- Transaction insert fails: Check inventory_transactions RLS
- Quantity update fails: Check inventory_items RLS
- Invalid quantity: Check input validation

## Testing Procedures

### Test 1: Add New Item
1. Open Stock Control modal
2. Go to "Raw" tab
3. Click "+ Add Item"
4. Fill in: Name="Test Item", Unit="kg"
5. Click "Save Item"
6. Check console for logs
7. Verify success alert appears

### Test 2: Stock Movement
1. Click "Stock In/Out" on any item
2. Select "Stock In"
3. Enter quantity: 10
4. Click "Record Movement"
5. Check console for step-by-step logs
6. Verify quantity updated

### Test 3: Database Verification

```sql
-- Check if tables exist
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN ('inventory_items', 'inventory_transactions');

-- Check RLS is enabled
SELECT tablename, rowsecurity FROM pg_tables 
WHERE schemaname = 'public' 
AND tablename IN ('inventory_items', 'inventory_transactions');

-- Check existing policies
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
FROM pg_policies
WHERE tablename IN ('inventory_items', 'inventory_transactions');

-- Test insert permission
INSERT INTO inventory_items (item_name, category, quantity, unit)
VALUES ('Test Item', 'raw_materials', 0, 'kg');

-- Clean up test
DELETE FROM inventory_items WHERE item_name = 'Test Item';
```

## Error Messages Reference

| Error Code | Message | Solution |
|------------|---------|----------|
| 42501 | Row-level security policy violation | Fix RLS policies (see above) |
| 23505 | Unique constraint violation | Item name already exists |
| 23502 | Not null violation | Required field missing |
| 42P01 | Table does not exist | Run table creation SQL |

## Console Log Reference

### Successful Add Item Flow:
```
🔵 [ADD ITEM] Starting save process...
📝 Item Name: Test Item
📦 Category: raw_materials
📊 Unit: kg
💾 [ADD ITEM] Attempting to insert into database...
📤 [ADD ITEM] Data to insert: {...}
✅ [ADD ITEM] Item added successfully!
```

### Successful Stock Movement Flow:
```
🔵 [STOCK MOVEMENT] Starting save process...
📦 Item ID: 123
📊 Movement Type: in
🔢 Quantity: 10
💾 [STOCK MOVEMENT] Step 1: Recording transaction...
✅ [STOCK MOVEMENT] Step 1 complete: Transaction recorded
💾 [STOCK MOVEMENT] Step 2: Updating item quantity...
📊 Current quantity: 50
📊 New quantity: 60
✅ [STOCK MOVEMENT] Complete! Stock updated successfully
```

## Quick Fixes

### Reset All Inventory Permissions:
```sql
-- Run this to fix all permission issues
ALTER TABLE inventory_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON inventory_items;
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON inventory_transactions;

CREATE POLICY "Enable all operations for authenticated users" ON inventory_items
  FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Enable all operations for authenticated users" ON inventory_transactions
  FOR ALL USING (true) WITH CHECK (true);
```

### Check User Authentication:
```javascript
// In browser console
const { data: { user } } = await supabase.auth.getUser();
console.log('Current user:', user);
```

## Support

If issues persist after following this guide:
1. Check all console logs for error messages
2. Verify database schema matches expected structure
3. Ensure user is authenticated
4. Check network tab for failed requests
5. Review Supabase dashboard for policy errors
