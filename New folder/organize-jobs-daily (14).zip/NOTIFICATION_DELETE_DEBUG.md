# Notification Delete Debug Guide

## Step 1: Check Console Output

When you click the delete button, you should see these logs in order:

### From MessageDetailModal (if deleting from modal):
```
🗑️ MessageDetailModal: Delete button clicked for notification: [notification-id]
```

### From NotificationContext:
```
🗑️ Deleting notification: [notification-id]
🗑️ Delete result: { data: ..., error: ... }
```

### If there's an error:
```
❌ Delete error details: {
  code: '[error-code]',
  message: '[error-message]',
  details: '[error-details]',
  hint: '[error-hint]'
}
```

### From notifications.tsx (if deleting from list):
```
=== DELETE NOTIFICATION STARTED ===
Notification ID: [notification-id]
User: [user-object]
Supabase client: initialized
Delete confirmed, executing delete...
Delete response - data: [data]
Delete response - error: [error]
```

## Step 2: Verify RLS is Actually Disabled

Run this in Supabase SQL Editor:

```sql
-- Check if RLS is enabled
SELECT tablename, rowsecurity 
FROM pg_tables 
WHERE schemaname = 'public' 
AND tablename = 'notifications';

-- Should return: rowsecurity = false
-- If rowsecurity = true, RLS is still enabled!
```

## Step 3: Check for Policies (even if RLS is disabled)

```sql
-- List all policies on notifications table
SELECT * FROM pg_policies WHERE tablename = 'notifications';

-- Drop ALL policies
DROP POLICY IF EXISTS "Users can delete own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can view own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can update own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can insert notifications" ON notifications;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON notifications;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON notifications;
DROP POLICY IF EXISTS "Enable read for authenticated users" ON notifications;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON notifications;
```

## Step 4: Check for Foreign Key Constraints

```sql
-- Check if there are foreign key constraints preventing deletion
SELECT
    tc.constraint_name,
    tc.table_name,
    kcu.column_name,
    ccu.table_name AS foreign_table_name,
    ccu.column_name AS foreign_column_name
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage AS ccu
    ON ccu.constraint_name = tc.constraint_name
WHERE tc.table_name = 'notifications' AND tc.constraint_type = 'FOREIGN KEY';
```

## Step 5: Check for Triggers

```sql
-- Check if there are triggers preventing deletion
SELECT trigger_name, event_manipulation, action_statement
FROM information_schema.triggers
WHERE event_object_table = 'notifications';
```

## Step 6: Test Direct Delete

Try deleting directly in SQL Editor:

```sql
-- Replace with an actual notification ID from your database
DELETE FROM notifications WHERE id = 'your-notification-id-here';
```

If this fails, check the error message.

## Step 7: Complete Fix Script

Run this complete script:

```sql
-- 1. Disable RLS
ALTER TABLE notifications DISABLE ROW LEVEL SECURITY;

-- 2. Drop all possible policies
DO $$ 
DECLARE
    r RECORD;
BEGIN
    FOR r IN (SELECT policyname FROM pg_policies WHERE tablename = 'notifications') LOOP
        EXECUTE 'DROP POLICY IF EXISTS "' || r.policyname || '" ON notifications';
    END LOOP;
END $$;

-- 3. Grant full permissions
GRANT ALL ON notifications TO anon;
GRANT ALL ON notifications TO authenticated;
GRANT ALL ON notifications TO service_role;

-- 4. Verify
SELECT tablename, rowsecurity FROM pg_tables WHERE tablename = 'notifications';
SELECT COUNT(*) as policy_count FROM pg_policies WHERE tablename = 'notifications';
```

## Step 8: What to Report

Please provide:

1. **Console output** when clicking delete (copy all logs)
2. **Result of Step 2** (is rowsecurity true or false?)
3. **Result of Step 3** (how many policies exist?)
4. **Result of Step 6** (can you delete directly in SQL?)
5. **Any error messages** from the app or database

This will help identify if the issue is:
- RLS still enabled
- Policies still active
- Foreign key constraint
- Trigger blocking deletion
- App-side issue
- Permission issue
