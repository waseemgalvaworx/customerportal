# Messaging System Fix

## Issues Identified

1. **Messages not appearing in Sent Messages folder**
2. **Delete button (X) not working**

## Root Cause

The app uses **password-based authentication** (not Supabase Auth), but the RLS policies on the `notifications` table use `auth.uid()` which is always `null` since there's no Supabase Auth session. This blocks:
- SELECT queries for sent messages (sender_id check fails)
- DELETE operations (user_id check fails)

## Solution Applied

Created migration: `supabase/migrations/fix_notifications_rls_for_password_auth.sql`

This migration **disables RLS** on the notifications table since the app handles authentication at the application level.

## How to Apply the Fix

Run this SQL in your Supabase SQL Editor:

```sql
-- Drop all existing RLS policies
DROP POLICY IF EXISTS "Users can view own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can view sent notifications" ON notifications;
DROP POLICY IF EXISTS "Users can update own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can delete own notifications" ON notifications;

-- Disable RLS
ALTER TABLE notifications DISABLE ROW LEVEL SECURITY;
```

## Verification

After applying the migration:

1. **Send a message** - Should appear in Sent Messages folder
2. **Click on any message** - Should open detail modal with full content
3. **Click X button** - Should delete the notification after confirmation

## Features Already Implemented

✅ Click message to view full content in modal
✅ Delete button with confirmation dialog
✅ Sent messages tracking
✅ Message detail modal
✅ Return to notifications screen when modal closes
