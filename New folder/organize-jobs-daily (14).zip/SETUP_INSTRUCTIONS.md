# Galvanizing Job Tracker - Setup Instructions

## Prerequisites
- Node.js (v18 or higher)
- npm or yarn
- Expo CLI (`npm install -g expo-cli`)
- Supabase account
- iOS Simulator (Mac) or Android Emulator, or Expo Go app on physical device

## Important: Realtime Setup
**Before testing, you MUST enable Realtime in Supabase for instant sync across devices.**
See [REALTIME_SETUP.md](./REALTIME_SETUP.md) for detailed instructions.

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Supabase Connection

**IMPORTANT: You must configure your Supabase credentials before the app will work!**

#### Option 1: Environment Variables (Recommended)
1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```

2. Edit `.env` and add your Supabase credentials:
   ```
   EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
   EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
   ```

3. Get your credentials from: https://app.supabase.com/project/_/settings/api

#### Option 2: Direct Configuration
1. Open `app/lib/supabase.ts`
2. Replace the placeholder values with your actual Supabase credentials
3. Save the file

**Note:** Without proper Supabase credentials, the "Add Job" button will not work!


### 3. Start Development Server
```bash
npx expo start
```

### 4. Run on Device/Emulator
- Press `i` for iOS Simulator
- Press `a` for Android Emulator
- Scan QR code with Expo Go app on your phone

## Database Tables
The following tables are already created in Supabase:
- ✅ `jobs` - Job tracking and management
- ✅ `customers` - Customer information
- ✅ `profiles` - User profiles
- ✅ `job_assignments` - Job assignments
- ✅ `job_history` - Job history tracking
- ✅ `completed_jobs` - Completed jobs archive
- ✅ `notifications` - System notifications
- ✅ `job_templates` - Job templates

## Features
- 📋 Job Management (Planning, WIP, Done, Archive)
- 👥 Customer Management
- 📊 Job Status Tracking
- 📄 PDF Export
- 🔔 Notifications
- ⚙️ Settings & Customization
- 🗄️ Auto-archive functionality

## Testing the App

1. **Create a Job**: Go to Planning tab and add a new job
2. **Manage Customers**: Navigate to Customers tab to add/edit customers
3. **Track Progress**: Update job item statuses in the job details
4. **Export PDFs**: Use the export button to generate job reports
5. **Archive Jobs**: Jobs automatically archive or manually move them

## Troubleshooting

### If jobs don't load:
- Check your internet connection
- Verify Supabase is accessible
- Check console for error messages

### If app won't start:
```bash
# Clear cache and restart
npx expo start -c
```

### Database Issues:
- All database operations are logged to console
- Check Network tab in browser dev tools
- Verify RLS policies in Supabase dashboard

## Next Steps
- Add sample data through the app
- Customize settings in the Settings modal
- Test all features thoroughly
- Deploy to TestFlight/Play Store when ready
