export interface DraftItem {
  itemCount?: string;
  descriptionOfWorks: string;
  weightKg: string;
  paintVarnish?: boolean;
  galva?: boolean;
  lightGalva?: boolean;
  lightPaint?: boolean;
  rusty?: boolean;
  doubleDip?: boolean;
  multipleDip?: boolean;
}

export interface Draft {
  id: string;
  createdAt: string;
  updatedAt: string;
  jobNumber: string;
  customerName: string;
  notes: string;
  galvaXpress: boolean;
  items: DraftItem[];
}

export interface DraftPreview {
  id: string;
  jobNumber: string;
  customerName: string;
  itemCount: number;
  updatedAt: string;
}
