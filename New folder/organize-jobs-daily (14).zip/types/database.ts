/**
 * Database Type Definitions
 * Provides type safety for Supabase tables
 */

export interface Job {
  id: string;
  job_number: string;
  client_name: string;
  description?: string;
  status: JobStatus;
  priority: Priority;
  created_at: string;
  updated_at: string;
  due_date?: string;
  assigned_to?: string;
  notes?: string;
  kgs_received?: number;
  kgs_completed?: number;
}

export type JobStatus = 
  | 'pending' 
  | 'in_progress' 
  | 'quality_control' 
  | 'completed' 
  | 'archived';

export type Priority = 'low' | 'medium' | 'high' | 'urgent';

export interface Customer {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  address?: string;
  created_at: string;
  notes?: string;
}

export interface LogisticsDelivery {
  id: string;
  delivery_number: string;
  client_name: string;
  delivery_address: string;
  scheduled_date: string;
  status: DeliveryStatus;
  contact_phone?: string;
  notes?: string;
  driver_id?: string;
  vehicle_id?: string;
  created_at: string;
  updated_at: string;
}

export type DeliveryStatus = 
  | 'requested' 
  | 'scheduled' 
  | 'in_transit' 
  | 'delivered' 
  | 'cancelled';

export interface InventoryItem {
  id: string;
  name: string;
  category: string;
  quantity: number;
  unit: string;
  min_stock_level: number;
  location?: string;
  created_at: string;
  updated_at: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  created_at: string;
  is_active: boolean;
}

export type UserRole = 'admin' | 'manager' | 'operator' | 'viewer';

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: NotificationType;
  read: boolean;
  created_at: string;
  data?: Record<string, any>;
}

export type NotificationType = 
  | 'info' 
  | 'warning' 
  | 'error' 
  | 'success' 
  | 'job_update' 
  | 'delivery_update';

export interface StockRequest {
  id: string;
  item_id: string;
  quantity: number;
  status: StockRequestStatus;
  requested_by: string;
  approved_by?: string;
  created_at: string;
  notes?: string;
}

export type StockRequestStatus = 'pending' | 'approved' | 'rejected' | 'fulfilled';

export interface Driver {
  id: string;
  name: string;
  phone: string;
  license_number: string;
  is_active: boolean;
  created_at: string;
}

export interface Vehicle {
  id: string;
  registration: string;
  make: string;
  model: string;
  status: VehicleStatus;
  created_at: string;
}

export type VehicleStatus = 'available' | 'in_use' | 'maintenance' | 'retired';
