# Stock Requests System Setup Guide

## Problem
The stock-requests screen was showing a blank/white screen because the `stock_requests` table doesn't exist in the database.

## Solution
A database migration file has been created to set up the stock requests table with proper RLS policies.

## Setup Instructions

### Step 1: Run the Migration
1. Go to your Supabase project dashboard
2. Navigate to the SQL Editor
3. Open the migration file: `supabase/migrations/create_stock_requests_table.sql`
4. Copy the entire SQL content
5. Paste it into the Supabase SQL Editor
6. Click "Run" to execute the migration

### Step 2: Verify the Table
After running the migration, verify the table was created:
```sql
SELECT * FROM stock_requests LIMIT 1;
```

### Step 3: Test the Screen
1. Restart your React Native app
2. Navigate to the Stock Requests screen
3. The screen should now load properly and show either:
   - A loading indicator (while fetching data)
   - An empty state message (if no requests exist)
   - A list of stock requests (if data exists)

## Features

### Stock Request Workflow
1. **Request**: Users can request stock items with quantity and reason
2. **Approval**: Authorized users (admin, Lovena, KH) can approve or reject requests
3. **Fulfillment**: After approval, the system opens the Stock Movement modal to record the actual inventory movement
4. **Tracking**: All requests are tracked with status (pending, approved, fulfilled, rejected)

### Filtering
- View all requests
- Filter by status: pending, approved, fulfilled, rejected

### Notifications
- Users receive notifications when:
  - A new request is submitted
  - A request is approved
  - A request is fulfilled
  - A request is rejected

## Troubleshooting

### Screen Still Blank
If the screen is still blank after running the migration:
1. Check the console logs for any error messages
2. Verify the migration ran successfully in Supabase
3. Make sure RLS policies are enabled
4. Check that your user has proper authentication

### Permission Errors
If you see permission errors:
1. Verify RLS policies are set correctly
2. Make sure you're logged in as an authenticated user
3. Check the policies allow authenticated users to view/insert/update

### Missing Inventory Items
If inventory items don't show in the request modal:
1. Verify the `inventory_items` table exists
2. Check that there are items in the inventory
3. Verify RLS policies on inventory_items allow reads

## Database Schema

```sql
stock_requests (
  id UUID PRIMARY KEY,
  item_id UUID REFERENCES inventory_items(id),
  quantity_requested NUMERIC,
  reason TEXT,
  status TEXT (pending|approved|fulfilled|rejected),
  requested_by TEXT,
  approved_by TEXT,
  fulfilled_by TEXT,
  created_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ
)
```

## RLS Policies
All authenticated users can:
- View all stock requests (SELECT)
- Create new requests (INSERT)
- Update request status (UPDATE)

This allows for a collaborative workflow where anyone can request stock and authorized users can approve.
