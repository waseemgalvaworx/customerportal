# Slow Queries Analysis and Fix

## Problem Identified

The Supabase dashboard showed extremely high query counts for realtime subscriptions:
- `SELECT wal->>$5 as type...` - **11,375,350 calls** (0.01s avg)
- `select * from realtime.list_changes(...)` - **6,304,040 calls** (0.00s avg)
- Schema introspection queries taking **3+ seconds**

## Root Cause

**Excessive Realtime Subscriptions** - The app had 15+ simultaneous realtime channels with many duplicates:
- RealtimeContext subscribed to 8 tables globally
- JobContext, CustomerContext duplicated some of these
- InventoryItemsList and inventory.tsx both subscribed to inventory_items
- HourlyProductionTableV2 and HourlyProductionView both subscribed to hourly_production

## Fixes Applied

1. **RealtimeContext.tsx** - Simplified to only track connection status (removed 8 table subscriptions)
2. **app/inventory.tsx** - Removed duplicate subscription (InventoryItemsList handles it)
3. **components/InventoryItemsList.tsx** - Combined 2 channels into 1 with proper cleanup
4. **components/HourlyProductionView.tsx** - Added unique channel names with date filter
5. **components/HourlyProductionTableV2.tsx** - Added proper cleanup with supabase.removeChannel()
6. **app/stock-requests.tsx** - Combined 2 channels into 1

## Expected Results

- Reduced active realtime channels from ~15 to ~8
- Eliminated duplicate subscriptions
- Proper cleanup on component unmount
- Significantly reduced WAL query load

## Monitoring

Check Supabase Dashboard > Database > Query Performance after deployment to verify improvement.


1. **Consider Polling for Non-Critical Data**
   - Not everything needs real-time updates
   - Use polling (e.g., every 30 seconds) for less critical data

2. **Lazy Load Subscriptions**
   - Only subscribe when the component is visible
   - Unsubscribe when navigating away

3. **Use Specific Filters**
   - Filter by user_id, date, or status where possible
   - Reduces the number of events processed

4. **Monitor Subscription Count**
   - Keep total active subscriptions under 10
   - Use Supabase dashboard to monitor

## Files Modified
- `contexts/RealtimeContext.tsx` - Simplified to connection status only
- `app/inventory.tsx` - Removed duplicate subscription
- `components/InventoryItemsList.tsx` - Kept as primary inventory subscription
