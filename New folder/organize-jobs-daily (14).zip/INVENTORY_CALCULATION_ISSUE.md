# Inventory Stock Calculation Issue - Root Cause Analysis

## Problem
Stock levels showing incorrect values. Example:
- Opening balance: 100
- Out: 25 and 40 (total 65)
- **Expected balance: 35**
- **Actual showing: -30**

## Root Cause
The system maintains TWO sources of truth:
1. `inventory_items.quantity` - Current stock level (direct field)
2. `inventory_transactions` - Historical record of all movements

**The issue:** These can become DESYNCHRONIZED if:
- Transactions are recorded but quantity update fails
- Quantity is updated but transaction recording fails  
- Manual database edits bypass one system
- Race conditions during concurrent updates

## Why -30 Instead of 35?
The -65 difference (35 - (-30) = 65) suggests:
- Opening balance was correctly set to 100
- Transactions were recorded: -25, -40
- BUT the quantity field was updated from a STALE value
- Result: Old value (35) - 65 = -30

## Solution: Recalculate from Transactions
Add a "Recalculate Stock" function that:
1. Fetches ALL transactions for an item
2. Sums: opening + all 'in' - all 'out'
3. Updates `inventory_items.quantity` with correct value
4. Ensures single source of truth

## Implementation
See updated StockMovementModal with recalculation logic.
