# Finishing to Ready Status Update - Diagnostic Guide

## Issue Reported
Users experiencing issues/delays when updating items from 'Finishing' to 'Ready' status in WIP.

## Status Update Flow Analysis

### Single Item (Finishing → Ready):
1. User selects item → Opens StatusQCModal
2. Modal loads QC data from `quality_control` table (with 3s timeout)
3. User enters "Coating Thickness" (optional)
4. User clicks "Save & Update Status" or "Skip QC"
5. `updateItemStatus()` called with optimistic UI update
6. Background operations (fire-and-forget):
   - `trackHourlyProduction` → `hourly_production` table
   - `trackItemStatusChange` → `item_stage_tracking` table (optimized)
   - `completed_jobs` upsert
7. Awaited: `updateJob()` → `jobs` table update

### Multiple Items (Finishing → Ready):
- QC modal is SKIPPED
- Confirmation modal shown instead
- `updateMultipleItemStatuses()` called

---

## Recent Optimizations Applied

### 1. StatusQCModal (components/StatusQCModal.tsx)
- Added 3-second timeout for QC data loading
- Added `console.time` logging for debugging
- QC data loading no longer blocks the modal
- "Skip QC" button available for faster updates

### 2. Performance Tracker (utils/performanceTracker.ts)
- SELECT and UPSERT now run in parallel using `Promise.allSettled`
- Duration calculation is fire-and-forget
- Added timing logs (`STAGE_TRACKING_*`)

---

## Console Timing Logs

When updating status, check console for these timing logs:
- `QC_MODAL_LOAD` - Time to load QC data
- `QC_STATUS_UPDATE` - Time for status update call
- `STAGE_TRACKING_*` - Time for stage tracking operations

---

## Database Diagnostic Queries

Run these in Supabase SQL Editor:

```sql
-- 1. Check item_stage_tracking indexes
SELECT indexname, indexdef 
FROM pg_indexes 
WHERE tablename = 'item_stage_tracking';

-- 2. Check quality_control indexes
SELECT indexname, indexdef 
FROM pg_indexes 
WHERE tablename = 'quality_control';

-- 3. Check completed_jobs indexes
SELECT indexname, indexdef 
FROM pg_indexes 
WHERE tablename = 'completed_jobs';

-- 4. Check for missing unique constraints
SELECT conname, contype, conrelid::regclass
FROM pg_constraint
WHERE conrelid IN ('item_stage_tracking'::regclass, 'completed_jobs'::regclass);

-- 5. Check table sizes
SELECT relname, n_live_tup 
FROM pg_stat_user_tables 
WHERE relname IN ('item_stage_tracking', 'quality_control', 'completed_jobs', 'jobs');
```

---

## Required Migration

Run `supabase/migrations/fix_finishing_to_ready_indexes.sql` to add missing indexes:

```sql
-- item_stage_tracking unique constraint
ALTER TABLE item_stage_tracking 
ADD CONSTRAINT item_stage_tracking_job_item_unique 
UNIQUE (job_id, item_id);

-- quality_control index
CREATE INDEX IF NOT EXISTS idx_quality_control_job_item_name 
  ON quality_control(job_id, item_name);

-- completed_jobs unique constraint
ALTER TABLE completed_jobs 
ADD CONSTRAINT completed_jobs_item_id_unique 
UNIQUE (item_id);
```

---

## Quick Workaround

If users need to bypass QC check immediately:
1. Click "Skip QC" button in the QC modal
2. Or select multiple items (QC modal is skipped for bulk updates)

---

## If Issues Persist

1. Check console logs for timing information
2. Run the database diagnostic queries above
3. Apply the migration if indexes are missing
4. Check network latency to Supabase

---

## Optional: Disable Ready QC Check

If the QC check for Ready status is not needed, modify `app/wip.tsx`:

```javascript
// Line ~349-352
const requiresQC = (status: ItemStatus): boolean => {
  // Remove 'Ready' from QC-required statuses
  return ['Workshop', 'Acid', 'Finishing'].includes(status);
};
```

This will skip the QC modal entirely when moving to Ready status.
