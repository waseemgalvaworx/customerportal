# Data Integrity Safeguards

This document describes the three safeguards implemented to prevent data recording issues and ensure data accuracy.

## Overview

Three safeguards have been implemented:
1. **Database-Level Protection** - Unique constraints and validation rules
2. **Enhanced Error Logging** - Comprehensive logging of all database operations
3. **Reconciliation Checks** - Automated daily checks comparing jobs vs related tables

---

## 1. Database-Level Protection

### Unique Constraints Added

| Table | Constraint Name | Columns | Purpose |
|-------|----------------|---------|---------|
| `finishing_records` | `finishing_records_item_id_unique` | `item_id` | Prevents duplicate finishing records per item |
| `completed_jobs` | `completed_jobs_item_id_unique` | `item_id` | Prevents duplicate completed_jobs records per item |

### CHECK Constraints Added

| Table | Constraint Name | Rule | Purpose |
|-------|----------------|------|---------|
| `finishing_records` | `finishing_records_weight_check` | `weight_kg >= 0` | Validates weight is non-negative |
| `completed_jobs` | `completed_jobs_weight_check` | `weight_kg >= 0` | Validates weight is non-negative |

### NOT NULL Constraints

Critical fields now require values:
- `finishing_records`: `item_id`, `job_id`, `recorded_date`
- `completed_jobs`: `item_id`, `job_id`

### Impact
- **Zero operational impact** - these constraints prevent bad data at the database level
- Duplicate inserts will fail gracefully with the delete-before-insert pattern already in place
- Invalid data (negative weights, null IDs) will be rejected

---

## 2. Enhanced Error Logging

### New Table: `data_operation_logs`

Stores all database operations with their success/failure status.

```sql
CREATE TABLE data_operation_logs (
  id UUID PRIMARY KEY,
  operation_type VARCHAR(20),    -- INSERT, UPDATE, DELETE, UPSERT
  table_name VARCHAR(100),       -- finishing_records, completed_jobs, etc.
  record_id VARCHAR(100),
  job_id UUID,
  item_id VARCHAR(100),
  job_number VARCHAR(100),
  operation_status VARCHAR(20),  -- SUCCESS, FAILED
  error_message TEXT,
  error_code VARCHAR(50),
  operation_data JSONB,
  user_id VARCHAR(100),
  username VARCHAR(100),
  created_at TIMESTAMPTZ
);
```

### Utility Functions

Located in `utils/dataOperationLogger.ts`:

| Function | Purpose |
|----------|---------|
| `logSuccess()` | Log a successful operation |
| `logFailure()` | Log a failed operation with error details |
| `loggedInsert()` | Wrapper for inserts with automatic logging |
| `loggedUpsert()` | Wrapper for upserts with automatic logging |
| `loggedDelete()` | Wrapper for deletes with automatic logging |
| `getRecentOperationLogs()` | Retrieve recent logs for debugging |
| `getFailedOperationsSummary()` | Get summary of failed operations |

### Usage in JobContext

The `updateItemStatus` function now logs all `finishing_records` and `completed_jobs` operations:

```typescript
// Example: Logging a finishing_records insert
supabase.from('finishing_records').insert(finishingData)
  .then(({ error }) => {
    if (error) {
      logFailure('INSERT', 'finishing_records', error, { jobId, itemId, jobNumber });
    } else {
      logSuccess('INSERT', 'finishing_records', { jobId, itemId, jobNumber });
    }
  });
```

### Viewing Logs

Query recent failed operations:
```sql
SELECT * FROM data_operation_logs 
WHERE operation_status = 'FAILED' 
AND created_at > NOW() - INTERVAL '24 hours'
ORDER BY created_at DESC;
```

---

## 3. Reconciliation Checks

### New Table: `reconciliation_reports`

Stores results of reconciliation checks.

```sql
CREATE TABLE reconciliation_reports (
  id UUID PRIMARY KEY,
  report_date DATE,
  report_type VARCHAR(50),           -- DAILY, MANUAL
  total_jobs_checked INT,
  total_items_checked INT,
  finishing_mismatches INT,
  completed_mismatches INT,
  missing_finishing_records JSONB,   -- Items in Finishing status without records
  orphan_finishing_records JSONB,    -- Records without matching item status
  missing_completed_records JSONB,   -- Items in Ready status without records
  orphan_completed_records JSONB,    -- Records without matching item status
  status VARCHAR(20),                -- PENDING, COMPLETED, FAILED
  run_by VARCHAR(100),
  created_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ
);
```

### Utility Functions

Located in `utils/dataReconciliation.ts`:

| Function | Purpose |
|----------|---------|
| `runReconciliation()` | Run a full reconciliation check |
| `autoFixMissingRecords()` | Auto-create missing records from job data |
| `cleanupOrphanRecords()` | Remove orphan records |
| `getRecentReports()` | Get recent reconciliation reports |
| `getReportById()` | Get specific report details |
| `hasRunToday()` | Check if reconciliation ran today |
| `scheduleDailyReconciliation()` | Schedule automatic daily checks |

### Automatic Scheduling

The reconciliation system runs automatically:
- **On app startup**: Runs immediately if not run today
- **Every 6 hours**: Checks if reconciliation is needed
- **Notifications**: Sends alerts if mismatches are found

### What Gets Checked

1. **Missing Finishing Records**
   - Items with status `Finishing` but no record in `finishing_records`
   
2. **Orphan Finishing Records**
   - Records in `finishing_records` where item is no longer in `Finishing` status

3. **Missing Completed Records**
   - Items with status `Ready` but no record in `completed_jobs`

4. **Orphan Completed Records**
   - Records in `completed_jobs` where item is no longer in `Ready` status

### Manual Reconciliation

Run manually from code:
```typescript
import { runReconciliation } from '@/utils/dataReconciliation';

const result = await runReconciliation('admin_username');
console.log(`Found ${result.finishingMismatches} finishing mismatches`);
console.log(`Found ${result.completedMismatches} completed mismatches`);
```

### Auto-Fix Mismatches

Fix missing records automatically:
```typescript
import { autoFixMissingRecords, cleanupOrphanRecords } from '@/utils/dataReconciliation';

// Fix missing records
const fixResult = await autoFixMissingRecords(
  result.missingFinishingRecords,
  result.missingCompletedRecords
);

// Clean up orphans
const cleanResult = await cleanupOrphanRecords(
  result.orphanFinishingRecords,
  result.orphanCompletedRecords
);
```

---

## Monitoring & Alerts

### Notification System

When reconciliation finds mismatches:
- **Normal priority**: < 10 mismatches
- **Urgent priority**: >= 10 mismatches

Notifications are sent to all users via the existing notification system.

### Recommended Monitoring Queries

**Check for recent failures:**
```sql
SELECT table_name, COUNT(*) as failures
FROM data_operation_logs
WHERE operation_status = 'FAILED'
AND created_at > NOW() - INTERVAL '24 hours'
GROUP BY table_name;
```

**Check reconciliation history:**
```sql
SELECT report_date, finishing_mismatches, completed_mismatches, status
FROM reconciliation_reports
ORDER BY created_at DESC
LIMIT 10;
```

**View mismatch details:**
```sql
SELECT 
  report_date,
  jsonb_array_length(missing_finishing_records) as missing_finishing,
  jsonb_array_length(orphan_finishing_records) as orphan_finishing,
  jsonb_array_length(missing_completed_records) as missing_completed,
  jsonb_array_length(orphan_completed_records) as orphan_completed
FROM reconciliation_reports
WHERE status = 'COMPLETED'
ORDER BY created_at DESC;
```

---

## Summary

| Safeguard | Impact | Frequency |
|-----------|--------|-----------|
| Database Constraints | None - prevents bad data | Always active |
| Enhanced Logging | None - adds visibility | Every operation |
| Reconciliation Checks | None - runs in background | Every 6 hours |

These safeguards work together to:
1. **Prevent** duplicate/invalid data at the database level
2. **Track** all operations for debugging
3. **Detect** and **alert** on any mismatches that slip through
