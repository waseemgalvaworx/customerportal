# Stock Movement Debugging Guide

## Issue Fixed: Record Movement Button Not Working

### Root Causes Identified and Fixed:
1. **Database Column Mismatch**: Modal was using `reference_number` but database has `reference_id`
2. **Missing Validation**: No check for insufficient stock on "Stock Out"
3. **Insufficient Logging**: Hard to diagnose where failures occurred

### Changes Made:

#### 1. Fixed Database Column Names
```typescript
// OLD (WRONG):
reference_number: reference || null

// NEW (CORRECT):
reference_id: reference || null,
reference_type: reference ? 'manual' : null
```

#### 2. Added Stock Validation
```typescript
if (movementType === 'out' && qtyNum > item.quantity) {
  Alert.alert('Error', `Insufficient stock. Available: ${item.quantity} ${item.unit}`);
  return;
}
```

#### 3. Enhanced Logging
Every step now logs:
- Button press detection
- Validation checks
- Database operations
- Success/failure states

### Testing the Fix:

#### Test 1: Stock In
1. Open Stock Control
2. Select any item → "Stock In/Out"
3. Select "Stock In"
4. Enter quantity: 100
5. Click "Record Movement"
6. **Expected**: Success alert, stock increases by 100

#### Test 2: Stock Out
1. Open Stock Control
2. Select any item → "Stock In/Out"
3. Select "Stock Out"
4. Enter quantity: 50
5. Click "Record Movement"
6. **Expected**: Success alert, stock decreases by 50

#### Test 3: Insufficient Stock
1. Select "Stock Out"
2. Enter quantity greater than current stock
3. Click "Record Movement"
4. **Expected**: Error alert about insufficient stock

### Console Log Examples:

#### Successful Stock In:
```
═══════════════════════════════════════════
🔵 [STOCK MOVEMENT] BUTTON PRESSED - Starting save process...
📦 Item: Raw Material A (ID: uuid-here)
📊 Movement Type: in
🔢 Quantity Input: 100
═══════════════════════════════════════════
💾 [STEP 1/3] Recording transaction...
✅ [STEP 1 COMPLETE] Transaction recorded
💾 [STEP 2/3] Updating item quantity...
📊 Current quantity: 500
📊 Change: + 100
📊 New quantity: 600
✅ [STEP 2 COMPLETE] Item updated
🎉 [SUCCESS] Stock movement completed successfully!
```

#### Failed Transaction (Permission Error):
```
❌ [STEP 1 FAILED] Transaction error: {...}
Error details: {
  "code": "42501",
  "message": "permission denied for table inventory_transactions"
}
```

### Database Verification:

#### Check Transaction Was Recorded:
```sql
SELECT * FROM inventory_transactions 
WHERE item_id = 'your-item-id'
ORDER BY created_at DESC 
LIMIT 5;
```

#### Check Item Quantity Updated:
```sql
SELECT item_name, quantity, updated_at 
FROM inventory_items 
WHERE id = 'your-item-id';
```

#### Verify RLS Policies:
```sql
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual 
FROM pg_policies 
WHERE tablename IN ('inventory_items', 'inventory_transactions');
```

### Common Issues and Solutions:

#### Issue: Button doesn't respond
**Solution**: Check console for "🔴 RECORD MOVEMENT BUTTON PRESSED!" message
- If you see it: Database/validation issue
- If you don't see it: UI/modal issue

#### Issue: "Permission denied" error
**Solution**: Run RLS policy fixes:
```sql
-- Allow all operations on inventory_items
DROP POLICY IF EXISTS "Allow all operations on inventory_items" ON inventory_items;
CREATE POLICY "Allow all operations on inventory_items" ON inventory_items FOR ALL USING (true) WITH CHECK (true);

-- Allow all operations on inventory_transactions
DROP POLICY IF EXISTS "Allow all operations on inventory_transactions" ON inventory_transactions;
CREATE POLICY "Allow all operations on inventory_transactions" ON inventory_transactions FOR ALL USING (true) WITH CHECK (true);
```

#### Issue: Stock not updating
**Solution**: Check if transaction was recorded but update failed
```sql
-- Check last transaction
SELECT * FROM inventory_transactions ORDER BY created_at DESC LIMIT 1;

-- Manually fix if needed
UPDATE inventory_items 
SET quantity = quantity + 100  -- or - 100 for stock out
WHERE id = 'item-id';
```

### Key Features Now Working:

✅ Stock In - Adds to quantity
✅ Stock Out - Removes from quantity  
✅ Validation - Prevents negative stock
✅ Transaction History - Records all movements
✅ Reference Numbers - Optional tracking
✅ Notes - Additional context
✅ Real-time Updates - UI refreshes immediately
✅ Comprehensive Logging - Easy debugging

### Next Steps if Still Not Working:

1. Check console logs for specific error
2. Verify database permissions (see SQL above)
3. Check item exists and has valid quantity
4. Verify modal is actually opening (check for "🟢 [STOCK MODAL] Modal opened")
5. Test with simple values first (no decimals, no special characters)
