# Unarchive Jobs Troubleshooting Guide

## Overview
This guide helps diagnose and fix issues with the "Unarchive Report" functionality in the Archive screen.

## How It Works

### Flow
1. User clicks "Unarchive Report" button in Archive screen
2. Password prompt appears (password: 4321)
3. User confirms unarchive action
4. System processes each job:
   - Fetches job from database
   - Checks for completed_jobs entries
   - Deletes completed_jobs entries for all items
   - Updates job status to 'planning'
   - Updates local state
   - Creates audit log

### Database Operations
```sql
-- 1. Fetch job
SELECT * FROM jobs WHERE id = 'job-id';

-- 2. Check completed_jobs
SELECT * FROM completed_jobs WHERE item_id IN ('item-id-1', 'item-id-2', ...);

-- 3. Delete completed_jobs
DELETE FROM completed_jobs WHERE item_id IN ('item-id-1', 'item-id-2', ...);

-- 4. Update job status
UPDATE jobs 
SET status = 'planning', archivedDate = NULL, completedDate = NULL 
WHERE id = 'job-id';
```

## Debugging Steps

### 1. Check Console Logs
The restoreJob function now has comprehensive logging. Look for:

```
========================================
🔄 RESTORE JOB FUNCTION STARTED
========================================
📋 Job ID to restore: [job-id]
📊 Current jobs in state: [count]

--- STEP 1: FETCHING JOB FROM DATABASE ---
✅ Job found in database:
   - Job Number: [number]
   - Current Status: [status]
   - Customer: [name]
   - Items Count: [count]

--- STEP 2: CHECKING COMPLETED_JOBS ENTRIES ---
📝 Item IDs from job: [array]
✅ Found [count] completed_jobs entries

--- STEP 3: DELETING COMPLETED_JOBS ENTRIES ---
✅ Deleted [count] completed_jobs entries

--- STEP 4: UPDATING JOB STATUS ---
✅ Job status updated successfully
   New status: planning

--- STEP 5: UPDATING LOCAL STATE ---
✅ Local state updated
   Jobs with status=planning: [count]
   Jobs with status=archived: [count]

--- STEP 6: CREATING AUDIT LOG ---
✅ Audit log created

========================================
✅ RESTORE JOB COMPLETED SUCCESSFULLY
========================================
```

### 2. Check for Errors
If you see error messages, they will be detailed:

```
❌ Database fetch error: [message]
❌ Error checking completed_jobs: [message]
❌ Delete error: [message]
   Error code: [code]
   Error message: [message]
   Error details: [details]
❌ Update error: [message]
```

## Common Issues and Solutions

### Issue 1: Permission Denied
**Symptoms:** Error message contains "permission denied" or "RLS policy"

**Solution:** Run these SQL commands:
```sql
-- Fix RLS policies
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON jobs;
CREATE POLICY "Enable all operations for authenticated users" ON jobs 
FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON completed_jobs;
CREATE POLICY "Enable all operations for authenticated users" ON completed_jobs 
FOR ALL USING (true) WITH CHECK (true);
```

### Issue 2: Job Not Found
**Symptoms:** "Job not found in database" error

**Solution:**
- Verify the job exists: `SELECT * FROM jobs WHERE id = 'job-id';`
- Check if job was deleted
- Verify the correct job ID is being passed

### Issue 3: Completed Jobs Not Deleted
**Symptoms:** Deletion succeeds but count is 0

**Possible Causes:**
- Items might not have been in completed_jobs table
- Items might have already been deleted
- Check if items were actually marked as "Ready" before archiving

**Verification:**
```sql
-- Check if completed_jobs entries exist
SELECT * FROM completed_jobs WHERE job_id = 'job-id';

-- Check item statuses in job
SELECT id, items FROM jobs WHERE id = 'job-id';
```

### Issue 4: Local State Not Updating
**Symptoms:** Job still shows in archive after unarchive

**Solution:**
- Check if onBack() is being called in ArchiveModalMain
- Verify the archive screen is refreshing after unarchive
- Check console for "Local state updated" message

### Issue 5: Realtime Not Working
**Symptoms:** Need to manually refresh to see changes

**Solution:**
- Check realtime subscription in JobContext
- Verify Supabase realtime is enabled for jobs table
- Check browser/app console for realtime connection errors

## Testing Procedure

1. **Archive a job first:**
   - Complete all items in a job (move to Ready)
   - Job should auto-move to Done
   - Archive the job from Done screen

2. **Verify archive:**
   - Go to Archive screen
   - Select "Completed Jobs Report"
   - Find the archived job in the list

3. **Unarchive the job:**
   - Click "Unarchive Report"
   - Enter password: 4321
   - Confirm unarchive
   - Watch console for detailed logs

4. **Verify restoration:**
   - Check WIP screen - job should appear there
   - Job status should be "planning"
   - Items should retain their statuses
   - Check completed_jobs table is empty for those items

## SQL Verification Queries

```sql
-- Check job status
SELECT id, jobNumber, status, archivedDate, completedDate 
FROM jobs 
WHERE jobNumber = 'YOUR-JOB-NUMBER';

-- Check completed_jobs entries
SELECT * FROM completed_jobs 
WHERE job_number = 'YOUR-JOB-NUMBER';

-- Check audit logs
SELECT * FROM activity_logs 
WHERE entity_id = 'YOUR-JOB-ID' 
ORDER BY created_at DESC 
LIMIT 5;

-- Check all archived jobs
SELECT id, jobNumber, customerName, status, archivedDate 
FROM jobs 
WHERE status = 'archived' 
ORDER BY archivedDate DESC;
```

## Database Schema Reference

### jobs table
- id (uuid, primary key)
- jobNumber (text)
- status (text) - 'pending' | 'planning' | 'done' | 'archived'
- items (jsonb) - array of items with id and status
- archivedDate (timestamp)
- completedDate (timestamp)

### completed_jobs table
- id (uuid, primary key)
- job_id (uuid, foreign key)
- item_id (text)
- job_number (text)
- completed_at (timestamp)

## Need More Help?

If the issue persists:
1. Copy all console logs from the restore attempt
2. Run the verification queries above
3. Check the specific error messages
4. Verify RLS policies are correct
5. Check if Supabase connection is working
