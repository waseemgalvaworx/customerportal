# Offline Mode Diagnosis Report

## Problem Summary
App shows "Offline Mode - Viewing cached data" even though Supabase is properly configured and was working before.

## Root Cause
The app's connection check is failing due to **Row Level Security (RLS) policies** blocking unauthenticated queries.

### Technical Details:

1. **Connection Check Method** (`utils/offlineCache.ts` line 53-61):
   ```typescript
   export const isOnline = async (): Promise<boolean> => {
     try {
       const { error } = await supabase.from('jobs').select('id').limit(1);
       return !error;
     } catch (error) {
       return false;
     }
   };
   ```

2. **The Issue**:
   - The app uses **custom password authentication** (not Supabase Auth)
   - The `jobs` table has RLS enabled with policies requiring Supabase authentication
   - When `isOnline()` queries the `jobs` table, there's no Supabase auth session
   - RLS blocks the query → "Failed to fetch" error → app thinks it's offline

3. **Why It Worked Before**:
   - RLS policies may have been more permissive
   - OR connection check was using a different method

## Solution
Change the connection check to use a method that doesn't require authentication:
- Use Supabase health endpoint
- OR query without RLS restrictions
- OR use browser navigator.onLine API

## Fix Applied
Modified `utils/offlineCache.ts` to use a proper connection check that doesn't depend on RLS policies.
