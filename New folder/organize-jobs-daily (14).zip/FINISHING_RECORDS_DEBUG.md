# Finishing Records Not Updating - Diagnostic Guide

## Problem
The "Finishing" figures in WIP Statistics are not updating when items are moved to "Finishing" status.

## Root Cause Analysis

The issue is likely one of the following:

### 1. RLS Policy Issue (Most Likely)
The current RLS policy may not properly allow INSERT operations:

```sql
-- Current policy (may be incomplete)
CREATE POLICY "Allow all for authenticated users" ON finishing_records
  FOR ALL USING (true);
```

**Problem**: `FOR ALL USING (true)` doesn't include `WITH CHECK (true)` which is required for INSERT.

### 2. Unique Constraint Violation
If a `unique_item_per_day` constraint exists, race conditions between delete and insert could cause failures.

---

## Fix: Run in Supabase SQL Editor

### Step 1: Check Current Policies
```sql
SELECT policyname, cmd, qual, with_check 
FROM pg_policies 
WHERE tablename = 'finishing_records';
```

### Step 2: Drop and Recreate Policies
```sql
-- Drop existing policies
DROP POLICY IF EXISTS "Allow all for authenticated users" ON finishing_records;
DROP POLICY IF EXISTS "Allow all select" ON finishing_records;
DROP POLICY IF EXISTS "Allow all insert" ON finishing_records;
DROP POLICY IF EXISTS "Allow all update" ON finishing_records;
DROP POLICY IF EXISTS "Allow all delete" ON finishing_records;

-- Create proper permissive policies
CREATE POLICY "finishing_select" ON finishing_records FOR SELECT USING (true);
CREATE POLICY "finishing_insert" ON finishing_records FOR INSERT WITH CHECK (true);
CREATE POLICY "finishing_update" ON finishing_records FOR UPDATE USING (true);
CREATE POLICY "finishing_delete" ON finishing_records FOR DELETE USING (true);
```

### Step 3: Check for Unique Constraint Issues
```sql
-- Check if unique constraint exists
SELECT conname, contype 
FROM pg_constraint 
WHERE conrelid = 'finishing_records'::regclass;

-- If unique_item_per_day exists and causing issues, remove it:
-- ALTER TABLE finishing_records DROP CONSTRAINT IF EXISTS unique_item_per_day;
```

### Step 4: Verify RLS is Enabled
```sql
SELECT relname, relrowsecurity 
FROM pg_class 
WHERE relname = 'finishing_records';
```

### Step 5: Test Insert Manually
```sql
-- Test insert (use a real job_id from your jobs table)
INSERT INTO finishing_records (job_id, item_id, job_number, customer_name, item_description, weight_kg, recorded_date)
VALUES (
  '00000000-0000-0000-0000-000000000000', -- Replace with real job_id
  gen_random_uuid(),
  'TEST123',
  'Test Customer',
  'Test Item',
  '100',
  CURRENT_DATE
);

-- Check if it was inserted
SELECT * FROM finishing_records WHERE job_number = 'TEST123';

-- Clean up test
DELETE FROM finishing_records WHERE job_number = 'TEST123';
```

---

## Quick Fix SQL (Copy and Run)

```sql
-- Complete fix for finishing_records RLS policies
BEGIN;

-- Drop all existing policies
DROP POLICY IF EXISTS "Allow all for authenticated users" ON finishing_records;
DROP POLICY IF EXISTS "Allow all select" ON finishing_records;
DROP POLICY IF EXISTS "Allow all insert" ON finishing_records;
DROP POLICY IF EXISTS "Allow all update" ON finishing_records;
DROP POLICY IF EXISTS "Allow all delete" ON finishing_records;
DROP POLICY IF EXISTS "finishing_select" ON finishing_records;
DROP POLICY IF EXISTS "finishing_insert" ON finishing_records;
DROP POLICY IF EXISTS "finishing_update" ON finishing_records;
DROP POLICY IF EXISTS "finishing_delete" ON finishing_records;

-- Ensure RLS is enabled
ALTER TABLE finishing_records ENABLE ROW LEVEL SECURITY;

-- Create new permissive policies
CREATE POLICY "finishing_select" ON finishing_records FOR SELECT USING (true);
CREATE POLICY "finishing_insert" ON finishing_records FOR INSERT WITH CHECK (true);
CREATE POLICY "finishing_update" ON finishing_records FOR UPDATE USING (true);
CREATE POLICY "finishing_delete" ON finishing_records FOR DELETE USING (true);

COMMIT;
```

---

## After Running the Fix

1. Refresh the app
2. Move an item to "Finishing" status
3. Open Statistics → WIP Statistics
4. Check if the Finishing count updates
