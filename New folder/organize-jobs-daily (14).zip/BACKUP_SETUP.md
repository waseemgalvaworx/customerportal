# Setting Up Automatic Backups in Supabase

## Overview
Supabase provides automatic daily backups for Pro, Team, and Enterprise plans. Free tier does not include automatic backups.

## Steps to Enable Automatic Backups

### 1. Access Your Supabase Dashboard
- Go to https://supabase.com/dashboard
- Log in to your account
- Select your project

### 2. Navigate to Database Settings
- Click on **"Database"** in the left sidebar
- Select **"Backups"** tab

### 3. Configure Backup Schedule
- **Pro Plan**: Daily backups with 7-day retention (automatic)
- **Team Plan**: Daily backups with 14-day retention
- **Enterprise Plan**: Customizable schedule with 30+ day retention

### 4. Backup Options
The automatic backups include:
- Full database snapshots
- Point-in-time recovery (PITR) for higher plans
- Automatic retention management

### 5. Manual Backups (Alternative)
If you're on the Free tier, you can create manual backups:

```bash
# Install Supabase CLI
npm install -g supabase

# Login
supabase login

# Link your project
supabase link --project-ref YOUR_PROJECT_REF

# Create manual backup
supabase db dump -f backup.sql
```

## Restoration Process
To restore from a backup:
1. Go to Database > Backups
2. Find the backup you want to restore
3. Click "Restore" button
4. Confirm the restoration

## Best Practices
- Enable automatic backups on production databases
- Test restoration process periodically
- Keep local backups for critical data
- Document your backup schedule

## Cost
- Free tier: No automatic backups
- Pro plan ($25/month): Includes daily backups
- Additional backup storage may incur costs

## Support
For backup issues, contact Supabase support or check:
https://supabase.com/docs/guides/platform/backups
