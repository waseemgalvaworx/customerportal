# Fix Unarchive Jobs Functionality

## Problem
The "Unarchive Report" button in the completed jobs archive is not working properly. Jobs are not being restored to WIP status.

## Root Cause
This could be due to:
1. Row Level Security (RLS) policies blocking UPDATE operations on archived jobs
2. Missing permissions for the completed_jobs table DELETE operations
3. Database connection issues

## Solution

### Step 1: Check RLS Policies on Jobs Table

Run this SQL in Supabase SQL Editor to ensure UPDATE operations are allowed:

```sql
-- Check existing policies on jobs table
SELECT * FROM pg_policies WHERE tablename = 'jobs';

-- Drop restrictive policies if they exist
DROP POLICY IF EXISTS "Users can update their own jobs" ON public.jobs;
DROP POLICY IF EXISTS "Enable update for authenticated users only" ON public.jobs;

-- Create permissive policy for all operations
CREATE POLICY "Allow all operations on jobs" 
ON public.jobs 
FOR ALL 
USING (true) 
WITH CHECK (true);
```

### Step 2: Ensure completed_jobs Table Has Proper Permissions

```sql
-- Check if completed_jobs table exists
SELECT * FROM information_schema.tables WHERE table_name = 'completed_jobs';

-- If it exists, ensure RLS allows DELETE operations
DROP POLICY IF EXISTS "Allow all operations" ON public.completed_jobs;

CREATE POLICY "Allow all operations on completed_jobs" 
ON public.completed_jobs 
FOR ALL 
USING (true) 
WITH CHECK (true);
```

### Step 3: Verify Jobs Table Structure

Ensure the jobs table has the required columns:

```sql
-- Check jobs table structure
SELECT column_name, data_type, is_nullable 
FROM information_schema.columns 
WHERE table_name = 'jobs';

-- Required columns:
-- - id (uuid, primary key)
-- - status (text)
-- - archivedDate (timestamp with time zone, nullable)
-- - completedDate (timestamp with time zone, nullable)
```

## Testing the Fix

1. After running the SQL commands above, test the unarchive function:
   - Go to Archive screen
   - Select "Completed Jobs Report"
   - Choose a date with archived jobs
   - Click "Unarchive Report"
   - Enter password: 4321
   - Confirm the unarchive action

2. Check the console logs for detailed debugging information:
   - Look for "=== STARTING UNARCHIVE PROCESS ===" 
   - Check for any error messages
   - Verify "✅ Successfully restored job" messages

3. Verify the jobs appear in the WIP (Planning) screen

## Alternative: Disable RLS Temporarily for Testing

If you need to quickly test without RLS:

```sql
-- CAUTION: Only use this for testing!
ALTER TABLE public.jobs DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.completed_jobs DISABLE ROW LEVEL SECURITY;
```

Remember to re-enable RLS after testing:

```sql
ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.completed_jobs ENABLE ROW LEVEL SECURITY;
```

## Debugging Checklist

- [ ] Check browser console for error messages
- [ ] Verify Supabase connection in app
- [ ] Confirm jobs table has archived jobs with status='archived'
- [ ] Check that completed_jobs table exists
- [ ] Verify RLS policies allow UPDATE on jobs table
- [ ] Verify RLS policies allow DELETE on completed_jobs table
- [ ] Test with a single archived job first
- [ ] Check audit_logs table for any logged actions

## Expected Behavior

When unarchiving works correctly:
1. User clicks "Unarchive Report" button
2. Password prompt appears (password: 4321)
3. Confirmation dialog shows number of jobs to unarchive
4. Console logs show each job being processed
5. Success message displays: "X job(s) unarchived and moved to WIP"
6. Jobs appear in the WIP (Planning) screen
7. Jobs are removed from Archive screen
8. completed_jobs entries are deleted for those job items
