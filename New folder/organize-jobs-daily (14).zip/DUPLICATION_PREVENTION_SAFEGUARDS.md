# Duplication Prevention Safeguards

This document outlines all the safety nets implemented to prevent duplicate records across the platform, particularly for `finishing_records` and related tables.

## Overview

Duplication can occur when:
1. The same item is recorded multiple times in `finishing_records`
2. Data is combined from `finishing_records` and `archived_finishing_reports` without deduplication
3. Records are unarchived when they already exist in the active table
4. Concurrent operations create race conditions

## Safety Nets Implemented

### 1. Database-Level Protection

**Unique Constraint on `finishing_records.item_id`**
```sql
-- Migration: add_unique_constraint_finishing_records.sql
ALTER TABLE finishing_records 
ADD CONSTRAINT finishing_records_item_id_unique UNIQUE (item_id);
```

This ensures:
- Only ONE active finishing record per item at any time
- Database rejects duplicate inserts with error code `23505`
- Automatic cleanup of existing duplicates during migration

**Similar constraint on `completed_jobs.item_id`**
```sql
-- Already exists
CONSTRAINT completed_jobs_item_id_unique UNIQUE (item_id)
```

### 2. Application-Level Deduplication

**a. WipStatisticsModal.tsx - fetchFinishingRecords()**
```typescript
// Deduplicates by item_id, keeping the most recent record
const uniqueRecords = Array.from(
  data.reduce((map, item) => {
    const existing = map.get(item.item_id);
    if (!existing || new Date(item.created_at || 0) > new Date(existing.created_at || 0)) {
      map.set(item.item_id, item);
    }
    return map;
  }, new Map()).values()
);
```

**b. DailyFinishingKgsView.tsx**
```typescript
// Combines active + archived records with deduplication
// Active records take priority over archived
const deduplicatedRecords = Array.from(
  allRecords.reduce((map, record) => {
    const existing = map.get(record.item_id);
    if (!existing) {
      map.set(record.item_id, record);
    } else if (!existing.isArchived && record.isArchived) {
      // Keep active record over archived
    } else if (existing.isArchived && !record.isArchived) {
      map.set(record.item_id, record);
    }
    return map;
  }, new Map()).values()
);
```

**c. MetricsComparisonView.tsx**
- Same deduplication pattern as DailyFinishingKgsView

**d. app/statistics.tsx - fetchFinishingRecords()**
- Same Map-based deduplication pattern

### 3. Archive Process Protection

**WipStatisticsModal.tsx - handleArchivePasswordSubmit()**
```typescript
// Before archiving, check for already-archived item_ids
const archivedItemIds = new Set<string>();
existingReports.forEach(report => {
  report.records?.forEach((record: any) => {
    if (record.item_id) {
      archivedItemIds.add(record.item_id);
    }
  });
});

// Filter out already-archived records
const newRecordsToArchive = finishingRecords.filter(
  record => !archivedItemIds.has(record.item_id)
);
```

### 4. Unarchive Process Protection

**UnarchiveFinishingModal.tsx - handleUnarchive()**
```typescript
// Check for existing records before restoring
const { data: existingRecords } = await supabase
  .from('finishing_records')
  .select('item_id')
  .in('item_id', itemIdsToRestore);

// Filter out duplicates
const existingItemIds = new Set(existingRecords?.map(r => r.item_id) || []);
const filteredRecords = recordsToRestore.filter(
  (r: any) => !existingItemIds.has(r.item_id)
);
```

### 5. Insert Pattern Protection

**JobContext.tsx - updateItemStatus()**
```typescript
// Delete-then-insert pattern prevents duplicates
supabase.from('finishing_records').delete().eq('item_id', itemId)
  .then(() => {
    supabase.from('finishing_records').insert(finishingData)
  });
```

### 6. Reconciliation System

**utils/dataReconciliation.ts**
- Runs every 6 hours automatically
- Detects orphan records and duplicates
- Uses `upsert` for safe record creation
- Can auto-fix detected issues

## Components Protected

| Component | Protection Type |
|-----------|-----------------|
| WipStatisticsModal | Fetch dedup + Archive check |
| DailyFinishingKgsView | Fetch dedup (active + archived) |
| MetricsComparisonView | Fetch dedup (active + archived) |
| statistics.tsx | Fetch dedup |
| UnarchiveFinishingModal | Pre-insert check |
| JobContext | Delete-before-insert |
| dataReconciliation | Upsert + orphan detection |

## Database Tables with Unique Constraints

| Table | Constraint | Column |
|-------|------------|--------|
| finishing_records | finishing_records_item_id_unique | item_id |
| completed_jobs | completed_jobs_item_id_unique | item_id |

## Error Handling

When a duplicate is attempted:
1. **Database level**: Returns error code `23505` (unique_violation)
2. **Application level**: Gracefully handles and shows user-friendly message
3. **Logging**: Errors are logged for debugging

## Testing Duplication Prevention

To verify the safeguards work:

```sql
-- Try to insert duplicate (should fail)
INSERT INTO finishing_records (item_id, job_number, customer_name, weight_kg, recorded_date)
VALUES ('existing-item-id', 'TEST', 'Test', '100', CURRENT_DATE);
-- Expected: ERROR: duplicate key value violates unique constraint

-- Check for any existing duplicates
SELECT item_id, COUNT(*) as count 
FROM finishing_records 
GROUP BY item_id 
HAVING COUNT(*) > 1;
-- Expected: No results (0 rows)
```

## Maintenance

1. **Run reconciliation manually** if issues suspected:
   ```typescript
   import { runReconciliation } from '../utils/dataReconciliation';
   await runReconciliation();
   ```

2. **Check for duplicates** periodically:
   ```sql
   SELECT item_id, COUNT(*) FROM finishing_records GROUP BY item_id HAVING COUNT(*) > 1;
   SELECT item_id, COUNT(*) FROM completed_jobs GROUP BY item_id HAVING COUNT(*) > 1;
   ```

3. **Review logs** for any `23505` errors indicating attempted duplicates

## Summary

The platform now has **multi-layered protection** against duplication:
- ✅ Database unique constraints (hard stop)
- ✅ Application-level deduplication on fetch
- ✅ Pre-insert checks on archive/unarchive
- ✅ Delete-before-insert patterns
- ✅ Periodic reconciliation
- ✅ Graceful error handling

This ensures data integrity across all operations involving finishing records and completed jobs.
