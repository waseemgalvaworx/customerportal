# Logistics System Setup Guide

## Database Setup

### Required Tables

The logistics system requires the following tables to be created in Supabase:

1. **logistics_deliveries** - Main delivery tracking table
2. **vehicles** - Vehicle management
3. **drivers** - Driver management

### Migration Steps

Run the following SQL migrations in your Supabase SQL Editor in this order:

#### 1. Create logistics_deliveries table
```sql
-- Run: supabase/migrations/create_logistics_deliveries_table.sql
```

#### 2. Create vehicles and drivers tables
```sql
-- Run: supabase/migrations/create_logistics_tables.sql
```

### Verify Setup

After running migrations, verify:
1. Tables exist in Supabase dashboard
2. RLS policies are enabled
3. Test insert/select operations work

### Troubleshooting

**Issue: "relation logistics_deliveries does not exist"**
- Solution: Run the create_logistics_deliveries_table.sql migration

**Issue: "permission denied for table"**
- Solution: Check RLS policies are created with permissive access

**Issue: Delivery requests not showing**
- Check console logs for errors
- Verify data was inserted successfully
- Ensure status is set to 'requested'

## Features

### Request Delivery
- Date picker for selecting delivery date
- Time dropdown for selecting delivery time
- Saves requests with 'requested' status

### View Requests
- Navigate to delivery-requests screen
- Approve or reject pending requests
- Approved requests move to deliveries

### Vehicle Management
- Edit vehicle details
- Update status (active/maintenance/inactive)
- Changes save immediately and modal closes
