# Console Error Diagnostic Guide

## Step 1: Check Your App Console

When you try to delete a notification, look for these console messages:

### Expected Console Output:
```
=== DELETE NOTIFICATION STARTED ===
Notification ID: [some-uuid]
User: [user object]
Supabase client: initialized
Delete confirmed, executing delete...
Delete response - data: null
Delete response - error: null (or error object if failed)
```

### What to Look For:

1. **If you see an error object**, note these fields:
   - `error.code` - The error code
   - `error.message` - The error message
   - `error.details` - Additional details
   - `error.hint` - Suggested fix

2. **Common Error Messages:**
   - "new row violates row-level security policy" = RLS is still enabled
   - "permission denied" = RLS policies blocking delete
   - "null value in column" = Data validation issue

## Step 2: Check Database RLS Status

Run this in Supabase SQL Editor:

```sql
-- Check if RLS is enabled
SELECT tablename, rowsecurity 
FROM pg_tables 
WHERE schemaname = 'public' 
AND tablename = 'notifications';

-- Check existing policies
SELECT * FROM pg_policies WHERE tablename = 'notifications';
```

**Expected Results:**
- `rowsecurity` should be `false` (RLS disabled)
- No policies should exist

## Step 3: If RLS is Still Enabled

Run this fix script in Supabase SQL Editor:

```sql
-- Drop ALL policies
DO $$ 
DECLARE 
    r RECORD;
BEGIN
    FOR r IN (SELECT policyname FROM pg_policies WHERE tablename = 'notifications') LOOP
        EXECUTE 'DROP POLICY IF EXISTS "' || r.policyname || '" ON notifications';
    END LOOP;
END $$;

-- Disable RLS
ALTER TABLE notifications DISABLE ROW LEVEL SECURITY;

-- Verify
SELECT tablename, rowsecurity FROM pg_tables WHERE tablename = 'notifications';
```

## Step 4: Test Delete Operation

After running the fix, test in SQL Editor:

```sql
-- Try to delete a test notification
DELETE FROM notifications WHERE id = 'paste-notification-id-here';
```

If this works in SQL Editor but not in the app, the issue is with the app code, not RLS.

## Step 5: Share Console Output

If the issue persists, share:
1. The exact error message from console
2. The result of the RLS status check
3. Whether the SQL Editor delete works
