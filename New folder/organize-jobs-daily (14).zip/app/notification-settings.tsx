import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Switch, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import { supabase } from '../app/lib/supabase';

interface NotificationPreferences {
  job_created: boolean; job_updated: boolean; job_completed: boolean; job_archived: boolean;
  messages: boolean; stock_request_created: boolean; stock_request_approved: boolean;
  stock_request_acknowledged: boolean; inventory_stock_movements: boolean;
  inventory_low_stock: boolean; inventory_new_items: boolean; inventory_diesel: boolean;
  daily_report: boolean; system_alerts: boolean;
  logistics_new_request: boolean; logistics_request_approved: boolean; logistics_status_updates: boolean;
}

// Users with restricted notification settings visibility
const RESTRICTED_USERS: Record<string, string[]> = {
  'IM': ['logistics_new_request', 'logistics_request_approved', 'logistics_status_updates', 'daily_report'],
};

export default function NotificationSettings() {
  const router = useRouter();
  const { user } = usePasswordAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [preferences, setPreferences] = useState<NotificationPreferences>({
    job_created: true, job_updated: true, job_completed: true, job_archived: true,
    messages: true, stock_request_created: true, stock_request_approved: true,
    stock_request_acknowledged: true, inventory_stock_movements: true,
    inventory_low_stock: true, inventory_new_items: true, inventory_diesel: true,
    daily_report: true, system_alerts: true,
    logistics_new_request: true, logistics_request_approved: true, logistics_status_updates: true,
  });

  const isRestrictedUser = user?.username && RESTRICTED_USERS[user.username];
  const allowedSettings = isRestrictedUser ? RESTRICTED_USERS[user.username] : null;

  useEffect(() => { loadPreferences(); }, [user?.id]);

  const loadPreferences = async () => {
    try {
      setLoading(true);
      if (!user?.id) { setLoading(false); return; }
      const { data, error } = await supabase.from('profiles').select('notification_permissions').eq('id', user.id).single();
      if (error) { setLoading(false); return; }
      if (data?.notification_permissions) {
        const p = data.notification_permissions;
        setPreferences({
          job_created: p.job_created ?? true, job_updated: p.job_updated ?? true,
          job_completed: p.job_completed ?? true, job_archived: p.job_archived ?? true,
          messages: p.messages ?? true, stock_request_created: p.stock_request_created ?? true,
          stock_request_approved: p.stock_request_approved ?? true,
          stock_request_acknowledged: p.stock_request_acknowledged ?? true,
          inventory_stock_movements: p.inventory_stock_movements ?? true,
          inventory_low_stock: p.inventory_low_stock ?? true, inventory_new_items: p.inventory_new_items ?? true,
          inventory_diesel: p.inventory_diesel ?? true, daily_report: p.daily_report ?? true,
          system_alerts: p.system_alerts ?? true,
          logistics_new_request: p.logistics_new_request ?? true,
          logistics_request_approved: p.logistics_request_approved ?? true,
          logistics_status_updates: p.logistics_status_updates ?? true,
        });
      }
    } catch (error) { console.error('Error loading preferences:', error); }
    finally { setLoading(false); }
  };

  const savePreferences = async () => {
    if (!user?.id) { Alert.alert('Error', 'User not found.'); return; }
    setSaving(true);
    try {
      const { error } = await supabase.from('profiles').update({ notification_permissions: preferences }).eq('id', user.id);
      if (error) throw error;
      Alert.alert('Success', 'Preferences saved!', [{ text: 'OK', onPress: () => router.back() }]);
    } catch (error) { Alert.alert('Error', 'Failed to save preferences.'); }
    finally { setSaving(false); }
  };

  const toggle = (type: keyof NotificationPreferences) => {
    setPreferences(prev => ({ ...prev, [type]: !prev[type] }));
  };

  const canShow = (key: string) => !allowedSettings || allowedSettings.includes(key);

  if (loading) return <View style={styles.container}><Text>Loading...</Text></View>;

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}><Text style={styles.backButton}>← Back</Text></TouchableOpacity>
        <Text style={styles.title}>Notification Settings</Text>
        {isRestrictedUser && <Text style={styles.restrictedNote}>Showing available notification options for your account</Text>}
      </View>

      {(!allowedSettings || allowedSettings.some(k => ['logistics_new_request', 'logistics_request_approved', 'logistics_status_updates'].includes(k))) && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Logistics Notifications</Text>
          {canShow('logistics_new_request') && <Row label="New Delivery Requests" hint="For managers: when new requests are submitted" value={preferences.logistics_new_request} onToggle={() => toggle('logistics_new_request')} />}
          {canShow('logistics_request_approved') && <Row label="Request Approvals/Rejections" hint="For requesters: when your request is approved or rejected" value={preferences.logistics_request_approved} onToggle={() => toggle('logistics_request_approved')} />}
          {canShow('logistics_status_updates') && <Row label="Delivery Status Updates" hint="When delivery status changes" value={preferences.logistics_status_updates} onToggle={() => toggle('logistics_status_updates')} />}
        </View>
      )}

      {canShow('daily_report') && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Reports</Text>
          <Row label="Daily/Logistics Reports" value={preferences.daily_report} onToggle={() => toggle('daily_report')} />
        </View>
      )}

      {!isRestrictedUser && (
        <>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Job Notifications</Text>
            <Row label="New Jobs Created" value={preferences.job_created} onToggle={() => toggle('job_created')} />
            <Row label="Job Status Updates" hint="Includes: Job moved to Planning/WIP" value={preferences.job_updated} onToggle={() => toggle('job_updated')} />
            <Row label="Job Completions" value={preferences.job_completed} onToggle={() => toggle('job_completed')} />
            <Row label="Job Archived" value={preferences.job_archived} onToggle={() => toggle('job_archived')} />
            <Row label="Messages" value={preferences.messages} onToggle={() => toggle('messages')} />
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Inventory - Stock Requests</Text>
            <Row label="Request Created" value={preferences.stock_request_created} onToggle={() => toggle('stock_request_created')} />
            <Row label="Request Approved" value={preferences.stock_request_approved} onToggle={() => toggle('stock_request_approved')} />
            <Row label="Request Acknowledged" value={preferences.stock_request_acknowledged} onToggle={() => toggle('stock_request_acknowledged')} />
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Inventory - Operations</Text>
            <Row label="Stock Movements" value={preferences.inventory_stock_movements} onToggle={() => toggle('inventory_stock_movements')} />
            <Row label="Low Stock Alerts" value={preferences.inventory_low_stock} onToggle={() => toggle('inventory_low_stock')} />
            <Row label="New Items Added" value={preferences.inventory_new_items} onToggle={() => toggle('inventory_new_items')} />
            <Row label="Diesel Operations" value={preferences.inventory_diesel} onToggle={() => toggle('inventory_diesel')} />
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>System</Text>
            <Row label="System Alerts" value={preferences.system_alerts} onToggle={() => toggle('system_alerts')} />
          </View>
        </>
      )}

      <TouchableOpacity style={[styles.saveButton, saving && styles.saveButtonDisabled]} onPress={savePreferences} disabled={saving}>
        <Text style={styles.saveButtonText}>{saving ? 'Saving...' : 'Save Preferences'}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const Row = ({ label, hint, value, onToggle }: { label: string; hint?: string; value: boolean; onToggle: () => void }) => (
  <View style={styles.settingRow}>
    <View style={{ flex: 1 }}>
      <Text style={styles.settingLabel}>{label}</Text>
      {hint && <Text style={styles.settingHint}>{hint}</Text>}
    </View>
    <Switch value={value} onValueChange={onToggle} />
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { backgroundColor: '#fff', padding: 16, borderBottomWidth: 1, borderBottomColor: '#e0e0e0' },
  backButton: { fontSize: 16, color: '#007AFF', marginBottom: 8 },
  title: { fontSize: 24, fontWeight: 'bold' },
  restrictedNote: { fontSize: 12, color: '#666', marginTop: 8, fontStyle: 'italic' },
  section: { backgroundColor: '#fff', marginTop: 16, padding: 16 },
  sectionTitle: { fontSize: 18, fontWeight: '600', marginBottom: 16 },
  settingRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  settingLabel: { fontSize: 16 },
  settingHint: { fontSize: 12, color: '#666', marginTop: 2 },
  saveButton: { backgroundColor: '#007AFF', margin: 16, padding: 16, borderRadius: 8, alignItems: 'center' },
  saveButtonDisabled: { backgroundColor: '#ccc' },
  saveButtonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
});
