import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, RefreshControl } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { supabase } from './lib/supabase';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import MessageDetailModal from '../components/MessageDetailModal';

export default function SentMessagesScreen() {
  const router = useRouter();
  const { user } = usePasswordAuth();
  const [sentMessages, setSentMessages] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMessage, setSelectedMessage] = useState<any>(null);
  const [detailVisible, setDetailVisible] = useState(false);


  useEffect(() => {
    loadSentMessages();
  }, []);

  const loadSentMessages = async () => {
    if (!user) return;
    setLoading(true);
    console.log('Loading sent messages for user:', user.id);
    
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('sender_id', user.id)
      .eq('type', 'message')
      .order('created_at', { ascending: false});

    console.log('Sent messages query result:', { data, error, count: data?.length });
    
    if (error) {
      console.error('Error loading sent messages:', error);
    }
    
    if (data) {
      // Fetch recipient profiles
      const recipientIds = [...new Set(data.map(n => n.user_id))];
      let recipientProfiles: any = {};
      
      if (recipientIds.length > 0) {
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, full_name')
          .in('id', recipientIds);
        
        if (profiles) {
          profiles.forEach(p => {
            recipientProfiles[p.id] = p;
          });
        }
      }
      
      // Attach recipient profile to each message
      const enrichedData = data.map(n => ({
        ...n,
        recipient_profile: recipientProfiles[n.user_id] || null
      }));
      
      setSentMessages(enrichedData);
    }
    setLoading(false);
  };




  const getPriorityColor = (priority: string) => {
    if (priority === 'urgent') return '#ef4444';
    if (priority === 'high') return '#f59e0b';
    return '#6b7280';
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.title}>Sent Messages</Text>
        <View style={{ width: 24 }} />
      </View>

      <FlatList
        data={sentMessages}
        keyExtractor={item => item.id}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={loadSentMessages} />}
        renderItem={({ item }) => (
          <TouchableOpacity 
            style={styles.card}
            onPress={() => {
              setSelectedMessage(item);
              setDetailVisible(true);
            }}
          >
            <View style={styles.cardHeader}>
              <Text style={styles.recipient}>
                To: {item.recipient_profile?.full_name || 'Unknown'}
              </Text>

              <View style={[styles.priorityBadge, { backgroundColor: getPriorityColor(item.priority) }]}>
                <Text style={styles.priorityText}>{item.priority?.toUpperCase()}</Text>
              </View>
            </View>
            <Text style={styles.cardTitle}>{item.title}</Text>
            <Text style={styles.cardMessage} numberOfLines={2}>{item.message}</Text>
            <Text style={styles.timestamp}>
              {new Date(item.created_at).toLocaleString()}
            </Text>
          </TouchableOpacity>

        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="mail-outline" size={64} color="#ccc" />
            <Text style={styles.emptyText}>No sent messages</Text>
          </View>
        }
      />

      <MessageDetailModal
        visible={detailVisible}
        onClose={() => {
          setDetailVisible(false);
          setSelectedMessage(null);
        }}
        notification={selectedMessage}
        isSentMessage={true}
      />

    </View>
  );
}


const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f9fafb' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#e5e7eb' },
  title: { fontSize: 20, fontWeight: '600' },
  card: { backgroundColor: '#fff', margin: 8, padding: 16, borderRadius: 8, borderWidth: 1, borderColor: '#e5e7eb' },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  recipient: { fontSize: 14, color: '#6b7280', fontWeight: '500' },
  priorityBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 4 },
  priorityText: { fontSize: 10, color: '#fff', fontWeight: '600' },
  cardTitle: { fontSize: 16, fontWeight: '600', marginBottom: 4 },
  cardMessage: { fontSize: 14, color: '#6b7280', marginBottom: 8 },
  timestamp: { fontSize: 12, color: '#9ca3af' },
  empty: { alignItems: 'center', justifyContent: 'center', marginTop: 100 },
  emptyText: { fontSize: 16, color: '#9ca3af', marginTop: 16 },
});
