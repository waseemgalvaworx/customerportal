import { createClient } from '@supabase/supabase-js';
import logger from '../../utils/logger';

// IMPORTANT: Replace these with your actual Supabase credentials
// Get them from: https://app.supabase.com/project/_/settings/api

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL || 'https://obtmrrbajlrdnmnfhcas.supabase.co';
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '';

// Validate configuration
if (!supabaseAnonKey || supabaseAnonKey === 'YOUR_SUPABASE_ANON_KEY_HERE') {
  logger.error('Supabase', 'SUPABASE NOT CONFIGURED');
  logger.info('Supabase', 'Follow these steps:');
  logger.info('Supabase', '1. Open: https://app.supabase.com/project/obtmrrbajlrdnmnfhcas/settings/api');
  logger.info('Supabase', '2. Copy the "anon public" key');
  logger.info('Supabase', '3. Create a .env file with: EXPO_PUBLIC_SUPABASE_ANON_KEY=your_key');
  logger.info('Supabase', '4. Restart the app with: npx expo start --clear');
  logger.info('Supabase', 'See ANON_KEY_SETUP.md for detailed instructions');
}

// Use a placeholder key if not configured to prevent crashes
const finalKey = supabaseAnonKey || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9idG1ycmJhamxyZG5tbmZoY2FzIiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTc1NjQ0MDAsImV4cCI6MjAxMzE0MDQwMH0.placeholder';

export const supabase = createClient(supabaseUrl, finalKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

// Test connection
supabase.from('jobs').select('count', { count: 'exact', head: true })
  .then(({ error }) => {
    if (error) {
      logger.error('Supabase', 'Connection error', error.message);
      logger.info('Supabase', 'Check your EXPO_PUBLIC_SUPABASE_ANON_KEY in .env file');
    } else {
      logger.info('Supabase', 'Connected successfully');
    }
  });
