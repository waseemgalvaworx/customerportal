// Simple password-based authentication
export type UserRole = 'admin' | 'james' | 'lovena' | 'kh' | 'luvish' | 'ashok' | 'ikhlaas' | 'im' | 'js' | 'ij';

export interface PasswordUser {
  id: string;
  username: string;
  role: UserRole;
  name: string;
  permissions: {
    jobs: boolean;
    planning: boolean;
    wip: boolean;
    wipModify: boolean;
    done: boolean;
    finishing: boolean;
    statistics: boolean;
    customers: boolean;
    archive: boolean;
    userManagement: boolean;
    compliance: boolean;
    admin: boolean;
    inventory: boolean;
    inventoryLimited: boolean;
    logistics: boolean;
    logisticsRequestOnly: boolean; // Can only request deliveries and view active, no other logistics features
    canViewCompletedDeliveries: boolean; // Can view completed deliveries tab
    canUpdateDeliveryStatus: boolean; // Can update delivery status
    canViewRequests: boolean; // Can view requests tab to see submitted requests
    canCreateJobs: boolean;
    canExportDailyProduction: boolean;
    canAccessSettings: boolean;
    canRunArchive: boolean;
    canModifyQC: boolean;
    canEditJobDetails: boolean;
  };
}

const PASSWORD_MAP: Record<string, PasswordUser> = {
  'admin1531': { id: '00000000-0000-0000-0000-000000000001', username: 'admin', role: 'admin', name: 'Admin', permissions: { jobs: true, planning: true, wip: true, wipModify: true, done: true, finishing: true, statistics: true, customers: true, archive: true, userManagement: true, compliance: true, admin: true, inventory: true, inventoryLimited: false, logistics: true, logisticsRequestOnly: false, canViewCompletedDeliveries: true, canUpdateDeliveryStatus: true, canViewRequests: true, canCreateJobs: true, canExportDailyProduction: true, canAccessSettings: true, canRunArchive: true, canModifyQC: true, canEditJobDetails: true } },
  'James007': { id: '00000000-0000-0000-0000-000000000002', username: 'James', role: 'james', name: 'James', permissions: { jobs: true, planning: true, wip: true, wipModify: false, done: true, finishing: false, statistics: true, customers: false, archive: false, userManagement: false, compliance: false, admin: false, inventory: false, inventoryLimited: false, logistics: false, logisticsRequestOnly: false, canViewCompletedDeliveries: false, canUpdateDeliveryStatus: false, canViewRequests: false, canCreateJobs: false, canExportDailyProduction: true, canAccessSettings: true, canRunArchive: true, canModifyQC: false, canEditJobDetails: true } },
  'Lovena005': { id: '00000000-0000-0000-0000-000000000003', username: 'Lovena', role: 'lovena', name: 'Lovena', permissions: { jobs: true, planning: true, wip: true, wipModify: true, done: true, finishing: true, statistics: true, customers: true, archive: true, userManagement: true, compliance: true, admin: false, inventory: true, inventoryLimited: false, logistics: true, logisticsRequestOnly: false, canViewCompletedDeliveries: true, canUpdateDeliveryStatus: true, canViewRequests: true, canCreateJobs: true, canExportDailyProduction: true, canAccessSettings: true, canRunArchive: true, canModifyQC: true, canEditJobDetails: true } },
  'Luvish001': { id: '00000000-0000-0000-0000-000000000004', username: 'Luvish', role: 'luvish', name: 'Luvish', permissions: { jobs: true, planning: true, wip: false, wipModify: false, done: true, finishing: false, statistics: false, customers: true, archive: false, userManagement: false, compliance: false, admin: false, inventory: false, inventoryLimited: false, logistics: false, logisticsRequestOnly: false, canViewCompletedDeliveries: false, canUpdateDeliveryStatus: false, canViewRequests: false, canCreateJobs: true, canExportDailyProduction: true, canAccessSettings: true, canRunArchive: true, canModifyQC: false, canEditJobDetails: true } },
  'KH123': { id: '00000000-0000-0000-0000-000000000005', username: 'KH', role: 'kh', name: 'KH', permissions: { jobs: true, planning: true, wip: true, wipModify: true, done: true, finishing: true, statistics: true, customers: true, archive: true, userManagement: true, compliance: true, admin: false, inventory: true, inventoryLimited: false, logistics: true, logisticsRequestOnly: false, canViewCompletedDeliveries: true, canUpdateDeliveryStatus: true, canViewRequests: true, canCreateJobs: true, canExportDailyProduction: true, canAccessSettings: true, canRunArchive: true, canModifyQC: true, canEditJobDetails: true } },
  'Ashok009': { id: '00000000-0000-0000-0000-000000000006', username: 'Ashok', role: 'ashok', name: 'Ashok', permissions: { jobs: false, planning: false, wip: true, wipModify: true, done: true, finishing: false, statistics: false, customers: false, archive: false, userManagement: false, compliance: false, admin: false, inventory: true, inventoryLimited: true, logistics: false, logisticsRequestOnly: false, canViewCompletedDeliveries: false, canUpdateDeliveryStatus: false, canViewRequests: false, canCreateJobs: false, canExportDailyProduction: false, canAccessSettings: false, canRunArchive: false, canModifyQC: true, canEditJobDetails: false } },
  'IK786': { id: '00000000-0000-0000-0000-000000000007', username: 'Ikhlaas', role: 'ikhlaas', name: 'Ikhlaas', permissions: { jobs: false, planning: false, wip: true, wipModify: true, done: true, finishing: false, statistics: false, customers: false, archive: false, userManagement: false, compliance: false, admin: false, inventory: false, inventoryLimited: false, logistics: false, logisticsRequestOnly: false, canViewCompletedDeliveries: false, canUpdateDeliveryStatus: false, canViewRequests: false, canCreateJobs: false, canExportDailyProduction: false, canAccessSettings: false, canRunArchive: false, canModifyQC: true, canEditJobDetails: false } },
  // New users - Logistics Request Only with specific permissions
  '3292': { id: '00000000-0000-0000-0000-000000000008', username: 'IM', role: 'im', name: 'IM', permissions: { jobs: false, planning: false, wip: false, wipModify: false, done: false, finishing: false, statistics: false, customers: false, archive: false, userManagement: false, compliance: false, admin: false, inventory: false, inventoryLimited: false, logistics: true, logisticsRequestOnly: true, canViewCompletedDeliveries: true, canUpdateDeliveryStatus: false, canViewRequests: true, canCreateJobs: false, canExportDailyProduction: false, canAccessSettings: false, canRunArchive: false, canModifyQC: false, canEditJobDetails: false } },
  'JS292': { id: '00000000-0000-0000-0000-000000000009', username: 'JS', role: 'js', name: 'JS', permissions: { jobs: false, planning: false, wip: false, wipModify: false, done: false, finishing: false, statistics: false, customers: false, archive: false, userManagement: false, compliance: false, admin: false, inventory: false, inventoryLimited: false, logistics: true, logisticsRequestOnly: true, canViewCompletedDeliveries: false, canUpdateDeliveryStatus: true, canViewRequests: true, canCreateJobs: false, canExportDailyProduction: false, canAccessSettings: false, canRunArchive: false, canModifyQC: false, canEditJobDetails: false } },
  // IJ user - can view completed deliveries
  'IJ123': { id: '00000000-0000-0000-0000-000000000010', username: 'IJ', role: 'ij', name: 'IJ', permissions: { jobs: false, planning: false, wip: false, wipModify: false, done: false, finishing: false, statistics: false, customers: false, archive: false, userManagement: false, compliance: false, admin: false, inventory: false, inventoryLimited: false, logistics: true, logisticsRequestOnly: true, canViewCompletedDeliveries: true, canUpdateDeliveryStatus: false, canViewRequests: true, canCreateJobs: false, canExportDailyProduction: false, canAccessSettings: false, canRunArchive: false, canModifyQC: false, canEditJobDetails: false } },
};

export function authenticateWithPassword(password: string): PasswordUser | null {
  return PASSWORD_MAP[password] || null;
}
