import React, { useState, useEffect, useCallback, useRef } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Modal, TextInput, ScrollView, Alert, ActivityIndicator, Animated } from 'react-native';
import { useRouter } from 'expo-router';
import { useJobs, JobItem } from '../contexts/JobContext';
import { useCustomers } from '../contexts/CustomerContext';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import { Ionicons } from '@expo/vector-icons';
import CustomerPicker from '../components/CustomerPicker';
import ItemOptionsDropdown from '../components/ItemOptionsDropdown';
import ItemOptionsDisplay from '../components/ItemOptionsDisplay';
import SearchBar from '../components/SearchBar';
import AutocompleteInput from '../components/AutocompleteInput';
import DraftPickerModal from '../components/DraftPickerModal';
import { Draft, DraftItem } from '../types/drafts';
import { loadDrafts, saveDrafts, deleteDraft as removeDraft, getDraftPreviews, generateDraftId } from '../utils/draftStorage';

interface ItemWithOptions extends Omit<JobItem, 'id' | 'status'> {
  itemCount?: string;
  paintVarnish?: boolean;
  galva?: boolean;
  lightGalva?: boolean;
  lightPaint?: boolean;
  rusty?: boolean;
  doubleDip?: boolean;
  multipleDip?: boolean;
}

type AutoSaveStatus = 'idle' | 'saving' | 'saved' | 'error';

export default function JobsScreen() {
  const router = useRouter();
  const { jobs, addJob } = useJobs();
  const { customers } = useCustomers();
  const { user } = usePasswordAuth();
  const [modalVisible, setModalVisible] = useState(false);
  const [saving, setSaving] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [jobNumber, setJobNumber] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [notes, setNotes] = useState('');
  const [galvaXpress, setGalvaXpress] = useState(false);
  const [isDuplicateJobNumber, setIsDuplicateJobNumber] = useState(false);
  const [items, setItems] = useState<ItemWithOptions[]>([
    { itemCount: '', descriptionOfWorks: '', weightKg: '', paintVarnish: false, galva: false, lightGalva: false, lightPaint: false, rusty: false, doubleDip: false, multipleDip: false }
  ]);

  // Multiple drafts state
  const [drafts, setDrafts] = useState<Draft[]>([]);
  const [draftPickerVisible, setDraftPickerVisible] = useState(false);
  const [activeDraftId, setActiveDraftId] = useState<string | null>(null);

  // Auto-save state
  const [autoSaveStatus, setAutoSaveStatus] = useState<AutoSaveStatus>('idle');
  const lastSavedDataRef = useRef<string>('');
  const autoSaveOpacity = useRef(new Animated.Value(0)).current;

  // Check if there's draft data in current form
  const hasDraft = jobNumber.trim() || customerName.trim() || items.some(i => i.descriptionOfWorks.trim() || i.weightKg.trim());
  const totalDraftCount = drafts.length + (hasDraft && !activeDraftId ? 1 : 0);

  // Load drafts on mount
  useEffect(() => {
    const initDrafts = async () => {
      const saved = await loadDrafts();
      setDrafts(saved);
    };
    initDrafts();
  }, []);

  // Auto-save animation effect
  useEffect(() => {
    if (autoSaveStatus === 'saved') {
      Animated.sequence([
        Animated.timing(autoSaveOpacity, { toValue: 1, duration: 300, useNativeDriver: true }),
        Animated.delay(2000),
        Animated.timing(autoSaveOpacity, { toValue: 0, duration: 300, useNativeDriver: true }),
      ]).start(() => setAutoSaveStatus('idle'));
    }
  }, [autoSaveStatus]);

  // Silent auto-save function (no alerts)
  const performAutoSave = useCallback(async () => {
    if (!hasDraft) return;
    
    const currentData = JSON.stringify({ jobNumber, customerName, notes, galvaXpress, items });
    if (currentData === lastSavedDataRef.current) return; // No changes
    
    setAutoSaveStatus('saving');
    const draftData = { jobNumber, customerName, notes, galvaXpress, items: items as DraftItem[] };
    const now = new Date().toISOString();
    
    try {
      if (activeDraftId) {
        const updated = drafts.map(d => d.id === activeDraftId ? { ...d, ...draftData, updatedAt: now } : d);
        setDrafts(updated);
        await saveDrafts(updated);
      } else {
        const newDraft: Draft = { id: generateDraftId(), createdAt: now, updatedAt: now, ...draftData };
        const updated = [...drafts, newDraft];
        setDrafts(updated);
        await saveDrafts(updated);
        setActiveDraftId(newDraft.id);
      }
      lastSavedDataRef.current = currentData;
      setAutoSaveStatus('saved');
    } catch (error) {
      console.error('Auto-save error:', error);
      setAutoSaveStatus('error');
    }
  }, [jobNumber, customerName, notes, galvaXpress, items, activeDraftId, drafts, hasDraft]);

  // Auto-save interval (every 30 seconds when modal is visible)
  useEffect(() => {
    if (!modalVisible) return;
    
    const interval = setInterval(() => {
      performAutoSave();
    }, 30000); // 30 seconds
    
    return () => clearInterval(interval);
  }, [modalVisible, performAutoSave]);

  // Real-time duplicate job number checking
  useEffect(() => {
    if (jobNumber.trim()) {
      const isDuplicate = jobs.some(job => 
        job.jobNumber.toLowerCase() === jobNumber.trim().toLowerCase()
      );
      setIsDuplicateJobNumber(isDuplicate);
    } else {
      setIsDuplicateJobNumber(false);
    }
  }, [jobNumber, jobs]);

  const pendingJobs = jobs.filter(job => job.status === 'pending');



  // Filter jobs based on search query
  const filteredJobs = pendingJobs.filter(job => {
    const query = searchQuery.toLowerCase();
    return (
      job.jobNumber.toLowerCase().includes(query) ||
      job.customerName.toLowerCase().includes(query) ||
      job.items.some(item => item.descriptionOfWorks.toLowerCase().includes(query))
    );
  });


  const calculateTotalWeight = (jobItems: JobItem[]) => {
    return jobItems.reduce((sum, item) => sum + parseFloat(item.weightKg || '0'), 0);
  };

  const handleAddItem = () => {
    if (items.length < 10) {
      setItems([...items, { itemCount: '', descriptionOfWorks: '', weightKg: '', paintVarnish: false, galva: false, lightGalva: false, lightPaint: false, rusty: false, doubleDip: false, multipleDip: false }]);
    } else {
      Alert.alert('Maximum Items', 'You can only add up to 10 items per job');
    }
  };




  const toggleItemOption = (index: number, option: string) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [option]: !newItems[index][option as keyof ItemWithOptions] };
    setItems(newItems);
  };

  const handleRemoveItem = (index: number) => {
    if (items.length > 1) {
      setItems(items.filter((_, i) => i !== index));
    }
  };

  const updateItem = (index: number, field: string, value: string) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };
    setItems(newItems);
  };


  const handleAddJob = async () => {
    if (!jobNumber.trim() || !customerName.trim()) {
      Alert.alert('Error', 'Job Number and Customer Name are required');
      return;
    }

    // Check for duplicate job number before saving
    if (isDuplicateJobNumber) {
      Alert.alert(
        'Duplicate Job Number', 
        `Job number "${jobNumber}" already exists. Please use a unique job number.`
      );
      return;
    }

    const validItems = items.filter(item => 
      item.descriptionOfWorks.trim() && item.weightKg.trim()
    );
    
    if (validItems.length === 0) {
      Alert.alert('Error', 'Please add at least one item with description and weight');
      return;
    }

    const jobItems: JobItem[] = validItems.map((item, index) => ({
      id: `item-${Date.now()}-${index}`,
      itemCount: item.itemCount,
      descriptionOfWorks: item.descriptionOfWorks,
      weightKg: item.weightKg,
      status: 'Pending',
      paintVarnish: item.paintVarnish,
      galva: item.galva,
      lightGalva: item.lightGalva,
      lightPaint: item.lightPaint,
      rusty: item.rusty,
      doubleDip: item.doubleDip,
      multipleDip: item.multipleDip
    }));

    // Store the draft ID before we start (in case we need to delete it after success)
    const draftIdToDelete = activeDraftId;

    setSaving(true);
    
    try {
      await addJob({
        jobNumber,
        dateOfEntry: new Date(),
        customerName,
        notes,
        items: jobItems,
        galvaXpress,
        priority: galvaXpress ? 'high' : undefined
      });
      
      // If this job was created from a draft, delete the draft now
      if (draftIdToDelete) {
        const updatedDrafts = drafts.filter(d => d.id !== draftIdToDelete);
        setDrafts(updatedDrafts);
        await saveDrafts(updatedDrafts);
      }
      
      resetForm();
      Alert.alert('Success', 'Job added successfully!');
    } catch (error: any) {
      console.error('Error adding job:', error);
      Alert.alert(
        'Error', 
        error?.message || 'Failed to add job. Please check your connection and try again.'
      );
    } finally {
      setSaving(false);
    }
  };





  const resetForm = (clearDraftId = true) => {
    setJobNumber('');
    setCustomerName('');
    setNotes('');
    setGalvaXpress(false);
    setItems([{ descriptionOfWorks: '', weightKg: '', paintVarnish: false, galva: false, lightGalva: false, lightPaint: false, rusty: false }]);
    setModalVisible(false);
    if (clearDraftId) setActiveDraftId(null);
  };

  // Save current form as draft
  const handleSaveDraft = async () => {
    if (!hasDraft) {
      Alert.alert('Empty Draft', 'Please add some data before saving as draft');
      return;
    }
    const draftData = { jobNumber, customerName, notes, galvaXpress, items: items as DraftItem[] };
    const now = new Date().toISOString();
    
    if (activeDraftId) {
      // Update existing draft
      const updated = drafts.map(d => d.id === activeDraftId ? { ...d, ...draftData, updatedAt: now } : d);
      setDrafts(updated);
      await saveDrafts(updated);
      Alert.alert('Draft Updated', 'Your draft has been updated');
    } else {
      // Create new draft
      const newDraft: Draft = { id: generateDraftId(), createdAt: now, updatedAt: now, ...draftData };
      const updated = [...drafts, newDraft];
      setDrafts(updated);
      await saveDrafts(updated);
      setActiveDraftId(newDraft.id);
      Alert.alert('Draft Saved', 'Your draft has been saved');
    }
    setModalVisible(false);
  };

  // Load a draft into the form
  const loadDraftToForm = (draft: Draft) => {
    setJobNumber(draft.jobNumber);
    setCustomerName(draft.customerName);
    setNotes(draft.notes);
    setGalvaXpress(draft.galvaXpress);
    setItems(draft.items.length > 0 ? draft.items : [{ descriptionOfWorks: '', weightKg: '' }]);
    setActiveDraftId(draft.id);
    setDraftPickerVisible(false);
    setModalVisible(true);
  };

  // Delete a draft
  const handleDeleteDraft = async (id: string): Promise<void> => {
    console.log('=== handleDeleteDraft START ===');
    console.log('Deleting draft with id:', id);
    console.log('Current drafts count:', drafts.length);
    
    try {
      // Filter out the draft to delete
      const updated = drafts.filter(d => d.id !== id);
      console.log('Filtered drafts count:', updated.length);
      
      // Save to AsyncStorage first
      await saveDrafts(updated);
      console.log('Saved to AsyncStorage');
      
      // Update state
      setDrafts(updated);
      console.log('State updated');
      
      // If this was the active draft, clear it
      if (activeDraftId === id) {
        setActiveDraftId(null);
        console.log('Cleared active draft');
      }
      
      // Close picker if no more drafts
      if (updated.length === 0) {
        setDraftPickerVisible(false);
        console.log('Closed picker - no more drafts');
      }
      
      console.log('=== handleDeleteDraft SUCCESS ===');
    } catch (error) {
      console.error('=== handleDeleteDraft ERROR ===', error);
      Alert.alert('Error', 'Failed to delete draft. Please try again.');
      // Reload drafts to ensure consistency
      const reloaded = await loadDrafts();
      setDrafts(reloaded);
    }
  };





  // Handle FAB press - show picker if multiple drafts, else open modal
  const handleFabPress = () => {
    if (drafts.length > 0) {
      setDraftPickerVisible(true);
    } else {
      setModalVisible(true);
    }
  };

  // Create new draft from picker
  const handleCreateNew = () => {
    resetForm(true);
    setDraftPickerVisible(false);
    setModalVisible(true);
  };

  // Handle selecting a draft
  const handleSelectDraft = (id: string) => {
    const draft = drafts.find(d => d.id === id);
    if (draft) loadDraftToForm(draft);
  };






  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color="#111827" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Pending Jobs</Text>
        <View style={styles.placeholder} />
      </View>

      <SearchBar
        value={searchQuery}
        onChangeText={setSearchQuery}
        placeholder="Search by job number, customer, or item..."
      />

      <FlatList
        data={filteredJobs}

        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingBottom: 100 }}
        renderItem={({ item }) => (
          <TouchableOpacity 
            style={styles.jobCard}
            onPress={() => router.push(`/job/${item.id}`)}
          >
            <View style={styles.jobHeader}>
              <Text style={styles.jobTitle}>{item.jobNumber}</Text>
              <View style={styles.badgePending}>
                <Text style={styles.badgeText}>PENDING</Text>
              </View>
            </View>
            {item.galvaXpress && (
              <View style={styles.galvaBadge}>
                <Text style={styles.galvaText}>🔴 GalvXpress</Text>
              </View>
            )}
            <Text style={styles.jobCustomer}>👤 {item.customerName}</Text>
            <Text style={styles.itemCount}>📦 Items: {item.items.length}</Text>
            <Text style={styles.jobWeight}>⚖️ Total: {calculateTotalWeight(item.items).toFixed(1)} kg</Text>
            <Text style={styles.jobDate}>📅 {new Date(item.dateOfEntry).toLocaleDateString()}</Text>
            {item.deliveryDate && (
              <Text style={styles.deliveryDate}>
                🚚 Delivery: {new Date(item.deliveryDate).toLocaleDateString()}
              </Text>
            )}
            
            <View style={styles.itemsSection}>
              {item.items.map((subItem: any) => (
                <View key={subItem.id} style={styles.itemRow}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.itemText}>{subItem.descriptionOfWorks}</Text>
                    <ItemOptionsDisplay 
                      paintVarnish={subItem.paintVarnish}
                      galva={subItem.galva}
                      lightGalva={subItem.lightGalva}
                      lightPaint={subItem.lightPaint}
                      rusty={subItem.rusty}
                      doubleDip={subItem.doubleDip}
                      multipleDip={subItem.multipleDip}
                    />
                  </View>
                  <Text style={styles.itemWeightText}>{subItem.weightKg} kg</Text>
                </View>
              ))}
            </View>

          </TouchableOpacity>
        )}

        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Ionicons name="briefcase-outline" size={64} color="#D1D5DB" />
            <Text style={styles.emptyText}>
              {searchQuery ? 'No jobs match your search' : 'No pending jobs'}
            </Text>
          </View>
        }
      />



      {/* Only show FAB if user has permission to create jobs */}
      {user?.permissions.canCreateJobs && (
        <TouchableOpacity 
          style={[styles.fab, (drafts.length > 0 || hasDraft) && !modalVisible && styles.fabDraft]}
          onPress={handleFabPress}
        >
          <Ionicons name={drafts.length > 0 ? "documents" : (hasDraft ? "create" : "add")} size={32} color="#fff" />
          {(drafts.length > 0 || (hasDraft && !activeDraftId)) && !modalVisible && (
            <View style={styles.draftBadge}>
              <Text style={styles.draftBadgeText}>{drafts.length || 1}</Text>
            </View>
          )}
        </TouchableOpacity>
      )}

      {/* Draft Picker Modal */}
      <DraftPickerModal
        visible={draftPickerVisible}
        onClose={() => setDraftPickerVisible(false)}
        drafts={getDraftPreviews(drafts)}
        onSelectDraft={handleSelectDraft}
        onCreateNew={handleCreateNew}
      />








      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            {/* Minimize button at top right */}
            <TouchableOpacity 
              style={styles.minimizeBtn}
              onPress={() => setModalVisible(false)}
            >
              <Ionicons name="chevron-down" size={24} color="#6B7280" />
            </TouchableOpacity>
            
            <ScrollView showsVerticalScrollIndicator={false}>
              <View style={styles.modalTitleRow}>
                <Text style={styles.modalTitle}>Add New Job</Text>
                <View style={styles.titleRightSection}>
                  {/* Auto-save status indicator */}
                  {autoSaveStatus === 'saving' && (
                    <View style={styles.autoSaveIndicator}>
                      <ActivityIndicator size="small" color="#6B7280" />
                      <Text style={styles.autoSaveText}>Saving...</Text>
                    </View>
                  )}
                  <Animated.View style={[styles.autoSaveIndicator, styles.autoSaveSaved, { opacity: autoSaveOpacity }]}>
                    <Ionicons name="checkmark-circle" size={16} color="#10B981" />
                    <Text style={styles.autoSaveSavedText}>Auto-saved</Text>
                  </Animated.View>
                  {activeDraftId && (
                    <View style={styles.editingDraftBadge}>
                      <Ionicons name="document-text" size={14} color="#F59E0B" />
                      <Text style={styles.editingDraftText}>Editing Draft</Text>
                    </View>
                  )}
                </View>
              </View>


              <Text style={styles.label}>Job Number *</Text>
              <View>
                <TextInput
                  style={[styles.input, isDuplicateJobNumber && styles.inputError]}
                  placeholder="e.g., JOB-003"
                  value={jobNumber}
                  onChangeText={setJobNumber}
                />
                {isDuplicateJobNumber && (
                  <View style={styles.warningBadge}>
                    <Ionicons name="warning" size={16} color="#EF4444" />
                    <Text style={styles.warningText}>This job number already exists</Text>
                  </View>
                )}
              </View>



              <Text style={styles.label}>Customer *</Text>
              {customers.length > 0 && !customerName ? (
                <>
                  <CustomerPicker
                    customers={customers}
                    selectedCustomer={customerName}
                    onSelectCustomer={setCustomerName}
                  />
                  <Text style={styles.orText}>— OR —</Text>
                </>
              ) : null}
              <TextInput
                style={styles.input}
                placeholder="Type customer name..."
                value={customerName}
                onChangeText={setCustomerName}
              />


              <TouchableOpacity style={styles.galvaSection} onPress={() => setGalvaXpress(!galvaXpress)}>
                <Ionicons name={galvaXpress ? "checkbox" : "square-outline"} size={24} color="#EF4444" />
                <Text style={styles.galvaXpressText}>GalvXpress</Text>
              </TouchableOpacity>

              <Text style={styles.label}>Items ({items.length}/10)</Text>


              {items.map((item, index) => (
                <View key={index} style={styles.itemContainer}>
                  <View style={styles.itemHeader}>
                    <Text style={styles.itemNumber}>Item {index + 1}</Text>
                    {items.length > 1 && (
                      <TouchableOpacity onPress={() => handleRemoveItem(index)}>
                        <Ionicons name="trash-outline" size={20} color="#EF4444" />
                      </TouchableOpacity>
                    )}
                  </View>
                  


                  <AutocompleteInput
                    value={item.descriptionOfWorks}
                    onChangeText={(text) => updateItem(index, 'descriptionOfWorks', text)}
                    placeholder="Description of works"
                    field="descriptionOfWorks"
                    style={styles.input}
                  />

                  <TextInput
                    style={styles.input}
                    placeholder="Quantity (kg)"
                    value={item.weightKg}
                    onChangeText={(text) => updateItem(index, 'weightKg', text)}
                    keyboardType="numeric"
                  />


                  <ItemOptionsDropdown
                    paintVarnish={item.paintVarnish || false}
                    galva={item.galva || false}
                    lightGalva={item.lightGalva || false}
                    lightPaint={item.lightPaint || false}
                    rusty={item.rusty || false}
                    doubleDip={item.doubleDip || false}
                    multipleDip={item.multipleDip || false}
                    onToggle={(option) => toggleItemOption(index, option)}
                  />



                </View>


              ))}

              {/* Add Item button placed below the last item */}
              <TouchableOpacity onPress={handleAddItem} style={styles.addItemBtnBottom}>
                <Ionicons name="add-circle" size={24} color="#3B82F6" />
                <Text style={styles.addItemText}>Add Item</Text>
              </TouchableOpacity>


              <Text style={styles.label}>Notes (Optional)</Text>
              <TextInput
                style={[styles.input, styles.inputMulti]}
                placeholder="Add any additional notes..."
                value={notes}
                onChangeText={setNotes}
                multiline
                numberOfLines={3}
              />

              <View style={styles.modalActions}>
                <TouchableOpacity 
                  style={[styles.btn, styles.btnSecondary]}
                  onPress={() => resetForm()}
                  disabled={saving}
                >
                  <Text style={styles.btnText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={[styles.btn, styles.btnDraft]}
                  onPress={handleSaveDraft}
                  disabled={saving}
                >
                  <Text style={styles.btnText}>Save Draft</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={[styles.btn, styles.btnPrimary, saving && styles.btnDisabled]}
                  onPress={handleAddJob}
                  disabled={saving}
                >
                  {saving ? (
                    <ActivityIndicator color="#fff" />
                  ) : (
                    <Text style={styles.btnText}>Add Job</Text>
                  )}
                </TouchableOpacity>
              </View>


            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>


  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { backgroundColor: '#fff', padding: 16, paddingTop: 60, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  backBtn: { padding: 8 },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: '#111827' },
  placeholder: { width: 40 },
  jobCard: { backgroundColor: '#fff', borderRadius: 12, padding: 16, marginHorizontal: 16, marginTop: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  jobHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  jobTitle: { fontSize: 20, fontWeight: 'bold', color: '#111827', flex: 1 },
  jobCustomer: { fontSize: 16, color: '#2563EB', marginBottom: 6, fontWeight: '600' },
  itemCount: { fontSize: 14, color: '#6B7280', marginBottom: 4 },
  jobWeight: { fontSize: 13, color: '#8B5CF6', marginBottom: 4, fontWeight: '600' },
  jobDate: { fontSize: 12, color: '#9CA3AF' },
  galvaBadge: { marginBottom: 8 },
  galvaText: { fontSize: 14, color: '#EF4444', fontWeight: 'bold', backgroundColor: '#FEF2F2', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, alignSelf: 'flex-start' },
  deliveryDate: { fontSize: 12, color: '#059669', fontWeight: '600', marginTop: 4 },
  badgePending: { backgroundColor: '#FEF3C7', paddingHorizontal: 12, paddingVertical: 4, borderRadius: 12 },
  badgeText: { fontSize: 12, fontWeight: '600', color: '#92400E' },
  itemsSection: { marginTop: 8, paddingTop: 8, borderTopWidth: 1, borderTopColor: '#E5E7EB' },
  itemRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  itemText: { fontSize: 12, color: '#6B7280' },
  itemWeightText: { fontSize: 12, color: '#6B7280', fontWeight: '500' },
  emptyContainer: { alignItems: 'center', marginTop: 100 },
  emptyText: { fontSize: 16, color: '#9CA3AF', marginTop: 16 },
  fab: { position: 'absolute', right: 20, bottom: 20, width: 64, height: 64, borderRadius: 32, backgroundColor: '#2563EB', alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 8 },
  fabDraft: { backgroundColor: '#F59E0B' },
  draftBadge: { position: 'absolute', top: -4, right: -4, backgroundColor: '#EF4444', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 8 },
  draftBadgeText: { color: '#fff', fontSize: 10, fontWeight: 'bold' },
  minimizeBtn: { position: 'absolute', top: 12, right: 12, padding: 8, zIndex: 10, backgroundColor: '#F3F4F6', borderRadius: 20 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#fff', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: '90%' },
  modalTitle: { fontSize: 24, fontWeight: 'bold', marginBottom: 20, color: '#111827' },
  label: { fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 8 },
  input: { borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, padding: 12, marginBottom: 16, fontSize: 16, backgroundColor: '#F9FAFB' },
  inputError: { borderColor: '#EF4444', borderWidth: 2, backgroundColor: '#FEF2F2' },
  inputMulti: { height: 80, textAlignVertical: 'top' },
  warningBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#FEF2F2', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, marginTop: -12, marginBottom: 12, borderWidth: 1, borderColor: '#FEE2E2' },
  warningText: { fontSize: 13, color: '#EF4444', fontWeight: '600' },
  modalActions: { flexDirection: 'row', gap: 8, marginTop: 8 },
  btn: { padding: 10, borderRadius: 8, alignItems: 'center', flex: 1 },
  btnPrimary: { backgroundColor: '#2563EB' },
  btnSecondary: { backgroundColor: '#6B7280' },
  btnDraft: { backgroundColor: '#F59E0B' },
  btnDisabled: { opacity: 0.6 },
  btnText: { color: '#fff', fontWeight: '600', fontSize: 13 },
  itemsHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  addItemBtn: { padding: 4 },
  itemContainer: { backgroundColor: '#F9FAFB', padding: 12, borderRadius: 8, marginBottom: 12 },
  itemHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  itemNumber: { fontSize: 14, fontWeight: '600', color: '#374151' },
  galvaSection: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 16, marginTop: 8 },
  galvaXpressText: { fontSize: 18, fontWeight: 'bold', color: '#EF4444' },
  addItemBtnBottom: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#EFF6FF', padding: 16, borderRadius: 8, marginBottom: 16, borderWidth: 2, borderColor: '#3B82F6', borderStyle: 'dashed' },
  addItemText: { fontSize: 16, fontWeight: '600', color: '#3B82F6' },
  orText: { textAlign: 'center', color: '#9CA3AF', marginVertical: 8, fontSize: 14 },
  modalTitleRow: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20 },
  titleRightSection: { flexDirection: 'column', alignItems: 'flex-end', gap: 4 },
  autoSaveIndicator: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, backgroundColor: '#F3F4F6' },
  autoSaveText: { fontSize: 11, color: '#6B7280', fontWeight: '500' },
  autoSaveSaved: { backgroundColor: '#ECFDF5', position: 'absolute', right: 0, top: 0 },
  autoSaveSavedText: { fontSize: 11, color: '#10B981', fontWeight: '600' },
  editingDraftBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#FEF3C7', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, marginTop: 4 },
  editingDraftText: { fontSize: 12, color: '#F59E0B', fontWeight: '600' }
});
