import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl, Alert, SafeAreaView, ActivityIndicator, Animated, Dimensions } from 'react-native';

import { supabase } from './lib/supabase';
import { usePasswordAuth } from '@/contexts/PasswordAuthContext';
import RequestStockModal from '@/components/RequestStockModal';
import ApproveRequestModal from '@/components/ApproveRequestModal';
import { router } from 'expo-router';
import { getUserIdFromUsername } from '@/utils/userMapping';
import { checkUserNotificationPermission } from '@/utils/notificationHelper';
import { createDebouncedRefresh } from '@/utils/realtimeHelpers';


export default function StockRequestsScreen() {
  const { user } = usePasswordAuth();
  const filterScrollRef = useRef<ScrollView>(null);
  const [showLeftChevron, setShowLeftChevron] = useState(false);
  const [showRightChevron, setShowRightChevron] = useState(true);
  const screenWidth = Dimensions.get('window').width;

  const [requests, setRequests] = useState<any[]>([]);
  const [inventoryItems, setInventoryItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [showApproveModal, setShowApproveModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<any>(null);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'fulfilled' | 'rejected'>('all');
  const [error, setError] = useState<string | null>(null);
  const debouncedRefreshRef = useRef<{ trigger: () => void; cancel: () => void } | null>(null);

  const canApprove = user?.role === 'admin' || user?.username === 'Lovena' || user?.username === 'KH';

  // Handle scroll position to show/hide chevrons
  const handleFilterScroll = (event: any) => {
    const { contentOffset, contentSize, layoutMeasurement } = event.nativeEvent;
    const scrollX = contentOffset.x;
    const maxScrollX = contentSize.width - layoutMeasurement.width;
    
    setShowLeftChevron(scrollX > 10);
    setShowRightChevron(scrollX < maxScrollX - 10);
  };

  // Scroll filter tabs with slow animation
  const scrollFilters = (direction: 'left' | 'right') => {
    if (filterScrollRef.current) {
      // Get current scroll position and scroll by a small amount for smooth experience
      filterScrollRef.current.scrollTo({
        x: direction === 'left' ? 0 : 500,
        animated: true,
      });
    }
  };




  useEffect(() => {
    fetchData();

    // OPTIMIZED: Create debounced refresh to batch rapid updates
    debouncedRefreshRef.current = createDebouncedRefresh(fetchData, 500);

    // OPTIMIZED: Combined subscriptions into single channel with debouncing
    const stockChannel = supabase
      .channel('stock_requests_combined')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'stock_requests' },
        () => debouncedRefreshRef.current?.trigger()
      )
      .on('postgres_changes', 
        { event: 'UPDATE', schema: 'public', table: 'inventory_items' },
        () => debouncedRefreshRef.current?.trigger()
      )
      .subscribe();

    return () => {
      debouncedRefreshRef.current?.cancel();
      supabase.removeChannel(stockChannel);
    };
  }, [filter]);






  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      console.log('Fetching stock requests with filter:', filter);
      
      // Fetch requests with join
      let query = supabase
        .from('stock_requests')
        .select(`
          *,
          inventory_items (
            id,
            item_name,
            unit,
            quantity
          )
        `)

        .order('created_at', { ascending: false });

      
      if (filter !== 'all') {
        query = query.eq('status', filter);
      }

      const { data: requestsData, error: requestsError } = await query;
      
      if (requestsError) {
        console.error('Requests error:', requestsError);
        if (requestsError.message.includes('relation "stock_requests" does not exist')) {
          setError('Stock requests table not found. Please run the database migration.');
          Alert.alert(
            'Database Setup Required',
            'The stock_requests table needs to be created. Please run the migration file: supabase/migrations/create_stock_requests_table.sql',
            [{ text: 'OK' }]
          );
        } else {
          throw requestsError;
        }
        setRequests([]);
      } else {
        setRequests(requestsData || []);
      }

      // Fetch inventory items
      const { data: itemsData, error: itemsError } = await supabase
        .from('inventory_items')
        .select('*')
        .order('item_name');
        
      console.log('Items data:', itemsData);
      console.log('Items error:', itemsError);
      
      if (itemsError) {
        console.error('Error fetching items:', itemsError);
        throw itemsError;
      }
      
      setInventoryItems(itemsData || []);
    } catch (error: any) {
      console.error('Fetch error:', error);
      setError(error.message);
      Alert.alert('Error Loading Data', error.message || 'Please check your connection and try again');
    } finally {
      setLoading(false);
    }
  };



  const handleApprove = (request: any) => {
    setSelectedRequest(request);
    setShowApproveModal(true);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return '#FF9500';
      case 'approved': return '#007AFF';
      case 'fulfilled': return '#34C759';
      case 'rejected': return '#FF3B30';
      default: return '#666';
    }
  };

  const filteredRequests = requests;

  if (loading && requests.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={styles.backText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.title}>Stock Requests</Text>
          <View style={{ width: 60 }} />
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#007AFF" />
          <Text style={styles.loadingText}>Loading stock requests...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (error) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={styles.backText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.title}>Stock Requests</Text>
          <View style={{ width: 60 }} />
        </View>
        <View style={styles.errorContainer}>
          <Text style={styles.errorTitle}>Database Setup Required</Text>
          <Text style={styles.errorText}>{error}</Text>
          <Text style={styles.errorInstructions}>
            Please run this migration in your Supabase SQL editor:
          </Text>
          <Text style={styles.errorFile}>
            supabase/migrations/create_stock_requests_table.sql
          </Text>
          <TouchableOpacity style={styles.retryBtn} onPress={fetchData}>
            <Text style={styles.retryText}>Retry</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Stock Requests</Text>
        <View style={styles.headerRight}>
          <TouchableOpacity 
            style={styles.archiveBtn} 
            onPress={() => router.push('/stock-requests-archive')}
          >
            <Text style={styles.archiveBtnText}>Archive</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.newBtn} 
            onPress={() => {
              console.log('New Request button pressed');
              console.log('Current inventoryItems:', inventoryItems);
              setShowRequestModal(true);
            }}
          >
            <Text style={styles.newBtnText}>+ New</Text>
          </TouchableOpacity>
        </View>
      </View>



      {/* Filter Tabs with Chevrons */}
      <View style={styles.filterWrapper}>
        {/* Left Chevron */}
        {showLeftChevron && (
          <TouchableOpacity 
            style={[styles.chevronBtn, styles.chevronLeft]} 
            onPress={() => scrollFilters('left')}
            activeOpacity={0.7}
          >
            <Text style={styles.chevronText}>{'‹'}</Text>
          </TouchableOpacity>
        )}
        
        <ScrollView 
          ref={filterScrollRef}
          horizontal 
          showsHorizontalScrollIndicator={false} 
          style={styles.filterContainer}
          contentContainerStyle={styles.filterContentContainer}
          onScroll={handleFilterScroll}
          scrollEventThrottle={16}
          decelerationRate={0.95}
        >
          {['all', 'pending', 'approved', 'fulfilled', 'rejected'].map(f => (
            <TouchableOpacity 
              key={f} 
              style={[styles.filterBtn, filter === f && styles.filterBtnActive]} 
              onPress={() => setFilter(f as any)}
            >
              <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Right Chevron */}
        {showRightChevron && (
          <TouchableOpacity 
            style={[styles.chevronBtn, styles.chevronRight]} 
            onPress={() => scrollFilters('right')}
            activeOpacity={0.7}
          >
            <Text style={styles.chevronText}>{'›'}</Text>
          </TouchableOpacity>
        )}
      </View>


      <ScrollView refreshControl={<RefreshControl refreshing={loading} onRefresh={fetchData} />}>
        {filteredRequests.length === 0 ? (
          <Text style={styles.emptyText}>No requests found</Text>
        ) : (
          filteredRequests.map(request => (
            <View key={request.id} style={styles.card}>
              <View style={styles.cardHeader}>
                <Text style={styles.itemName}>{request.inventory_items?.item_name || 'Unknown Item'}</Text>
                <View style={[styles.statusBadge, { backgroundColor: getStatusColor(request.status) }]}>
                  <Text style={styles.statusText}>{request.status}</Text>
                </View>
              </View>
              <Text style={styles.quantity}>Quantity: {request.quantity_requested} {request.inventory_items?.unit}</Text>
              <Text style={styles.requestedBy}>Requested by: {request.requested_by}</Text>
              {request.reason && <Text style={styles.reason}>Reason: {request.reason}</Text>}
              {request.ref && <Text style={styles.reason}>Ref: {request.ref}</Text>}
              <Text style={styles.date}>{new Date(request.created_at).toLocaleString()}</Text>
              
              {canApprove && request.status === 'pending' && (
                <TouchableOpacity style={styles.approveBtn} onPress={() => handleApprove(request)}>
                  <Text style={styles.approveBtnText}>Approve Request</Text>
                </TouchableOpacity>
              )}

              {request.status === 'approved' && request.requested_by === user?.username && !request.acknowledged && (
                <TouchableOpacity 
                  style={styles.acknowledgeBtn} 
                  onPress={async () => {
                    try {
                      await supabase.from('stock_requests').update({
                        acknowledged: true,
                        status: 'fulfilled',
                        fulfilled_at: new Date().toISOString()
                      }).eq('id', request.id);

                      const currentQty = request.inventory_items?.quantity || 0;
                      await supabase.from('inventory_items').update({
                        quantity: currentQty - request.quantity_requested
                      }).eq('id', request.item_id);

                      await supabase.from('inventory_transactions').insert({
                        item_id: request.item_id,
                        transaction_type: 'out',
                        quantity: request.quantity_requested,
                        notes: `Stock request fulfilled - ${request.reason || 'No reason'}`,
                        created_by: user?.username || 'Unknown'
                      });

                      // Notify with permission check
                      const notificationTargets = ['admin', 'Lovena', 'KH', 'Ashok'];
                      for (const target of notificationTargets) {
                        const targetUserId = getUserIdFromUsername(target);
                        if (!targetUserId) continue;
                        
                        const hasPermission = await checkUserNotificationPermission(
                          targetUserId, 'stock_request_acknowledged', 'Stock Request Acknowledged', ''
                        );
                        if (!hasPermission) continue;
                        
                        await supabase.from('notifications').insert({
                          user_id: targetUserId,
                          title: 'Stock Request Acknowledged',
                          message: `${user?.username} has collected ${request.quantity_requested} ${request.inventory_items?.unit} of ${request.inventory_items?.item_name}`,
                          type: 'stock_request_acknowledged',
                          created_at: new Date().toISOString()
                        });
                      }

                      Alert.alert('Success', 'Item collected. Inventory updated.');
                      fetchData();
                    } catch (error: any) {
                      Alert.alert('Error', error.message);
                    }
                  }}
                >
                  <Text style={styles.acknowledgeBtnText}>Acknowledge & Collect Item</Text>
                </TouchableOpacity>
              )}




            </View>
          ))
        )}
      </ScrollView>



      <RequestStockModal
        visible={showRequestModal}
        onClose={() => setShowRequestModal(false)}
        inventoryItems={inventoryItems}
        onSuccess={fetchData}
      />

      <ApproveRequestModal
        visible={showApproveModal}
        onClose={() => setShowApproveModal(false)}
        request={selectedRequest}
        onSuccess={fetchData}
      />
    </SafeAreaView>
  );
}


const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between', 
    padding: 16, 
    backgroundColor: '#fff', 
    borderBottomWidth: 1, 
    borderBottomColor: '#ddd' 
  },
  backBtn: { padding: 8 },
  backText: { fontSize: 16, color: '#007AFF' },
  title: { fontSize: 20, fontWeight: 'bold' },
  headerRight: { flexDirection: 'row', gap: 8 },
  archiveBtn: { padding: 8, backgroundColor: '#666', borderRadius: 8 },
  archiveBtnText: { color: '#fff', fontWeight: '600' },
  newBtn: { padding: 8, backgroundColor: '#007AFF', borderRadius: 8 },
  newBtnText: { color: '#fff', fontWeight: '600' },
  
  // Filter wrapper with chevrons
  filterWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    position: 'relative',
  },
  filterContainer: { 
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 8,
  },
  filterContentContainer: {
    paddingHorizontal: 8,
    alignItems: 'center',
    paddingVertical: 4,
  },
  filterBtn: { 
    paddingHorizontal: 16, 
    paddingVertical: 10, 
    borderRadius: 20, 
    marginHorizontal: 4, 
    backgroundColor: '#f0f0f0', 
    minWidth: 80,
    alignItems: 'center',
    justifyContent: 'center',
  },
  filterBtnActive: { backgroundColor: '#007AFF' },
  filterText: { fontSize: 14, color: '#666', textAlign: 'center' },
  filterTextActive: { color: '#fff', fontWeight: '600' },
  
  // Chevron buttons
  chevronBtn: {
    width: 32,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    zIndex: 10,
  },
  chevronLeft: {
    borderRightWidth: 1,
    borderRightColor: '#e0e0e0',
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 0 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  chevronRight: {
    borderLeftWidth: 1,
    borderLeftColor: '#e0e0e0',
    shadowColor: '#000',
    shadowOffset: { width: -2, height: 0 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  chevronText: {
    fontSize: 24,
    color: '#007AFF',
    fontWeight: '300',
  },
  
  emptyText: { textAlign: 'center', marginTop: 40, fontSize: 16, color: '#666' },
  card: { 
    backgroundColor: '#fff', 
    margin: 12, 
    padding: 16, 
    borderRadius: 12, 
    shadowColor: '#000', 
    shadowOffset: { width: 0, height: 2 }, 
    shadowOpacity: 0.1, 
    shadowRadius: 4, 
    elevation: 3 
  },
  cardHeader: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    marginBottom: 8 
  },
  itemName: { fontSize: 18, fontWeight: 'bold', flex: 1 },
  statusBadge: { paddingHorizontal: 12, paddingVertical: 4, borderRadius: 12 },
  statusText: { color: '#fff', fontSize: 12, fontWeight: '600' },
  quantity: { fontSize: 16, marginBottom: 4 },
  requestedBy: { fontSize: 14, color: '#666', marginBottom: 4 },
  reason: { fontSize: 14, color: '#666', fontStyle: 'italic', marginBottom: 4 },
  date: { fontSize: 12, color: '#999', marginTop: 4 },
  approveBtn: { marginTop: 12, padding: 12, backgroundColor: '#34C759', borderRadius: 8 },
  approveBtnText: { textAlign: 'center', color: '#fff', fontWeight: '600', fontSize: 16 },
  acknowledgeBtn: { marginTop: 12, padding: 12, backgroundColor: '#007AFF', borderRadius: 8 },
  acknowledgeBtnText: { textAlign: 'center', color: '#fff', fontWeight: '600', fontSize: 16 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  loadingText: { marginTop: 12, fontSize: 16, color: '#666' },
  errorContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  errorTitle: { fontSize: 20, fontWeight: 'bold', color: '#FF3B30', marginBottom: 12 },
  errorText: { fontSize: 16, color: '#666', textAlign: 'center', marginBottom: 12 },
  errorInstructions: { fontSize: 14, color: '#666', textAlign: 'center', marginBottom: 8 },
  errorFile: { fontSize: 14, fontWeight: '600', color: '#007AFF', textAlign: 'center', marginBottom: 20 },
  retryBtn: { padding: 12, backgroundColor: '#007AFF', borderRadius: 8, paddingHorizontal: 24 },
  retryText: { color: '#fff', fontSize: 16, fontWeight: '600' }
});
