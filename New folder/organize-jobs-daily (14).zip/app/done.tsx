import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  Image,
  Modal,
  TextInput,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

import { supabase } from './lib/supabase';

import { useJobs, ItemStatus } from '../contexts/JobContext';
import { useSettings } from '../contexts/SettingsContext';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import { Ionicons } from '@expo/vector-icons';

import SettingsModal from '../components/SettingsModal';
import ItemOptionsDisplay from '../components/ItemOptionsDisplay';
import DailyProductionPreviewModal from '../components/DailyProductionPreviewModal';
import RestorePasswordModal from '../components/RestorePasswordModal';
import SelectiveRevertModal from '../components/SelectiveRevertModal';
import DeliveredCheckbox from '../components/DeliveredCheckbox';
import { saveDailyProductionPDF } from '../utils/dailyProductionExport';
import SearchBar from '../components/SearchBar';
import { saveCustomerNote } from '../utils/customerNoteHelper';

import { checkAndPerformAutoArchive } from '../utils/autoArchiveScheduler';
import { useTaskState } from '../hooks/useTaskState';

const VIEWED_JOBS_KEY = '@viewed_jobs';

// Task configuration for this screen
const TASK_CONFIG = {
  route: '/done',
  title: 'Completed Jobs',
  icon: 'checkmark-done-circle',
  color: '#10B981'
};

interface DoneTaskData {
  searchQuery: string;
  pickupNoteFilter: 'all' | 'with-notes' | 'without-notes';
  expandedJobs: string[];
}

export default function DoneScreen() {
  const { jobs, archiveJob, revertSelectedItemsToWIP } = useJobs();

  const { autoArchiveEnabled, autoArchiveTime, pdfSaveLocation, newBadgeEnabled } = useSettings();
  const { user } = usePasswordAuth();
  const doneJobs = jobs.filter(job => job.status === 'done');

  // Initialize task state management
  const { savedData, saveTaskData, markAsSaved } = useTaskState<DoneTaskData>(TASK_CONFIG);

  // State declarations must come before useMemo that depends on them
  const [searchQuery, setSearchQuery] = useState(savedData?.searchQuery || '');
  const [showSettings, setShowSettings] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [showRestoreModal, setShowRestoreModal] = useState(false);
  const [showSelectiveRevertModal, setShowSelectiveRevertModal] = useState(false);
  const [selectedJobForRestore, setSelectedJobForRestore] = useState<{ id: string; jobNumber: string; items: any[] } | null>(null);
  const [expandedJobs, setExpandedJobs] = useState<Set<string>>(new Set(savedData?.expandedJobs || []));
  const [customerNotes, setCustomerNotes] = useState<Record<string, string>>({});
  const [pickupNoteFilter, setPickupNoteFilter] = useState<'all' | 'with-notes' | 'without-notes'>(savedData?.pickupNoteFilter || 'all');
  const [viewedJobs, setViewedJobs] = useState<Set<string>>(new Set());
  const saveTimeouts = useRef<Record<string, any>>({});

  // Save task data when filters change
  useEffect(() => {
    const hasChanges = searchQuery !== '' || pickupNoteFilter !== 'all' || expandedJobs.size > 0;
    saveTaskData({ 
      searchQuery, 
      pickupNoteFilter,
      expandedJobs: Array.from(expandedJobs)
    }, hasChanges);
  }, [searchQuery, pickupNoteFilter, expandedJobs]);



  // Load viewed jobs from AsyncStorage
  useEffect(() => {
    const loadViewedJobs = async () => {
      try {
        const stored = await AsyncStorage.getItem(VIEWED_JOBS_KEY);
        if (stored) {
          setViewedJobs(new Set(JSON.parse(stored)));
        }
      } catch (error) {
        console.error('Error loading viewed jobs:', error);
      }
    };
    loadViewedJobs();
  }, []);

  // Clean up old viewed jobs (remove jobs that no longer exist in doneJobs)
  useEffect(() => {
    const cleanupViewedJobs = async () => {
      const currentJobIds = new Set(doneJobs.map(j => j.id));
      const stored = await AsyncStorage.getItem(VIEWED_JOBS_KEY);
      if (stored) {
        const viewedArray = JSON.parse(stored);
        const cleaned = viewedArray.filter((id: string) => currentJobIds.has(id));
        if (cleaned.length !== viewedArray.length) {
          await AsyncStorage.setItem(VIEWED_JOBS_KEY, JSON.stringify(cleaned));
          setViewedJobs(new Set(cleaned));
        }
      }
    };
    cleanupViewedJobs();
  }, [doneJobs]);

  // Mark job as viewed
  const markJobAsViewed = async (jobId: string) => {
    setViewedJobs(prev => {
      const newSet = new Set(prev);
      if (!newSet.has(jobId)) {
        newSet.add(jobId);
        AsyncStorage.setItem(VIEWED_JOBS_KEY, JSON.stringify(Array.from(newSet))).catch(err => 
          console.error('Error saving viewed jobs:', err)
        );
      }
      return newSet;
    });
  };

  const newJobsCount = useMemo(() => {
    return doneJobs.filter(job => {
      // Don't show as new if job has customer pickup note (already viewed)
      const hasPickupNote = (job as any).customer_pickup_note && (job as any).customer_pickup_note.trim().length > 0;
      return !hasPickupNote && !viewedJobs.has(job.id);
    }).length;
  }, [doneJobs, viewedJobs]);










  // WIP status options


  // WIP status options
  const wipStatuses: ItemStatus[] = ['Pending', 'Workshop', 'Acid', 'Galva', 'Finishing', 'Ready'];
  const statusColors: Record<ItemStatus, string> = {
    'Pending': '#9CA3AF',
    'Workshop': '#3B82F6',
    'Acid': '#F59E0B',
    'Galva': '#8B5CF6',
    'Finishing': '#EC4899',
    'Ready': '#059669'
  };




  const sortedDoneJobs = useMemo(() => {
    return [...doneJobs].sort((a, b) => {
      const numA = parseInt(a.jobNumber.replace(/\D/g, '')) || 0;
      const numB = parseInt(b.jobNumber.replace(/\D/g, '')) || 0;
      return numA - numB;
    });
  }, [doneJobs]);


  // Filter done jobs based on search query and pickup note filter
  const filteredDoneJobs = useMemo(() => {
    let filtered = sortedDoneJobs;
    
    // Apply pickup note filter
    if (pickupNoteFilter === 'with-notes') {
      filtered = filtered.filter(job => {
        const note = (job as any).customer_pickup_note || customerNotes[job.id] || '';
        return note.trim().length > 0;
      });
    } else if (pickupNoteFilter === 'without-notes') {
      filtered = filtered.filter(job => {
        const note = (job as any).customer_pickup_note || customerNotes[job.id] || '';
        return note.trim().length === 0;
      });
    }
    
    // Apply search query filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(job => {
        return (
          job.jobNumber.toLowerCase().includes(query) ||
          job.customerName.toLowerCase().includes(query) ||
          job.items.some(item => item.descriptionOfWorks.toLowerCase().includes(query))
        );
      });
    }
    
    return filtered;
  }, [sortedDoneJobs, searchQuery, pickupNoteFilter, customerNotes]);




  // Load customer notes from job data and sync with realtime updates
  useEffect(() => {
    const notesMap: Record<string, string> = {};
    doneJobs.forEach(job => {
      if ((job as any).customer_pickup_note) {
        // Only update if there's no pending save for this job (user not actively typing)
        if (!saveTimeouts.current[job.id]) {
          notesMap[job.id] = (job as any).customer_pickup_note;
        }
      }
    });
    // Only update state for jobs that don't have pending saves
    setCustomerNotes(prev => {
      const updated = { ...prev };
      Object.keys(notesMap).forEach(jobId => {
        if (!saveTimeouts.current[jobId]) {
          updated[jobId] = notesMap[jobId];
        }
      });
      return updated;
    });
  }, [doneJobs]);





  useEffect(() => {
    checkAndPerformAutoArchive(archiveJob, doneJobs, autoArchiveEnabled, autoArchiveTime);
    const interval = setInterval(() => {
      checkAndPerformAutoArchive(archiveJob, doneJobs, autoArchiveEnabled, autoArchiveTime);
    }, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [doneJobs, archiveJob, autoArchiveEnabled, autoArchiveTime]);



  const totalWeight = useMemo(() => {
    return doneJobs.reduce((total, job) => {
      return total + job.items.reduce((sum, item) => 
        sum + parseFloat(item.weightKg || '0'), 0
      );
    }, 0);
  }, [doneJobs]);

  const calculateTotalWeight = (items: any[]) => {
    return items.reduce((sum, item) => sum + parseFloat(item.weightKg || '0'), 0);
  };

  const handleDailyProductionPreview = () => {
    if (doneJobs.length === 0) {
      Alert.alert('No Jobs', 'No completed jobs to export');
      return;
    }
    setShowPreviewModal(true);
  };

  const handleExport = async () => {
    setShowPreviewModal(false);
    
    try {
      // Automatically save PDF to the configured location
      const filePath = await saveDailyProductionPDF(sortedDoneJobs, pdfSaveLocation);
      console.log('PDF saved successfully to:', filePath);
    } catch (error) {
      console.error('Error saving PDF:', error);
      Alert.alert('Error', `Failed to save PDF: ${error.message || 'Unknown error'}`);
    }
  };

  const handleRestoreClick = (job: any) => {
    console.log('🔄 Restore button clicked for job:', job.jobNumber);
    setSelectedJobForRestore({ id: job.id, jobNumber: job.jobNumber, items: job.items });
    setShowRestoreModal(true);
    console.log('✅ Password modal should now be visible');
  };


  const handleRestoreConfirm = async (password: string) => {
    if (!selectedJobForRestore) return;

    if (password === '4321') {
      // Password correct - close password modal and open selective revert modal
      setShowRestoreModal(false);
      setShowSelectiveRevertModal(true);
    } else {
      Alert.alert('Error', 'Incorrect password');
    }
  };

  const handleSelectiveRevert = async (selectedItemIds: string[], targetStatus: ItemStatus) => {
    if (!selectedJobForRestore) return;

    try {
      await revertSelectedItemsToWIP(selectedJobForRestore.id, selectedItemIds, targetStatus);
      Alert.alert('Success', `${selectedItemIds.length} item(s) reverted to ${targetStatus}`);
      setShowSelectiveRevertModal(false);
      setSelectedJobForRestore(null);
    } catch (error) {
      Alert.alert('Error', `Failed to revert items: ${error.message}`);
    }
  };

  const handleRestoreCancel = () => {
    setShowRestoreModal(false);
    setSelectedJobForRestore(null);
  };

  const handleSelectiveRevertCancel = () => {
    setShowSelectiveRevertModal(false);
    setSelectedJobForRestore(null);
  };
  const toggleJobExpanded = (jobId: string) => {
    // Mark as viewed when expanded
    markJobAsViewed(jobId);
    
    setExpandedJobs(prev => {
      const newSet = new Set(prev);
      if (newSet.has(jobId)) {
        newSet.delete(jobId);
      } else {
        newSet.add(jobId);
      }
      return newSet;
    });
  };




  // Handle customer note text change with debounced save
  const handleCustomerNoteChange = (jobId: string, text: string) => {
    // Mark as viewed when text is entered
    if (text.trim().length > 0) {
      markJobAsViewed(jobId);
    }
    
    // Update local state immediately for responsive typing
    setCustomerNotes(prev => ({ ...prev, [jobId]: text }));
    
    // Clear existing timeout for this job
    if (saveTimeouts.current[jobId]) {
      clearTimeout(saveTimeouts.current[jobId]);
    }
    
    // Set new timeout to save after 1 second of no typing
    const timeoutId = setTimeout(() => {
      saveCustomerNoteToDatabase(jobId, text);
    }, 1000);
    
    saveTimeouts.current[jobId] = timeoutId;
  };


  const saveCustomerNoteToDatabase = async (jobId: string, note: string) => {
    try {
      await saveCustomerNote(jobId, note);
      // Clear the timeout reference after successful save
      delete saveTimeouts.current[jobId];
    } catch (error: any) {
      console.error('Error saving customer note:', error?.message || 'Unknown error');
    }
  };









  const renderJob = ({ item }: any) => {
    const isExpanded = expandedJobs.has(item.id);
    // Don't show NEW badge if job has customer pickup note (already viewed)
    const hasPickupNote = (item as any).customer_pickup_note && (item as any).customer_pickup_note.trim().length > 0;
    const isNew = newBadgeEnabled && !hasPickupNote && !viewedJobs.has(item.id);
    

    return (
      <View style={styles.jobCard}>
        <View style={styles.jobContent}>
          <TouchableOpacity 
            style={styles.jobMainInfo}
            onPress={() => toggleJobExpanded(item.id)}
            activeOpacity={0.7}
          >
            <View style={{ flex: 1 }}>
              <View style={styles.jobTitleRow}>
                <Text style={styles.jobNumber}>{item.jobNumber}</Text>
                {item.galvaXpress && (
                  <View style={styles.badgeGalvXpress}>
                    <Text style={styles.badgeText}>GalvXpress</Text>
                  </View>
                )}
                {isNew && (
                  <View style={styles.badgeNew}>
                    <Text style={styles.badgeNewText}>NEW</Text>
                  </View>
                )}
              </View>
              <Text style={styles.customerName}>{item.customerName}</Text>
            </View>
            <Ionicons 
              name={isExpanded ? "chevron-up" : "chevron-down"} 
              size={24} 
              color="#6B7280" 
            />
          </TouchableOpacity>



          {isExpanded && (
            <>
              <View style={styles.expandedContent}>
                <Text style={styles.dateText}>
                  Completed: {item.completedDate ? new Date(item.completedDate).toLocaleDateString('en-GB') : new Date().toLocaleDateString('en-GB')}
                </Text>
                
                <View style={styles.itemsSection}>
                  <Text style={styles.sectionTitle}>Items ({item.items.length})</Text>
                  {item.items.map((subItem: any) => (
                    <View key={subItem.id} style={styles.itemRow}>
                      <View style={{ flex: 1 }}>
                        {subItem.itemCount && (
                          <Text style={styles.itemCount}>Qty: {subItem.itemCount}</Text>
                        )}
                        <Text style={styles.itemText}>{subItem.descriptionOfWorks}</Text>
                        <ItemOptionsDisplay item={subItem} />
                      </View>
                      <Text style={styles.weightText}>{subItem.weightKg} kg</Text>
                    </View>
                  ))}


                  <View style={styles.totalRow}>
                    <Text style={styles.totalLabel}>Total Weight:</Text>
                    <Text style={styles.totalValue}>{calculateTotalWeight(item.items).toFixed(1)} kg</Text>
                  </View>
                </View>
              </View>
            </>
          )}
          {/* Hide delivered checkbox for Ashok */}
          {user?.username !== 'Ashok' && (
            <View style={styles.deliveredSection}>
              <DeliveredCheckbox jobId={item.id} onToggle={() => markJobAsViewed(item.id)} />
            </View>

          )}

          <View style={styles.customerNoteSection}>
            <Text style={styles.noteLabel}>Customer Pickup Note:</Text>
            <TextInput
              style={styles.noteInput}
              placeholder="input text here"

              value={customerNotes[item.id] || ''}
              onChangeText={(text) => handleCustomerNoteChange(item.id, text)}

              multiline
            />
          </View>

        </View>

        {/* Hide revert button for Ashok and Ikhlaas */}
        {user?.username !== 'Ashok' && user?.username !== 'Ikhlaas' && (
          <TouchableOpacity 
            style={styles.unarchiveIconBtn} 
            onPress={() => handleRestoreClick(item)}
          >
            <Ionicons name="arrow-undo" size={18} color="#fff" />
          </TouchableOpacity>
        )}
      </View>
    );
  };












  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Image 
          source={{ uri: 'https://d64gsuwffb70l.cloudfront.net/6826def9056908ac6c0eb35d_1759490551243_ee723b3c.jpg' }}
          style={styles.logo}
          resizeMode="contain"
        />
        <View style={styles.headerRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.headerTitle}>Completed Jobs</Text>
            <Text style={styles.headerSubtitle}>
              {doneJobs.length} job(s) • {totalWeight.toFixed(1)} kg total
            </Text>
            {autoArchiveEnabled && (
              <View style={styles.autoArchiveBadge}>
                <Ionicons name="time-outline" size={12} color="#10B981" />
                <Text style={styles.autoArchiveText}>Auto-archive at {autoArchiveTime}</Text>
              </View>
            )}
          </View>
          <View style={styles.headerButtons}>
            {(user?.role === 'admin' || user?.username === 'KH' || user?.username === 'Lovena') && (
              <TouchableOpacity onPress={() => setShowSettings(true)} style={styles.settingsBtn}>
                <Ionicons name="settings-outline" size={22} color="#fff" />
              </TouchableOpacity>
            )}

          </View>
        </View>
      </View>







      <SearchBar
        value={searchQuery}
        onChangeText={setSearchQuery}
        placeholder="Search by job number, customer, or item..."
      />

      {/* Filter chips for pickup notes */}
      <View style={styles.filterChipsContainer}>
        <TouchableOpacity
          style={[styles.filterChip, pickupNoteFilter === 'all' && styles.filterChipActive]}
          onPress={() => setPickupNoteFilter('all')}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
            <Text style={[styles.filterChipText, pickupNoteFilter === 'all' && styles.filterChipTextActive]}>
              All Jobs
            </Text>
            {newJobsCount > 0 && (
              <View style={styles.newBadge}>
                <Text style={styles.newBadgeText}>{newJobsCount}</Text>
              </View>
            )}
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.filterChip, pickupNoteFilter === 'with-notes' && styles.filterChipActive]}
          onPress={() => setPickupNoteFilter('with-notes')}
        >
          <Text style={[styles.filterChipText, pickupNoteFilter === 'with-notes' && styles.filterChipTextActive]}>
            With Notes
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.filterChip, pickupNoteFilter === 'without-notes' && styles.filterChipActive]}
          onPress={() => setPickupNoteFilter('without-notes')}
        >
          <Text style={[styles.filterChipText, pickupNoteFilter === 'without-notes' && styles.filterChipTextActive]}>
            Without Notes
          </Text>
        </TouchableOpacity>
      </View>





      <FlatList
        data={filteredDoneJobs}

        renderItem={renderJob}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Ionicons name="clipboard-outline" size={64} color="#D1D5DB" />
            <Text style={styles.emptyText}>
              {searchQuery ? 'No jobs match your search' : 'No completed jobs yet'}
            </Text>
          </View>
        }
      />


      <SettingsModal visible={showSettings} onClose={() => setShowSettings(false)} />
      <DailyProductionPreviewModal
        visible={showPreviewModal}
        onClose={() => setShowPreviewModal(false)}
        jobs={sortedDoneJobs.map(job => ({
          id: job.id,
          job_number: job.jobNumber,
          customer_name: job.customerName,
          date_of_entry: job.dateOfEntry.toISOString(),
          completed_date: job.completedDate?.toISOString(),
          items: job.items.map(item => ({
            description: item.descriptionOfWorks,
            weight: parseFloat(item.weightKg || '0'),
            paint_varnish: item.paintVarnish,
            galva: item.galva,
            light_galva: item.lightGalva,
            light_paint: item.lightPaint,
            rusty: item.rusty
          }))
        }))}
        onExport={handleExport}

      />

      <RestorePasswordModal
        visible={showRestoreModal}
        jobNumber={selectedJobForRestore?.jobNumber || ''}
        onConfirm={handleRestoreConfirm}
        onCancel={handleRestoreCancel}
      />

      <SelectiveRevertModal
        visible={showSelectiveRevertModal}
        jobNumber={selectedJobForRestore?.jobNumber || ''}
        items={selectedJobForRestore?.items || []}
        onConfirm={handleSelectiveRevert}
        onCancel={handleSelectiveRevertCancel}
      />


    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { backgroundColor: 'white', padding: 20, paddingTop: 12, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  logo: { width: '100%', height: 60, marginBottom: 12 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  headerTitle: { fontSize: 24, fontWeight: 'bold', color: '#1F2937' },
  headerSubtitle: { fontSize: 14, color: '#6B7280', marginTop: 4 },
  autoArchiveBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 6, backgroundColor: '#D1FAE5', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, alignSelf: 'flex-start' },
  autoArchiveText: { fontSize: 11, color: '#10B981', fontWeight: '600' },
  headerButtons: { flexDirection: 'row', gap: 10 },
  settingsBtn: { backgroundColor: '#8B5CF6', padding: 10, borderRadius: 8 },
  filterChipsContainer: { flexDirection: 'row', paddingHorizontal: 16, paddingVertical: 12, gap: 8, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  filterChip: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB' },
  filterChipActive: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  filterChipText: { fontSize: 13, fontWeight: '600', color: '#6B7280' },
  filterChipTextActive: { color: '#FFFFFF' },
  newBadge: { backgroundColor: '#EF4444', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 10, minWidth: 20, alignItems: 'center' },
  newBadgeText: { fontSize: 10, fontWeight: '700', color: '#FFFFFF' },
  badgeNew: { backgroundColor: '#EF4444', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8 },
  badgeNewText: { fontSize: 10, fontWeight: '700', color: '#FFFFFF' },
  listContent: { paddingHorizontal: 16, paddingTop: 16, paddingBottom: 100 },
  jobCard: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3, flexDirection: 'row', gap: 12 },
  jobContent: { flex: 1 },
  jobMainInfo: { flexDirection: 'row', alignItems: 'center', paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  jobTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  jobNumber: { fontSize: 20, fontWeight: 'bold', color: '#1F2937' },
  badgeGalvXpress: { backgroundColor: '#FEF3C7', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8 },
  badgeText: { fontSize: 10, fontWeight: '600', color: '#92400E' },
  customerName: { fontSize: 16, color: '#374151', marginTop: 4 },
  expandedContent: { paddingTop: 12 },
  dateText: { fontSize: 12, color: '#6B7280', marginBottom: 8 },
  itemsSection: { backgroundColor: '#F9FAFB', borderRadius: 8, padding: 12, marginTop: 8 },
  sectionTitle: { fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 8 },
  itemRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4, alignItems: 'flex-start' },
  itemCount: { fontSize: 12, color: '#3B82F6', fontWeight: '600', marginBottom: 2 },
  itemText: { flex: 1, fontSize: 13, color: '#6B7280' },
  weightText: { fontSize: 13, color: '#6B7280', fontWeight: '500' },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8, paddingTop: 8, borderTopWidth: 1, borderTopColor: '#E5E7EB' },
  totalLabel: { fontSize: 14, fontWeight: '600', color: '#374151' },
  totalValue: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' },
  deliveredSection: { marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: '#E5E7EB' },
  customerNoteSection: { marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: '#E5E7EB' },
  noteLabel: { fontSize: 13, fontWeight: '600', color: '#374151', marginBottom: 6 },
  noteInput: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 10, fontSize: 13, color: '#374151', minHeight: 60, textAlignVertical: 'top' },
  unarchiveIconBtn: { backgroundColor: '#F59E0B', width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', alignSelf: 'flex-start' },
  emptyContainer: { alignItems: 'center', marginTop: 100 },
  emptyText: { fontSize: 16, color: '#9CA3AF', marginTop: 12 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { backgroundColor: 'white', borderRadius: 20, padding: 20, width: '80%', maxWidth: 400 },
  modalTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 8, textAlign: 'center', color: '#1F2937' },
  modalSubtitle: { fontSize: 14, color: '#6B7280', marginBottom: 20, textAlign: 'center' },
  statusOption: { padding: 16, borderLeftWidth: 4, marginBottom: 8, backgroundColor: '#F9FAFB', borderRadius: 8 },
  statusOptionText: { fontSize: 16, color: '#374151', fontWeight: '500' },
  cancelButton: { marginTop: 12, padding: 12, alignItems: 'center' },
  cancelButtonText: { color: '#6B7280', fontSize: 16, fontWeight: '600' }
});





