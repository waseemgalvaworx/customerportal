import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  SectionList,

  TouchableOpacity,
  Modal,
  ScrollView,
  Alert,
} from 'react-native';

import { useJobs, ItemStatus, Job } from '../contexts/JobContext';
import { Ionicons } from '@expo/vector-icons';
import ItemOptionsDisplay from '../components/ItemOptionsDisplay';
import SearchBar from '../components/SearchBar';
import { useSettings } from '../contexts/SettingsContext';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import { useRouter } from 'expo-router';
import StatusQCModal from '../components/StatusQCModal';
import PriorityBadge from '../components/PriorityBadge';
import DeliveryCountdown from '../components/DeliveryCountdown';
import StatusFilterModal from '../components/StatusFilterModal';
import { useTaskState } from '../hooks/useTaskState';

// Task configuration for this screen
const TASK_CONFIG = {
  route: '/wip',
  title: 'Work in Progress',
  icon: 'construct',
  color: '#3B82F6'
};

interface WipTaskData {
  searchQuery: string;
  selectedDate: string | null;
  selectedItems: string[];
}

export default function WipScreen() {
  const router = useRouter();
  const { jobs, updateItemStatus, updateMultipleItemStatuses } = useJobs();
  const { 
    pdfSaveLocation, 
    wipViewMode, 
    wipActiveFilter, 
    wipStatusFilter,
    setWipViewMode,
    setWipActiveFilter,
    setWipStatusFilter
  } = useSettings();
  const { user } = usePasswordAuth();

  // Initialize task state management
  const { savedData, saveTaskData, markAsSaved } = useTaskState<WipTaskData>(TASK_CONFIG);

  // Date filter state
  const scrollViewRef = useRef<ScrollView>(null);
  const [scrollOffset, setScrollOffset] = useState(0);
  const [selectedDate, setSelectedDate] = useState<string | null>(savedData?.selectedDate || null);

  const [selectedItems, setSelectedItems] = useState<Set<string>>(
    new Set(savedData?.selectedItems || [])
  );
  const [statusModalVisible, setStatusModalVisible] = useState(false);
  const [confirmModalVisible, setConfirmModalVisible] = useState(false);
  const [pendingReadyItems, setPendingReadyItems] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState(savedData?.searchQuery || '');
  const [qcModalVisible, setQcModalVisible] = useState(false);
  const [pendingStatus, setPendingStatus] = useState<ItemStatus | null>(null);
  const [currentQCItem, setCurrentQCItem] = useState<{jobId: string, itemId: string, itemName: string, jobNumber: string} | null>(null);
  const [statusFilterModalVisible, setStatusFilterModalVisible] = useState(false);

  // Save task data when search, date filter, or selected items change
  useEffect(() => {
    const hasChanges = searchQuery !== '' || selectedDate !== null || selectedItems.size > 0;
    saveTaskData({ 
      searchQuery, 
      selectedDate, 
      selectedItems: Array.from(selectedItems) 
    }, hasChanges);
  }, [searchQuery, selectedDate, selectedItems]);


  const canModify = user?.permissions.wipModify || false;
  const isAdmin = user?.permissions.admin || false;


  const wipJobs = jobs.filter(job => job.status === 'planning');

  // Calculate overall status statistics
  const statusStats = useMemo(() => {
    const stats: Record<ItemStatus, number> = {
      'Pending': 0,
      'Workshop': 0,
      'Acid': 0,
      'Galva': 0,
      'Finishing': 0,
      'Ready': 0
    };
    
    wipJobs.forEach(job => {
      job.items.forEach(item => {
        stats[item.status]++;
      });
    });
    
    const total = Object.values(stats).reduce((sum, count) => sum + count, 0);
    
    return { stats, total };
  }, [wipJobs]);

  // Calculate GalvXpress and High Priority counts
  const galvXpressCount = useMemo(() => {
    return wipJobs.filter(j => j.galvaXpress).length;
  }, [wipJobs]);

  const highPriorityCount = useMemo(() => {
    return wipJobs.filter(j => j.priority === 'high').length;
  }, [wipJobs]);


  // Filter and sort jobs
  const filteredJobs = useMemo(() => {
    let filtered = wipJobs.filter(job => {
      const query = searchQuery.toLowerCase();
      const matchesSearch = (
        job.jobNumber.toLowerCase().includes(query) ||
        job.customerName.toLowerCase().includes(query) ||
        job.items.some(item => item.descriptionOfWorks.toLowerCase().includes(query))
      );
      
      // Apply status filter
      const matchesStatus = wipStatusFilter === 'all' || job.items.some(item => item.status === wipStatusFilter);
      
      return matchesSearch && matchesStatus;
    });

    // Apply priority/galvaxpress filter
    if (wipActiveFilter === 'galvaxpress') {
      filtered = filtered.filter(j => j.galvaXpress);
    } else if (wipActiveFilter === 'high') {
      filtered = filtered.filter(j => j.priority === 'high');
    }

    
    // Sort by priority and delivery date
    return filtered.sort((a, b) => {
      // GalvXpress first
      if (a.galvaXpress && !b.galvaXpress) return -1;
      if (!a.galvaXpress && b.galvaXpress) return 1;
      
      // Then by priority
      const priorityOrder = { high: 0, medium: 1, low: 2 };
      const aPriority = priorityOrder[a.priority || 'low'];
      const bPriority = priorityOrder[b.priority || 'low'];
      if (aPriority !== bPriority) return aPriority - bPriority;
      
      // Then by delivery date
      if (a.deliveryDate && b.deliveryDate) {
        return new Date(a.deliveryDate).getTime() - new Date(b.deliveryDate).getTime();
      }
      if (a.deliveryDate) return -1;
      if (b.deliveryDate) return 1;
      
      return a.jobNumber.localeCompare(b.jobNumber);
    });
  }, [wipJobs, searchQuery, wipActiveFilter, wipStatusFilter]);

  // Generate date tabs from filtered jobs
  const dateTabs = useMemo(() => {
    const tabs = new Map<string, number>();
    filteredJobs.forEach(job => {
      if (job.deliveryDate) {
        const date = new Date(job.deliveryDate);
        const key = date.toISOString().split('T')[0];
        tabs.set(key, (tabs.get(key) || 0) + 1);
      }
    });
    return Array.from(tabs.entries()).map(([date, count]) => ({ date, count })).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [filteredJobs]);

  // Apply date filter to get displayed jobs
  let displayedJobs = filteredJobs;
  
  if (selectedDate) {
    displayedJobs = displayedJobs.filter(job => 
      job.deliveryDate && new Date(job.deliveryDate).toISOString().split('T')[0] === selectedDate
    );
  }

  const formatTabDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const today = new Date(); today.setHours(0,0,0,0);
    const tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate() + 1);
    const dateOnly = new Date(date); dateOnly.setHours(0,0,0,0);
    if (dateOnly.getTime() === today.getTime()) return 'Today';
    if (dateOnly.getTime() === tomorrow.getTime()) return 'Tomorrow';
    return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  };


  // Group jobs by delivery date (use displayedJobs after date filter)
  const jobsByDate = useMemo(() => {
    const grouped = new Map<string, typeof displayedJobs>();
    const noDateJobs: typeof displayedJobs = [];
    
    displayedJobs.forEach(job => {
      if (job.deliveryDate) {
        const date = new Date(job.deliveryDate);
        const dateKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
        if (!grouped.has(dateKey)) {
          grouped.set(dateKey, []);
        }
        grouped.get(dateKey)!.push(job);
      } else {
        noDateJobs.push(job);
      }
    });

    const sortedDates = Array.from(grouped.keys()).sort();
    const sections = sortedDates.map(dateKey => ({
      title: dateKey,
      data: grouped.get(dateKey)!
    }));

    if (noDateJobs.length > 0) {
      sections.push({ title: 'no-date', data: noDateJobs });
    }

    return sections;
  }, [displayedJobs]);

  // Group jobs by item status
  const jobsByStatus = useMemo(() => {
    const statusOrder: ItemStatus[] = ['Ready', 'Finishing', 'Galva', 'Acid', 'Workshop', 'Pending'];


    const grouped = new Map<ItemStatus, typeof filteredJobs>();
    
    // Initialize all status groups
    statusOrder.forEach(status => {
      grouped.set(status, []);
    });
    
    // Group jobs by their items' statuses
    filteredJobs.forEach(job => {
      const jobStatuses = new Set(job.items.map(item => item.status));
      jobStatuses.forEach(status => {
        if (!grouped.get(status)!.includes(job)) {
          grouped.get(status)!.push(job);
        }
      });
    });
    
    // Convert to sections array, only including statuses with jobs
    const sections = statusOrder
      .filter(status => grouped.get(status)!.length > 0)
      .map(status => ({
        title: status,
        data: grouped.get(status)!
      }));
    
    return sections;
  }, [filteredJobs]);

  const formatSectionTitle = (dateKey: string) => {
    if (dateKey === 'no-date') return 'No Delivery Date Set';
    
    const date = new Date(dateKey);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const isToday = date.toDateString() === today.toDateString();
    const isTomorrow = date.toDateString() === tomorrow.toDateString();
    
    const dayName = date.toLocaleDateString('en-US', { weekday: 'long' });
    const formatted = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    
    if (isToday) return `Today - ${dayName}, ${formatted}`;
    if (isTomorrow) return `Tomorrow - ${dayName}, ${formatted}`;
    return `${dayName}, ${formatted}`;
  };



  const statuses: ItemStatus[] = ['Pending', 'Workshop', 'Acid', 'Galva', 'Finishing', 'Ready'];

  const statusColors: Record<ItemStatus, string> = {
    'Pending': '#9CA3AF',
    'Workshop': '#3B82F6',
    'Acid': '#F59E0B',
    'Galva': '#8B5CF6',
    'Finishing': '#EC4899',
    'Ready': '#059669'
  };

  // Status progression validation
  const getNextValidStatus = (currentStatus: ItemStatus): ItemStatus | null => {
    const statusOrder: ItemStatus[] = ['Pending', 'Workshop', 'Acid', 'Galva', 'Finishing', 'Ready'];
    const currentIndex = statusOrder.indexOf(currentStatus);
    if (currentIndex === -1 || currentIndex === statusOrder.length - 1) {
      return null; // Invalid status or already at the end
    }
    return statusOrder[currentIndex + 1];
  };

  const validateStatusTransition = (currentStatus: ItemStatus, newStatus: ItemStatus): boolean => {
    const nextValidStatus = getNextValidStatus(currentStatus);
    return nextValidStatus === newStatus;
  };

  const getStatusOrderMessage = (): string => {
    return 'Status must progress in order: Pending → Workshop → Acid → Galva → Finishing → Ready';
  };

  // Get valid statuses for currently selected items
  const getValidStatusesForSelection = (): ItemStatus[] => {
    if (selectedItems.size === 0) return [];

    // If admin, return all statuses
    if (isAdmin) {
      return statuses;
    }

    const selectedItemsData = Array.from(selectedItems).map(key => {
      const [jobId, itemId] = key.split('|||');
      const job = jobs.find(j => j.id === jobId);
      const item = job?.items.find(i => i.id === itemId);
      return item;
    }).filter(item => item !== undefined);

    if (selectedItemsData.length === 0) return [];

    // Get the next valid status for each selected item
    const validStatusSets = selectedItemsData.map(item => {
      const nextStatus = getNextValidStatus(item!.status);
      return nextStatus ? [nextStatus] : [];
    });

    // Find intersection - only statuses valid for ALL selected items
    if (validStatusSets.length === 0) return [];
    
    const intersection = validStatusSets[0].filter(status => 
      validStatusSets.every(set => set.includes(status))
    );

    return intersection;
  };




  const toggleItemSelection = (jobId: string, itemId: string) => {
    if (!canModify) {
      Alert.alert('Permission Denied', 'You do not have permission to modify job statuses.');
      return;
    }
    const key = `${jobId}|||${itemId}`;
    const newSelected = new Set(selectedItems);
    if (newSelected.has(key)) {
      newSelected.delete(key);
    } else {
      newSelected.add(key);
    }
    setSelectedItems(newSelected);
  };



  // Check if a status requires QC
  const requiresQC = (status: ItemStatus): boolean => {
    // Only these statuses require QC
    return ['Workshop', 'Acid', 'Finishing', 'Ready'].includes(status);
  };

  const handleStatusSelection = (status: ItemStatus) => {
    // Validate that this status is allowed for all selected items (only for non-admin)
    const validStatuses = getValidStatusesForSelection();
    if (!isAdmin && !validStatuses.includes(status)) {
      Alert.alert(
        'Invalid Status Transition',
        `Cannot skip statuses. ${getStatusOrderMessage()}`,
        [{ text: 'OK' }]
      );
      return;
    }

    // Check if this is a status reversion (going backwards)
    const isReversion = () => {
      if (!isAdmin) return false; // Only admins can revert
      
      const statusOrder: ItemStatus[] = ['Pending', 'Workshop', 'Acid', 'Galva', 'Finishing', 'Ready'];
      const newStatusIndex = statusOrder.indexOf(status);
      
      // Check if any selected item has a higher status than the target
      for (const key of Array.from(selectedItems)) {
        const [jobId, itemId] = key.split('|||');
        const job = jobs.find(j => j.id === jobId);
        const item = job?.items.find(i => i.id === itemId);
        if (item) {
          const currentStatusIndex = statusOrder.indexOf(item.status);
          if (currentStatusIndex > newStatusIndex) {
            return true; // This is a reversion
          }
        }
      }
      return false;
    };

    // If admin is reverting status, skip QC and update directly
    if (isAdmin && isReversion()) {
      updateSelectedStatus(status);
      return;
    }

    // Check if single item AND status requires QC - show QC modal first
    if (selectedItems.size === 1 && requiresQC(status)) {
      const key = Array.from(selectedItems)[0];
      const [jobId, itemId] = key.split('|||');
      const job = jobs.find(j => j.id === jobId);
      const item = job?.items.find(i => i.id === itemId);
      
      if (job && item) {
        setCurrentQCItem({
          jobId,
          itemId,
          itemName: item.descriptionOfWorks,
          jobNumber: job.jobNumber
        });
        setPendingStatus(status);
        setStatusModalVisible(false);
        setQcModalVisible(true);
      }
    } else if (status === 'Ready') {
      // Multiple items going to Ready - show confirmation modal
      setPendingReadyItems(new Set(selectedItems));
      setStatusModalVisible(false);
      setConfirmModalVisible(true);
    } else {
      // Multiple items OR status doesn't require QC - skip QC and update directly
      updateSelectedStatus(status);
    }
  };





  const handleQCConfirm = async (qcData: any) => {
    if (pendingStatus && currentQCItem) {
      // Close modal and clear state FIRST to prevent UI getting stuck
      setQcModalVisible(false);
      setSelectedItems(new Set());
      setPendingStatus(null);
      setCurrentQCItem(null);
      
      try {
        await updateItemStatus(currentQCItem.jobId, currentQCItem.itemId, pendingStatus);
      } catch (error) {
        console.error('Error updating item status:', error);
        Alert.alert('Update Error', 'Failed to update item status. Please try again.');
      }
    }
  };


  const handleQCClose = () => {
    setQcModalVisible(false);
    setPendingStatus(null);
    setCurrentQCItem(null);
    setStatusModalVisible(true);
  };

  const confirmMoveToReady = async () => {
    try {
      const itemsByJob = new Map<string, string[]>();
      for (const key of Array.from(pendingReadyItems)) {
        const [jobId, itemId] = key.split('|||');
        if (!itemsByJob.has(jobId)) {
          itemsByJob.set(jobId, []);
        }
        itemsByJob.get(jobId)!.push(itemId);
      }

      for (const [jobId, itemIds] of itemsByJob.entries()) {
        await updateMultipleItemStatuses(jobId, itemIds, 'Ready');
      }

      setSelectedItems(new Set());
      setPendingReadyItems(new Set());
      setConfirmModalVisible(false);
    } catch (error) {
      console.error('Error updating items to Ready:', error);
    }
  };

  const cancelMoveToReady = () => {
    setConfirmModalVisible(false);
    setPendingReadyItems(new Set());
    setStatusModalVisible(true);
  };

  const updateSelectedStatus = async (status: ItemStatus) => {
    try {
      for (const key of Array.from(selectedItems)) {
        const [jobId, itemId] = key.split('|||');
        await updateItemStatus(jobId, itemId, status);
      }
      setSelectedItems(new Set());
      setStatusModalVisible(false);
    } catch (error) {
      console.error('Error updating item status:', error);
    }
  };








  const renderJobItem = ({ item: job }: any) => {
    // Calculate status counts for progress indicator
    const statusCounts = job.items.reduce((acc: any, item: any) => {
      acc[item.status] = (acc[item.status] || 0) + 1;
      return acc;
    }, {});
    
    const borderColor = job.galvaXpress ? '#DC2626' : job.priority === 'high' ? '#EF4444' : job.priority === 'medium' ? '#F59E0B' : '#E5E7EB';
    const bgColor = job.galvaXpress ? '#FEF2F2' : job.priority === 'high' ? '#FEF2F2' : 'white';
    
    return (
    <View style={[styles.jobCard, { borderLeftWidth: 5, borderLeftColor: borderColor, backgroundColor: bgColor }]}>
      <TouchableOpacity onPress={() => router.push(`/job/${job.id}?source=wip` as any)}>
        <View style={styles.jobHeader}>
          <View style={styles.jobHeaderLeft}>
            <Text style={styles.jobNumber}>{job.jobNumber}</Text>
            <Text style={styles.customerName}>{job.customerName}</Text>
          </View>
          <View style={styles.jobHeaderRight}>
            <PriorityBadge priority={job.priority} galvaXpress={job.galvaXpress} size="small" />
            <DeliveryCountdown deliveryDate={job.deliveryDate} />
          </View>
        </View>
      </TouchableOpacity>

      {Object.keys(statusCounts).length > 0 && (
        <View style={styles.progressSummary}>
          {Object.entries(statusCounts).map(([status, count]: any) => (
            <View key={status} style={styles.progressItem}>
              <View style={[styles.progressDot, { backgroundColor: statusColors[status as ItemStatus] }]} />
              <Text style={styles.progressText}>{status}: {count}</Text>
            </View>
          ))}
        </View>
      )}


      {job.deliveryDate && (
        <View style={styles.deliveryInfo}>
          <Ionicons name="calendar-outline" size={14} color="#6B7280" />
          <Text style={styles.deliveryText}>
            Delivery: {`${new Date(job.deliveryDate).getDate().toString().padStart(2, '0')}/${(new Date(job.deliveryDate).getMonth() + 1).toString().padStart(2, '0')}/${new Date(job.deliveryDate).getFullYear()}`} at {new Date(job.deliveryDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </Text>
        </View>
      )}

      {job.notes && (
        <View style={styles.notesInfo}>
          <Ionicons name="document-text-outline" size={14} color="#6B7280" />
          <Text style={styles.notesText}>{job.notes}</Text>
        </View>
      )}


      
      
      {job.items.map((item: any) => {
        const isSelected = selectedItems.has(`${job.id}|||${item.id}`);

        return (
          <TouchableOpacity
            key={item.id}
            style={[styles.itemCard, isSelected && styles.selectedItem]}
            onPress={() => toggleItemSelection(job.id, item.id)}
          >
            <View style={styles.itemContent}>
              <Text style={styles.itemDescription}>{item.descriptionOfWorks}</Text>
              <Text style={styles.itemWeight}>{item.weightKg} kg</Text>
            </View>
            <ItemOptionsDisplay 
              paintVarnish={item.paintVarnish}
              galva={item.galva}
              lightGalva={item.lightGalva}
              lightPaint={item.lightPaint}
              rusty={item.rusty}
              doubleDip={item.doubleDip}
              multipleDip={item.multipleDip}
            />
            <View style={[styles.statusBadge, { backgroundColor: statusColors[item.status] }]}>
              <Text style={styles.statusText}>{item.status}</Text>
            </View>
            {isSelected && (
              <Ionicons name="checkmark-circle" size={24} color="#10B981" style={styles.checkIcon} />
            )}
          </TouchableOpacity>
        );
      })}


    </View>
  );
  };



  return (
    <View style={styles.container}>

      {/* Status Filter Button - Opens Modal */}
      <View style={styles.statusFilterContainer}>
        <TouchableOpacity 
          style={styles.statusFilterButton}
          onPress={() => setStatusFilterModalVisible(true)}
        >
          <Ionicons name="filter" size={18} color="#3B82F6" />
          <Text style={styles.statusFilterButtonText}>
            {(() => {
              const filters = [];
              if (wipActiveFilter === 'galvaxpress') filters.push('GalvXpress');
              if (wipActiveFilter === 'high') filters.push('High Priority');
              if (wipStatusFilter !== 'all') filters.push(wipStatusFilter);
              return filters.length > 0 ? filters.join(' + ') : 'All Filters';
            })()}
          </Text>
          <View style={styles.statusFilterCount}>
            <Text style={styles.statusFilterCountText}>
              {filteredJobs.length}
            </Text>
          </View>
        </TouchableOpacity>
      </View>




      {/* Date Filter Tabs */}
      {dateTabs.length > 0 && (
        <View style={styles.tabsWrapper}>
          {dateTabs.length > 2 && (
            <TouchableOpacity 
              style={[styles.scrollIndicator, styles.scrollIndicatorLeft]}
              onPress={() => {
                const newOffset = Math.max(0, scrollOffset - 200);
                scrollViewRef.current?.scrollTo({ x: newOffset, animated: true });
              }}
            >
              <Ionicons name="chevron-back" size={18} color="#6B7280" />
            </TouchableOpacity>
          )}

          <ScrollView 
            ref={scrollViewRef}
            horizontal 
            showsHorizontalScrollIndicator={false} 
            style={styles.tabsContainer}
            onScroll={(event) => {
              setScrollOffset(event.nativeEvent.contentOffset.x);
            }}
            scrollEventThrottle={16}
            contentContainerStyle={[
              styles.tabsContent,
              dateTabs.length > 2 && styles.tabsContentWithChevrons
            ]}
          >
            <TouchableOpacity 
              style={[styles.tab, !selectedDate && styles.tabActive]} 
              onPress={() => setSelectedDate(null)}
            >
              <Text style={[styles.tabText, !selectedDate && styles.tabTextActive]}>All</Text>
              <View style={styles.tabBadge}>
                <Text style={[styles.tabBadgeText, !selectedDate && styles.tabBadgeTextActive]}>{filteredJobs.length}</Text>
              </View>
            </TouchableOpacity>
            
            {dateTabs.map(({ date, count }) => (
              <TouchableOpacity 
                key={date} 
                style={[styles.tab, selectedDate === date && styles.tabActive]} 
                onPress={() => setSelectedDate(date)}
              >
                <Text style={[styles.tabText, selectedDate === date && styles.tabTextActive]}>
                  {formatTabDate(date)}
                </Text>
                <View style={styles.tabBadge}>
                  <Text style={[styles.tabBadgeText, selectedDate === date && styles.tabBadgeTextActive]}>{count}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
          
          {dateTabs.length > 2 && (
            <TouchableOpacity 
              style={[styles.scrollIndicator, styles.scrollIndicatorRight]}
              onPress={() => {
                const newOffset = scrollOffset + 200;
                scrollViewRef.current?.scrollTo({ x: newOffset, animated: true });
              }}
            >
              <Ionicons name="chevron-forward" size={18} color="#6B7280" />
            </TouchableOpacity>
          )}
        </View>
      )}

      <View style={styles.searchBarContainer}>
        <SearchBar
          value={searchQuery}
          onChangeText={setSearchQuery}
          placeholder="Search by job number, customer, or item..."
        />
      </View>

      <SectionList
        sections={jobsByDate}
        renderItem={renderJobItem}
        renderSectionHeader={({ section: { title, data } }) => (
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionHeaderText}>{formatSectionTitle(title)}</Text>
            <View style={styles.sectionHeaderBadge}>
              <Text style={styles.sectionHeaderBadgeText}>{data.length} {data.length === 1 ? 'job' : 'jobs'}</Text>
            </View>
          </View>
        )}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContent}
        stickySectionHeadersEnabled={true}
        ListEmptyComponent={
          <Text style={styles.emptyText}>
            {searchQuery ? 'No jobs match your search' : 'No jobs in WIP'}
          </Text>
        }
      />


      {selectedItems.size > 0 && (
        <TouchableOpacity
          style={styles.updateButton}
          onPress={() => setStatusModalVisible(true)}
        >
          <Text style={styles.updateButtonText}>Update Status ({selectedItems.size})</Text>
        </TouchableOpacity>
      )}



      <Modal
        animationType="slide"
        transparent={true}
        visible={statusModalVisible}
        onRequestClose={() => setStatusModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Select Status</Text>
            {isAdmin && (
              <View style={[styles.statusOrderInfo, { backgroundColor: '#FEF3C7' }]}>
                <Ionicons name="shield-checkmark" size={16} color="#92400E" />
                <Text style={[styles.statusOrderText, { color: '#92400E' }]}>
                  Admin Mode: You can select any status
                </Text>
              </View>
            )}
            {!isAdmin && (
              <View style={styles.statusOrderInfo}>
                <Ionicons name="information-circle-outline" size={16} color="#6B7280" />
                <Text style={styles.statusOrderText}>{getStatusOrderMessage()}</Text>
              </View>
            )}

            {(() => {
              const validStatuses = getValidStatusesForSelection();
              if (validStatuses.length === 0) {
                return (
                  <View style={styles.noStatusContainer}>
                    <Text style={styles.noStatusText}>
                      No valid status transitions available for selected items.
                    </Text>
                  </View>
                );
              }
              return statuses.map(status => {
                const isValid = validStatuses.includes(status);
                return (
                  <TouchableOpacity
                    key={status}
                    style={[
                      styles.statusOption, 
                      { borderLeftColor: statusColors[status] },
                      !isValid && styles.statusOptionDisabled
                    ]}
                    onPress={() => handleStatusSelection(status)}
                    disabled={!isValid}
                  >
                    <Text style={[
                      styles.statusOptionText,
                      !isValid && styles.statusOptionTextDisabled
                    ]}>
                      {status}
                    </Text>
                    {!isValid && (
                      <Ionicons name="lock-closed" size={16} color="#D1D5DB" style={styles.lockIcon} />
                    )}
                  </TouchableOpacity>
                );
              });
            })()}
            <TouchableOpacity
              style={styles.cancelButton}
              onPress={() => setStatusModalVisible(false)}
            >
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>


      <Modal
        animationType="fade"
        transparent={true}
        visible={confirmModalVisible}
        onRequestClose={() => setConfirmModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.confirmModal}>
            <Ionicons name="checkmark-circle" size={60} color="#059669" style={styles.confirmIcon} />
            <Text style={styles.confirmTitle}>Move to Done?</Text>
            <Text style={styles.confirmMessage}>
              Do you want to move {pendingReadyItems.size} item(s) to the Done section?
            </Text>
            <View style={styles.confirmButtons}>
              <TouchableOpacity
                style={[styles.confirmButton, styles.confirmYes]}
                onPress={confirmMoveToReady}
              >
                <Text style={styles.confirmYesText}>Yes, Move to Done</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.confirmButton, styles.confirmNo]}
                onPress={cancelMoveToReady}
              >
                <Text style={styles.confirmNoText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {currentQCItem && pendingStatus && (
        <StatusQCModal
          visible={qcModalVisible}
          onClose={handleQCClose}
          onConfirm={handleQCConfirm}
          targetStatus={pendingStatus}
          jobId={currentQCItem.jobId}
          itemId={currentQCItem.itemId}
          itemName={currentQCItem.itemName}
          jobNumber={currentQCItem.jobNumber}
        />
      )}

      <StatusFilterModal
        visible={statusFilterModalVisible}
        onClose={() => setStatusFilterModalVisible(false)}
        statusFilter={wipStatusFilter}
        onSelectStatus={setWipStatusFilter}
        statusStats={statusStats.stats}
        total={statusStats.total}
        statusColors={statusColors}
        activeFilter={wipActiveFilter}
        onSelectActiveFilter={setWipActiveFilter}
        galvXpressCount={galvXpressCount}
        highPriorityCount={highPriorityCount}
      />


    </View>


  );
}

const styles = StyleSheet.create({

  container: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { 
    backgroundColor: 'white', 
    padding: 16, 
    paddingTop: 12, 
    borderBottomWidth: 1, 
    borderBottomColor: '#E5E7EB',
    position: 'relative'
  },
  logo: { width: '100%', height: 60 },
  listContent: { padding: 16 },





  jobCard: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  jobHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 },
  jobHeaderLeft: { flex: 1 },
  jobHeaderRight: { flexDirection: 'column', gap: 4, alignItems: 'flex-end' },
  jobNumber: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  customerName: { fontSize: 14, color: '#6B7280', marginTop: 2 },
  galvXpressBadge: { backgroundColor: '#FEE2E2', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 4 },
  galvXpressText: { fontSize: 10, fontWeight: 'bold', color: '#EF4444' },
  deliveryInfo: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 12, paddingVertical: 6, paddingHorizontal: 8, backgroundColor: '#F9FAFB', borderRadius: 6 },
  deliveryText: { fontSize: 12, color: '#6B7280' },
  notesInfo: { flexDirection: 'row', alignItems: 'flex-start', gap: 6, marginBottom: 12, paddingVertical: 6, paddingHorizontal: 8, backgroundColor: '#FEF3C7', borderRadius: 6 },
  notesText: { flex: 1, fontSize: 12, color: '#92400E', lineHeight: 16 },


  itemCard: { backgroundColor: '#F9FAFB', borderRadius: 8, padding: 12, marginBottom: 8, borderWidth: 2, borderColor: 'transparent' },
  selectedItem: { borderColor: '#10B981', backgroundColor: '#ECFDF5' },
  itemContent: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  itemDescription: { flex: 1, fontSize: 14, color: '#374151' },
  itemWeight: { fontSize: 14, color: '#6B7280', marginLeft: 8 },
  statusBadge: { paddingHorizontal: 12, paddingVertical: 4, borderRadius: 12, alignSelf: 'flex-start' },
  statusText: { color: 'white', fontSize: 12, fontWeight: 'bold' },
  statusAndOptionsRow: { flexDirection: 'row', alignItems: 'center', gap: 6, flexWrap: 'wrap', marginBottom: 4 },
  checkIcon: { position: 'absolute', top: 8, right: 8 },

  updateButton: { position: 'absolute', bottom: 20, left: 20, right: 20, backgroundColor: '#3B82F6', borderRadius: 12, padding: 16, alignItems: 'center' },
  updateButtonText: { color: 'white', fontSize: 16, fontWeight: 'bold' },
  emptyText: { textAlign: 'center', color: '#6B7280', fontSize: 16, marginTop: 50 },
  priorityBadge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 4 },
  prioritylow: { backgroundColor: '#D1FAE5' },
  prioritymedium: { backgroundColor: '#FED7AA' },
  priorityhigh: { backgroundColor: '#FEE2E2' },
  priorityText: { fontSize: 10, fontWeight: 'bold', color: '#374151' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { backgroundColor: 'white', borderRadius: 20, padding: 20, width: '80%', maxHeight: '80%' },
  modalTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 12, textAlign: 'center' },
  statusOrderInfo: { 
    flexDirection: 'row', 
    alignItems: 'flex-start', 
    backgroundColor: '#EFF6FF', 
    padding: 12, 
    borderRadius: 8, 
    marginBottom: 16,
    gap: 8
  },
  statusOrderText: { 
    flex: 1,
    fontSize: 12, 
    color: '#1E40AF', 
    lineHeight: 18 
  },
  noStatusContainer: {
    padding: 20,
    alignItems: 'center'
  },
  noStatusText: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center'
  },
  statusOption: { 
    padding: 16, 
    borderLeftWidth: 4, 
    marginBottom: 8, 
    backgroundColor: '#F9FAFB',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  statusOptionDisabled: {
    opacity: 0.4,
    backgroundColor: '#F3F4F6'
  },
  statusOptionText: { fontSize: 16, color: '#374151' },
  statusOptionTextDisabled: {
    color: '#9CA3AF'
  },
  lockIcon: {
    marginLeft: 8
  },
  cancelButton: { marginTop: 12, padding: 12, alignItems: 'center' },
  cancelButtonText: { color: '#6B7280', fontSize: 16 },
  confirmModal: { backgroundColor: 'white', borderRadius: 20, padding: 24, width: '85%', alignItems: 'center' },
  confirmIcon: { marginBottom: 16 },
  confirmTitle: { fontSize: 22, fontWeight: 'bold', color: '#1F2937', marginBottom: 8 },
  confirmMessage: { fontSize: 16, color: '#6B7280', textAlign: 'center', marginBottom: 24 },
  confirmButtons: { width: '100%', gap: 12 },
  confirmButton: { padding: 14, borderRadius: 10, alignItems: 'center' },
  confirmYes: { backgroundColor: '#059669' },
  confirmNo: { backgroundColor: '#F3F4F6' },
  confirmYesText: { color: 'white', fontSize: 16, fontWeight: 'bold' },
  confirmNoText: { color: '#6B7280', fontSize: 16, fontWeight: '600' },
  filterTabsContainer: { 
    backgroundColor: 'white', 
    borderBottomWidth: 1, 
    borderBottomColor: '#E5E7EB', 
    paddingVertical: 12,
    paddingHorizontal: 16,
    flexDirection: 'row',
    gap: 10
  },
  filterTab: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    paddingHorizontal: 16, 
    paddingVertical: 10, 
    borderRadius: 20, 
    backgroundColor: '#F3F4F6', 
    gap: 6,
    flex: 1,
    justifyContent: 'center'
  },
  filterTabActive: { backgroundColor: '#3B82F6' },
  filterTabText: { fontSize: 13, fontWeight: '600', color: '#6B7280' },
  filterTabTextActive: { color: 'white' },
  viewToggle: { flexDirection: 'row', backgroundColor: 'white', padding: 12, gap: 8, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  viewToggleBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 10, paddingHorizontal: 16, borderRadius: 8, backgroundColor: '#F3F4F6' },
  viewToggleBtnActive: { backgroundColor: '#3B82F6' },
  viewToggleText: { fontSize: 14, fontWeight: '600', color: '#6B7280' },
  viewToggleTextActive: { color: 'white' },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#EFF6FF', paddingVertical: 12, paddingHorizontal: 16, marginBottom: 8, borderRadius: 8, marginTop: 8 },
  sectionHeaderText: { fontSize: 16, fontWeight: 'bold', color: '#1E40AF', flex: 1 },
  sectionHeaderBadge: { backgroundColor: '#3B82F6', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  sectionHeaderBadgeText: { fontSize: 12, fontWeight: 'bold', color: 'white' },
  searchBarContainer: {
    backgroundColor: 'white',
    paddingHorizontal: 16,
    paddingBottom: 12
  },
  progressSummary: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  progressItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  progressDot: { width: 8, height: 8, borderRadius: 4 },
  progressText: { fontSize: 11, color: '#6B7280' },
  statusDot: { width: 12, height: 12, borderRadius: 6 },
  
  // Progress Bar Styles
  progressBarContainer: {
    backgroundColor: 'white',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB'
  },
  progressBarWrapper: {
    height: 8,
    backgroundColor: '#E5E7EB',
    borderRadius: 4,
    flexDirection: 'row',
    overflow: 'hidden',
    marginBottom: 8
  },
  progressBarSegment: {
    height: '100%'
  },
  progressLegend: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12
  },
  progressLegendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4
  },
  progressLegendDot: {
    width: 8,
    height: 8,
    borderRadius: 4
  },
  progressLegendText: {
    fontSize: 11,
    color: '#6B7280'
  },
  
  // Status Filter Badges Styles
  // Status Filter Button Styles
  statusFilterContainer: {
    backgroundColor: 'white',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB'
  },
  statusFilterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
    backgroundColor: '#F3F4F6',
    gap: 10
  },
  statusFilterButtonText: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    color: '#374151'
  },
  statusFilterCount: {
    backgroundColor: '#3B82F6',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12
  },
  statusFilterCountText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white'
  },

  // Date Filter Tabs Styles
  tabsWrapper: { 
    position: 'relative',
    backgroundColor: 'white', 
    borderBottomWidth: 2, 
    borderBottomColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  tabsContainer: { 
    maxHeight: 70,
  },
  tabsContent: { 
    paddingHorizontal: 12, 
    paddingVertical: 10, 
    gap: 8,
    alignItems: 'center',
  },
  tabsContentWithChevrons: {
    paddingHorizontal: 44,
  },
  tab: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    paddingHorizontal: 14, 
    paddingVertical: 10, 
    backgroundColor: '#F3F4F6', 
    borderRadius: 20, 
    gap: 6,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    minWidth: 80,
    justifyContent: 'center',
  },
  tabActive: { 
    backgroundColor: '#3B82F6',
    borderColor: '#3B82F6',
    shadowColor: '#3B82F6',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  tabText: { 
    fontSize: 13, 
    fontWeight: '600', 
    color: '#6B7280' 
  },
  tabTextActive: { 
    color: 'white',
    fontWeight: '700',
  },
  tabBadge: { 
    backgroundColor: 'rgba(0,0,0,0.1)', 
    paddingHorizontal: 6, 
    paddingVertical: 2, 
    borderRadius: 10,
    minWidth: 22,
    alignItems: 'center',
  },
  tabBadgeText: { 
    fontSize: 11, 
    fontWeight: 'bold', 
    color: '#374151' 
  },
  tabBadgeTextActive: {
    color: 'white',
  },
  scrollIndicator: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    width: 32,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.98)',
    zIndex: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  scrollIndicatorLeft: {
    left: 0,
    borderRightWidth: 1,
    borderRightColor: '#E5E7EB',
  },
  scrollIndicatorRight: {
    right: 0,
    borderLeftWidth: 1,
    borderLeftColor: '#E5E7EB',
  },

});




