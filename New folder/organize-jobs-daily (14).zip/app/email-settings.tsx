import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from './lib/supabase';
import { router } from 'expo-router';

export default function EmailSettingsScreen() {
  const [fromEmail, setFromEmail] = useState('');
  const [domain, setDomain] = useState('');
  const [isVerified, setIsVerified] = useState(false);
  const [loading, setLoading] = useState(true);
  const [checking, setChecking] = useState(false);
  const [saving, setSaving] = useState(false);
  const [testEmail, setTestEmail] = useState('');
  const [sendingTest, setSendingTest] = useState(false);

  useEffect(() => { loadSettings(); }, []);

  const loadSettings = async () => {
    try {
      const { data } = await supabase.from('email_settings').select('*').order('created_at', { ascending: false }).limit(1).single();
      if (data) { setFromEmail(data.from_email); setDomain(data.domain); setIsVerified(data.is_verified); }
    } catch (error) { console.error('Error loading email settings:', error); }
    finally { setLoading(false); }
  };

  const extractDomain = (email: string) => { const match = email.match(/@(.+)$/); return match ? match[1] : ''; };

  const saveSettings = async () => {
    if (!fromEmail || !domain) { Alert.alert('Error', 'Please fill in all fields'); return; }
    setSaving(true);
    try {
      const { error } = await supabase.from('email_settings').upsert({ from_email: fromEmail, domain, is_verified: isVerified });
      if (error) throw error;
      Alert.alert('Success', 'Email settings saved');
    } catch (error: any) { Alert.alert('Error', error.message || 'Failed to save settings'); }
    finally { setSaving(false); }
  };

  const sendTestEmail = async () => {
    if (!testEmail) { Alert.alert('Error', 'Please enter a test email address'); return; }
    setSendingTest(true);
    try {
      const htmlContent = `
        <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #4CAF50;">Gmail SMTP Test Successful!</h1>
          <p>This is a test email sent from your application using Gmail SMTP.</p>
          <p><strong>Timestamp:</strong> ${new Date().toLocaleString()}</p>
          <hr style="border: 1px solid #eee; margin: 20px 0;" />
          <p style="color: #666; font-size: 12px;">If you received this email, your Gmail SMTP configuration is working correctly.</p>
        </div>
      `;
      const { data, error } = await supabase.functions.invoke('send-daily-report', {
        body: { recipients: [testEmail], subject: 'Test Email - Gmail SMTP Configuration', htmlContent }
      });
      if (error) throw error;
      Alert.alert('Success', `Test email sent to ${testEmail}!\n\nCheck your inbox (and spam folder).`);
    } catch (error: any) {
      console.error('Test email error:', error);
      Alert.alert('Error', error.message || 'Failed to send test email. Check Supabase logs for details.');
    } finally { setSendingTest(false); }
  };

  if (loading) { return <View style={styles.container}><ActivityIndicator size="large" color="#007AFF" /></View>; }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}><Ionicons name="arrow-back" size={24} color="#007AFF" /></TouchableOpacity>
        <Text style={styles.title}>Email Settings</Text>
      </View>
      <ScrollView style={styles.content}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Gmail SMTP Configuration</Text>
          <Text style={styles.instructions}>Your app is configured to use Gmail SMTP. Make sure you have added these secrets in Supabase:{'\n\n'}• GMAIL_USER - Your Gmail address{'\n'}• GMAIL_APP_PASSWORD - 16-char app password</Text>
        </View>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Send Test Email</Text>
          <Text style={styles.label}>Recipient Email Address</Text>
          <TextInput style={styles.input} value={testEmail} onChangeText={setTestEmail} placeholder="test@example.com" keyboardType="email-address" autoCapitalize="none" />
          <TouchableOpacity style={[styles.button, styles.testButton]} onPress={sendTestEmail} disabled={sendingTest}>
            {sendingTest ? <ActivityIndicator color="#FFF" /> : <><Ionicons name="mail" size={20} color="#FFF" /><Text style={styles.buttonText}>Send Test Email</Text></>}
          </TouchableOpacity>
        </View>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Sender Configuration (Optional)</Text>
          <Text style={styles.label}>From Email Address</Text>
          <TextInput style={styles.input} value={fromEmail} onChangeText={(t) => { setFromEmail(t); setDomain(extractDomain(t)); }} placeholder="reports@yourdomain.com" keyboardType="email-address" autoCapitalize="none" />
          <TouchableOpacity style={[styles.button, styles.saveButton]} onPress={saveSettings} disabled={saving}>
            {saving ? <ActivityIndicator color="#FFF" /> : <><Ionicons name="save" size={20} color="#FFF" /><Text style={styles.buttonText}>Save Settings</Text></>}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F5F5F5' },
  header: { flexDirection: 'row', alignItems: 'center', padding: 16, backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#E0E0E0' },
  backButton: { marginRight: 16 },
  title: { fontSize: 20, fontWeight: 'bold' },
  content: { flex: 1, padding: 16 },
  section: { backgroundColor: '#FFF', borderRadius: 8, padding: 16, marginBottom: 16 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 12 },
  label: { fontSize: 14, fontWeight: '600', marginBottom: 8, color: '#333' },
  input: { borderWidth: 1, borderColor: '#DDD', borderRadius: 8, padding: 12, marginBottom: 16, fontSize: 16 },
  instructions: { fontSize: 14, lineHeight: 22, color: '#666' },
  button: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: 16, borderRadius: 8, marginBottom: 12 },
  testButton: { backgroundColor: '#2196F3' },
  saveButton: { backgroundColor: '#4CAF50' },
  buttonText: { color: '#FFF', fontSize: 16, fontWeight: 'bold', marginLeft: 8 }
});
