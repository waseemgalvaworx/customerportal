import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Image, Alert, ActivityIndicator, Platform, Modal, TextInput } from 'react-native';

import { useRouter, useFocusEffect } from 'expo-router';
import { useJobs } from '../contexts/JobContext';
import { useCustomers } from '../contexts/CustomerContext';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import { Ionicons } from '@expo/vector-icons';

import JobSearchModal from '../components/JobSearchModal';
import SettingsModal from '../components/SettingsModal';


import BackupRestoreModal from '../components/BackupRestoreModal';
import PasswordPrompt from '../components/PasswordPrompt';

import TrendGraphsModal from '../components/TrendGraphsModal';
import { RealtimeSyncIndicator } from '../components/RealtimeSyncIndicator';
import { createBackup } from '../utils/backupManager';
import { cacheData, CACHE_KEYS } from '../utils/offlineCache';

// Optional imports for OTA updates
let Updates: any = null;
try {
  Updates = require('expo-updates');
} catch (e) {
  console.log('expo-updates not installed');
}
import Constants from 'expo-constants';


export default function MainScreen() {
  const router = useRouter();
  const { jobs } = useJobs();
  const { customers } = useCustomers();
  const { user, loading, signOut } = usePasswordAuth();
  const [refreshKey, setRefreshKey] = useState(0);
  const [searchModalVisible, setSearchModalVisible] = useState(false);
  const [restoreModalVisible, setRestoreModalVisible] = useState(false);
  const [trendsModalVisible, setTrendsModalVisible] = useState(false);
  const [settingsModalVisible, setSettingsModalVisible] = useState(false);
  const [isOffline, setIsOffline] = useState(false);


  const [backupLoading, setBackupLoading] = useState(false);
  const [passwordPromptVisible, setPasswordPromptVisible] = useState(false);
  const [passwordAction, setPasswordAction] = useState<'backup' | 'restore' | null>(null);

  // Update states for non-admin users
  const [updatePasswordModalVisible, setUpdatePasswordModalVisible] = useState(false);
  const [updatePassword, setUpdatePassword] = useState('');
  const [isCheckingUpdate, setIsCheckingUpdate] = useState(false);
  const [updateStatus, setUpdateStatus] = useState('');

  // Cache data when jobs/customers change (non-blocking, fire-and-forget)
  useEffect(() => {
    if (jobs.length > 0) {
      cacheData(CACHE_KEYS.JOBS, jobs).catch(err => console.error('Cache jobs error:', err));
    }
    if (customers.length > 0) {
      cacheData(CACHE_KEYS.CUSTOMERS, customers).catch(err => console.error('Cache customers error:', err));
    }
  }, [jobs, customers]);


  // Check if user has backup permission (admin, Lovena, KH)
  const canBackup = user?.username === 'admin' || user?.username === 'Lovena' || user?.username === 'KH';
  const isAdmin = user?.username === 'admin';

  const handleBackup = async () => {
    setBackupLoading(true);
    
    try {
      const result = await createBackup();
      setBackupLoading(false);
      
      if (Platform.OS === 'web') {
        // Show success message in a visible way on web
        const successMsg = result.message || 'Backup downloaded successfully!';
        alert(successMsg);
      } else {
        Alert.alert('Success', result.message || 'Backup created successfully!');
      }
    } catch (error) {
      setBackupLoading(false);
      const errorMsg = error instanceof Error ? error.message : String(error);
      
      if (Platform.OS === 'web') {
        alert(`Backup Failed: ${errorMsg}`);
      } else {
        Alert.alert('Error', `Failed to create backup: ${errorMsg}`);
      }
    }
  };

  const handleBackupButtonPress = () => {
    setPasswordAction('backup');
    setPasswordPromptVisible(true);
  };

  const handleRestoreButtonPress = () => {
    setPasswordAction('restore');
    setPasswordPromptVisible(true);
  };

  const handlePasswordConfirm = () => {
    setPasswordPromptVisible(false);
    if (passwordAction === 'backup') {
      handleBackup();
    } else if (passwordAction === 'restore') {
      setRestoreModalVisible(true);
    }
    setPasswordAction(null);
  };

  const handlePasswordCancel = () => {
    setPasswordPromptVisible(false);
    setPasswordAction(null);
  };

  const handleMenuItemPress = (item: any) => {
    if (item.route) {
      router.push(item.route);
    }
  };

  // Check for updates function (for non-admin users)
  const checkForUpdates = async () => {
    if (!Updates) {
      Alert.alert('Setup Required', 'Please install expo-updates package to enable OTA updates. Run: npx expo install expo-updates');
      return;
    }

    if (__DEV__) {
      Alert.alert('Development Mode', 'Updates are only available in production builds. Please build and install the app to test updates.');
      return;
    }

    try {
      setIsCheckingUpdate(true);
      setUpdateStatus('Checking for updates...');

      const update = await Updates.checkForUpdateAsync();
      
      if (update.isAvailable) {
        setUpdateStatus('Update available! Downloading...');
        await Updates.fetchUpdateAsync();
        
        Alert.alert(
          'Update Ready',
          'A new version has been downloaded. The app will restart now to apply the update.',
          [
            {
              text: 'Restart Now',
              onPress: async () => {
                await Updates.reloadAsync();
              }
            }
          ]
        );
      } else {
        setUpdateStatus('App is up to date!');
        Alert.alert('No Updates', 'You are already running the latest version.');
      }
    } catch (error) {
      console.error('Error checking for updates:', error);
      setUpdateStatus('Error checking for updates');
      Alert.alert('Update Error', 'Failed to check for updates. Please try again later.');
    } finally {
      setIsCheckingUpdate(false);
      setTimeout(() => setUpdateStatus(''), 3000);
    }
  };

  // Handle update button press for non-admin users
  const handleUpdateButtonPress = () => {
    setUpdatePassword('');
    setUpdatePasswordModalVisible(true);
  };

  // Verify password and check for updates
  const handleUpdatePasswordSubmit = () => {
    if (updatePassword === '4321') {
      setUpdatePasswordModalVisible(false);
      setUpdatePassword('');
      checkForUpdates();
    } else {
      Alert.alert('Incorrect Password', 'Please enter the correct password to check for updates.');
    }
  };


  useEffect(() => {
    if (!loading && !user) {
      router.replace('/login');
    }
  }, [user, loading]);


  useFocusEffect(
    React.useCallback(() => {
      setRefreshKey(prev => prev + 1);
    }, [jobs, customers])
  );

  const pendingJobs = jobs.filter(job => job.status === 'pending');
  const planningJobs = jobs.filter(job => job.status === 'planning');
  const completedJobs = jobs.filter(job => job.status === 'done');
  const archivedJobs = jobs.filter(job => job.status === 'archived');

  const filteredMenuItems = [
    { title: 'Jobs', icon: 'briefcase', color: '#F59E0B', route: '/jobs', count: pendingJobs.length, permission: 'jobs', showCount: true },
    { title: 'Planning', icon: 'clipboard', color: '#6366F1', route: '/planning', count: planningJobs.length, permission: 'planning', showCount: true },
    { title: 'Work in Progress', icon: 'construct', color: '#3B82F6', route: '/wip', count: planningJobs.length, permission: 'wip', showCount: true },
    { title: 'Completed Jobs', icon: 'checkmark-done-circle', color: '#10B981', route: '/done', count: completedJobs.length, permission: 'done', showCount: true },
    { title: 'Archive', icon: 'archive', color: '#8B5CF6', route: '/archive', count: archivedJobs.length, permission: 'archive', showCount: false },
    { title: 'Statistics', icon: 'stats-chart', color: '#EC4899', route: '/statistics', count: jobs.length, permission: 'statistics', showCount: false },
    { title: 'Customers', icon: 'people', color: '#EC4899', route: '/customers', count: customers.length, permission: 'customers', showCount: true },
    { title: 'Inventory', icon: 'cube', color: '#14B8A6', route: '/inventory', count: 0, permission: 'inventory', showCount: false },
    { title: 'Logistics', icon: 'car', color: '#0EA5E9', route: '/logistics', count: 0, permission: 'logistics', showCount: false },
    { title: 'Compliance Certificate', icon: 'document-text', color: '#F97316', route: '/compliance', count: 0, permission: 'compliance', showCount: false },
  ].filter(item => {
    // Check permission - user must have the permission to see the menu item
    if (!user?.permissions[item.permission as keyof typeof user.permissions]) {
      return false;
    }
    return true;
  });


  if (loading) {
    return <View style={styles.container}><View style={styles.loadingContainer}><Text>Loading...</Text></View></View>;
  }

  return (
    <View style={styles.container}>
      {isOffline && (
        <View style={{ backgroundColor: '#FF9500', padding: 10, alignItems: 'center' }}>
          <Text style={{ color: 'white', fontWeight: '600' }}>Offline Mode - Viewing cached data</Text>
        </View>
      )}
      
      <JobSearchModal visible={searchModalVisible} onClose={() => setSearchModalVisible(false)} />
      <BackupRestoreModal visible={restoreModalVisible} onClose={() => setRestoreModalVisible(false)} />
      <TrendGraphsModal visible={trendsModalVisible} onClose={() => setTrendsModalVisible(false)} />
      <SettingsModal visible={settingsModalVisible} onClose={() => setSettingsModalVisible(false)} />

      <PasswordPrompt 
        visible={passwordPromptVisible} 
        title={passwordAction === 'backup' ? 'Backup Database' : 'Restore Database'}
        onConfirm={handlePasswordConfirm}
        onCancel={handlePasswordCancel}
      />

      {/* Update Password Modal for non-admin users */}
      <Modal visible={updatePasswordModalVisible} transparent animationType="fade">
        <View style={styles.updateModalOverlay}>
          <View style={styles.updateModalContent}>
            <Text style={styles.updateModalTitle}>Check for Updates</Text>
            <Text style={styles.updateModalSubtitle}>Enter password to continue</Text>
            <TextInput
              style={styles.updatePasswordInput}
              placeholder="Enter password"
              value={updatePassword}
              onChangeText={setUpdatePassword}
              secureTextEntry
              autoFocus
            />
            <View style={styles.updateModalButtons}>
              <TouchableOpacity 
                style={[styles.updateModalBtn, styles.updateModalCancelBtn]}
                onPress={() => {
                  setUpdatePasswordModalVisible(false);
                  setUpdatePassword('');
                }}
              >
                <Text style={styles.updateModalCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.updateModalBtn, styles.updateModalConfirmBtn]}
                onPress={handleUpdatePasswordSubmit}
              >
                <Text style={styles.updateModalConfirmText}>Check</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>


      
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <View style={styles.headerTop}>
            <Image source={{ uri: 'https://d64gsuwffb70l.cloudfront.net/6826def9056908ac6c0eb35d_1759490551243_ee723b3c.jpg' }} style={styles.logo} resizeMode="contain" />
            <RealtimeSyncIndicator />
          </View>
          <Text style={styles.subtitle}>Job Management System</Text>
          <Text style={styles.userRole}>Logged in as: {user?.name}</Text>
          <View style={styles.headerActions}>
            {isAdmin && (
              <>
                <TouchableOpacity style={styles.settingsButton} onPress={() => setSettingsModalVisible(true)}>
                  <Ionicons name="settings" size={20} color="#6366F1" />
                  <Text style={styles.settingsText}>Settings</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.auditButton} onPress={() => router.push('/audit-logs')}>
                  <Ionicons name="document-text" size={20} color="#6B7280" />
                  <Text style={styles.auditText}>Audit Logs</Text>
                </TouchableOpacity>
              </>
            )}
            <TouchableOpacity style={styles.logoutButton} onPress={signOut}>
              <Ionicons name="log-out-outline" size={20} color="#EF4444" />
              <Text style={styles.logoutText}>Logout</Text>
            </TouchableOpacity>
          </View>


        </View>

        {/* Hide Search All Jobs button for logistics-request-only users (IM, JS) */}
        {!user?.permissions?.logisticsRequestOnly && (
          <TouchableOpacity style={styles.searchButton} onPress={() => setSearchModalVisible(true)}>
            <Ionicons name="search" size={24} color="#fff" />
            <Text style={styles.searchButtonText}>Search All Jobs</Text>
          </TouchableOpacity>
        )}


        <View style={styles.grid}>
          {filteredMenuItems.map((item, index) => (
            <TouchableOpacity key={index} style={[styles.menuCard, { borderLeftColor: item.color }]} onPress={() => handleMenuItemPress(item)}>
              <View style={[styles.iconContainer, { backgroundColor: item.color + '20' }]}>
                <Ionicons name={item.icon as any} size={32} color={item.color} />
              </View>
              <Text style={styles.menuTitle}>{item.title}</Text>
              {item.showCount && (
                <View style={[styles.countBadge, { backgroundColor: item.color }]}>
                  <Text style={styles.countText}>{item.count}</Text>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>



        {canBackup && (
          <View style={styles.backupSection}>
            <View style={styles.buttonRow}>
              <TouchableOpacity 
                style={[styles.backupButton, backupLoading && styles.backupButtonDisabled]} 
                onPress={handleBackupButtonPress}
                disabled={backupLoading}
              >
                {backupLoading ? (
                  <ActivityIndicator size="small" color="#fff" />
                ) : (
                  <Ionicons name="cloud-download" size={24} color="#fff" />
                )}
                <Text style={styles.backupButtonText}>
                  {backupLoading ? 'Creating...' : 'Backup'}
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.restoreButton} 
                onPress={handleRestoreButtonPress}
              >
                <Ionicons name="cloud-upload" size={24} color="#fff" />
                <Text style={styles.restoreButtonText}>Restore</Text>
              </TouchableOpacity>

            </View>
            <Text style={styles.backupHint}>Backup or restore database</Text>
          </View>
        )}

        {/* Show View Trends and Performance buttons for Admin, Lovena, KH only */}
        {(user?.username === 'admin' || user?.username === 'Lovena' || user?.username === 'KH') && (
          <View style={styles.featuresSection}>
            <TouchableOpacity style={styles.featureButton} onPress={() => setTrendsModalVisible(true)}>
              <Ionicons name="trending-up" size={24} color="#fff" />
              <Text style={styles.featureButtonText}>View Trends</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.featureButton} onPress={() => router.push('/statistics')}>
              <Ionicons name="speedometer" size={24} color="#fff" />
              <Text style={styles.featureButtonText}>Performance</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Check for Updates button for non-admin users */}
        {!isAdmin && (
          <View style={styles.updateSection}>
            <TouchableOpacity 
              style={[styles.checkUpdateButton, isCheckingUpdate && styles.checkUpdateButtonDisabled]}
              onPress={handleUpdateButtonPress}
              disabled={isCheckingUpdate}
            >
              {isCheckingUpdate ? (
                <ActivityIndicator size="small" color="#fff" />
              ) : (
                <Ionicons name="cloud-download-outline" size={22} color="#fff" />
              )}
              <Text style={styles.checkUpdateButtonText}>
                {isCheckingUpdate ? 'Checking...' : 'Check for Updates'}
              </Text>
            </TouchableOpacity>
            {updateStatus !== '' && (
              <Text style={styles.updateStatusText}>{updateStatus}</Text>
            )}
            <Text style={styles.versionText}>Version: {Constants.expoConfig?.version || '1.0.0'}</Text>
          </View>
        )}

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  scrollContent: { paddingBottom: 20 },
  header: { backgroundColor: '#fff', padding: 24, paddingTop: 60, alignItems: 'center', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%' },
  logo: { width: '70%', height: 80 },

  subtitle: { fontSize: 16, color: '#6B7280', fontWeight: '500', marginTop: 8 },
  userRole: { fontSize: 14, color: '#10B981', fontWeight: '600', marginTop: 8 },
  headerActions: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 12, width: '100%' },
  settingsButton: { flexDirection: 'row', alignItems: 'center', padding: 8, gap: 6 },
  settingsText: { fontSize: 14, color: '#6366F1', fontWeight: '600' },
  auditButton: { flexDirection: 'row', alignItems: 'center', padding: 8, gap: 6 },
  auditText: { fontSize: 14, color: '#6B7280', fontWeight: '600' },
  logoutButton: { flexDirection: 'row', alignItems: 'center', padding: 8, gap: 6, marginLeft: 'auto' },
  logoutText: { fontSize: 14, color: '#EF4444', fontWeight: '600' },


  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  searchButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#6366F1', margin: 16, padding: 16, borderRadius: 12, gap: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 4, elevation: 4 },
  searchButtonText: { fontSize: 18, fontWeight: 'bold', color: '#fff' },
  grid: { padding: 16, gap: 16 },
  menuCard: { backgroundColor: '#fff', borderRadius: 16, padding: 20, flexDirection: 'row', alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 8, elevation: 4, borderLeftWidth: 4 },
  iconContainer: { width: 56, height: 56, borderRadius: 28, alignItems: 'center', justifyContent: 'center', marginRight: 16 },
  menuTitle: { fontSize: 18, fontWeight: '600', color: '#111827', flex: 1 },
  countBadge: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12 },
  countText: { fontSize: 16, fontWeight: 'bold', color: '#fff' },
  backupSection: { margin: 16, marginTop: 8, padding: 16, backgroundColor: '#fff', borderRadius: 12, alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  buttonRow: { flexDirection: 'row', gap: 12, width: '100%' },
  backupButton: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#059669', paddingVertical: 14, paddingHorizontal: 16, borderRadius: 10, gap: 8 },
  backupButtonDisabled: { backgroundColor: '#9CA3AF' },
  backupButtonText: { fontSize: 16, fontWeight: 'bold', color: '#fff' },
  restoreButton: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#6366F1', paddingVertical: 14, paddingHorizontal: 16, borderRadius: 10, gap: 8 },
  restoreButtonText: { fontSize: 16, fontWeight: 'bold', color: '#fff' },
  backupHint: { fontSize: 12, color: '#6B7280', marginTop: 8, textAlign: 'center' },
  featuresSection: { margin: 16, marginTop: 8, flexDirection: 'row', gap: 12 },
  featureButton: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#8B5CF6', paddingVertical: 14, paddingHorizontal: 16, borderRadius: 10, gap: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  featureButtonText: { fontSize: 14, fontWeight: '600', color: '#fff' },
  
  // Update section styles for non-admin users
  updateSection: { 
    margin: 16, 
    marginTop: 8, 
    padding: 16, 
    backgroundColor: '#fff', 
    borderRadius: 12, 
    alignItems: 'center', 
    shadowColor: '#000', 
    shadowOffset: { width: 0, height: 2 }, 
    shadowOpacity: 0.1, 
    shadowRadius: 4, 
    elevation: 3 
  },
  checkUpdateButton: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'center', 
    backgroundColor: '#0EA5E9', 
    paddingVertical: 14, 
    paddingHorizontal: 24, 
    borderRadius: 10, 
    gap: 8,
    width: '100%',
  },
  checkUpdateButtonDisabled: { 
    backgroundColor: '#7DD3FC',
    opacity: 0.7,
  },
  checkUpdateButtonText: { 
    fontSize: 16, 
    fontWeight: '600', 
    color: '#fff' 
  },
  updateStatusText: { 
    fontSize: 14, 
    color: '#0EA5E9', 
    marginTop: 8, 
    fontWeight: '500' 
  },
  versionText: { 
    fontSize: 12, 
    color: '#9CA3AF', 
    marginTop: 4 
  },

  // Update password modal styles
  updateModalOverlay: { 
    flex: 1, 
    backgroundColor: 'rgba(0,0,0,0.5)', 
    justifyContent: 'center', 
    alignItems: 'center',
    padding: 20,
  },
  updateModalContent: { 
    backgroundColor: '#fff', 
    borderRadius: 16, 
    padding: 24, 
    width: '100%',
    maxWidth: 340,
  },
  updateModalTitle: { 
    fontSize: 20, 
    fontWeight: 'bold', 
    color: '#1F2937', 
    textAlign: 'center',
    marginBottom: 4,
  },
  updateModalSubtitle: { 
    fontSize: 14, 
    color: '#6B7280', 
    textAlign: 'center',
    marginBottom: 20,
  },
  updatePasswordInput: { 
    borderWidth: 1, 
    borderColor: '#D1D5DB', 
    borderRadius: 10, 
    padding: 14, 
    fontSize: 16,
    backgroundColor: '#F9FAFB',
    marginBottom: 20,
  },
  updateModalButtons: { 
    flexDirection: 'row', 
    gap: 12 
  },
  updateModalBtn: { 
    flex: 1, 
    padding: 14, 
    borderRadius: 10, 
    alignItems: 'center' 
  },
  updateModalCancelBtn: { 
    backgroundColor: '#F3F4F6' 
  },
  updateModalConfirmBtn: { 
    backgroundColor: '#0EA5E9' 
  },
  updateModalCancelText: { 
    fontSize: 16, 
    fontWeight: '600', 
    color: '#6B7280' 
  },
  updateModalConfirmText: { 
    fontSize: 16, 
    fontWeight: '600', 
    color: '#fff' 
  },
});
