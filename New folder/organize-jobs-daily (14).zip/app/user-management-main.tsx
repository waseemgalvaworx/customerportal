import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList, Alert } from 'react-native';
import { supabase } from '@/app/lib/supabase';

interface User {
  id: string;
  username: string;
  full_name: string;
  role: string;
  is_active: boolean;
}

interface Props {
  users: User[];
  onRefresh: () => void;
  loading: boolean;
  onEdit: (user: User) => void;
  onAddUser: () => void;
  onBack: () => void;
}

export default function UserManagementMain({ users, onRefresh, loading, onEdit, onAddUser, onBack }: Props) {
  const handleDeactivate = async (userId: string) => {
    Alert.alert('Confirm', 'Deactivate this user?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Deactivate',
        onPress: async () => {
          try {
            const { error } = await supabase.from('profiles').update({ is_active: false }).eq('id', userId);
            if (error) throw error;
            Alert.alert('Success', 'User deactivated');
            onRefresh();
          } catch (error: any) {
            Alert.alert('Error', error.message);
          }
        }
      }
    ]);
  };

  const renderUser = ({ item }: { item: User }) => (
    <View style={styles.userCard}>
      <View style={styles.userInfo}>
        <Text style={styles.userName}>{item.full_name}</Text>
        <Text style={styles.userDetail}>@{item.username}</Text>
        <Text style={styles.userRole}>{item.role.replace('_', ' ').toUpperCase()}</Text>
        <Text style={[styles.status, item.is_active ? styles.active : styles.inactive]}>
          {item.is_active ? 'Active' : 'Inactive'}
        </Text>
      </View>
      <View style={styles.actions}>
        <TouchableOpacity style={styles.editButton} onPress={() => onEdit(item)}>
          <Text style={styles.editText}>Edit</Text>
        </TouchableOpacity>
        {item.is_active && (
          <TouchableOpacity style={styles.deactivateButton} onPress={() => handleDeactivate(item.id)}>
            <Text style={styles.deactivateText}>Deactivate</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack} style={styles.backButton}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>User Management</Text>
        <TouchableOpacity style={styles.addButton} onPress={onAddUser}>
          <Text style={styles.addText}>+ Add User</Text>
        </TouchableOpacity>
      </View>
      <FlatList data={users} renderItem={renderUser} keyExtractor={item => item.id} refreshing={loading} onRefresh={onRefresh} contentContainerStyle={styles.list} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 20, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#ddd' },
  backButton: { padding: 8 },
  backText: { color: '#007AFF', fontSize: 16 },
  title: { fontSize: 20, fontWeight: 'bold' },
  addButton: { backgroundColor: '#007AFF', padding: 10, borderRadius: 8 },
  addText: { color: '#fff', fontWeight: '600' },
  list: { padding: 20 },
  userCard: { backgroundColor: '#fff', padding: 16, borderRadius: 12, marginBottom: 12, flexDirection: 'row', justifyContent: 'space-between' },
  userInfo: { flex: 1 },
  userName: { fontSize: 18, fontWeight: 'bold', marginBottom: 4 },
  userDetail: { fontSize: 14, color: '#666', marginBottom: 4 },
  userRole: { fontSize: 12, color: '#007AFF', fontWeight: '600', marginBottom: 4 },
  status: { fontSize: 12, fontWeight: '600' },
  active: { color: '#34C759' },
  inactive: { color: '#FF3B30' },
  actions: { justifyContent: 'center', gap: 8 },
  editButton: { backgroundColor: '#007AFF', padding: 8, borderRadius: 6 },
  editText: { color: '#fff', fontSize: 12, fontWeight: '600' },
  deactivateButton: { backgroundColor: '#FF3B30', padding: 8, borderRadius: 6 },
  deactivateText: { color: '#fff', fontSize: 12, fontWeight: '600' }
});
