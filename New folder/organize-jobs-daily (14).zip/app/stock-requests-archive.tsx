import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView, ActivityIndicator, Alert } from 'react-native';
import { supabase } from './lib/supabase';
import { router } from 'expo-router';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';

type FilterType = 'all' | 'weekly' | 'monthly' | 'yearly';

export default function StockRequestsArchiveScreen() {
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<FilterType>('all');
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    fetchArchived();
  }, [filter]);

  const fetchArchived = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('archived_stock_requests')
        .select('*')
        .order('archived_at', { ascending: false });

      const now = new Date();
      if (filter === 'weekly') {
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        query = query.gte('archived_at', weekAgo.toISOString());
      } else if (filter === 'monthly') {
        const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        query = query.gte('archived_at', monthAgo.toISOString());
      } else if (filter === 'yearly') {
        const yearAgo = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
        query = query.gte('archived_at', yearAgo.toISOString());
      }

      const { data, error } = await query;
      if (error) throw error;
      setRequests(data || []);
    } catch (error: any) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  const exportReport = async () => {
    setExporting(true);
    try {
      const csv = generateCSV();
      const fileName = `stock_requests_${filter}_${new Date().toISOString().split('T')[0]}.csv`;
      const filePath = `${FileSystem.documentDirectory}${fileName}`;
      
      await FileSystem.writeAsStringAsync(filePath, csv);
      await Sharing.shareAsync(filePath);
    } catch (error: any) {
      Alert.alert('Error', error.message);
    } finally {
      setExporting(false);
    }
  };

  const generateCSV = () => {
    const headers = 'Item,Quantity,Unit,Requested By,Status,Reason,Ref,Approved By,Created,Archived\n';
    const rows = requests.map(r => 
      `"${r.item_name}",${r.quantity_requested},"${r.unit}","${r.requested_by}","${r.status}","${r.reason || ''}","${r.ref || ''}","${r.approved_by || ''}","${new Date(r.created_at).toLocaleString()}","${new Date(r.archived_at).toLocaleString()}"`
    ).join('\n');
    return headers + rows;
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Archive</Text>
        <TouchableOpacity onPress={exportReport} disabled={exporting || requests.length === 0}>
          <Text style={[styles.exportText, (exporting || requests.length === 0) && styles.disabled]}>
            {exporting ? 'Exporting...' : 'Export'}
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterContainer}>
        {(['all', 'weekly', 'monthly', 'yearly'] as FilterType[]).map(f => (
          <TouchableOpacity key={f} style={[styles.filterBtn, filter === f && styles.filterBtnActive]} onPress={() => setFilter(f)}>
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>{f.charAt(0).toUpperCase() + f.slice(1)}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#007AFF" />
        </View>
      ) : (
        <ScrollView>
          {requests.length === 0 ? (
            <Text style={styles.emptyText}>No archived requests</Text>
          ) : (
            <View style={styles.tableContainer}>
              <View style={styles.tableHeader}>
                <Text style={[styles.tableCell, styles.headerCell, { flex: 2 }]}>Item</Text>
                <Text style={[styles.tableCell, styles.headerCell, { flex: 1 }]}>Qty</Text>
                <Text style={[styles.tableCell, styles.headerCell, { flex: 1.5 }]}>Requested</Text>
                <Text style={[styles.tableCell, styles.headerCell, { flex: 1 }]}>Status</Text>
              </View>
              {requests.map(req => (
                <View key={req.id} style={styles.tableRow}>
                  <Text style={[styles.tableCell, { flex: 2 }]}>{req.item_name}</Text>
                  <Text style={[styles.tableCell, { flex: 1 }]}>{req.quantity_requested} {req.unit}</Text>
                  <Text style={[styles.tableCell, { flex: 1.5 }]}>{req.requested_by}</Text>
                  <Text style={[styles.tableCell, { flex: 1 }]}>{req.status}</Text>
                </View>
              ))}
            </View>
          )}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#ddd' },
  backText: { fontSize: 16, color: '#007AFF' },
  title: { fontSize: 20, fontWeight: 'bold' },
  exportText: { fontSize: 16, color: '#007AFF', fontWeight: '600' },
  disabled: { color: '#ccc' },
  filterContainer: { padding: 12, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#ddd', maxHeight: 60 },
  filterBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, marginRight: 8, backgroundColor: '#f0f0f0' },
  filterBtnActive: { backgroundColor: '#007AFF' },
  filterText: { fontSize: 14, color: '#666' },
  filterTextActive: { color: '#fff', fontWeight: '600' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyText: { textAlign: 'center', marginTop: 40, fontSize: 16, color: '#666' },
  tableContainer: { margin: 12 },
  tableHeader: { flexDirection: 'row', backgroundColor: '#007AFF', padding: 12, borderRadius: 8 },
  tableRow: { flexDirection: 'row', backgroundColor: '#fff', padding: 12, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  tableCell: { fontSize: 14 },
  headerCell: { color: '#fff', fontWeight: 'bold' },
});
