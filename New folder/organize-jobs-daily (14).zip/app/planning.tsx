import React, { useState, useMemo, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image, Modal, TextInput, Alert, ScrollView } from 'react-native';
import { useJobs } from '../contexts/JobContext';
import { ItemStatus } from '../contexts/JobContext';
import DateTimePicker from '../components/DateTimePicker';
import PlanningJobCard from '../components/PlanningJobCard';
import { Ionicons } from '@expo/vector-icons';
import SearchBar from '../components/SearchBar';
import { authenticateWithPassword } from './lib/passwordAuth';
import { supabase } from './lib/supabase';
import { useTaskState } from '../hooks/useTaskState';

// Task configuration for this screen
const TASK_CONFIG = {
  route: '/planning',
  title: 'Planning',
  icon: 'clipboard',
  color: '#6366F1'
};

interface PlanningTaskData {
  searchQuery: string;
  selectedDate: string | null;
}

export default function PlanningScreen() {
  const { jobs, updateJob, revertToPending } = useJobs();
  
  // Initialize task state management
  const { savedData, saveTaskData, markAsSaved } = useTaskState<PlanningTaskData>(TASK_CONFIG);
  
  const [selectedJobs, setSelectedJobs] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState(savedData?.searchQuery || '');
  const [selectedDate, setSelectedDate] = useState<string | null>(savedData?.selectedDate || null);
  const [passwordModalVisible, setPasswordModalVisible] = useState(false);
  const [datePickerVisible, setDatePickerVisible] = useState(false);
  const [password, setPassword] = useState('');
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [pendingAction, setPendingAction] = useState<'clear' | 'revert' | 'changeDate' | null>(null);
  const scrollViewRef = useRef<ScrollView>(null);
  const [scrollOffset, setScrollOffset] = useState(0);
  const now = new Date();
  const [selectedDay, setSelectedDay] = useState(now.getDate());
  const [selectedMonth, setSelectedMonth] = useState(now.getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(now.getFullYear());
  const [selectedHour, setSelectedHour] = useState(now.getHours());
  const [selectedMinute, setSelectedMinute] = useState(now.getMinutes());
  const [completedJobsCount, setCompletedJobsCount] = useState(0);

  // Save task data when search or date filter changes
  useEffect(() => {
    saveTaskData({ searchQuery, selectedDate }, searchQuery !== '' || selectedDate !== null);
  }, [searchQuery, selectedDate]);



  // Fetch completed jobs count for the selected delivery date
  useEffect(() => {
    const fetchCompletedCount = async () => {
      if (!selectedDate) {
        setCompletedJobsCount(0);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('delivery_date_job_completions')
          .select('*')
          .eq('delivery_date', selectedDate);

        if (error) {
          console.error('Error fetching completed jobs count:', error);
          setCompletedJobsCount(0);
        } else {
          setCompletedJobsCount(data?.length || 0);
        }
      } catch (err) {
        console.error('Error in fetchCompletedCount:', err);
        setCompletedJobsCount(0);
      }
    };

    fetchCompletedCount();
  }, [selectedDate]);



  const planningJobs = jobs.filter(job => job.status === 'planning');
  const filteredJobs = planningJobs.filter(job => {
    const query = searchQuery.toLowerCase();
    return job.jobNumber.toLowerCase().includes(query) || job.customerName.toLowerCase().includes(query) || job.items.some(item => item.descriptionOfWorks.toLowerCase().includes(query));
  });

  const calculateTotalWeight = (items: any[]) => items.reduce((sum, item) => sum + parseFloat(item.weightKg || '0'), 0);
  const getStatusColor = (status: ItemStatus) => ({ Workshop: '#3B82F6', Acid: '#F59E0B', Galva: '#8B5CF6', Finishing: '#EC4899', Ready: '#059669' }[status] || '#6B7280');

  const dateTabs = useMemo(() => {
    const tabs = new Map<string, number>();
    filteredJobs.forEach(job => {
      if (job.deliveryDate) {
        const date = new Date(job.deliveryDate);
        const key = date.toISOString().split('T')[0];
        tabs.set(key, (tabs.get(key) || 0) + 1);
      }
    });
    return Array.from(tabs.entries()).map(([date, count]) => ({ date, count })).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [filteredJobs]);

  // Apply date filter
  let displayedJobs = filteredJobs;
  
  if (selectedDate) {
    displayedJobs = displayedJobs.filter(job => 
      job.deliveryDate && new Date(job.deliveryDate).toISOString().split('T')[0] === selectedDate
    );
  }

  // Calculate target job count and total weight (only for jobs still in planning)
  const targetJobCount = displayedJobs.length;
  const targetTotalWeight = useMemo(() => {
    return displayedJobs.reduce((sum, job) => {
      return sum + job.items.reduce((itemSum, item) => itemSum + parseFloat(item.weightKg || '0'), 0);
    }, 0);
  }, [displayedJobs]);

  // Calculate total target including completed jobs
  const totalTargetJobCount = targetJobCount + completedJobsCount;

  // Calculate progress percentage (completed / total)
  const progressPercentage = useMemo(() => {
    if (totalTargetJobCount === 0) return 0;
    return Math.round((completedJobsCount / totalTargetJobCount) * 100);
  }, [completedJobsCount, totalTargetJobCount]);






  const formatTabDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const today = new Date(); today.setHours(0,0,0,0);
    const tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate() + 1);
    const dateOnly = new Date(date); dateOnly.setHours(0,0,0,0);
    if (dateOnly.getTime() === today.getTime()) return 'Today';
    if (dateOnly.getTime() === tomorrow.getTime()) return 'Tomorrow';
    return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  };

  const handleRevert = async (jobId: string) => {
    console.log('=== REVERT BUTTON CLICKED ===');
    console.log('Job ID:', jobId);
    
    try {
      console.log('Starting revert operation...');
      await revertToPending(jobId);
      console.log('Revert operation completed successfully');
      Alert.alert('Success', 'Job reverted to Jobs screen');
    } catch (error) {
      console.error('Revert operation failed:', error);
      Alert.alert('Error', 'Failed to revert job. Please try again.');
    }
    
    console.log('=== REVERT COMPLETED ===');
  };

  const handlePasswordSubmit = async () => {
    // Placeholder function - not currently used but kept for modal reference
    setPasswordModalVisible(false);
    setPassword('');
  };



  return (
    <View style={styles.container}>
      <View style={styles.header}><Image source={{ uri: 'https://d64gsuwffb70l.cloudfront.net/6826def9056908ac6c0eb35d_1759490551243_ee723b3c.jpg' }} style={styles.logo} resizeMode="contain" /></View>
      <SearchBar value={searchQuery} onChangeText={setSearchQuery} placeholder="Search jobs..." />
      
      
      {/* Date Filter Tabs - Always visible */}
      {/* Date Filter Tabs - Always visible */}
      <View style={styles.tabsWrapper}>
        {dateTabs.length > 2 && (
          <TouchableOpacity 
            style={[styles.scrollIndicator, styles.scrollIndicatorLeft]}
            onPress={() => {
              const newOffset = Math.max(0, scrollOffset - 200);
              scrollViewRef.current?.scrollTo({ x: newOffset, animated: true });
            }}
          >
            <Ionicons name="chevron-back" size={18} color="#6B7280" />
          </TouchableOpacity>
        )}

        
        <ScrollView 
          ref={scrollViewRef}
          horizontal 
          showsHorizontalScrollIndicator={false} 
          style={styles.tabsContainer}
          onScroll={(event) => {
            setScrollOffset(event.nativeEvent.contentOffset.x);
          }}
          scrollEventThrottle={16}
          contentContainerStyle={[
            styles.tabsContent,
            dateTabs.length > 2 && styles.tabsContentWithChevrons
          ]}
        >
          <TouchableOpacity 
            style={[styles.tab, !selectedDate && styles.tabActive]} 
            onPress={() => setSelectedDate(null)}
          >
            <Text style={[styles.tabText, !selectedDate && styles.tabTextActive]}>All</Text>
            <View style={styles.tabBadge}>
              <Text style={[styles.tabBadgeText, !selectedDate && styles.tabBadgeTextActive]}>{filteredJobs.length}</Text>
            </View>
          </TouchableOpacity>
          
          {dateTabs.map(({ date, count }) => (
            <TouchableOpacity 
              key={date} 
              style={[styles.tab, selectedDate === date && styles.tabActive]} 
              onPress={() => setSelectedDate(date)}
            >
              <Text style={[styles.tabText, selectedDate === date && styles.tabTextActive]}>
                {formatTabDate(date)}
              </Text>
              <View style={styles.tabBadge}>
                <Text style={[styles.tabBadgeText, selectedDate === date && styles.tabBadgeTextActive]}>{count}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>
        
        {dateTabs.length > 2 && (
          <TouchableOpacity 
            style={[styles.scrollIndicator, styles.scrollIndicatorRight]}
            onPress={() => {
              const newOffset = scrollOffset + 200;
              scrollViewRef.current?.scrollTo({ x: newOffset, animated: true });
            }}
          >
            <Ionicons name="chevron-forward" size={18} color="#6B7280" />
          </TouchableOpacity>
        )}
      </View>

      {/* Target Production Weight Display with Progress - Only show progress bar when date is selected */}
      {/* Simple Job Count Target Display */}
      <View style={styles.targetWeightContainer}>
        <View style={styles.targetWeightContent}>
          <Ionicons name="list-outline" size={20} color="#3B82F6" />
          <Text style={styles.targetWeightLabel}>Target:</Text>
          <Text style={styles.targetWeightValue}>
            {targetJobCount} jobs ({targetTotalWeight.toFixed(1)} kg)
          </Text>
        </View>

        {/* Progress Bar - Only show when a specific date is selected */}
        {selectedDate && (
          <View style={styles.progressSection}>
            <View style={styles.progressHeader}>
              <View style={styles.progressStats}>
                <Ionicons name="checkmark-circle" size={16} color="#059669" />
                <Text style={styles.completedText}>Completed: {completedJobsCount} jobs</Text>

              </View>
              <Text style={styles.percentageText}>{progressPercentage.toFixed(0)}%</Text>
            </View>
            
            <View style={styles.progressBarContainer}>
              <View style={[styles.progressBarFill, { width: `${progressPercentage}%` }]} />
            </View>
            
            <Text style={styles.remainingText}>
              Remaining: {targetJobCount} jobs
            </Text>

          </View>
        )}
      </View>







      <FlatList data={displayedJobs.sort((a,b) => a.jobNumber.localeCompare(b.jobNumber))} renderItem={({ item }) => (<PlanningJobCard job={item} isSelected={selectedJobs.has(item.id)} onToggleSelect={() => {}} onRevert={() => handleRevert(item.id)} onChangeDeliveryDate={() => {}} calculateTotalWeight={calculateTotalWeight} getStatusColor={getStatusColor} />)} keyExtractor={item => item.id} contentContainerStyle={styles.listContent} />

      <Modal visible={passwordModalVisible} transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Enter Password to Revert Job</Text>
            <TextInput 
              style={styles.input} 
              value={password} 
              onChangeText={setPassword} 
              secureTextEntry 
              placeholder="Password"
              autoFocus
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity 
                style={[styles.btn, styles.cancelBtn]} 
                onPress={() => {
                  setPasswordModalVisible(false);
                  setPassword('');
                  setSelectedJobId(null);
                  setPendingAction(null);
                }}
              >
                <Text style={styles.cancelBtnText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.btn, styles.submitBtn]} 
                onPress={handlePasswordSubmit}
              >
                <Text style={styles.btnText}>Submit</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { backgroundColor: 'white', padding: 16, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  logo: { width: '100%', height: 60 },
  
  
  // Enhanced tabs styling for mobile-optimized layout
  tabsWrapper: { 
    position: 'relative',
    backgroundColor: 'white', 
    borderBottomWidth: 2, 
    borderBottomColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  tabsContainer: { 
    maxHeight: 70,
  },
  tabsContent: { 
    paddingHorizontal: 12, 
    paddingVertical: 10, 
    gap: 8,
    alignItems: 'center',
  },
  tabsContentWithChevrons: {
    paddingHorizontal: 44, // Add padding when chevrons are visible
  },
  tab: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    paddingHorizontal: 14, 
    paddingVertical: 10, 
    backgroundColor: '#F3F4F6', 
    borderRadius: 20, 
    gap: 6,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    minWidth: 80,
    justifyContent: 'center',
  },
  tabActive: { 
    backgroundColor: '#3B82F6',
    borderColor: '#3B82F6',
    shadowColor: '#3B82F6',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  tabText: { 
    fontSize: 13, 
    fontWeight: '600', 
    color: '#6B7280' 
  },
  tabTextActive: { 
    color: 'white',
    fontWeight: '700',
  },
  tabBadge: { 
    backgroundColor: 'rgba(0,0,0,0.1)', 
    paddingHorizontal: 6, 
    paddingVertical: 2, 
    borderRadius: 10,
    minWidth: 22,
    alignItems: 'center',
  },
  tabBadgeText: { 
    fontSize: 11, 
    fontWeight: 'bold', 
    color: '#374151' 
  },
  tabBadgeTextActive: {
    color: 'white',
  },
  scrollIndicator: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    width: 32,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.98)',
    zIndex: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  scrollIndicatorLeft: {
    left: 0,
    borderRightWidth: 1,
    borderRightColor: '#E5E7EB',
  },
  scrollIndicatorRight: {
    right: 0,
    borderLeftWidth: 1,
    borderLeftColor: '#E5E7EB',
  },


  // Target Weight Display Styles
  targetWeightContainer: {
    backgroundColor: '#EFF6FF',
    borderBottomWidth: 1,
    borderBottomColor: '#BFDBFE',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  targetWeightContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  targetWeightLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1E40AF',
  },
  targetWeightValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#3B82F6',
  },

  
  // Progress Section Styles
  progressSection: {
    marginTop: 12,
    gap: 8,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  progressStats: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  completedText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#059669',
  },
  percentageText: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#1E40AF',
  },
  progressBarContainer: {
    height: 12,
    backgroundColor: '#DBEAFE',
    borderRadius: 6,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: '#3B82F6',
    borderRadius: 6,
  },
  remainingText: {
    fontSize: 12,
    fontWeight: '500',
    color: '#6B7280',
    textAlign: 'center',
  },
  
  listContent: { padding: 16 },



  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { backgroundColor: 'white', borderRadius: 16, padding: 20, width: '80%' },
  modalTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 16, textAlign: 'center' },
  input: { borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, padding: 12, marginBottom: 16 },
  modalButtons: { flexDirection: 'row', gap: 12 },
  btn: { flex: 1, padding: 12, borderRadius: 8, alignItems: 'center' },
  submitBtn: { backgroundColor: '#3B82F6' },
  cancelBtn: { backgroundColor: '#E5E7EB' },
  btnText: { color: 'white', fontWeight: '600', fontSize: 16 },
  cancelBtnText: { color: '#374151', fontWeight: '600', fontSize: 16 }
});





