import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, TextInput, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from './lib/supabase';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import StatusHistoryTimeline from '../components/StatusHistoryTimeline';

interface AuditLog {
  id: string;
  created_at: string;
  username: string;
  action_type: string;
  action_description: string;
  entity_type?: string;
  entity_id?: string;
}

export default function AuditLogsScreen() {
  const router = useRouter();
  const { user } = usePasswordAuth();
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('ALL');
  const [activeTab, setActiveTab] = useState<'logs' | 'timeline'>('logs');


  useEffect(() => {
    if (!user?.permissions.admin) {
      router.back();
      return;
    }
    fetchLogs();
  }, [user]);

  useEffect(() => {
    applyFilters();
  }, [searchQuery, filterType, logs]);

  const fetchLogs = async () => {
    try {
      const { data, error } = await supabase
        .from('activity_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(500);

      if (error) throw error;
      setLogs(data || []);
    } catch (err) {
      console.error('Error fetching logs:', err);
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...logs];

    if (filterType !== 'ALL') {
      filtered = filtered.filter(log => log.action_type === filterType);
    }

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(log => 
        log.username.toLowerCase().includes(query) ||
        log.action_description.toLowerCase().includes(query) ||
        log.action_type.toLowerCase().includes(query)
      );
    }

    setFilteredLogs(filtered);
  };

  const getActionColor = (actionType: string) => {
    if (actionType.includes('LOGIN') || actionType.includes('LOGOUT')) return '#3B82F6';
    if (actionType.includes('CREATED')) return '#10B981';
    if (actionType.includes('UPDATED')) return '#F59E0B';
    if (actionType.includes('DELETED')) return '#EF4444';
    if (actionType.includes('COMPLIANCE')) return '#8B5CF6';
    return '#6B7280';
  };

  const renderLog = ({ item }: { item: AuditLog }) => (
    <View style={styles.logCard}>
      <View style={styles.logHeader}>
        <View style={[styles.actionBadge, { backgroundColor: getActionColor(item.action_type) }]}>
          <Text style={styles.actionText}>{item.action_type}</Text>
        </View>
        <Text style={styles.timestamp}>{new Date(item.created_at).toLocaleString()}</Text>
      </View>
      <Text style={styles.username}>User: {item.username}</Text>
      <Text style={styles.description}>{item.action_description}</Text>
      {item.entity_type && (
        <Text style={styles.entity}>Entity: {item.entity_type} {item.entity_id && `(${item.entity_id})`}</Text>
      )}
    </View>
  );

  if (!user?.permissions.admin) return null;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Audit Logs</Text>
        <TouchableOpacity onPress={fetchLogs}>
          <Ionicons name="refresh" size={24} color="#1F2937" />
        </TouchableOpacity>
      </View>

      <View style={styles.tabContainer}>
        <TouchableOpacity 
          style={[styles.tab, activeTab === 'logs' && styles.tabActive]} 
          onPress={() => setActiveTab('logs')}
        >
          <Ionicons name="list" size={20} color={activeTab === 'logs' ? '#3B82F6' : '#6B7280'} />
          <Text style={[styles.tabText, activeTab === 'logs' && styles.tabTextActive]}>Activity Logs</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tab, activeTab === 'timeline' && styles.tabActive]} 
          onPress={() => setActiveTab('timeline')}
        >
          <Ionicons name="git-branch" size={20} color={activeTab === 'timeline' ? '#3B82F6' : '#6B7280'} />
          <Text style={[styles.tabText, activeTab === 'timeline' && styles.tabTextActive]}>Status Timeline</Text>
        </TouchableOpacity>
      </View>

      {activeTab === 'timeline' ? (
        <StatusHistoryTimeline />
      ) : (
        <>
          <View style={styles.filters}>
            <TextInput
              style={styles.searchInput}
              placeholder="Search logs..."
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
            <View style={styles.filterButtons}>
              {['ALL', 'LOGIN', 'LOGOUT', 'JOB_UPDATED', 'COMPLIANCE_VIEWED'].map(type => (
                <TouchableOpacity
                  key={type}
                  style={[styles.filterBtn, filterType === type && styles.filterBtnActive]}
                  onPress={() => setFilterType(type)}
                >
                  <Text style={[styles.filterBtnText, filterType === type && styles.filterBtnTextActive]}>
                    {type.replace('_', ' ')}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {loading ? (
            <ActivityIndicator size="large" color="#3B82F6" style={styles.loader} />
          ) : (
            <FlatList
              data={filteredLogs}
              renderItem={renderLog}
              keyExtractor={item => item.id}
              contentContainerStyle={styles.list}
              ListEmptyComponent={<Text style={styles.emptyText}>No logs found</Text>}
            />
          )}
        </>
      )}

    </View>
  );
}


const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, paddingTop: 60, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: '#1F2937' },
  tabContainer: { flexDirection: 'row', backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  tab: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: 16, gap: 8, borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabActive: { borderBottomColor: '#3B82F6' },
  tabText: { fontSize: 14, color: '#6B7280', fontWeight: '500' },
  tabTextActive: { color: '#3B82F6', fontWeight: '600' },
  filters: { backgroundColor: 'white', padding: 16, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  searchInput: { borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, padding: 12, fontSize: 14, marginBottom: 12 },
  filterButtons: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  filterBtn: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#D1D5DB' },
  filterBtnActive: { backgroundColor: '#3B82F6', borderColor: '#3B82F6' },
  filterBtnText: { fontSize: 12, color: '#6B7280' },
  filterBtnTextActive: { color: 'white', fontWeight: '600' },
  list: { padding: 16, gap: 12 },
  logCard: { backgroundColor: 'white', padding: 16, borderRadius: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  logHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  actionBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 4 },
  actionText: { color: 'white', fontSize: 11, fontWeight: 'bold' },
  timestamp: { fontSize: 11, color: '#6B7280' },
  username: { fontSize: 13, fontWeight: '600', color: '#374151', marginBottom: 4 },
  description: { fontSize: 13, color: '#1F2937', marginBottom: 4 },
  entity: { fontSize: 11, color: '#6B7280', fontStyle: 'italic' },
  loader: { marginTop: 40 },
  emptyText: { textAlign: 'center', color: '#6B7280', fontSize: 14, marginTop: 40 }
});

