import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert, RefreshControl } from 'react-native';
import { supabase } from './lib/supabase';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import CalendarPicker from '../components/CalendarPicker';
import ConfirmationModal from '../components/ConfirmationModal';
import DeliveryArchiveCard from '../components/DeliveryArchiveCard';
import DeliveryArchiveFilters from '../components/DeliveryArchiveFilters';

export default function DeliveryArchiveScreen() {
  const router = useRouter();
  const [deliveries, setDeliveries] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [startDate, setStartDate] = useState<Date | null>(null);
  const [endDate, setEndDate] = useState<Date | null>(null);
  const [showStartPicker, setShowStartPicker] = useState(false);
  const [showEndPicker, setShowEndPicker] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [showRestoreModal, setShowRestoreModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [actionId, setActionId] = useState<string | null>(null);

  useEffect(() => { loadArchive(); }, []);

  const loadArchive = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('logistics_deliveries')
      .select('*, job:jobs!logistics_deliveries_job_id_fkey(id, jobNumber, customerName)')
      .eq('status', 'archived')
      .order('archived_at', { ascending: false });
    setDeliveries(data || []);
    setLoading(false);
  };

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadArchive();
    setRefreshing(false);
  }, []);

  const customers = [...new Set(deliveries.map(d => d.job?.customerName).filter(Boolean))];

  const filtered = deliveries.filter(d => {
    if (searchQuery && !d.delivery_number?.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !d.delivery_address?.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    if (selectedCustomer && d.job?.customerName !== selectedCustomer) return false;
    if (startDate && d.archived_at && new Date(d.archived_at) < startDate) return false;
    if (endDate) {
      const end = new Date(endDate); end.setHours(23, 59, 59, 999);
      if (d.archived_at && new Date(d.archived_at) > end) return false;
    }
    return true;
  });

  const handleRestore = (id: string) => { setActionId(id); setShowRestoreModal(true); };
  const handleDelete = (id: string) => { setActionId(id); setShowDeleteModal(true); };

  const confirmRestore = async () => {
    const ids = actionId ? [actionId] : selectedIds;
    try {
      const { error } = await supabase.from('logistics_deliveries')
        .update({ status: 'completed', archived_at: null }).in('id', ids);
      if (error) throw error;
      Alert.alert('Success', `${ids.length} delivery(s) restored`);
      setSelectedIds([]); loadArchive();
    } catch (e: any) { Alert.alert('Error', e.message); }
    setShowRestoreModal(false); setActionId(null);
  };

  const confirmDelete = async () => {
    const ids = actionId ? [actionId] : selectedIds;
    try {
      const { error } = await supabase.from('logistics_deliveries').delete().in('id', ids);
      if (error) throw error;
      Alert.alert('Success', `${ids.length} delivery(s) permanently deleted`);
      setSelectedIds([]); loadArchive();
    } catch (e: any) { Alert.alert('Error', e.message); }
    setShowDeleteModal(false); setActionId(null);
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const selectAll = () => setSelectedIds(filtered.map(d => d.id));
  const clearSelection = () => setSelectedIds([]);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color="white" />
        </TouchableOpacity>
        <Text style={styles.title}>Delivery Archive</Text>
        <View style={styles.headerRight}>
          <TouchableOpacity 
            onPress={handleRefresh} 
            style={styles.headerBtn}
            disabled={refreshing}
          >
            <Ionicons 
              name="refresh" 
              size={22} 
              color="white" 
              style={refreshing ? styles.spinning : undefined}
            />
          </TouchableOpacity>
          <Text style={styles.count}>{filtered.length} items</Text>
        </View>
      </View>

      <DeliveryArchiveFilters
        searchQuery={searchQuery} onSearchChange={setSearchQuery}
        startDate={startDate} endDate={endDate}
        onStartDatePress={() => setShowStartPicker(true)} onEndDatePress={() => setShowEndPicker(true)}
        onClearDates={() => { setStartDate(null); setEndDate(null); }}
        customers={customers} selectedCustomer={selectedCustomer} onCustomerChange={setSelectedCustomer}
      />

      {selectedIds.length > 0 && (
        <View style={styles.bulkBar}>
          <Text style={styles.bulkText}>{selectedIds.length} selected</Text>
          <TouchableOpacity style={styles.bulkBtn} onPress={selectAll}><Text style={styles.bulkBtnText}>All</Text></TouchableOpacity>
          <TouchableOpacity style={styles.bulkBtn} onPress={clearSelection}><Text style={styles.bulkBtnText}>Clear</Text></TouchableOpacity>
          <TouchableOpacity style={[styles.bulkBtn, styles.restoreBulk]} onPress={() => { setActionId(null); setShowRestoreModal(true); }}>
            <Ionicons name="refresh" size={16} color="white" /><Text style={styles.bulkActionText}>Restore</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.bulkBtn, styles.deleteBulk]} onPress={() => { setActionId(null); setShowDeleteModal(true); }}>
            <Ionicons name="trash" size={16} color="white" /><Text style={styles.bulkActionText}>Delete</Text>
          </TouchableOpacity>
        </View>
      )}

      <ScrollView 
        style={styles.content}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            colors={['#2563eb']}
            tintColor="#2563eb"
          />
        }
      >
        {loading && !refreshing ? <Text style={styles.empty}>Loading...</Text> : filtered.length === 0 ? (
          <Text style={styles.empty}>No archived deliveries found</Text>
        ) : filtered.map(d => (
          <DeliveryArchiveCard key={d.id} delivery={d} onRestore={handleRestore} onDelete={handleDelete}
            selected={selectedIds.includes(d.id)} onSelect={toggleSelect} />
        ))}
      </ScrollView>

      <CalendarPicker visible={showStartPicker} selectedDate={startDate} onSelectDate={setStartDate} onClose={() => setShowStartPicker(false)} />
      <CalendarPicker visible={showEndPicker} selectedDate={endDate} onSelectDate={setEndDate} onClose={() => setShowEndPicker(false)} />
      <ConfirmationModal visible={showRestoreModal} title="Restore Delivery" message={`Restore ${actionId ? '1' : selectedIds.length} delivery(s) to completed status?`}
        confirmText="Restore" onConfirm={confirmRestore} onCancel={() => setShowRestoreModal(false)} />
      <ConfirmationModal visible={showDeleteModal} title="Delete Permanently" message={`Permanently delete ${actionId ? '1' : selectedIds.length} delivery(s)? This cannot be undone.`}
        confirmText="Delete" confirmStyle="destructive" onConfirm={confirmDelete} onCancel={() => setShowDeleteModal(false)} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { backgroundColor: '#2563eb', padding: 16, paddingTop: 60, flexDirection: 'row', alignItems: 'center' },
  backBtn: { marginRight: 12 },
  title: { fontSize: 20, fontWeight: 'bold', color: 'white', flex: 1 },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  headerBtn: { padding: 8, backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 8 },
  count: { fontSize: 14, color: 'rgba(255,255,255,0.8)' },
  spinning: { opacity: 0.6 },
  content: { flex: 1, padding: 12 },
  empty: { textAlign: 'center', color: '#6b7280', padding: 40, fontSize: 16 },
  bulkBar: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#1e40af', padding: 10, gap: 8 },
  bulkText: { color: 'white', fontSize: 13, fontWeight: '600' },
  bulkBtn: { paddingHorizontal: 10, paddingVertical: 6, backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 6 },
  bulkBtnText: { color: 'white', fontSize: 12 },
  restoreBulk: { backgroundColor: '#16a34a', flexDirection: 'row', alignItems: 'center', gap: 4 },
  deleteBulk: { backgroundColor: '#ef4444', flexDirection: 'row', alignItems: 'center', gap: 4 },
  bulkActionText: { color: 'white', fontSize: 12, fontWeight: '600' }
});
