import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import { supabase } from './lib/supabase';

import AddInventoryItemModal from '../components/AddInventoryItemModal';
import StockMovementModal from '../components/StockMovementModal';
import InventoryItemsList from '../components/InventoryItemsList';
import DieselModal from '../components/DieselModal';
import InventoryReportModal from '../components/InventoryReportModal';
import { useTaskState } from '../hooks/useTaskState';


const CATEGORIES = ['Raw Materials', 'Direct Sale', 'By Products'];

// Task configuration for this screen
const TASK_CONFIG = {
  route: '/inventory',
  title: 'Inventory',
  icon: 'cube',
  color: '#14B8A6'
};

interface InventoryTaskData {
  selectedCategory: string;
}


export default function InventoryScreen() {
  const router = useRouter();
  const { user, loading } = usePasswordAuth();
  
  // Initialize task state management
  const { savedData, saveTaskData, markAsSaved } = useTaskState<InventoryTaskData>(TASK_CONFIG);
  
  const [selectedCategory, setSelectedCategory] = useState(savedData?.selectedCategory || 'Raw Materials');
  const [addModalVisible, setAddModalVisible] = useState(false);
  const [stockModalVisible, setStockModalVisible] = useState(false);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [dropdownVisible, setDropdownVisible] = useState(false);
  const [dieselModalVisible, setDieselModalVisible] = useState(false);
  const [reportModalVisible, setReportModalVisible] = useState(false);

  // Save task data when category changes
  useEffect(() => {
    saveTaskData({ selectedCategory }, selectedCategory !== 'Raw Materials');
  }, [selectedCategory]);

  // Restrict access to users with inventory permission
  useEffect(() => {
    if (!loading && user) {
      if (!user.permissions?.inventory) {
        Alert.alert('Access Denied', 'You do not have permission to access the inventory system.');
        router.back();
      }
    }
  }, [user, loading]);




  if (loading) {
    return (
      <View style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text>Loading...</Text>
        </View>
      </View>
    );
  }

  const handleStockMovement = (item: any) => {

    setSelectedItem(item);
    setStockModalVisible(true);
  };

  const handleRefresh = () => {
    setRefreshKey(prev => prev + 1);
  };


  // Check if user has limited inventory access
  const isLimitedAccess = user?.permissions?.inventoryLimited || false;

  return (

    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="#007AFF" />
        </TouchableOpacity>
        <Text style={styles.title}>Inventory</Text>
        <View style={{ width: 50 }} />
      </View>

      {/* Action buttons row - conditionally show based on access level */}
      <View style={styles.actionButtonsRow}>
        {!isLimitedAccess && (
          <TouchableOpacity onPress={() => setDieselModalVisible(true)} style={[styles.actionButton, { backgroundColor: '#007AFF' }]}>
            <Ionicons name="water" size={24} color="#fff" />
            <Text style={styles.actionButtonText}>Diesel</Text>
          </TouchableOpacity>
        )}

        <TouchableOpacity onPress={() => router.push('/stock-requests')} style={styles.actionButton}>
          <Ionicons name="list" size={24} color="#fff" />
          <Text style={styles.actionButtonText}>Requests</Text>
        </TouchableOpacity>
        
        {!isLimitedAccess && (
          <TouchableOpacity onPress={() => setReportModalVisible(true)} style={[styles.actionButton, { backgroundColor: '#8B5CF6' }]}>
            <Ionicons name="document-text" size={24} color="#fff" />
            <Text style={styles.actionButtonText}>Report</Text>
          </TouchableOpacity>
        )}
        
        {!isLimitedAccess && (
          <TouchableOpacity onPress={() => setAddModalVisible(true)} style={[styles.actionButton, { backgroundColor: '#10B981' }]}>
            <Ionicons name="add-circle" size={24} color="#fff" />
            <Text style={styles.actionButtonText}>Add</Text>
          </TouchableOpacity>
        )}
      </View>




      <View style={styles.dropdownContainer}>

        <TouchableOpacity 
          style={styles.dropdown} 
          onPress={() => setDropdownVisible(!dropdownVisible)}
        >
          <Text style={styles.dropdownText}>{selectedCategory}</Text>
          <Ionicons name={dropdownVisible ? "chevron-up" : "chevron-down"} size={20} color="#333" />
        </TouchableOpacity>
        
        {dropdownVisible && (
          <View style={styles.dropdownMenu}>
            {CATEGORIES.map(cat => (
              <TouchableOpacity
                key={cat}
                style={styles.dropdownItem}
                onPress={() => {
                  setSelectedCategory(cat);
                  setDropdownVisible(false);
                }}
              >
                <Text style={[styles.dropdownItemText, selectedCategory === cat && styles.dropdownItemTextActive]}>
                  {cat}
                </Text>
                {selectedCategory === cat && <Ionicons name="checkmark" size={20} color="#007AFF" />}
              </TouchableOpacity>
            ))}
          </View>
        )}
      </View>

      <InventoryItemsList
        category={selectedCategory}
        onStockMovement={handleStockMovement}
        refreshKey={refreshKey}
      />

      <AddInventoryItemModal
        visible={addModalVisible}
        onClose={() => setAddModalVisible(false)}
        category={selectedCategory}
        onSuccess={handleRefresh}
      />
      <StockMovementModal
        visible={stockModalVisible}
        onClose={() => setStockModalVisible(false)}
        item={selectedItem}
        onSuccess={handleRefresh}
      />

      <DieselModal
        visible={dieselModalVisible}
        onClose={() => setDieselModalVisible(false)}
        onRefresh={handleRefresh}
      />

      <InventoryReportModal
        visible={reportModalVisible}
        onClose={() => setReportModalVisible(false)}
      />
    </View>

  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#ddd' },
  backButton: { padding: 8 },
  title: { fontSize: 20, fontWeight: 'bold', flex: 1, textAlign: 'center' },
  
  actionButtonsRow: { flexDirection: 'row', padding: 12, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#ddd', gap: 8 },
  actionButton: { flex: 1, flexDirection: 'column', alignItems: 'center', justifyContent: 'center', backgroundColor: '#FF9500', paddingVertical: 12, borderRadius: 10, gap: 4 },
  actionButtonText: { color: '#fff', fontSize: 12, fontWeight: '600' },

  dropdownContainer: { backgroundColor: '#fff', padding: 12, borderBottomWidth: 1, borderBottomColor: '#ddd' },
  dropdown: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 12, backgroundColor: '#f8f8f8', borderRadius: 8, borderWidth: 1, borderColor: '#ddd' },
  dropdownText: { fontSize: 16, fontWeight: '600', color: '#333' },
  dropdownMenu: { marginTop: 8, backgroundColor: '#fff', borderRadius: 8, borderWidth: 1, borderColor: '#ddd', elevation: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4 },
  dropdownItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 14, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  dropdownItemText: { fontSize: 15, color: '#333' },
  dropdownItemTextActive: { fontWeight: '600', color: '#007AFF' }
});



