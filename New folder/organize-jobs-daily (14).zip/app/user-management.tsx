import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { supabase } from '@/app/lib/supabase';
import AddUserModal from '@/components/AddUserModal';
import EditUserModal from '@/components/EditUserModal';
import UserManagementMain from './user-management-main';

interface User {
  id: string;
  username: string;
  full_name: string;
  role: string;
  is_active: boolean;
}

export default function UserManagementScreen() {
  const [authenticated, setAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [addModalVisible, setAddModalVisible] = useState(false);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const router = useRouter();

  const handlePasswordSubmit = () => {
    if (password === '1531') {
      setAuthenticated(true);
      fetchUsers();
    } else {
      Alert.alert('Error', 'Invalid password');
    }
  };

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      setUsers(data || []);
    } catch (error: any) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  if (!authenticated) {
    return (
      <View style={styles.container}>
        <Image source={{ uri: 'https://d64gsuwffb70l.cloudfront.net/6826def9056908ac6c0eb35d_1759490551243_ee723b3c.jpg' }} style={styles.logo} resizeMode="contain" />
        <Text style={styles.title}>User Management</Text>
        <Text style={styles.subtitle}>Enter admin password</Text>
        <View style={styles.form}>
          <TextInput style={styles.input} placeholder="Password" value={password} onChangeText={setPassword} secureTextEntry />
          <TouchableOpacity style={styles.button} onPress={handlePasswordSubmit}>
            <Text style={styles.buttonText}>Access</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.linkButton} onPress={() => router.back()}>
            <Text style={styles.linkText}>Back to Login</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <>
      <UserManagementMain users={users} onRefresh={fetchUsers} loading={loading} onEdit={(user) => { setSelectedUser(user); setEditModalVisible(true); }} onAddUser={() => setAddModalVisible(true)} onBack={() => router.back()} />
      <AddUserModal visible={addModalVisible} onClose={() => setAddModalVisible(false)} onUserAdded={fetchUsers} />
      <EditUserModal visible={editModalVisible} user={selectedUser} onClose={() => setEditModalVisible(false)} onUserUpdated={fetchUsers} />
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f5f5f5', padding: 20 },
  logo: { width: 250, height: 80, marginBottom: 20 },
  title: { fontSize: 28, fontWeight: 'bold', color: '#333', marginBottom: 10 },
  subtitle: { fontSize: 16, color: '#666', marginBottom: 30 },
  form: { width: '100%', maxWidth: 400 },
  input: { backgroundColor: '#fff', padding: 15, borderRadius: 8, marginBottom: 15, borderWidth: 1, borderColor: '#ddd' },
  button: { backgroundColor: '#007AFF', padding: 15, borderRadius: 8, alignItems: 'center', marginBottom: 15 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  linkButton: { alignItems: 'center', padding: 10 },
  linkText: { color: '#007AFF', fontSize: 14 }
});
