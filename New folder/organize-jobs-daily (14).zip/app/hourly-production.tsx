import React from 'react';
import { View, Text, StyleSheet, SafeAreaView } from 'react-native';
import HourlyProductionTableV2 from '@/components/HourlyProductionTableV2';

export default function HourlyProductionScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Hourly Production Statistics</Text>
        <Text style={styles.subtitle}>Real-time tracking from 7am to 8pm</Text>
      </View>
      <HourlyProductionTableV2 />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6'
  },
  header: {
    padding: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb'
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 4
  },
  subtitle: {
    fontSize: 14,
    color: '#6b7280'
  }
});
