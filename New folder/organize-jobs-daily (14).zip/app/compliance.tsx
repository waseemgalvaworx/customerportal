import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput, ActivityIndicator, Alert, Image } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from './lib/supabase';
import ComplianceCertificateModal from '../components/ComplianceCertificateModal';
import QCArchiveModal from '../components/QCArchiveModal';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import { logAction } from '../utils/auditLogger';
import { useTaskState } from '../hooks/useTaskState';
import DraftSavedIndicator from '../components/DraftSavedIndicator';



interface JobData {
  id: string;
  jobNumber: string;
  customerName: string;
  dateOfEntry: string;
  completedDate?: string;
  items: Array<{ descriptionOfWorks: string; weightKg: string; id: string }>;
}

interface ComplianceTaskData {
  searchQuery: string;
  jobData: JobData | null;
}


export default function ComplianceScreen() {
  const router = useRouter();
  const { user } = usePasswordAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [jobData, setJobData] = useState<JobData | null>(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [qcArchiveVisible, setQcArchiveVisible] = useState(false);

  // Integrate with Active Tasks system for allowed users
  const { savedData, saveTaskData, isEnabled, showDraftIndicator } = useTaskState<ComplianceTaskData>({
    route: '/compliance',
    title: 'Compliance',
    icon: 'shield-checkmark',
    color: '#8B5CF6'
  });

  // Restore saved data on mount
  useEffect(() => {
    if (savedData && isEnabled) {
      if (savedData.searchQuery) {
        setSearchQuery(savedData.searchQuery);
      }
      if (savedData.jobData) {
        setJobData(savedData.jobData);
      }
    }
  }, [savedData, isEnabled]);

  // Save state when it changes
  useEffect(() => {
    if (isEnabled) {
      const timeout = setTimeout(() => {
        saveTaskData({ searchQuery, jobData }, searchQuery.trim().length > 0 || jobData !== null, 'search');
      }, 500);
      return () => clearTimeout(timeout);
    }
  }, [searchQuery, jobData, isEnabled]);


  // Check permission
  useEffect(() => {
    if (user && !user.permissions.compliance) {
      Alert.alert('Access Denied', 'You do not have permission to access this feature');
      router.back();
    }
  }, [user]);

  if (!user?.permissions.compliance) {
    return null;
  }

  const searchJob = async () => {
    if (!searchQuery.trim()) {
      Alert.alert('Error', 'Please enter a job number');
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .ilike('jobNumber', searchQuery.trim())
        .limit(1);

      if (error) throw error;
      
      if (!data || data.length === 0) {
        Alert.alert('Not Found', `Job number "${searchQuery.trim()}" not found`);
        setJobData(null);
        return;
      }

      const fetchedJob = data[0];
      
      if (!fetchedJob.items || !Array.isArray(fetchedJob.items) || fetchedJob.items.length === 0) {
        Alert.alert('No Items', 'This job has no items');
        setJobData(null);
        return;
      }

      setJobData(fetchedJob);
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Failed to fetch job');
      setJobData(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="#1F2937" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Compliance Certificate</Text>
        <View style={styles.headerRight}>
          {isEnabled && showDraftIndicator && (
            <View style={styles.draftIndicator}>
              <Ionicons name="cloud-done" size={14} color="#10B981" />
              <Text style={styles.draftIndicatorText}>Saved</Text>
            </View>
          )}
          <TouchableOpacity 
            style={styles.headerQcButton} 
            onPress={() => setQcArchiveVisible(true)}
          >
            <Ionicons name="clipboard-outline" size={18} color="#007AFF" />
            <Text style={styles.headerQcButtonText}>QC Archive</Text>
          </TouchableOpacity>
        </View>
      </View>


      <ScrollView style={styles.content}>
        <View style={styles.searchSection}>
          <Text style={styles.label}>Search Job Number</Text>
          <View style={styles.searchContainer}>
            <TextInput
              style={styles.searchInput}
              placeholder="Enter job number..."
              value={searchQuery}
              onChangeText={setSearchQuery}
              onSubmitEditing={searchJob}
            />
            <TouchableOpacity style={styles.searchButton} onPress={searchJob} disabled={loading}>
              {loading ? <ActivityIndicator color="#fff" /> : <Ionicons name="search" size={20} color="#fff" />}
            </TouchableOpacity>
          </View>
        </View>




        {jobData && (
          <View style={styles.resultSection}>
            <View style={styles.jobInfoCard}>
              <Text style={styles.jobInfoLabel}>Job Found</Text>
              <Text style={styles.jobNumber}>{jobData.jobNumber}</Text>
              <Text style={styles.customerName}>{jobData.customerName}</Text>
              <Text style={styles.itemCount}>{jobData.items.length} item(s)</Text>
            </View>
            <TouchableOpacity style={styles.openButton} onPress={() => {
              setModalVisible(true);
              // Log compliance certificate access
              if (user) {
                logAction({
                  userId: user.id,
                  username: user.username,
                  actionType: 'COMPLIANCE_VIEWED',
                  actionDescription: `Viewed compliance certificate for job ${jobData.jobNumber}`,
                  entityType: 'job',
                  entityId: jobData.id,
                  metadata: { jobNumber: jobData.jobNumber, customerName: jobData.customerName }
                });
              }
            }}>
              <Ionicons name="document-text" size={24} color="#fff" />
              <Text style={styles.openButtonText}>Open & Edit Certificate</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>



      {jobData && (
        <ComplianceCertificateModal
          visible={modalVisible}
          onClose={() => setModalVisible(false)}
          jobId={jobData.id}
          jobNumber={jobData.jobNumber}
          customerName={jobData.customerName}
          items={jobData.items}
        />
      )}

      <QCArchiveModal 
        visible={qcArchiveVisible} 
        onClose={() => setQcArchiveVisible(false)} 
      />

    </View>

  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, paddingTop: 60, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: '#1F2937' },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  draftIndicator: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#ECFDF5', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  draftIndicatorText: { fontSize: 11, color: '#059669', fontWeight: '500' },
  headerQcButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#E3F2FD',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 6,
    gap: 4
  },
  headerQcButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#007AFF'
  },
  content: { flex: 1, padding: 16 },
  searchSection: { backgroundColor: 'white', padding: 16, borderRadius: 12, marginBottom: 16 },
  label: { fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 8 },
  searchContainer: { flexDirection: 'row', gap: 8 },
  searchInput: { flex: 1, borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, padding: 12, fontSize: 16 },
  searchButton: { backgroundColor: '#3B82F6', padding: 12, borderRadius: 8, justifyContent: 'center', alignItems: 'center', width: 48 },
  resultSection: { backgroundColor: 'white', padding: 16, borderRadius: 12 },
  jobInfoCard: { backgroundColor: '#F0FDF4', padding: 12, borderRadius: 8, marginBottom: 16, borderWidth: 1, borderColor: '#BBF7D0' },
  jobInfoLabel: { fontSize: 12, color: '#15803D', fontWeight: '600', marginBottom: 4 },
  jobNumber: { fontSize: 18, fontWeight: 'bold', color: '#166534' },
  customerName: { fontSize: 14, color: '#374151', marginTop: 4 },
  itemCount: { fontSize: 12, color: '#6B7280', marginTop: 4 },
  openButton: { backgroundColor: '#8B5CF6', padding: 16, borderRadius: 8, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 12 },
  openButtonText: { color: 'white', fontSize: 16, fontWeight: 'bold' }
});


