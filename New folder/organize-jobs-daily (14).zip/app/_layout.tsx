import { Stack } from 'expo-router';
import { JobProvider } from '../contexts/JobContext';
import { CustomerProvider } from '../contexts/CustomerContext';
import { SettingsProvider } from '../contexts/SettingsContext';
import { PasswordAuthProvider } from '../contexts/PasswordAuthContext';
import { RealtimeProvider } from '../contexts/RealtimeContext';
import { NotificationProvider } from '../contexts/NotificationContext';
import { TaskProvider } from '../contexts/TaskContext';
import { NetworkStatusIndicator } from '../components/NetworkStatusIndicator';
import { NotificationBell } from '../components/NotificationBell';
import { ActiveTasksButton } from '../components/ActiveTasksButton';
import { ErrorBoundary } from '../components/ErrorBoundary';
import { View } from 'react-native';
import { useEffect } from 'react';
import { scheduleDailyReconciliation } from '../utils/dataReconciliation';

export default function RootLayout() {
  // Initialize daily reconciliation scheduler on app startup
  useEffect(() => {
    const reconciliationInterval = scheduleDailyReconciliation();
    
    return () => {
      clearInterval(reconciliationInterval);
    };
  }, []);

  return (
    <ErrorBoundary>
      <PasswordAuthProvider>
        <SettingsProvider>
          <RealtimeProvider>
            <NotificationProvider>
              <TaskProvider>
                <CustomerProvider>
                  <JobProvider>
                    <Stack
                      screenOptions={{
                        headerRight: () => (
                          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <ActiveTasksButton />
                            <NotificationBell />
                            <NetworkStatusIndicator />
                          </View>
                        )
                      }}
                    >
                      <Stack.Screen name="login" options={{ title: 'Login', headerShown: false }} />
                      <Stack.Screen name="index" options={{ title: 'Jobs' }} />
                      <Stack.Screen name="job/[id]" options={{ title: 'Job Details' }} />
                      <Stack.Screen name="planning" options={{ title: 'Planning' }} />
                      <Stack.Screen name="wip" options={{ title: 'WIP' }} />
                      <Stack.Screen name="done" options={{ title: 'Completed Jobs' }} />
                      <Stack.Screen name="archive" options={{ title: 'Archive' }} />
                      <Stack.Screen name="customers" options={{ title: 'Customers' }} />
                      <Stack.Screen name="statistics" options={{ title: 'Statistics' }} />
                      <Stack.Screen name="notifications" options={{ title: 'Notifications' }} />
                    </Stack>
                  </JobProvider>
                </CustomerProvider>
              </TaskProvider>
            </NotificationProvider>
          </RealtimeProvider>
        </SettingsProvider>
      </PasswordAuthProvider>
    </ErrorBoundary>
  );
}

