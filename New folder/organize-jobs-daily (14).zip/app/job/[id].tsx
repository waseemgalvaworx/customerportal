import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Modal, Alert, Platform, ActionSheetIOS } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useJobs, Priority, JobItem } from '../../contexts/JobContext';
import { usePasswordAuth } from '../../contexts/PasswordAuthContext';
import { Ionicons } from '@expo/vector-icons';
import DateTimePicker from '../../components/DateTimePicker';
import ItemOptionsDisplay from '../../components/ItemOptionsDisplay';
import ComplianceCertificateModal from '../../components/ComplianceCertificateModal';
import QualityControlModal from '../../components/QualityControlModal';
import AutocompleteInput from '../../components/AutocompleteInput';
import PasswordPrompt from '../../components/PasswordPrompt';






export default function JobDetailsScreen() {
  const params = useLocalSearchParams();
  const router = useRouter();
  const { jobs, updateJob, moveToPlanning, deleteJob } = useJobs();
  const { user } = usePasswordAuth();
  
  // Ensure id is always a string
  const jobId = Array.isArray(params.id) ? params.id[0] : params.id || '';
  const readOnly = params.readOnly === 'true';
  const source = Array.isArray(params.source) ? params.source[0] : params.source;
  const showQcButton = (source === 'planning' || source === 'wip') && user?.permissions.canModifyQC;
  
  // For WIP context, check canEditJobDetails permission
  const canEditInWip = source === 'wip' ? (user?.permissions.canEditJobDetails ?? true) : true;
  const canEdit = !readOnly && canEditInWip;
  
  const job = jobs.find(j => j.id === jobId);


  const [editMode, setEditMode] = useState(false);
  const [deletePromptVisible, setDeletePromptVisible] = useState(false);

  const [editedJobNumber, setEditedJobNumber] = useState(job?.jobNumber || '');
  const [editedCustomerName, setEditedCustomerName] = useState(job?.customerName || '');
  const [editedNotes, setEditedNotes] = useState(job?.notes || '');
  const [priority, setPriority] = useState<Priority | undefined>(job?.priority);
  const [priorityModalVisible, setPriorityModalVisible] = useState(false);
  const [items, setItems] = useState<JobItem[]>(job?.items || []);
  const [addItemModalVisible, setAddItemModalVisible] = useState(false);
  const [newItemCount, setNewItemCount] = useState('');
  const [newItemDesc, setNewItemDesc] = useState('');
  const [newItemWeight, setNewItemWeight] = useState('');

  const [galvaXpress, setGalvaXpress] = useState(job?.galvaXpress || false);
  const [deliveryDate, setDeliveryDate] = useState<Date | undefined>(job?.deliveryDate);
  const [datePickerVisible, setDatePickerVisible] = useState(false);
  
  const now = new Date();
  const [selectedDay, setSelectedDay] = useState(now.getDate());
  const [selectedMonth, setSelectedMonth] = useState(now.getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(now.getFullYear());
  const [selectedHour, setSelectedHour] = useState(now.getHours());
  const [selectedMinute, setSelectedMinute] = useState(now.getMinutes());
  const [certificateVisible, setCertificateVisible] = useState(false);
  const [qcModalVisible, setQcModalVisible] = useState(false);
  const [selectedQcItem, setSelectedQcItem] = useState<{ itemName: string } | null>(null);








  if (!job) return <View style={styles.container}><Text style={styles.errorText}>Job not found</Text></View>;

  const handleAddItem = () => {
    if (items.length >= 10) {
      Alert.alert('Maximum Items', 'Cannot add more than 10 items');
      return;
    }
    if (newItemDesc.trim() && newItemWeight.trim()) {
      const newItem: JobItem = {
        id: `item-${Date.now()}`,
        itemCount: newItemCount,
        descriptionOfWorks: newItemDesc,
        weightKg: newItemWeight,
        status: 'Pending'
      };
      const updatedItems = [...items, newItem];
      setItems(updatedItems);
      updateJob(job.id, { items: updatedItems });
      setNewItemCount('');
      setNewItemDesc('');
      setNewItemWeight('');
      setAddItemModalVisible(false);
    }
  };


  const handleDeleteItem = (itemId: string) => {
    const updatedItems = items.filter(item => item.id !== itemId);
    setItems(updatedItems);
    updateJob(job.id, { items: updatedItems });
  };

  const handleSetPriority = (p: Priority) => {
    setPriority(p);
    updateJob(job.id, { priority: p });
    setPriorityModalVisible(false);
  };

  const handleMoveToPlanning = async () => {
    if (!priority) {
      Alert.alert('Set Priority', 'Please set a priority before moving to planning');
      setPriorityModalVisible(true);
      return;
    }
    try {
      await moveToPlanning(job.id);
      Alert.alert('Success', 'Job moved to Planning and WIP');
      router.back();
    } catch (error) {
      console.error('Error moving to planning:', error);
      Alert.alert('Error', 'Failed to move job to planning');
    }
  };


  const handleSaveEdit = () => {
    updateJob(job.id, {
      jobNumber: editedJobNumber,
      customerName: editedCustomerName,
      notes: editedNotes
    });
    setEditMode(false);
    Alert.alert('Success', 'Job details updated');
  };

  const handleDeleteJob = async () => {
    try {
      await deleteJob(jobId);
      setDeletePromptVisible(false);
      Alert.alert('Success', 'Job deleted successfully');
      router.back();
    } catch (error) {
      console.error('Error deleting job:', error);
      Alert.alert('Error', 'Failed to delete job');
    }
  };



  const handleToggleGalvaXpress = () => {
    const newValue = !galvaXpress;
    setGalvaXpress(newValue);
    if (newValue) {
      // Automatically set priority to HIGH when GalvXpress is selected
      setPriority('high');
      updateJob(job.id, { galvaXpress: newValue, priority: 'high' });
    } else {
      updateJob(job.id, { galvaXpress: newValue });
    }
  };


  const handleSetDeliveryDate = () => {
    const newDate = new Date(selectedYear, selectedMonth - 1, selectedDay, selectedHour, selectedMinute);
    setDeliveryDate(newDate);
    updateJob(job.id, { deliveryDate: newDate });
    setDatePickerVisible(false);
  };

  const handleOpenDatePicker = () => {
    if (deliveryDate) {
      setSelectedDay(deliveryDate.getDate());
      setSelectedMonth(deliveryDate.getMonth() + 1);
      setSelectedYear(deliveryDate.getFullYear());
      setSelectedHour(deliveryDate.getHours());
      setSelectedMinute(deliveryDate.getMinutes());
    }
    setDatePickerVisible(true);
  };


  const handleClearDeliveryDate = () => {
    setDeliveryDate(undefined);
    updateJob(job.id, { deliveryDate: undefined });
  };


  const totalWeight = items.reduce((sum, item) => sum + parseFloat(item.weightKg || '0'), 0);



  return (
    <ScrollView style={styles.container}>
      {readOnly && (
        <View style={styles.readOnlyBanner}>
          <Text style={styles.readOnlyText}>📋 Read-Only View</Text>
        </View>
      )}
      <View style={styles.header}>
        {editMode ? (
          <>
            <TextInput
              style={styles.editInput}
              value={editedJobNumber}
              onChangeText={setEditedJobNumber}
              placeholder="Job Number"
            />
            <TextInput
              style={styles.editInput}
              value={editedCustomerName}
              onChangeText={setEditedCustomerName}
              placeholder="Customer Name"
            />
          </>
        ) : (
          <>
            <Text style={styles.jobNumber}>{job.jobNumber}</Text>
            <Text style={styles.customerName}>{job.customerName}</Text>
          </>
        )}
        <Text style={styles.dateText}>Entry: {new Date(job.dateOfEntry).toLocaleDateString()}</Text>
      </View>


      <View style={styles.prioritySection}>
        <Text style={styles.sectionTitle}>Priority</Text>
        {readOnly ? (
          <View style={styles.priorityButton}>
            <Text style={styles.priorityButtonText}>
              {priority ? priority.toUpperCase() : 'Not Set'}
            </Text>
          </View>
        ) : (
          <TouchableOpacity style={styles.priorityButton} onPress={() => setPriorityModalVisible(true)}>
            <Text style={styles.priorityButtonText}>
              {priority ? priority.toUpperCase() : 'Set Priority'}
            </Text>
            <Ionicons name="chevron-down" size={20} color="#6B7280" />
          </TouchableOpacity>
        )}
      </View>




      <View style={styles.deliverySection}>
        <Text style={styles.sectionTitle}>Delivery Date</Text>
        {deliveryDate ? (
          <View style={styles.deliveryDateContainer}>
            <View style={styles.deliveryDateInfo}>
              <Text style={styles.deliveryDateText}>
                {`${deliveryDate.getDate().toString().padStart(2, '0')}-${(deliveryDate.getMonth() + 1).toString().padStart(2, '0')}-${deliveryDate.getFullYear()}`} at {deliveryDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </Text>
            </View>
            {canEdit && (
              <View style={styles.deliveryActions}>
                <TouchableOpacity onPress={() => setDatePickerVisible(true)}>
                  <Ionicons name="create-outline" size={20} color="#3B82F6" />
                </TouchableOpacity>
                <TouchableOpacity onPress={handleClearDeliveryDate}>
                  <Ionicons name="trash-outline" size={20} color="#EF4444" />
                </TouchableOpacity>
              </View>
            )}
          </View>
        ) : (
          canEdit ? (
            <TouchableOpacity style={styles.setDateButton} onPress={() => setDatePickerVisible(true)}>
              <Ionicons name="calendar-outline" size={20} color="#6B7280" />
              <Text style={styles.setDateText}>Set Delivery Date & Time</Text>
            </TouchableOpacity>
          ) : (
            <Text style={styles.notesText}>No delivery date set</Text>
          )
        )}
      </View>




      <View style={styles.itemsSection}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Items ({items.length}/10)</Text>
          {canEdit && (
            <TouchableOpacity onPress={() => setAddItemModalVisible(true)}>
              <Ionicons name="add-circle" size={28} color="#3B82F6" />
            </TouchableOpacity>
          )}
        </View>

        
        
        {items.map(item => (
          <View key={item.id} style={styles.itemCard}>
            <View style={styles.itemContent}>
              <View style={styles.itemHeader}>
                <View style={{ flex: 1 }}>
                  {item.itemCount && (
                    <Text style={styles.itemCount}>Qty: {item.itemCount}</Text>
                  )}
                  <Text style={styles.itemDesc}>{item.descriptionOfWorks}</Text>
                </View>
                {showQcButton && (
                  <TouchableOpacity 
                    style={styles.qcButton}
                    onPress={() => {
                      setSelectedQcItem({ itemName: item.descriptionOfWorks });
                      setQcModalVisible(true);
                    }}
                  >
                    <Ionicons name="clipboard-outline" size={20} color="#8B5CF6" />
                    <Text style={styles.qcButtonText}>QC</Text>
                  </TouchableOpacity>
                )}
              </View>
              <Text style={styles.itemWeight}>{item.weightKg} kg</Text>
              <ItemOptionsDisplay 
                paintVarnish={item.paintVarnish}
                galva={item.galva}
                lightGalva={item.lightGalva}
                lightPaint={item.lightPaint}
                rusty={item.rusty}
              />
            </View>
            {canEdit && (
              <TouchableOpacity onPress={() => handleDeleteItem(item.id)}>
                <Ionicons name="trash-outline" size={20} color="#EF4444" />
              </TouchableOpacity>
            )}
          </View>


        ))}




        <View style={styles.totalRow}>
          <Text style={styles.totalLabel}>Total Weight:</Text>
          <Text style={styles.totalValue}>{totalWeight.toFixed(1)} kg</Text>
        </View>

      </View>

      {selectedQcItem && (
        <QualityControlModal
          visible={qcModalVisible}
          onClose={() => setQcModalVisible(false)}
          jobId={jobId}
          itemName={selectedQcItem.itemName}
          jobNumber={job.jobNumber}
        />
      )}



      <View style={styles.notesSection}>
        <Text style={styles.sectionTitle}>Notes</Text>
        {editMode ? (
          <TextInput
            style={styles.notesInput}
            value={editedNotes}
            onChangeText={setEditedNotes}
            placeholder="Notes"
            multiline
          />
        ) : (
          <Text style={styles.notesText}>{job.notes || 'No notes'}</Text>
        )}
      </View>



      {!readOnly && job.status === 'pending' && (
        <TouchableOpacity style={styles.planButton} onPress={handleMoveToPlanning}>
          <Ionicons name="calendar" size={24} color="white" />
          <Text style={styles.planButtonText}>Move to Planning</Text>
        </TouchableOpacity>
      )}





      {canEdit && (
        editMode ? (
          <View style={styles.editModeContainer}>
            <View style={styles.editActions}>
              <TouchableOpacity style={styles.cancelEditButton} onPress={() => setEditMode(false)}>
                <Text style={styles.cancelEditText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveEditButton} onPress={handleSaveEdit}>
                <Text style={styles.saveEditText}>Save Changes</Text>
              </TouchableOpacity>
            </View>
            <TouchableOpacity 
              style={styles.deleteButton} 
              onPress={() => setDeletePromptVisible(true)}
            >
              <Ionicons name="trash-outline" size={20} color="#EF4444" />
              <Text style={styles.deleteButtonText}>Delete Job</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <TouchableOpacity style={styles.editButton} onPress={() => setEditMode(true)}>
            <Ionicons name="create-outline" size={20} color="#3B82F6" />
            <Text style={styles.editButtonText}>Edit Job</Text>
          </TouchableOpacity>
        )
      )}







      <Modal visible={priorityModalVisible} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Set Priority</Text>
            {(['low', 'medium', 'high'] as Priority[]).map(p => (
              <TouchableOpacity key={p} style={styles.priorityOption} onPress={() => handleSetPriority(p)}>
                <Text style={[styles.priorityOptionText, priority === p && styles.selectedPriority]}>{p.toUpperCase()}</Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={styles.cancelButton} onPress={() => setPriorityModalVisible(false)}>
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={addItemModalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Add Item</Text>
            
            <TextInput
              style={styles.input}
              placeholder="Item Count (Qty)"
              value={newItemCount}
              onChangeText={setNewItemCount}
              keyboardType="numeric"
            />

            <AutocompleteInput
              value={newItemDesc}
              onChangeText={setNewItemDesc}
              placeholder="Description of works"
              field="descriptionOfWorks"
              style={styles.input}
            />

            <TextInput
              style={styles.input}
              placeholder="Quantity (kg)"
              value={newItemWeight}
              onChangeText={setNewItemWeight}
              keyboardType="numeric"
            />

            <View style={styles.modalActions}>
              <TouchableOpacity style={styles.modalButton} onPress={() => setAddItemModalVisible(false)}>
                <Text style={styles.modalButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.modalButton, styles.primaryButton]} onPress={handleAddItem}>
                <Text style={[styles.modalButtonText, styles.primaryButtonText]}>Add</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={datePickerVisible} transparent animationType="slide">


        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { maxHeight: '80%' }]}>
            <Text style={styles.modalTitle}>Set Delivery Date & Time</Text>
            <DateTimePicker
              selectedDay={selectedDay}
              selectedMonth={selectedMonth}
              selectedYear={selectedYear}
              selectedHour={selectedHour}
              selectedMinute={selectedMinute}
              onDayChange={setSelectedDay}
              onMonthChange={setSelectedMonth}
              onYearChange={setSelectedYear}
              onHourChange={setSelectedHour}
              onMinuteChange={setSelectedMinute}
            />
            <View style={styles.modalActions}>
              <TouchableOpacity style={styles.modalButton} onPress={() => setDatePickerVisible(false)}>
                <Text style={styles.modalButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.modalButton, styles.primaryButton]} onPress={handleSetDeliveryDate}>
                <Text style={[styles.modalButtonText, styles.primaryButtonText]}>Set Date</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <ComplianceCertificateModal
        visible={certificateVisible}
        onClose={() => setCertificateVisible(false)}
        jobId={job.id}
        jobNumber={job.jobNumber}
        customerName={job.customerName}
        items={items}
      />

      <PasswordPrompt
        visible={deletePromptVisible}
        title="Delete Job"
        onConfirm={handleDeleteJob}
        onCancel={() => setDeletePromptVisible(false)}
      />

    </ScrollView>


  );
}


const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  readOnlyBanner: { backgroundColor: '#FEF3C7', padding: 12, alignItems: 'center', borderBottomWidth: 1, borderBottomColor: '#F59E0B' },
  readOnlyText: { fontSize: 14, fontWeight: '600', color: '#92400E' },
  header: { backgroundColor: 'white', padding: 20, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  jobNumber: { fontSize: 24, fontWeight: 'bold', color: '#1F2937' },
  customerName: { fontSize: 18, color: '#374151', marginTop: 4 },
  dateText: { fontSize: 14, color: '#6B7280', marginTop: 4 },
  editInput: { borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, padding: 12, marginBottom: 8, fontSize: 16, backgroundColor: '#F9FAFB' },
  prioritySection: { backgroundColor: 'white', padding: 16, marginTop: 8 },
  sectionTitle: { fontSize: 16, fontWeight: '600', color: '#374151', marginBottom: 8 },
  priorityButton: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 12, backgroundColor: '#F9FAFB', borderRadius: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  priorityButtonText: { fontSize: 16, color: '#374151' },
  itemsSection: { backgroundColor: 'white', padding: 16, marginTop: 8 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  itemCard: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 12, backgroundColor: '#F9FAFB', borderRadius: 8, marginBottom: 8 },
  itemContent: { flex: 1 },
  itemHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  qcButton: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 4, backgroundColor: '#F3E8FF', borderRadius: 6 },
  qcButtonText: { fontSize: 12, color: '#8B5CF6', fontWeight: '600' },
  itemCount: { fontSize: 13, color: '#3B82F6', fontWeight: '600', marginBottom: 2 },
  itemDesc: { fontSize: 14, color: '#374151' },
  itemWeight: { fontSize: 13, color: '#6B7280' },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: '#E5E7EB' },
  totalLabel: { fontSize: 16, fontWeight: '600', color: '#374151' },
  totalValue: { fontSize: 16, fontWeight: 'bold', color: '#1F2937' },
  notesSection: { backgroundColor: 'white', padding: 16, marginTop: 8 },
  notesText: { fontSize: 14, color: '#6B7280' },
  notesInput: { borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, padding: 12, fontSize: 14, backgroundColor: '#F9FAFB', minHeight: 80 },
  planButton: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', backgroundColor: '#3B82F6', margin: 16, padding: 16, borderRadius: 12, gap: 8 },
  planButtonText: { color: 'white', fontSize: 16, fontWeight: 'bold' },
  certificateButton: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', backgroundColor: '#10B981', margin: 16, marginTop: 8, padding: 16, borderRadius: 12, gap: 8 },
  certificateButtonText: { color: 'white', fontSize: 16, fontWeight: 'bold' },
  exportButton: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', backgroundColor: '#8B5CF6', margin: 16, marginBottom: 8, padding: 16, borderRadius: 12, gap: 8 },
  exportButtonText: { color: 'white', fontSize: 16, fontWeight: 'bold' },
  editButton: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', margin: 16, padding: 14, borderRadius: 12, backgroundColor: '#EBF5FF', gap: 8 },
  editButtonText: { color: '#3B82F6', fontSize: 16, fontWeight: '600' },
  editModeContainer: { marginBottom: 16 },
  editActions: { flexDirection: 'row', gap: 12, marginHorizontal: 16, marginTop: 16 },
  cancelEditButton: { flex: 1, padding: 14, borderRadius: 12, backgroundColor: '#F3F4F6', alignItems: 'center' },
  cancelEditText: { color: '#6B7280', fontSize: 16, fontWeight: '600' },
  saveEditButton: { flex: 1, padding: 14, borderRadius: 12, backgroundColor: '#10B981', alignItems: 'center' },
  saveEditText: { color: 'white', fontSize: 16, fontWeight: 'bold' },
  errorText: { fontSize: 18, color: '#EF4444', textAlign: 'center', marginTop: 40 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { backgroundColor: 'white', borderRadius: 16, padding: 20, width: '80%' },
  modalTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 16, textAlign: 'center' },
  priorityOption: { padding: 16, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  priorityOptionText: { fontSize: 16, color: '#374151', textAlign: 'center' },
  selectedPriority: { color: '#3B82F6', fontWeight: 'bold' },
  cancelButton: { padding: 16, marginTop: 8 },
  cancelButtonText: { fontSize: 16, color: '#6B7280', textAlign: 'center' },
  input: { borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, padding: 12, marginBottom: 12, fontSize: 16 },
  modalActions: { flexDirection: 'row', gap: 12, marginTop: 8 },
  modalButton: { flex: 1, padding: 12, borderRadius: 8, backgroundColor: '#F3F4F6', alignItems: 'center' },
  primaryButton: { backgroundColor: '#3B82F6' },
  modalButtonText: { fontSize: 16, color: '#374151', fontWeight: '600' },
  primaryButtonText: { color: 'white' },
  galvaSection: { backgroundColor: 'white', padding: 16, marginTop: 8 },
  galvaXpressButton: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  galvaXpressText: { fontSize: 18, fontWeight: 'bold', color: '#EF4444' },
  deliverySection: { backgroundColor: 'white', padding: 16, marginTop: 8 },
  deliveryDateContainer: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 12, backgroundColor: '#F9FAFB', borderRadius: 8 },
  deliveryDateInfo: { flex: 1 },
  deliveryDateText: { fontSize: 15, color: '#374151', fontWeight: '500' },
  deliveryActions: { flexDirection: 'row', gap: 12 },
  setDateButton: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 12, backgroundColor: '#F9FAFB', borderRadius: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  setDateText: { fontSize: 15, color: '#6B7280' },
  deleteButton: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginHorizontal: 16, marginTop: 8, padding: 14, borderRadius: 12, backgroundColor: '#FEE2E2', gap: 8 },
  deleteButtonText: { color: '#EF4444', fontSize: 16, fontWeight: '600' }
});




