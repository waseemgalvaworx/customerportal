import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert } from 'react-native';

import { useNotifications } from '../contexts/NotificationContext';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import ComposeMessageModal from '../components/ComposeMessageModal';
import MessageDetailModal from '../components/MessageDetailModal';
import { supabase } from './lib/supabase';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';

type TabType = 'inbox' | 'sent' | 'archive';
type ArchiveFolderType = 'messages' | 'notifications' | null;
type InboxFilterType = 'all' | 'messages' | 'notifications';


export default function NotificationsScreen() {
  const { notifications, unreadCount, markAsRead, markAllAsRead, refreshNotifications } = useNotifications();
  const router = useRouter();
  const [composeVisible, setComposeVisible] = useState(false);
  const [selectedNotification, setSelectedNotification] = useState<any>(null);
  const [detailVisible, setDetailVisible] = useState(false);
  const [activeTab, setActiveTab] = useState<TabType>('inbox');
  const [sentMessages, setSentMessages] = useState<any[]>([]);
  const [archiveFolder, setArchiveFolder] = useState<ArchiveFolderType>(null);
  const [inboxFilter, setInboxFilter] = useState<InboxFilterType>('all');
  const { user } = usePasswordAuth();

  useEffect(() => {
    const cleanupOldNotifications = async () => {
      if (!user) return;
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      await supabase
        .from('notifications')
        .delete()
        .eq('user_id', user.id)
        .eq('read', true)
        .lt('created_at', thirtyDaysAgo.toISOString());
    };
    
    cleanupOldNotifications();
  }, [user]);

  useEffect(() => {
    if (activeTab === 'sent' && user) {
      fetchSentMessages();
    }
  }, [activeTab, user]);



  const fetchSentMessages = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('notifications')
      .select('*')
      .eq('sender_id', user.id)
      .order('created_at', { ascending: false });
    
    if (data) {
      // Fetch recipient profiles
      const recipientIds = [...new Set(data.map(n => n.user_id))];
      let recipientProfiles: any = {};
      
      if (recipientIds.length > 0) {
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, full_name')
          .in('id', recipientIds);
        
        if (profiles) {
          profiles.forEach(p => {
            recipientProfiles[p.id] = p;
          });
        }
      }
      
      // Attach recipient profile to each message
      const enrichedData = data.map(n => ({
        ...n,
        recipient_profile: recipientProfiles[n.user_id] || null
      }));
      
      setSentMessages(enrichedData);
    }
  };




  const handleNotificationPress = async (notification: any) => {
    console.log('=== NOTIFICATION PRESSED ===');
    console.log('Notification:', { id: notification.id, type: notification.type, read: notification.read, job_id: notification.job_id });
    
    // Always mark as read when pressed
    if (!notification.read) {
      console.log('📖 Marking notification as read...');
      await markAsRead(notification.id);
    }
    
    if (notification.type === 'message') {
      setSelectedNotification(notification);
      setDetailVisible(true);
    } else if (notification.job_id && activeTab !== 'inbox') {
      // Only navigate to job details if not in inbox tab
      router.push(`/job/${notification.job_id}`);
    }
    // For system notifications in inbox without job_id, just mark as read (already done above)
  };



  const handleArchiveNotification = async (notificationId: string) => {
    const { error } = await supabase
      .from('notifications')
      .update({ archived: true })
      .eq('id', notificationId);
    
    if (!error) {
      await refreshNotifications();
    }
  };














  const handleDeleteNotification = async (notificationId: string) => {
    console.log('=== DELETE NOTIFICATION STARTED ===');
    console.log('Notification ID:', notificationId);
    console.log('User:', user);
    console.log('Supabase client:', supabase ? 'initialized' : 'NOT initialized');
    
    Alert.alert(
      'Delete Permanently',
      'Are you sure you want to permanently delete this item from the database? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            console.log('Delete confirmed, executing delete...');
            
            try {
              const { data, error } = await supabase
                .from('notifications')
                .delete()
                .eq('id', notificationId);

              console.log('Delete response - data:', data);
              console.log('Delete response - error:', error);

              if (error) {
                console.error('DELETE FAILED:', error);
                console.error('Error code:', error.code);
                console.error('Error message:', error.message);
                console.error('Error details:', error.details);
                console.error('Error hint:', error.hint);
                Alert.alert('Error', `Failed to delete item: ${error.message}`);
              } else {
                console.log('DELETE SUCCESSFUL');
                Alert.alert('Success', 'Item deleted successfully');
                // Refresh the data based on active tab
                if (activeTab === 'sent') {
                  fetchSentMessages();
                }
              }
            } catch (err) {
              console.error('EXCEPTION during delete:', err);
              Alert.alert('Error', `Exception occurred: ${err}`);
            }
          }
        }
      ]
    );
  };




  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return '#ef4444';
      case 'high': return '#f59e0b';
      default: return '#6b7280';
    }
  };


  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'galvxpress': return 'flash';
      case 'job_status': return 'briefcase';
      case 'qc': return 'checkmark-circle';
      case 'inventory': return 'cube';
      case 'delivery': return 'car';
      case 'message': return 'mail';
      default: return 'information-circle';
    }
  };

  const inboxNotifications = notifications.filter(n => !n.archived);
  const inboxMessages = inboxNotifications.filter(n => n.type === 'message');
  const inboxSystemNotifs = inboxNotifications.filter(n => n.type !== 'message');
  
  // Apply inbox filter
  const filteredInboxNotifications = inboxFilter === 'all' 
    ? inboxNotifications 
    : inboxFilter === 'messages' 
      ? inboxMessages 
      : inboxSystemNotifs;
  
  const archivedNotifications = notifications.filter(n => n.archived);
  const archivedMessages = archivedNotifications.filter(n => n.type === 'message');
  const archivedSystemNotifs = archivedNotifications.filter(n => n.type !== 'message');





  const renderNotificationList = (notifList: any[], showDeleteButton: boolean = false) => (
    notifList.length === 0 ? (
      <View style={styles.empty}>
        <Ionicons name="notifications-off-outline" size={48} color="#9ca3af" />
        <Text style={styles.emptyText}>No notifications</Text>
      </View>
    ) : (
      notifList.map((notification) => (
        <View key={notification.id} style={[styles.item, !notification.read && styles.unread]}>
          <TouchableOpacity
            style={styles.itemContent}
            onPress={() => handleNotificationPress(notification)}
            activeOpacity={0.7}
          >
            <View style={styles.iconContainer}>
              <Ionicons 
                name={getTypeIcon(notification.type)} 
                size={24} 
                color={getPriorityColor(notification.priority)} 
              />
            </View>
            <View style={styles.content}>
              <Text style={styles.notifTitle}>{notification.title}</Text>
              <Text style={styles.message}>{notification.message}</Text>
              {activeTab === 'inbox' && notification.sender_profile && (
                <Text style={styles.sender}>From: {notification.sender_profile.full_name}</Text>
              )}
              {activeTab === 'sent' && notification.recipient_profile && (
                <Text style={styles.recipient}>To: {notification.recipient_profile.full_name}</Text>
              )}
              <Text style={styles.time}>
                {new Date(notification.created_at).toLocaleString()}
              </Text>
            </View>
          </TouchableOpacity>
          {activeTab === 'inbox' && !notification.read && !showDeleteButton && (
            <TouchableOpacity 
              onPress={async () => {
                await markAsRead(notification.id);
              }}
              style={styles.markReadBtn}
            >
              <Ionicons name="checkmark-circle-outline" size={20} color="#10b981" />
            </TouchableOpacity>
          )}
          {activeTab === 'inbox' && notification.read && !showDeleteButton && (
            <TouchableOpacity 
              onPress={() => handleArchiveNotification(notification.id)}
              style={styles.archiveBtn}
            >
              <Ionicons name="archive-outline" size={20} color="#6b7280" />
            </TouchableOpacity>
          )}
          {showDeleteButton && (
            <TouchableOpacity 
              onPress={() => handleDeleteNotification(notification.id)}
              style={styles.deleteBtn}
            >
              <Ionicons name="trash-outline" size={20} color="#ef4444" />
            </TouchableOpacity>
          )}
        </View>
      ))
    )
  );





  return (
    <View style={styles.container}>

      <View style={styles.header}>
        {activeTab === 'archive' && archiveFolder && (
          <TouchableOpacity onPress={() => setArchiveFolder(null)} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </TouchableOpacity>
        )}
        <Text style={styles.title}>Messages</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity onPress={() => setComposeVisible(true)} style={styles.iconBtn}>
            <Ionicons name="create-outline" size={24} color="#007AFF" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => router.push('/notification-settings')} style={styles.iconBtn}>
            <Ionicons name="settings-outline" size={24} color="#007AFF" />
          </TouchableOpacity>
        </View>
      </View>


      <View style={styles.tabs}>
        <TouchableOpacity 
          style={[styles.tab, activeTab === 'inbox' && styles.activeTab]} 
          onPress={() => setActiveTab('inbox')}
        >
          <Ionicons name="mail-outline" size={20} color={activeTab === 'inbox' ? '#007AFF' : '#6b7280'} />
          <Text style={[styles.tabText, activeTab === 'inbox' && styles.activeTabText]}>Inbox</Text>
          {unreadCount > 0 && activeTab === 'inbox' && (
            <View style={styles.badge}><Text style={styles.badgeText}>{unreadCount}</Text></View>
          )}
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tab, activeTab === 'sent' && styles.activeTab]} 
          onPress={() => setActiveTab('sent')}
        >
          <Ionicons name="send-outline" size={20} color={activeTab === 'sent' ? '#007AFF' : '#6b7280'} />
          <Text style={[styles.tabText, activeTab === 'sent' && styles.activeTabText]}>Sent</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tab, activeTab === 'archive' && styles.activeTab]} 
          onPress={() => setActiveTab('archive')}
        >
          <Ionicons name="archive-outline" size={20} color={activeTab === 'archive' ? '#007AFF' : '#6b7280'} />
          <Text style={[styles.tabText, activeTab === 'archive' && styles.activeTabText]}>Archive</Text>
        </TouchableOpacity>
      </View>

      {/* Inbox Filter Chips */}
      {activeTab === 'inbox' && inboxNotifications.length > 0 && (
        <View style={styles.filterChips}>
          <TouchableOpacity 
            style={[styles.filterChip, inboxFilter === 'all' && styles.filterChipActive]}
            onPress={() => setInboxFilter('all')}
          >
            <Text style={[styles.filterChipText, inboxFilter === 'all' && styles.filterChipTextActive]}>
              All ({inboxNotifications.length})
            </Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.filterChip, inboxFilter === 'messages' && styles.filterChipActive]}
            onPress={() => setInboxFilter('messages')}
          >
            <Ionicons name="mail" size={14} color={inboxFilter === 'messages' ? '#fff' : '#007AFF'} />
            <Text style={[styles.filterChipText, inboxFilter === 'messages' && styles.filterChipTextActive]}>
              Messages ({inboxMessages.length})
            </Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.filterChip, inboxFilter === 'notifications' && styles.filterChipActive]}
            onPress={() => setInboxFilter('notifications')}
          >
            <Ionicons name="notifications" size={14} color={inboxFilter === 'notifications' ? '#fff' : '#10b981'} />
            <Text style={[styles.filterChipText, inboxFilter === 'notifications' && styles.filterChipTextActive]}>
              System ({inboxSystemNotifs.length})
            </Text>
          </TouchableOpacity>
        </View>
      )}

      {activeTab === 'inbox' && inboxNotifications.length > 0 && unreadCount > 0 && (
        <View style={styles.actionBar}>
          <TouchableOpacity style={styles.actionBtn} onPress={markAllAsRead}>
            <Ionicons name="checkmark-done-outline" size={18} color="#007AFF" />
            <Text style={styles.actionBtnText}>Mark all as read</Text>
          </TouchableOpacity>
        </View>
      )}




      <ScrollView style={styles.list}>
        {activeTab === 'inbox' && renderNotificationList(filteredInboxNotifications)}
        {activeTab === 'sent' && renderNotificationList(sentMessages)}
        {activeTab === 'archive' && !archiveFolder && (
          <View style={styles.folderContainer}>
            <TouchableOpacity style={styles.folderCard} onPress={() => setArchiveFolder('messages')}>
              <Ionicons name="mail" size={40} color="#007AFF" />
              <Text style={styles.folderTitle}>Messages</Text>
              <Text style={styles.folderCount}>{archivedMessages.length}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.folderCard} onPress={() => setArchiveFolder('notifications')}>
              <Ionicons name="notifications" size={40} color="#10b981" />
              <Text style={styles.folderTitle}>Notifications</Text>
              <Text style={styles.folderCount}>{archivedSystemNotifs.length}</Text>
            </TouchableOpacity>
          </View>
        )}
        {activeTab === 'archive' && archiveFolder === 'messages' && renderNotificationList(archivedMessages, true)}
        {activeTab === 'archive' && archiveFolder === 'notifications' && renderNotificationList(archivedSystemNotifs, true)}
      </ScrollView>

      <ComposeMessageModal 
        visible={composeVisible} 
        onClose={() => setComposeVisible(false)} 
      />

      <MessageDetailModal
        visible={detailVisible}
        onClose={() => {
          setDetailVisible(false);
          setSelectedNotification(null);
        }}
        notification={selectedNotification}
        isSentMessage={activeTab === 'sent'}
      />

    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f9fafb' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#e5e7eb' },
  backBtn: { marginRight: 8 },
  title: { fontSize: 24, fontWeight: 'bold', flex: 1 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  iconBtn: { padding: 4 },
  tabs: { flexDirection: 'row', backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#e5e7eb' },
  tab: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 12, gap: 6, borderBottomWidth: 2, borderBottomColor: 'transparent' },
  activeTab: { borderBottomColor: '#007AFF' },
  tabText: { fontSize: 15, color: '#6b7280', fontWeight: '500' },
  activeTabText: { color: '#007AFF', fontWeight: '600' },
  badge: { backgroundColor: '#ef4444', borderRadius: 10, paddingHorizontal: 6, paddingVertical: 2, minWidth: 20, alignItems: 'center' },
  badgeText: { color: '#fff', fontSize: 11, fontWeight: '600' },
  filterChips: { flexDirection: 'row', backgroundColor: 'white', paddingVertical: 8, paddingHorizontal: 12, gap: 8, borderBottomWidth: 1, borderBottomColor: '#e5e7eb' },
  filterChip: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 6, paddingHorizontal: 12, borderRadius: 16, backgroundColor: '#f3f4f6', borderWidth: 1, borderColor: '#e5e7eb' },
  filterChipActive: { backgroundColor: '#007AFF', borderColor: '#007AFF' },
  filterChipText: { fontSize: 12, color: '#374151', fontWeight: '500' },
  filterChipTextActive: { color: '#fff' },
  actionBar: { flexDirection: 'row', backgroundColor: '#eff6ff', paddingVertical: 8, paddingHorizontal: 16, borderBottomWidth: 1, borderBottomColor: '#e5e7eb', gap: 16, justifyContent: 'center' },
  actionBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 4, paddingHorizontal: 12, backgroundColor: 'white', borderRadius: 20, borderWidth: 1, borderColor: '#e5e7eb' },
  actionBtnText: { color: '#007AFF', fontSize: 13, fontWeight: '500' },
  list: { flex: 1 },
  folderContainer: { padding: 16, gap: 16 },
  folderCard: { backgroundColor: 'white', borderRadius: 12, padding: 24, alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  folderTitle: { fontSize: 18, fontWeight: 'bold', marginTop: 12, color: '#1F2937' },
  folderCount: { fontSize: 14, color: '#6b7280', marginTop: 4 },
  item: { flexDirection: 'row', backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#e5e7eb', alignItems: 'center' },
  unread: { backgroundColor: '#eff6ff', borderLeftWidth: 4, borderLeftColor: '#3b82f6' },
  itemContent: { flex: 1, flexDirection: 'row', alignItems: 'center', paddingVertical: 12, paddingLeft: 16 },
  iconContainer: { marginRight: 12 },
  content: { flex: 1 },
  notifTitle: { fontSize: 16, fontWeight: '600', marginBottom: 4 },
  message: { fontSize: 14, color: '#6b7280', marginBottom: 4 },
  sender: { fontSize: 12, color: '#3b82f6', marginBottom: 4, fontWeight: '500' },
  recipient: { fontSize: 12, color: '#10b981', marginBottom: 4, fontWeight: '500' },
  time: { fontSize: 12, color: '#9ca3af' },
  markReadBtn: { padding: 12, paddingRight: 16 },
  archiveBtn: { padding: 12, paddingRight: 16 },
  empty: { alignItems: 'center', justifyContent: 'center', paddingVertical: 80 },
  emptyText: { fontSize: 16, color: '#9ca3af', marginTop: 12 },
  deleteBtn: { padding: 12, paddingRight: 16 }
});
