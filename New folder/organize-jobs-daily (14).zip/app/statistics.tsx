import React, { useMemo, useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import { useJobs } from '../contexts/JobContext';
import { Ionicons } from '@expo/vector-icons';
import WipStatisticsModal from '../components/WipStatisticsModal';
import DailyKgsReceivedView from '../components/DailyKgsReceivedView';
import DailyFinishingKgsView from '../components/DailyFinishingKgsView';
import DailyCompletedKgsView from '../components/DailyCompletedKgsView';
import MetricsComparisonView from '../components/MetricsComparisonView';
import CustomerStatistics from '../components/CustomerStatistics';
import PerformanceMetricsView from '../components/PerformanceMetricsView';
import DraftSavedIndicator from '../components/DraftSavedIndicator';

import { saveAllSnapshots } from '../utils/autoSnapshotScheduler';
import { supabase } from './lib/supabase';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import { useTaskState } from '../hooks/useTaskState';

// Type for task state
interface StatisticsTaskState {
  comparisonMode: boolean;
  showCustomers: boolean;
  showPerformance: boolean;
}

export default function StatisticsScreen() {
  const { jobs } = useJobs();
  const { user } = usePasswordAuth();
  const [wipStatisticsVisible, setWipStatisticsVisible] = useState(false);
  const [comparisonMode, setComparisonMode] = useState(false);
  const [showCustomers, setShowCustomers] = useState(false);
  const [showPerformance, setShowPerformance] = useState(false);

  const [finishingRecords, setFinishingRecords] = useState<any[]>([]);

  // Integrate with Active Tasks system
  const { savedData, saveTaskData, isEnabled, showDraftIndicator } = useTaskState<StatisticsTaskState>({
    route: '/statistics',
    title: 'Statistics',
    icon: 'bar-chart',
    color: '#8B5CF6'
  });

  // Restore saved state on mount
  useEffect(() => {
    if (savedData && isEnabled) {
      if (savedData.comparisonMode !== undefined) setComparisonMode(savedData.comparisonMode);
      if (savedData.showCustomers !== undefined) setShowCustomers(savedData.showCustomers);
      if (savedData.showPerformance !== undefined) setShowPerformance(savedData.showPerformance);
    }
  }, [savedData, isEnabled]);

  // Save state when it changes
  useEffect(() => {
    if (isEnabled) {
      saveTaskData({
        comparisonMode,
        showCustomers,
        showPerformance
      }, true, 'filter');
    }
  }, [comparisonMode, showCustomers, showPerformance, isEnabled]);

  // Define allowed users for Customer Statistics
  const allowedCustomerStatsUsers = ['admin', 'Lovena', 'KH'];
  const hasCustomerStatsAccess = user && allowedCustomerStatsUsers.includes(user.username);

  // Define allowed users for Performance Metrics (trends and performance)
  const allowedPerformanceUsers = ['admin', 'Lovena', 'KH'];
  const hasPerformanceAccess = user && allowedPerformanceUsers.includes(user.username);

  useEffect(() => {
    saveAllSnapshots();
    fetchFinishingRecords();
  }, []);

  const fetchFinishingRecords = async () => {
    const today = new Date().toISOString().split('T')[0];
    const { data, error } = await supabase.from('finishing_records').select('*').eq('recorded_date', today);
    if (!error && data) {
      const uniqueRecords = Array.from(
        data.reduce((map, item) => {
          const existing = map.get(item.item_id);
          if (!existing || new Date(item.created_at || 0) > new Date(existing.created_at || 0)) {
            map.set(item.item_id, item);
          }
          return map;
        }, new Map()).values()
      );
      setFinishingRecords(uniqueRecords);
    }
  };

  const wipJobs = jobs.filter(job => job.status === 'planning');

  return (
    <View style={styles.container}>
      {/* Draft Saved Indicator */}
      {isEnabled && <DraftSavedIndicator visible={showDraftIndicator} style={styles.draftIndicator} />}
      
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <Image 
            source={{ uri: 'https://d64gsuwffb70l.cloudfront.net/6826def9056908ac6c0eb35d_1759490551243_ee723b3c.jpg' }}
            style={styles.logo}
            resizeMode="contain"
          />
          <View style={styles.headerButtons}>
            <TouchableOpacity 
              style={styles.statsButton}
              onPress={() => setWipStatisticsVisible(true)}
            >
              <Ionicons name="stats-chart" size={24} color="#3B82F6" />
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.title}>Production Statistics</Text>

        <View style={styles.modeToggle}>
          <TouchableOpacity
            style={[styles.modeButton, !comparisonMode && styles.modeButtonActive]}
            onPress={() => setComparisonMode(false)}
          >
            <Text style={[styles.modeText, !comparisonMode && styles.modeTextActive]}>Single View</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.modeButton, comparisonMode && styles.modeButtonActive]}
            onPress={() => setComparisonMode(true)}
          >
            <Text style={[styles.modeText, comparisonMode && styles.modeTextActive]}>Comparison</Text>
          </TouchableOpacity>
        </View>

        {!comparisonMode ? (
          <>
            <DailyKgsReceivedView jobs={jobs} />
            <DailyFinishingKgsView jobs={jobs} />
            <DailyCompletedKgsView jobs={jobs} />
          </>
        ) : (
          <MetricsComparisonView jobs={jobs} />
        )}

        {/* Customer Statistics Section - Only visible to authorized users */}
        {hasCustomerStatsAccess && (
          <View style={styles.customerStatsSection}>
            <TouchableOpacity 
              style={styles.customerStatsHeader} 
              onPress={() => setShowCustomers(!showCustomers)}
            >
              <View style={styles.customerStatsLeft}>
                <Text style={styles.customerStatsTitle}>Customer Statistics</Text>
                <Text style={styles.customerStatsSubtitle}>View customer metrics and trends</Text>
              </View>
              <Ionicons 
                name={showCustomers ? "chevron-up" : "chevron-down"} 
                size={24} 
                color="white" 
              />
            </TouchableOpacity>
            {showCustomers && (
              <View style={styles.customerStatsContent}>
                <CustomerStatistics jobs={jobs} finishingRecords={finishingRecords} />
              </View>
            )}
          </View>
        )}

        {/* Performance Metrics Section - Only visible to authorized users */}
        {hasPerformanceAccess && (
          <View style={styles.customerStatsSection}>
            <TouchableOpacity 
              style={[styles.customerStatsHeader, { backgroundColor: '#FF9500' }]} 
              onPress={() => setShowPerformance(!showPerformance)}
            >
              <View style={styles.customerStatsLeft}>
                <Text style={styles.customerStatsTitle}>Performance Metrics</Text>
                <Text style={styles.customerStatsSubtitle}>Completion times and bottlenecks</Text>
              </View>
              <Ionicons 
                name={showPerformance ? "chevron-up" : "chevron-down"} 
                size={24} 
                color="white" 
              />
            </TouchableOpacity>
            {showPerformance && (
              <View style={styles.customerStatsContent}>
                <PerformanceMetricsView />
              </View>
            )}
          </View>
        )}
      </ScrollView>

      <WipStatisticsModal
        visible={wipStatisticsVisible}
        onClose={() => setWipStatisticsVisible(false)}
        jobs={wipJobs}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { backgroundColor: 'white', padding: 16, paddingTop: 12, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerContent: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  logo: { flex: 1, height: 60 },
  headerButtons: { flexDirection: 'row' },
  statsButton: { padding: 8, marginLeft: 12 },
  draftIndicator: { position: 'absolute', top: 80, right: 16, zIndex: 100 },

  content: { padding: 16 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#1F2937', marginBottom: 16 },
  modeToggle: { flexDirection: 'row', marginBottom: 16, backgroundColor: 'white', borderRadius: 8, padding: 4 },
  modeButton: { flex: 1, paddingVertical: 10, paddingHorizontal: 16, borderRadius: 6, alignItems: 'center' },
  modeButtonActive: { backgroundColor: '#3B82F6' },
  modeText: { fontSize: 14, fontWeight: '600', color: '#6B7280' },
  modeTextActive: { color: 'white' },
  periodSelector: { flexDirection: 'row', marginBottom: 16, backgroundColor: 'white', borderRadius: 8, padding: 4 },
  periodButton: { flex: 1, paddingVertical: 8, paddingHorizontal: 12, borderRadius: 6, alignItems: 'center' },
  periodButtonActive: { backgroundColor: '#3B82F6' },
  periodText: { fontSize: 14, fontWeight: '600', color: '#6B7280' },
  periodTextActive: { color: 'white' },
  summaryCard: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 20, flexDirection: 'row', justifyContent: 'space-around' },
  summaryItem: { alignItems: 'center' },
  summaryLabel: { fontSize: 12, color: '#6B7280', marginBottom: 4 },
  summaryValue: { fontSize: 20, fontWeight: 'bold', color: '#1F2937' },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', marginBottom: 12 },
  stageCard: { backgroundColor: 'white', borderRadius: 8, padding: 16, marginBottom: 8, flexDirection: 'row', alignItems: 'center' },
  stageIndicator: { width: 4, height: 40, borderRadius: 2, marginRight: 12 },
  stageInfo: { flex: 1 },
  stageName: { fontSize: 16, fontWeight: '600', color: '#1F2937' },
  stageCount: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  stageWeight: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  comparisonTypeScroll: { marginBottom: 16, marginHorizontal: -16 },
  comparisonTypeScrollContent: { paddingHorizontal: 16 },
  comparisonTypeButton: { backgroundColor: 'white', paddingVertical: 10, paddingHorizontal: 16, borderRadius: 8, marginRight: 8, borderWidth: 2, borderColor: '#E5E7EB' },
  comparisonTypeButtonActive: { backgroundColor: '#3B82F6', borderColor: '#3B82F6' },
  comparisonTypeText: { fontSize: 14, fontWeight: '600', color: '#6B7280' },
  comparisonTypeTextActive: { color: 'white' },
  
  // Customer Statistics styles
  customerStatsSection: { marginTop: 16, marginBottom: 16, backgroundColor: 'white', borderRadius: 12, overflow: 'hidden', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  customerStatsHeader: { padding: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#10B981' },
  customerStatsLeft: { flex: 1 },
  customerStatsTitle: { fontSize: 18, fontWeight: 'bold', color: 'white', marginBottom: 4 },
  customerStatsSubtitle: { fontSize: 14, color: 'white', fontWeight: '600' },
  customerStatsContent: { height: 500 },
});
