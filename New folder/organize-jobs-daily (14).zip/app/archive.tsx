import React, { useState, useMemo, useEffect } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useJobs } from '../contexts/JobContext';
import { ArchiveModalMainContent } from '../components/ArchiveModalMain';
import { handleViewPDF, handleEmailReport } from '../components/ArchiveModalHandlers';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from './lib/supabase';
import { useFocusEffect } from '@react-navigation/native';
import { useTaskState } from '../hooks/useTaskState';
import DraftSavedIndicator from '../components/DraftSavedIndicator';

type ReportType = 'completed' | 'finishing' | 'delivered' | null;

// Type for task state
interface ArchiveTaskState {
  selectedReportType: ReportType;
  selectedDate: string | null;
}

const formatDateForReport = (date: Date) => {
  const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
  const months = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'];
  return `${days[date.getDay()]} ${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`;
};

export default function ArchiveScreen() {
  const { jobs } = useJobs();
  const [selectedReportType, setSelectedReportType] = useState<ReportType>(null);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [emailingReport, setEmailingReport] = useState(false);
  const [archivedFinishingReports, setArchivedFinishingReports] = useState<any[]>([]);
  const [completedItems, setCompletedItems] = useState<any[]>([]);
  const [deliveredItems, setDeliveredItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // Integrate with Active Tasks system
  const { savedData, saveTaskData, isEnabled, showDraftIndicator } = useTaskState<ArchiveTaskState>({
    route: '/archive',
    title: 'Archive',
    icon: 'archive',
    color: '#6366F1'
  });

  // Restore saved state on mount
  useEffect(() => {
    if (savedData && isEnabled) {
      if (savedData.selectedReportType !== undefined) setSelectedReportType(savedData.selectedReportType);
      if (savedData.selectedDate !== undefined) setSelectedDate(savedData.selectedDate);
    }
  }, [savedData, isEnabled]);

  // Save state when it changes
  useEffect(() => {
    if (isEnabled) {
      saveTaskData({
        selectedReportType,
        selectedDate
      }, selectedReportType !== null, 'filter');
    }
  }, [selectedReportType, selectedDate, isEnabled]);

  useFocusEffect(
    React.useCallback(() => {
      fetchAllData();
    }, [])
  );

  const fetchAllData = async () => {
    setLoading(true);
    await Promise.all([
      fetchArchivedFinishingReports(),
      fetchCompletedItems(),
      fetchDeliveredItems()
    ]);
    setLoading(false);
  };

  const fetchArchivedFinishingReports = async () => {
    const { data, error } = await supabase.from('archived_finishing_reports').select('*').order('report_date', { ascending: false });
    if (!error && data) setArchivedFinishingReports(data);
  };

  const fetchCompletedItems = async () => {
    const allCompleted: any[] = [];
    const seenIds = new Set<string>();

    // Fetch from item_stage_tracking (newer records with ready_date)
    const { data: tracking, error: trackingError } = await supabase
      .from('item_stage_tracking')
      .select('*')
      .not('ready_date', 'is', null)
      .order('ready_date', { ascending: false });

    if (!trackingError && tracking) {
      const jobIds = [...new Set(tracking.map(t => t.job_id))];
      if (jobIds.length > 0) {
        const { data: jobsData } = await supabase.from('jobs').select('id, jobNumber, customerName, items').in('id', jobIds);
        const jobMap: { [key: string]: any } = {};
        (jobsData || []).forEach(job => { jobMap[job.id] = job; });

        tracking.forEach(t => {
          const job = jobMap[t.job_id];
          if (!job) return;
          const item = (job.items || []).find((i: any) => i.id === t.item_id);
          if (!item) return;
          const key = `${t.job_id}-${t.item_id}`;
          if (!seenIds.has(key)) {
            seenIds.add(key);
            allCompleted.push({
              id: key, job_id: t.job_id, job_number: job.jobNumber, customer_name: job.customerName,
              item_id: t.item_id, item_description: item.descriptionOfWorks, weight_kg: parseFloat(item.weightKg || '0'),
              item_options: { paintVarnish: item.paintVarnish, galva: item.galva, lightGalva: item.lightGalva, lightPaint: item.lightPaint, rusty: item.rusty },
              ready_date: t.ready_date
            });
          }
        });
      }
    }

    // Fetch from completed_jobs table (includes older records)
    const { data: completedJobsData, error: completedError } = await supabase
      .from('completed_jobs')
      .select('*')
      .order('completed_at', { ascending: false });

    if (!completedError && completedJobsData) {
      completedJobsData.forEach(item => {
        const key = `${item.job_id}-${item.item_id}`;
        if (!seenIds.has(key)) {
          seenIds.add(key);
          allCompleted.push({
            id: key,
            job_id: item.job_id,
            job_number: item.job_number,
            customer_name: item.customer_name,
            item_id: item.item_id,
            item_description: item.item_description,
            weight_kg: parseFloat(item.weight_kg || '0'),
            item_options: item.item_options || {},
            ready_date: item.completed_at // Use completed_at as ready_date for grouping
          });
        }
      });
    }

    setCompletedItems(allCompleted);
  };

  const fetchDeliveredItems = async () => {
    // Fetch from archived_deliveries
    const { data: archived } = await supabase.from('archived_deliveries').select('*').order('delivery_date', { ascending: false });
    
    // Fetch from completed_jobs where delivered = true
    const { data: completedDelivered } = await supabase.from('completed_jobs').select('*').eq('delivered', true).order('delivery_date', { ascending: false });
    
    // Fetch from jobs where delivered = true
    const { data: deliveredJobs } = await supabase.from('jobs').select('*').eq('delivered', true).order('delivered_at', { ascending: false });
    
    const allDelivered: any[] = [];
    const seenIds = new Set<string>();
    
    // Add archived deliveries
    (archived || []).forEach(item => {
      const key = `${item.job_id}-${item.item_id}`;
      if (!seenIds.has(key)) { seenIds.add(key); allDelivered.push(item); }
    });
    
    // Add from completed_jobs
    (completedDelivered || []).forEach(item => {
      const key = `${item.job_id}-${item.item_id}`;
      if (!seenIds.has(key)) {
        seenIds.add(key);
        allDelivered.push({ ...item, delivery_date: item.delivery_date || item.delivered_at || item.completed_at });
      }
    });
    
    // Add items from delivered jobs
    (deliveredJobs || []).forEach(job => {
      (job.items || []).forEach((item: any) => {
        const key = `${job.id}-${item.id}`;
        if (!seenIds.has(key)) {
          seenIds.add(key);
          allDelivered.push({
            id: key, job_id: job.id, job_number: job.jobNumber, customer_name: job.customerName,
            item_id: item.id, item_description: item.descriptionOfWorks, weight_kg: parseFloat(item.weightKg || '0'),
            item_options: { paintVarnish: item.paintVarnish, galva: item.galva, lightGalva: item.lightGalva, lightPaint: item.lightPaint, rusty: item.rusty },
            delivery_date: job.deliveredAt || job.delivered_at || new Date().toISOString()
          });
        }
      });
    });
    
    setDeliveredItems(allDelivered);
  };

  const completedByDate = useMemo(() => {
    const grouped: { [key: string]: any[] } = {};
    completedItems.forEach(item => {
      if (item.ready_date) {
        const date = new Date(item.ready_date).toLocaleDateString('en-GB');
        if (!grouped[date]) grouped[date] = [];
        grouped[date].push(item);
      }
    });
    return grouped;
  }, [completedItems]);

  const deliveredByDate = useMemo(() => {
    const grouped: { [key: string]: any[] } = {};
    deliveredItems.forEach(item => {
      if (item.delivery_date) {
        const date = new Date(item.delivery_date).toLocaleDateString('en-GB');
        if (!grouped[date]) grouped[date] = [];
        grouped[date].push(item);
      }
    });
    return grouped;
  }, [deliveredItems]);

  const finishingByDate = useMemo(() => {
    const grouped: { [key: string]: any } = {};
    archivedFinishingReports.forEach(report => {
      const date = new Date(report.report_date).toLocaleDateString('en-GB');
      grouped[date] = report;
    });
    return grouped;
  }, [archivedFinishingReports]);

  const getDataByDate = () => {
    if (selectedReportType === 'finishing') return finishingByDate;
    if (selectedReportType === 'delivered') return deliveredByDate;
    return completedByDate;
  };

  const dates = useMemo(() => {
    const dataByDate = getDataByDate();
    return Object.keys(dataByDate).sort((a, b) => {
      const [dayA, monthA, yearA] = a.split('/');
      const [dayB, monthB, yearB] = b.split('/');
      return new Date(`${yearB}-${monthB}-${dayB}`).getTime() - new Date(`${yearA}-${monthA}-${dayA}`).getTime();
    });
  }, [selectedReportType, completedByDate, finishingByDate, deliveredByDate]);

  const dataByDate = getDataByDate();
  const selectedData = selectedDate ? dataByDate[selectedDate] : (selectedReportType === 'finishing' ? null : []);
  
  const reportDate = selectedDate 
    ? (() => { const [day, month, year] = selectedDate.split('/'); return formatDateForReport(new Date(parseInt(year), parseInt(month) - 1, parseInt(day))); })()
    : formatDateForReport(new Date());

  const handleSelectReportType = (type: ReportType) => {
    setSelectedReportType(type);
    setSelectedDate(null);
    const relevantDates = type === 'finishing' ? Object.keys(finishingByDate) : type === 'delivered' ? Object.keys(deliveredByDate) : Object.keys(completedByDate);
    const sortedDates = relevantDates.sort((a, b) => {
      const [dayA, monthA, yearA] = a.split('/');
      const [dayB, monthB, yearB] = b.split('/');
      return new Date(`${yearB}-${monthB}-${dayB}`).getTime() - new Date(`${yearA}-${monthA}-${dayA}`).getTime();
    });
    if (sortedDates.length > 0) setSelectedDate(sortedDates[0]);
  };

  const handleBack = () => { setSelectedReportType(null); setSelectedDate(null); setDropdownOpen(false); };
  const onViewPDFHandler = (includeTime: boolean) => { handleViewPDF(selectedReportType, selectedData, selectedDate, includeTime); };
  const onEmailReportHandler = (recipients: string[], includeTime: boolean) => { handleEmailReport(selectedReportType, selectedData, selectedDate, recipients, setEmailingReport, includeTime); };
  const handleRefresh = () => { fetchAllData(); };

  const getTitle = () => {
    if (selectedReportType === 'finishing') return 'Finishing Report';
    if (selectedReportType === 'delivered') return 'Delivered Items';
    if (selectedReportType === 'completed') return 'Completed Items';
    return 'Archive';
  };

  return (
    <View style={styles.container}>
      {/* Draft Saved Indicator */}
      {isEnabled && <DraftSavedIndicator visible={showDraftIndicator} style={styles.draftIndicator} />}
      
      <View style={styles.header}>
        <Image source={{ uri: 'https://d64gsuwffb70l.cloudfront.net/6826def9056908ac6c0eb35d_1759490551243_ee723b3c.jpg' }} style={styles.logo} resizeMode="contain" />
        <View style={styles.titleRow}>
          {selectedReportType && <TouchableOpacity onPress={handleBack} style={styles.backButton}><Ionicons name="arrow-back" size={24} color="#007AFF" /></TouchableOpacity>}
          <Text style={styles.title}>{getTitle()}</Text>
          {loading && <ActivityIndicator size="small" color="#007AFF" style={{ marginLeft: 10 }} />}
        </View>
      </View>

      <ArchiveModalMainContent
        selectedReportType={selectedReportType} dates={dates} dataByDate={dataByDate} selectedDate={selectedDate}
        setSelectedDate={setSelectedDate} dropdownOpen={dropdownOpen} setDropdownOpen={setDropdownOpen}
        handleSelectReportType={handleSelectReportType} selectedData={selectedData} reportDate={reportDate}
        onViewPDF={onViewPDFHandler} onEmailReport={onEmailReportHandler} emailingReport={emailingReport}
        onBack={handleBack} onRefresh={handleRefresh}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { backgroundColor: 'white', padding: 16, paddingTop: 12, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  logo: { width: '100%', height: 60, marginBottom: 8 },
  titleRow: { flexDirection: 'row', alignItems: 'center' },
  backButton: { marginRight: 12 },
  title: { fontSize: 20, fontWeight: 'bold', color: '#1F2937', flex: 1 },
  draftIndicator: { position: 'absolute', top: 80, right: 16, zIndex: 100 },
});
