import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, TextInput, Modal, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { useCustomers, Customer } from '../contexts/CustomerContext';
import { useJobs } from '../contexts/JobContext';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import { Ionicons } from '@expo/vector-icons';
import { useTaskState } from '../hooks/useTaskState';
import DraftSavedIndicator from '../components/DraftSavedIndicator';

// Type for task state
interface CustomersTaskState {
  searchQuery: string;
  expandedId: string | null;
  // Form data for add/edit modal
  formData?: {
    name: string;
    email: string;
    phone: string;
    company: string;
    address: string;
    notes: string;
    editingCustomerId: string | null;
  };
}

export default function CustomersScreen() {
  const router = useRouter();
  const { customers, addCustomer, updateCustomer } = useCustomers();
  const { jobs } = useJobs();
  const { user } = usePasswordAuth();
  const [modalVisible, setModalVisible] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [company, setCompany] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  // Integrate with Active Tasks system
  const { savedData, saveTaskData, isEnabled, showDraftIndicator, markAsSaved } = useTaskState<CustomersTaskState>({
    route: '/customers',
    title: 'Customers',
    icon: 'people',
    color: '#EC4899'
  });

  // Restore saved state on mount
  useEffect(() => {
    if (savedData && isEnabled) {
      if (savedData.searchQuery !== undefined) setSearchQuery(savedData.searchQuery);
      if (savedData.expandedId !== undefined) setExpandedId(savedData.expandedId);
      
      // Restore form data if modal was open
      if (savedData.formData) {
        setName(savedData.formData.name || '');
        setEmail(savedData.formData.email || '');
        setPhone(savedData.formData.phone || '');
        setCompany(savedData.formData.company || '');
        setAddress(savedData.formData.address || '');
        setNotes(savedData.formData.notes || '');
        if (savedData.formData.editingCustomerId) {
          const customer = customers.find(c => c.id === savedData.formData?.editingCustomerId);
          if (customer) {
            setEditingCustomer(customer);
            setModalVisible(true);
          }
        } else if (savedData.formData.name || savedData.formData.email || savedData.formData.phone) {
          // Had unsaved form data, reopen modal
          setModalVisible(true);
        }
      }
    }
  }, [savedData, isEnabled, customers]);

  // Save state when it changes (excluding modal state)
  useEffect(() => {
    if (isEnabled) {
      const taskState: CustomersTaskState = {
        searchQuery,
        expandedId,
      };
      
      // Include form data if modal is open and has content
      if (modalVisible && (name || email || phone || company || address || notes)) {
        taskState.formData = {
          name,
          email,
          phone,
          company,
          address,
          notes,
          editingCustomerId: editingCustomer?.id || null,
        };
      }
      
      saveTaskData(taskState, modalVisible && (!!name || !!email || !!phone), 'filter');
    }
  }, [searchQuery, expandedId, isEnabled, modalVisible, name, email, phone, company, address, notes, editingCustomer]);

  // Check if user is admin
  const isAdmin = user?.username === 'admin';
  
  // Users who can add/edit customers
  const canManageCustomers = ['admin', 'Luvish', 'Lovena', 'KH'].includes(user?.username || '');

  const filteredCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.company.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getCustomerStats = (customerName: string) => {
    const customerJobs = jobs.filter(j => j.customerName === customerName);
    const completedJobs = customerJobs.filter(j => j.status === 'done' || j.status === 'archived');
    const totalWeight = customerJobs.reduce((sum, job) => 
      sum + job.items.reduce((itemSum, item) => itemSum + parseFloat(item.weightKg || '0'), 0), 0
    );
    return { totalJobs: customerJobs.length, completedJobs: completedJobs.length, totalWeight };
  };

  const openAddModal = () => {
    resetForm();
    setEditingCustomer(null);
    setModalVisible(true);
  };

  const openEditModal = (customer: Customer) => {
    setEditingCustomer(customer);
    setName(customer.name);
    setEmail(customer.email);
    setPhone(customer.phone);
    setCompany(customer.company);
    setAddress(customer.address);
    setNotes(customer.notes);
    setModalVisible(true);
  };

  const handleSave = async () => {
    if (!name.trim()) {
      Alert.alert('Error', 'Customer name is required');
      return;
    }
    
    setSaving(true);
    
    try {
      if (editingCustomer) {
        await updateCustomer(editingCustomer.id, { name, email, phone, company, address, notes });
      } else {
        await addCustomer({ name, email, phone, company, address, notes });
      }
      resetForm();
      markAsSaved(); // Mark task as saved after successful save
      Alert.alert('Success', `Customer ${editingCustomer ? 'updated' : 'added'} successfully!`);
    } catch (error: any) {
      console.error('Error saving customer:', error);
      Alert.alert('Error', error?.message || 'Failed to save customer. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const resetForm = () => {
    setName(''); setEmail(''); setPhone(''); setCompany(''); setAddress(''); setNotes('');
    setModalVisible(false); setEditingCustomer(null);
  };

  // Navigate to job details - read-only for non-admin users
  const handleJobPress = (jobId: string) => {
    if (isAdmin) {
      router.push(`/job/${jobId}`);
    } else {
      // Non-admin users get read-only view
      router.push(`/job/${jobId}?readOnly=true`);
    }
  };

  return (
    <View style={styles.container}>
      {/* Draft Saved Indicator */}
      {isEnabled && <DraftSavedIndicator visible={showDraftIndicator} style={styles.draftIndicator} />}
      
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color="#2563eb" />
        </TouchableOpacity>
        <Text style={styles.title}>Customers</Text>
      </View>

      <View style={styles.searchContainer}>
        <Ionicons name="search" size={20} color="#6B7280" />
        <TextInput style={styles.searchInput} placeholder="Search..." value={searchQuery} onChangeText={setSearchQuery} />
      </View>

      <FlatList
        data={filteredCustomers}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingBottom: 100 }}
        renderItem={({ item }) => {
          const stats = getCustomerStats(item.name);
          const customerJobs = jobs.filter(j => j.customerName === item.name);
          const isExpanded = expandedId === item.id;
          return (
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <TouchableOpacity 
                  onPress={() => setExpandedId(isExpanded ? null : item.id)}
                  style={{ flex: 1 }}
                >
                  <View style={{ flex: 1 }}>
                    <Text style={styles.name}>{item.name}</Text>
                    {item.company && <Text style={styles.company}><Ionicons name="business" size={14} color="#2563eb" /> {item.company}</Text>}
                  </View>
                </TouchableOpacity>
                {/* Only show edit button for users who can manage customers */}
                {canManageCustomers && (
                  <View style={styles.actions}>
                    <TouchableOpacity 
                      onPress={() => openEditModal(item)}
                      style={styles.actionButton}
                      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                    >
                      <Ionicons name="create-outline" size={22} color="#3B82F6" />
                    </TouchableOpacity>
                  </View>
                )}
              </View>

              {item.email && <Text style={styles.detail}><Ionicons name="mail" size={14} color="#6B7280" /> {item.email}</Text>}
              {item.phone && <Text style={styles.detail}><Ionicons name="call" size={14} color="#6B7280" /> {item.phone}</Text>}
              {item.address && <Text style={styles.detail}><Ionicons name="location" size={14} color="#6B7280" /> {item.address}</Text>}
              
              <View style={styles.statsRow}>
                <Text style={styles.stat}><Ionicons name="cube" size={13} color="#8b5cf6" /> {stats.totalJobs} Jobs</Text>
                <Text style={styles.stat}><Ionicons name="checkmark-circle" size={13} color="#8b5cf6" /> {stats.completedJobs} Completed</Text>
                <Text style={styles.stat}><Ionicons name="scale" size={13} color="#8b5cf6" /> {stats.totalWeight.toFixed(0)} kg</Text>
              </View>

              {isExpanded && customerJobs.length > 0 && (
                <View style={styles.jobHistory}>
                  <Text style={styles.historyTitle}>Job History {!isAdmin && <Text style={styles.readOnlyHint}>(View Only)</Text>}</Text>
                  {customerJobs.map(job => (
                    <TouchableOpacity key={job.id} onPress={() => handleJobPress(job.id)} style={styles.jobItem}>
                      <Text style={styles.jobNumber}>{job.jobNumber}</Text>
                      <Text style={styles.jobDate}>{new Date(job.dateOfEntry).toLocaleDateString()}</Text>
                      <Text style={[styles.jobStatus, { color: job.status === 'done' ? '#10b981' : job.status === 'planning' ? '#f59e0b' : '#6b7280' }]}>
                        {(job.status || 'pending').toUpperCase()}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              )}
            </View>
          );
        }}
      />

      {/* Show FAB for Admin, Luvish, Lovena, and KH users */}
      {canManageCustomers && (
        <TouchableOpacity style={styles.fab} onPress={openAddModal}>
          <Text style={styles.fabText}>+</Text>
        </TouchableOpacity>
      )}


      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <ScrollView>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>{editingCustomer ? 'Edit' : 'Add'} Customer</Text>
                {isEnabled && (name || email || phone) && (
                  <View style={styles.draftBadge}>
                    <Ionicons name="cloud-done-outline" size={12} color="#10B981" />
                    <Text style={styles.draftBadgeText}>Auto-saving</Text>
                  </View>
                )}
              </View>
              <Text style={styles.label}>Name *</Text>
              <TextInput style={styles.input} value={name} onChangeText={setName} />
              <Text style={styles.label}>Company</Text>
              <TextInput style={styles.input} value={company} onChangeText={setCompany} />
              <Text style={styles.label}>Email</Text>
              <TextInput style={styles.input} value={email} onChangeText={setEmail} keyboardType="email-address" />
              <Text style={styles.label}>Phone</Text>
              <TextInput style={styles.input} value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
              <Text style={styles.label}>Address</Text>
              <TextInput style={styles.input} value={address} onChangeText={setAddress} />
              <Text style={styles.label}>Notes</Text>
              <TextInput style={[styles.input, styles.inputMulti]} value={notes} onChangeText={setNotes} multiline numberOfLines={3} />
              <View style={styles.modalActions}>
                <TouchableOpacity 
                  style={[styles.btn, styles.btnSecondary]} 
                  onPress={resetForm}
                  disabled={saving}
                >
                  <Text style={styles.btnText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={[styles.btn, styles.btnPrimary, saving && styles.btnDisabled]} 
                  onPress={handleSave}
                  disabled={saving}
                >
                  {saving ? (
                    <ActivityIndicator color="#fff" />
                  ) : (
                    <Text style={styles.btnText}>Save</Text>
                  )}
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f3f4f6' },
  header: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'white', padding: 16, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  backBtn: { marginRight: 12 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#1F2937' },
  draftIndicator: { position: 'absolute', top: 70, right: 16, zIndex: 100 },
  searchContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'white', margin: 16, padding: 12, borderRadius: 8, gap: 8 },
  searchInput: { flex: 1, fontSize: 16 },
  card: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginHorizontal: 16, marginBottom: 12, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 },
  name: { fontSize: 18, fontWeight: 'bold', color: '#111827' },
  company: { fontSize: 14, color: '#2563eb', marginTop: 2, fontWeight: '600' },
  actions: { flexDirection: 'row', gap: 12 },
  actionButton: { padding: 8, borderRadius: 8, backgroundColor: '#f3f4f6' },
  detail: { fontSize: 14, color: '#6B7280', marginBottom: 3 },
  statsRow: { flexDirection: 'row', gap: 12, marginTop: 8, paddingTop: 8, borderTopWidth: 1, borderTopColor: '#E5E7EB' },
  stat: { fontSize: 13, color: '#8b5cf6', fontWeight: '600' },
  jobHistory: { marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: '#E5E7EB' },
  historyTitle: { fontSize: 14, fontWeight: 'bold', color: '#374151', marginBottom: 8 },
  readOnlyHint: { fontSize: 12, fontWeight: 'normal', color: '#9CA3AF', fontStyle: 'italic' },
  jobItem: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6, paddingHorizontal: 8, backgroundColor: '#f9fafb', borderRadius: 6, marginBottom: 4 },
  jobNumber: { fontSize: 13, fontWeight: '600', color: '#111827' },
  jobDate: { fontSize: 12, color: '#6B7280' },
  jobStatus: { fontSize: 11, fontWeight: 'bold' },
  fab: { position: 'absolute', right: 20, bottom: 20, width: 60, height: 60, borderRadius: 30, backgroundColor: '#2563eb', alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 8 },
  fabText: { fontSize: 32, color: '#fff', fontWeight: 'bold' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#fff', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: '90%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 24, fontWeight: 'bold', color: '#111827' },
  draftBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#ECFDF5', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  draftBadgeText: { fontSize: 11, color: '#059669', fontWeight: '500' },
  label: { fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 8 },
  input: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, padding: 12, marginBottom: 16, fontSize: 16, backgroundColor: '#f9fafb' },
  inputMulti: { height: 80, textAlignVertical: 'top' },
  modalActions: { flexDirection: 'row', gap: 12, marginTop: 8 },
  btn: { padding: 12, borderRadius: 8, alignItems: 'center', flex: 1 },
  btnPrimary: { backgroundColor: '#2563eb' },
  btnSecondary: { backgroundColor: '#6b7280' },
  btnDisabled: { opacity: 0.6 },
  btnText: { color: '#fff', fontWeight: '600' }
});
