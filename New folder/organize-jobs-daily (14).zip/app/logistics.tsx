import React, { useState, useEffect, useRef, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert, Animated, Modal, ActivityIndicator, RefreshControl } from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import { supabase } from './lib/supabase';
import { useRouter } from 'expo-router';
import { logAudit } from '../utils/auditLogger';
import { notifyLogisticsReportUsers } from '../utils/notificationHelper';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import logger from '../utils/logger';
import errorHandler from '../utils/errorHandler';
import { useTaskState } from '../hooks/useTaskState';
import DraftSavedIndicator from '../components/DraftSavedIndicator';

import AddDeliveryModal from '../components/AddDeliveryModal';
import RequestDeliveryModal from '../components/RequestDeliveryModal';
import ManageDeliveryModal from '../components/ManageDeliveryModal';
import ConfigureLogisticsModal from '../components/ConfigureLogisticsModal';
import DeliveryActionChoiceModal from '../components/DeliveryActionChoiceModal';
import DeliveryCardActionMenu from '../components/DeliveryCardActionMenu';
import ApproveDeliveryRequestModal from '../components/ApproveDeliveryRequestModal';
import SelectEmailRecipientsModal from '../components/SelectEmailRecipientsModal';

// Type for task state
interface LogisticsTaskState {
  activeTab: string;
  statusFilter: string;
  dateFilter: string;
  expandedCard: string | null;
}

export default function LogisticsScreen() {
  const router = useRouter();
  const { user } = usePasswordAuth();
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const dateScrollRef = useRef<ScrollView>(null);

  // Check if user has limited logistics access (request only)
  const isRequestOnly = user?.permissions?.logisticsRequestOnly === true;
  const canViewCompleted = user?.permissions?.canViewCompletedDeliveries === true;
  const canUpdateStatus = user?.permissions?.canUpdateDeliveryStatus === true;
  const canViewRequests = user?.permissions?.canViewRequests === true;

  const [deliveries, setDeliveries] = useState([]);
  const [completedDeliveries, setCompletedDeliveries] = useState([]);
  const [requestedDeliveries, setRequestedDeliveries] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState('active');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState('all');
  const [expandedCard, setExpandedCard] = useState<string | null>(null);
  const [sendingReport, setSendingReport] = useState(false);
  const [sendingEmail, setSendingEmail] = useState(false);

  const [showChoiceModal, setShowChoiceModal] = useState(false);
  const [showDeliveryModal, setShowDeliveryModal] = useState(false);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [showManageModal, setShowManageModal] = useState(false);
  const [showConfigureModal, setShowConfigureModal] = useState(false);
  const [showActionMenu, setShowActionMenu] = useState<string | null>(null);
  const [selectedDeliveryId, setSelectedDeliveryId] = useState(null);
  const [showOptionsMenu, setShowOptionsMenu] = useState(false);
  const [showStatusPicker, setShowStatusPicker] = useState<string | null>(null);
  const [showApproveModal, setShowApproveModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<any>(null);
  const [showEmailRecipientsModal, setShowEmailRecipientsModal] = useState(false);

  // Integrate with Active Tasks system
  const { savedData, saveTaskData, isEnabled, showDraftIndicator } = useTaskState<LogisticsTaskState>({
    route: '/logistics',
    title: 'Logistics',
    icon: 'car',
    color: '#2563EB'
  });

  // Restore saved state on mount
  useEffect(() => {
    if (savedData && isEnabled) {
      if (savedData.activeTab !== undefined) setActiveTab(savedData.activeTab);
      if (savedData.statusFilter !== undefined) setStatusFilter(savedData.statusFilter);
      if (savedData.dateFilter !== undefined) setDateFilter(savedData.dateFilter);
      if (savedData.expandedCard !== undefined) setExpandedCard(savedData.expandedCard);
    }
  }, [savedData, isEnabled]);

  // Save state when it changes
  useEffect(() => {
    if (isEnabled) {
      saveTaskData({
        activeTab,
        statusFilter,
        dateFilter,
        expandedCard
      }, false, 'filter');
    }
  }, [activeTab, statusFilter, dateFilter, expandedCard, isEnabled]);

  useEffect(() => {
    loadData();
    Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
  }, [activeTab]);

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      // Optimize: Load data in parallel and only load what's needed for current tab
      const baseQuery = `*, job:jobs!logistics_deliveries_job_id_fkey(id, jobNumber, customerName, notes)`;
      
      // Always load drivers and vehicles as they're needed for display
      const [driversRes, vehiclesRes] = await Promise.all([
        supabase.from('drivers').select('*'),
        supabase.from('vehicles').select('*')
      ]);
      
      setDrivers(driversRes.data || []);
      setVehicles(vehiclesRes.data || []);

      // Load deliveries based on active tab - use Promise.all for parallel loading

      const [activeRes, completedRes, requestedRes] = await Promise.all([
        activeTab === 'active' || activeTab === 'requests' ? 
          supabase.from('logistics_deliveries').select(baseQuery)
            .neq('status', 'completed').neq('status', 'requested').neq('status', 'archived')
            .order('scheduled_date', { ascending: false }) :
          Promise.resolve({ data: deliveries, error: null }),
        
        activeTab === 'completed' || !completedDeliveries.length ?
          supabase.from('logistics_deliveries').select(baseQuery)
            .eq('status', 'completed')
            .order('completed_at', { ascending: false }).limit(50) :
          Promise.resolve({ data: completedDeliveries, error: null }),
        
        activeTab === 'requests' || !requestedDeliveries.length ?
          supabase.from('logistics_deliveries').select(baseQuery)
            .eq('status', 'requested')
            .order('created_at', { ascending: false }) :
          Promise.resolve({ data: requestedDeliveries, error: null })
      ]);


      if (activeRes.error) throw activeRes.error;
      if (completedRes.error) throw completedRes.error;
      if (requestedRes.error) throw requestedRes.error;

      setDeliveries(activeRes.data || []);
      setCompletedDeliveries(completedRes.data || []);
      setRequestedDeliveries(requestedRes.data || []);
      setJobs([]);
    } catch (error) {
      console.error('Error loading data:', error);
      Alert.alert('Error', error.message);
    }
    setLoading(false);
  };

  const handleSendDailyReport = async () => {
    console.log('🚀 Send Daily Report button pressed');
    setSendingReport(true);
    try {
      const today = new Date();
      const todayStr = today.toISOString().split('T')[0];
      
      // Calculate tomorrow's date
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      const tomorrowStr = tomorrow.toISOString().split('T')[0];
      
      // Create start and end of today for proper date range comparison
      const todayStart = todayStr + 'T00:00:00';
      const todayEnd = todayStr + 'T23:59:59';
      
      console.log('📅 Generating report for date:', todayStr);
      console.log('📅 Today range:', todayStart, 'to', todayEnd);
      console.log('📅 Next day scheduled deliveries for:', tomorrowStr);

      // Fetch comprehensive data
      console.log('📊 Fetching deliveries data...');
      const { data: allDeliveries, error: deliveriesError } = await supabase
        .from('logistics_deliveries')
        .select('*')
        .order('scheduled_date', { ascending: false });
      
      if (deliveriesError) {
        console.error('❌ Error fetching deliveries:', deliveriesError);
        throw deliveriesError;
      }
      console.log(`✅ Fetched ${allDeliveries?.length || 0} deliveries`);

      console.log('👤 Fetching drivers data...');
      const { data: allDrivers, error: driversError } = await supabase
        .from('drivers')
        .select('*');
      
      if (driversError) {
        console.error('❌ Error fetching drivers:', driversError);
        throw driversError;
      }
      console.log(`✅ Fetched ${allDrivers?.length || 0} drivers`);

      console.log('🚗 Fetching vehicles data...');
      const { data: allVehicles, error: vehiclesError } = await supabase
        .from('vehicles')
        .select('*');
      
      if (vehiclesError) {
        console.error('❌ Error fetching vehicles:', vehiclesError);
        throw vehiclesError;
      }
      console.log(`✅ Fetched ${allVehicles?.length || 0} vehicles`);

      console.log('📋 Fetching jobs data...');
      const { data: allJobs, error: jobsError } = await supabase
        .from('jobs')
        .select('id, jobNumber, customerName, notes');

      if (jobsError) {
        console.error('❌ Error fetching jobs:', jobsError);
        throw jobsError;
      }
      console.log(`✅ Fetched ${allJobs?.length || 0} jobs`);

      // Filter deliveries completed TODAY (actual date)
      // Check both completed_at timestamp AND scheduled_date as fallback
      const completedToday = allDeliveries.filter(d => {
        if (d.status !== 'completed') return false;
        
        // Check completed_at timestamp (primary check)
        if (d.completed_at) {
          const completedDate = d.completed_at.substring(0, 10); // Extract YYYY-MM-DD
          console.log(`📦 Delivery ${d.delivery_number}: completed_at=${d.completed_at}, extracted date=${completedDate}, today=${todayStr}`);
          if (completedDate === todayStr) return true;
        }
        
        // Fallback: check scheduled_date if completed_at is not set or doesn't match
        if (d.scheduled_date === todayStr) {
          console.log(`📦 Delivery ${d.delivery_number}: matched by scheduled_date=${d.scheduled_date}`);
          return true;
        }
        
        return false;
      });
      
      // Filter scheduled deliveries for TOMORROW (next day)
      const scheduledTomorrow = allDeliveries.filter(d => 
        (d.status === 'scheduled' || d.status === 'pending') && d.scheduled_date === tomorrowStr
      );

      console.log('📈 Report statistics:', {
        completedToday: completedToday.length,
        scheduledTomorrow: scheduledTomorrow.length
      });
      
      // Debug: Log all completed deliveries to see their dates
      console.log('🔍 All completed deliveries:');
      allDeliveries.filter(d => d.status === 'completed').forEach(d => {
        console.log(`  - ${d.delivery_number}: completed_at=${d.completed_at}, scheduled_date=${d.scheduled_date}`);
      });


      // Format dates for display
      const todayFormatted = today.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
      const tomorrowFormatted = tomorrow.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

      // Build text report for notification
      let reportMessage = `📊 DAILY LOGISTICS REPORT\n`;
      reportMessage += `📅 ${todayFormatted}\n\n`;

      // Completed Deliveries for TODAY
      reportMessage += `✅ COMPLETED TODAY (${completedToday.length})\n`;
      reportMessage += `━━━━━━━━━━━━━━━━━━━━\n`;
      if (completedToday.length > 0) {
        completedToday.forEach((d, idx) => {
          const driver = allDrivers.find(dr => dr.id === d.driver_id);
          const vehicle = allVehicles.find(v => v.id === d.vehicle_id);
          const job = allJobs.find(j => j.id === d.job_id);
          reportMessage += `${idx + 1}. ${d.delivery_number}\n`;
          reportMessage += `   Address: ${d.delivery_address}\n`;
          if (job) {
            reportMessage += `   Job: ${job.jobNumber || 'N/A'} - ${job.customerName || 'N/A'}\n`;
            if (job.notes) reportMessage += `   Job Notes: ${job.notes}\n`;
          }
          reportMessage += `   Driver: ${driver?.full_name || 'Unassigned'}\n`;
          reportMessage += `   Vehicle: ${vehicle?.vehicle_number || 'Unassigned'}\n`;
          reportMessage += `   Completed: ${d.completed_at ? new Date(d.completed_at).toLocaleTimeString() : 'N/A'}\n`;

          if (d.delivery_type) reportMessage += `   Type: ${d.delivery_type}\n`;
          if (d.description) reportMessage += `   Description: ${d.description}\n`;
          reportMessage += `\n`;
        });
      } else {
        reportMessage += `No deliveries completed today.\n\n`;
      }

      // Scheduled Deliveries for TOMORROW
      reportMessage += `📅 SCHEDULED FOR TOMORROW (${scheduledTomorrow.length})\n`;
      reportMessage += `   ${tomorrowFormatted}\n`;
      reportMessage += `━━━━━━━━━━━━━━━━━━━━\n`;
      if (scheduledTomorrow.length > 0) {
        scheduledTomorrow.forEach((d, idx) => {
          const driver = allDrivers.find(dr => dr.id === d.driver_id);
          const vehicle = allVehicles.find(v => v.id === d.vehicle_id);
          const job = allJobs.find(j => j.id === d.job_id);
          reportMessage += `${idx + 1}. ${d.delivery_number}\n`;
          reportMessage += `   Address: ${d.delivery_address}\n`;
          if (job) {
            reportMessage += `   Job: ${job.jobNumber || 'N/A'} - ${job.customerName || 'N/A'}\n`;
            if (job.notes) reportMessage += `   Job Notes: ${job.notes}\n`;
          }
          reportMessage += `   Driver: ${driver?.name || 'Unassigned'}\n`;
          reportMessage += `   Vehicle: ${vehicle?.registration_number || 'Unassigned'}\n`;
          reportMessage += `   Status: ${d.status?.replace('_', ' ') || 'Scheduled'}\n`;
          if (d.delivery_type) reportMessage += `   Type: ${d.delivery_type}\n`;
          if (d.description) reportMessage += `   Description: ${d.description}\n`;
          reportMessage += `\n`;
        });
      } else {
        reportMessage += `No deliveries scheduled for tomorrow.\n\n`;
      }

      reportMessage += `━━━━━━━━━━━━━━━━━━━━\n`;
      reportMessage += `Report Generated: ${new Date().toLocaleString()}\n`;
      reportMessage += `This is an automated report from your Logistics Management System`;

      console.log('📧 Sending notification to allowed users (Admin, Lovena, KH, IM)...');
      console.log('📝 Report message length:', reportMessage.length);
      
      // Send notification only to allowed users (Admin, Lovena, KH, IM)
      await notifyLogisticsReportUsers({
        title: `Daily Logistics Report - ${todayStr}`,
        message: reportMessage,
        type: 'logistics',
        priority: 'normal'
      });

      console.log('✅ Notification sent successfully');
      Alert.alert('Success', 'Daily logistics report sent to Admin, Lovena, KH, and IM');
      
    } catch (error) {
      console.error('❌ Error sending report:', error);
      console.error('❌ Error details:', JSON.stringify(error, null, 2));
      Alert.alert('Error', 'Failed to send report: ' + error.message);
    } finally {
      setSendingReport(false);
      console.log('🏁 Send report process completed');
    }
  };



  // Open email recipients modal
  const handleEmailReport = () => {
    setShowEmailRecipientsModal(true);
  };

  // Send email to selected recipients
  // Send email to selected recipients
  const sendEmailToSelectedRecipients = async (selectedEmails: string[]) => {
    if (selectedEmails.length === 0) {
      Alert.alert('No Recipients', 'Please select at least one recipient.');
      return;
    }

    setShowEmailRecipientsModal(false);
    setSendingEmail(true);
    
    try {
      const today = new Date();
      const todayStr = today.toISOString().split('T')[0];
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      const tomorrowStr = tomorrow.toISOString().split('T')[0];

      // Fetch data
      const [deliveriesRes, driversRes, vehiclesRes, jobsRes] = await Promise.all([
        supabase.from('logistics_deliveries').select('*').order('scheduled_date', { ascending: false }),
        supabase.from('drivers').select('*'),
        supabase.from('vehicles').select('*'),
        supabase.from('jobs').select('id, jobNumber, customerName, notes')
      ]);

      const allDeliveries = deliveriesRes.data || [];
      const allDrivers = driversRes.data || [];
      const allVehicles = vehiclesRes.data || [];
      const allJobs = jobsRes.data || [];

      // Filter deliveries
      const completedToday = allDeliveries.filter(d => {
        if (d.status !== 'completed') return false;
        if (d.completed_at) {
          const completedDate = d.completed_at.substring(0, 10);
          if (completedDate === todayStr) return true;
        }
        return d.scheduled_date === todayStr;
      });
      
      const scheduledTomorrow = allDeliveries.filter(d => 
        (d.status === 'scheduled' || d.status === 'pending') && d.scheduled_date === tomorrowStr
      );

      // Format dates for display
      const todayFormatted = today.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
      const tomorrowFormatted = tomorrow.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

      // Helper function to get customer name from delivery or job
      const getCustomerName = (delivery: any, job: any) => {
        // Priority: delivery.customer_name > delivery.client_name > job.customerName
        if (delivery.customer_name) return delivery.customer_name;
        if (delivery.client_name) return delivery.client_name;
        if (job?.customerName) return job.customerName;
        return 'N/A';
      };

      // Helper function to decode Quoted-Printable and clean text
      const cleanText = (text: string) => {
        if (!text) return '';
        return String(text)
          // Decode common Quoted-Printable sequences
          .replace(/=20/g, ' ')      // Space
          .replace(/=3D/g, '=')      // Equals sign
          .replace(/=0A/g, '\n')     // Newline
          .replace(/=0D/g, '\r')     // Carriage return
          .replace(/=09/g, '\t')     // Tab
          .replace(/=([0-9A-Fa-f]{2})/g, (match, hex) => String.fromCharCode(parseInt(hex, 16))) // Any other hex codes
          .trim();
      };

      // Helper function to escape HTML (applied after cleaning)
      const escapeHtml = (text: string) => {
        if (!text) return '';
        const cleaned = cleanText(text);
        return cleaned
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;')
          .replace(/'/g, '&#039;');
      };

      // Build HTML report with complete information (no trailing spaces)
      let htmlContent = `
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
body{font-family:Arial,sans-serif;line-height:1.6;color:#333;max-width:800px;margin:0 auto;padding:20px}
h1{color:#2563eb;border-bottom:2px solid #2563eb;padding-bottom:10px}
h2{color:#1e40af;margin-top:30px}
.section{background:#f8fafc;border-radius:8px;padding:15px;margin:15px 0}
.delivery{background:white;border:1px solid #e2e8f0;border-radius:6px;padding:12px;margin:10px 0}
.delivery-header{font-weight:bold;color:#1e40af;font-size:16px;margin-bottom:8px}
.field{margin:4px 0}
.label{color:#64748b;font-size:13px}
.value{color:#1e293b;font-size:14px}
.footer{margin-top:30px;padding-top:15px;border-top:1px solid #e2e8f0;color:#64748b;font-size:12px}
</style>
</head>
<body>
<h1>Daily Logistics Report</h1>
<p><strong>${escapeHtml(todayFormatted)}</strong></p>

<h2>Completed Today (${completedToday.length})</h2>
<div class="section">`;

      if (completedToday.length > 0) {
        completedToday.forEach((d, idx) => {
          const driver = allDrivers.find(dr => dr.id === d.driver_id);
          const vehicle = allVehicles.find(v => v.id === d.vehicle_id);
          const job = allJobs.find(j => j.id === d.job_id);
          const customerName = getCustomerName(d, job);

          htmlContent += `<div class="delivery">
<div class="delivery-header">${idx + 1}. ${escapeHtml(d.delivery_number)}</div>
<div class="field"><span class="label">Customer:</span> <span class="value">${escapeHtml(customerName)}</span></div>
<div class="field"><span class="label">Address:</span> <span class="value">${escapeHtml(d.delivery_address || 'N/A')}</span></div>`;
          if (d.contact_phone) htmlContent += `<div class="field"><span class="label">Phone:</span> <span class="value">${escapeHtml(d.contact_phone)}</span></div>`;
          if (job) {
            htmlContent += `<div class="field"><span class="label">Job:</span> <span class="value">${escapeHtml(job.jobNumber || 'N/A')}</span></div>`;
            if (job.notes) htmlContent += `<div class="field"><span class="label">Job Notes:</span> <span class="value">${escapeHtml(job.notes)}</span></div>`;
          }
          htmlContent += `<div class="field"><span class="label">Driver:</span> <span class="value">${escapeHtml(driver?.full_name || driver?.name || 'Unassigned')}</span></div>
<div class="field"><span class="label">Vehicle:</span> <span class="value">${escapeHtml(vehicle?.vehicle_number || vehicle?.registration_number || 'Unassigned')}</span></div>
<div class="field"><span class="label">Completed:</span> <span class="value">${d.completed_at ? new Date(d.completed_at).toLocaleTimeString() : 'N/A'}</span></div>`;
          if (d.delivery_type) htmlContent += `<div class="field"><span class="label">Type:</span> <span class="value">${escapeHtml(d.delivery_type)}</span></div>`;
          if (d.description) htmlContent += `<div class="field"><span class="label">Description:</span> <span class="value">${escapeHtml(d.description)}</span></div>`;
          if (d.notes) htmlContent += `<div class="field"><span class="label">Notes:</span> <span class="value">${escapeHtml(d.notes)}</span></div>`;
          if (d.requested_by) htmlContent += `<div class="field"><span class="label">Requested By:</span> <span class="value">${escapeHtml(d.requested_by)}</span></div>`;
          htmlContent += `</div>`;
        });
      } else {
        htmlContent += `<p>No deliveries completed today.</p>`;
      }

      htmlContent += `</div>
<h2>Scheduled for Tomorrow (${scheduledTomorrow.length})</h2>
<p><em>${escapeHtml(tomorrowFormatted)}</em></p>
<div class="section">`;

      if (scheduledTomorrow.length > 0) {
        scheduledTomorrow.forEach((d, idx) => {
          const driver = allDrivers.find(dr => dr.id === d.driver_id);
          const vehicle = allVehicles.find(v => v.id === d.vehicle_id);
          const job = allJobs.find(j => j.id === d.job_id);
          const customerName = getCustomerName(d, job);

          htmlContent += `<div class="delivery">
<div class="delivery-header">${idx + 1}. ${escapeHtml(d.delivery_number)}</div>
<div class="field"><span class="label">Customer:</span> <span class="value">${escapeHtml(customerName)}</span></div>
<div class="field"><span class="label">Address:</span> <span class="value">${escapeHtml(d.delivery_address || 'N/A')}</span></div>`;
          if (d.contact_phone) htmlContent += `<div class="field"><span class="label">Phone:</span> <span class="value">${escapeHtml(d.contact_phone)}</span></div>`;
          if (job) {
            htmlContent += `<div class="field"><span class="label">Job:</span> <span class="value">${escapeHtml(job.jobNumber || 'N/A')}</span></div>`;
            if (job.notes) htmlContent += `<div class="field"><span class="label">Job Notes:</span> <span class="value">${escapeHtml(job.notes)}</span></div>`;
          }
          htmlContent += `<div class="field"><span class="label">Driver:</span> <span class="value">${escapeHtml(driver?.full_name || driver?.name || 'Unassigned')}</span></div>
<div class="field"><span class="label">Vehicle:</span> <span class="value">${escapeHtml(vehicle?.vehicle_number || vehicle?.registration_number || 'Unassigned')}</span></div>
<div class="field"><span class="label">Status:</span> <span class="value">${escapeHtml(d.status?.replace('_', ' ') || 'Scheduled')}</span></div>`;
          if (d.delivery_type) htmlContent += `<div class="field"><span class="label">Type:</span> <span class="value">${escapeHtml(d.delivery_type)}</span></div>`;
          if (d.description) htmlContent += `<div class="field"><span class="label">Description:</span> <span class="value">${escapeHtml(d.description)}</span></div>`;
          if (d.notes) htmlContent += `<div class="field"><span class="label">Notes:</span> <span class="value">${escapeHtml(d.notes)}</span></div>`;
          if (d.requested_by) htmlContent += `<div class="field"><span class="label">Requested By:</span> <span class="value">${escapeHtml(d.requested_by)}</span></div>`;
          htmlContent += `</div>`;
        });
      } else {
        htmlContent += `<p>No deliveries scheduled for tomorrow.</p>`;
      }

      htmlContent += `</div>
<div class="footer">
<p>Report Generated: ${new Date().toLocaleString()}</p>
<p>This is an automated report from your Logistics Management System</p>
</div>
</body>
</html>`;

      // Send email via edge function with HTML content
      const { data, error } = await supabase.functions.invoke('send-daily-report', {
        body: {
          recipients: selectedEmails,
          subject: `Daily Logistics Report - ${todayStr}`,
          htmlContent: htmlContent
        }
      });


      if (error) throw error;

      Alert.alert('Success', `Logistics report emailed to ${selectedEmails.length} recipient(s)`);
    } catch (error: any) {
      console.error('Error sending email report:', error);
      Alert.alert('Error', error.message || 'Failed to send email report');
    } finally {
      setSendingEmail(false);
    }
  };

  const handleUpdateStatus = async (deliveryId: string, newStatus: string) => {
    try {
      console.log('🔵 Updating delivery status:', { deliveryId, newStatus });
      
      // First get the delivery to check for associated job
      const { data: delivery, error: fetchError } = await supabase
        .from('logistics_deliveries')
        .select('job_id')
        .eq('id', deliveryId)
        .single();

      if (fetchError) {
        console.error('🔴 Error fetching delivery:', fetchError);
      }

      const { error } = await supabase
        .from('logistics_deliveries')
        .update({ status: newStatus })
        .eq('id', deliveryId);

      if (error) {
        console.error('🔴 Error updating status:', error);
        Alert.alert('Error', error.message);
      } else {
        console.log('✅ Status updated successfully');
        
        // If cancelled and has associated job, archive the job
        if (newStatus === 'cancelled' && delivery?.job_id) {
          console.log('🔵 Delivery cancelled - archiving associated job:', delivery.job_id);
          
          const { error: jobError } = await supabase
            .from('jobs')
            .update({
              status: 'archived',
              archivedDate: new Date().toISOString()
            })
            .eq('id', delivery.job_id);

          if (jobError) {
            console.error('🔴 Error archiving job:', jobError);
            Alert.alert('Warning', 'Delivery cancelled but failed to archive associated job');
          } else {
            console.log('✅ Associated job archived successfully');
            try {
              await logAudit({
                action: 'archive_job',
                entityType: 'job',
                entityId: delivery.job_id,
                metadata: { 
                  oldStatus: 'unknown',
                  newStatus: 'archived',
                  archivedVia: 'delivery_cancelled',
                  deliveryId: deliveryId
                }
              });
            } catch (auditError) {
              console.error('⚠️ Warning: Failed to create audit log:', auditError);
            }
          }
        }
        
        setShowStatusPicker(null);
        loadData();
      }
    } catch (err) {
      console.error('🔴 Unexpected error:', err);
      Alert.alert('Error', 'Failed to update status');
    }
  };




  const handleSignOff = async (deliveryId: string) => {
    console.log('🔵 Sign Off button pressed for delivery:', deliveryId);
    
    try {
      console.log('🔵 Step 1: Fetching delivery details...');
      
      // First, get the delivery to find the job_id
      const { data: delivery, error: fetchError } = await supabase
        .from('logistics_deliveries')
        .select('job_id')
        .eq('id', deliveryId)
        .single();

      console.log('🔵 Step 2: Delivery fetched:', delivery);
      
      if (fetchError) {
        console.error('🔴 Error fetching delivery:', fetchError);
        Alert.alert('Error', `Failed to fetch delivery: ${fetchError.message}`);
        return;
      }

      console.log('🔵 Step 3: Updating delivery status to completed...');
      
      // Update delivery status to completed
      const { error: deliveryError } = await supabase
        .from('logistics_deliveries')
        .update({
          status: 'completed',
          completed_at: new Date().toISOString()
        })
        .eq('id', deliveryId);

      if (deliveryError) {
        console.error('🔴 Error updating delivery:', deliveryError);
        Alert.alert('Error', `Failed to complete delivery: ${deliveryError.message}`);
        return;
      }
      
      console.log('✅ Delivery marked as completed');

      // If there's an associated job, archive it
      if (delivery?.job_id) {
        console.log('🔵 Step 4: Found job_id:', delivery.job_id);
        console.log('🔵 Step 5: Fetching current job status...');
        
        // First, get the current job status
        const { data: currentJob, error: jobFetchError } = await supabase
          .from('jobs')
          .select('status')
          .eq('id', delivery.job_id)
          .single();

        if (jobFetchError) {
          console.error('🔴 Error fetching job:', jobFetchError);
          Alert.alert('Error', `Failed to fetch job: ${jobFetchError.message}`);
          return;
        }

        console.log('🔵 Step 6: Current job status:', currentJob?.status);
        console.log('🔵 Step 7: Archiving job...');

        const archivedDate = new Date();
        
        // Update job status to archived
        const { error: jobError } = await supabase
          .from('jobs')
          .update({
            status: 'archived',
            archivedDate: archivedDate.toISOString()
          })
          .eq('id', delivery.job_id);

        if (jobError) {
          console.error('🔴 Error archiving job:', jobError);
          Alert.alert('Error', `Failed to archive job: ${jobError.message}`);
          return;
        }

        console.log('✅ Job archived successfully');
        console.log('🔵 Step 8: Creating audit log...');

        // Log the archive action
        try {
          await logAudit({
            action: 'archive_job',
            entityType: 'job',
            entityId: delivery.job_id,
            metadata: { 
              oldStatus: currentJob?.status || 'unknown',
              newStatus: 'archived',
              archivedVia: 'logistics_signoff',
              deliveryId: deliveryId
            }
          });
          console.log('✅ Audit log created');
        } catch (auditError) {
          console.error('⚠️ Warning: Failed to create audit log:', auditError);
          // Don't fail the whole operation if audit logging fails
        }

        Alert.alert('Success', `Delivery signed off and job ${delivery.job_id} archived successfully`);
      } else {
        console.log('⚠️ No job_id associated with delivery');
        Alert.alert('Success', 'Delivery signed off (no associated job found)');
      }
      
      console.log('🔵 Step 9: Reloading data...');
      loadData();
      console.log('✅ Sign off process completed successfully');
      
    } catch (error) {
      console.error('🔴 Unexpected error in sign off:', error);
      Alert.alert('Error', `Failed to sign off: ${error.message}`);
    }
  };

  // Determine current data based on active tab
  const currentData = activeTab === 'active' ? deliveries : activeTab === 'completed' ? completedDeliveries : activeTab === 'requests' ? requestedDeliveries : [];
  
  // Get unique scheduled dates for date filter
  const uniqueDates = [...new Set(currentData.map(d => d.scheduled_date).filter(Boolean))].sort();
  
  // Apply status filter first, then date filter
  let filtered = statusFilter === 'all' ? currentData : currentData.filter(d => d.status === statusFilter);
  if (dateFilter !== 'all') {
    filtered = filtered.filter(d => d.scheduled_date === dateFilter);
  }

  const stats = {
    total: deliveries.length,
    inTransit: deliveries.filter(d => d.status === 'in_transit').length,
    completed: completedDeliveries.length,
    requests: requestedDeliveries.length
  };


  const formatDateLabel = (dateStr: string) => {
    const date = new Date(dateStr);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    if (dateStr === today.toISOString().split('T')[0]) return 'Today';
    if (dateStr === tomorrow.toISOString().split('T')[0]) return 'Tomorrow';
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const scrollDateLeft = () => {
    dateScrollRef.current?.scrollTo({ x: 0, animated: true });
  };

  const scrollDateRight = () => {
    dateScrollRef.current?.scrollToEnd({ animated: true });
  };

  const handleStatClick = (type: string) => {
    if (type === 'requests') {
      router.push('/delivery-requests');
    } else if (type === 'active') {
      setActiveTab('active');
      setStatusFilter('all');
      setDateFilter('all');
    } else if (type === 'inTransit') {
      setActiveTab('active');
      setStatusFilter('in_transit');
    } else if (type === 'completed') {
      setActiveTab('completed');
      setStatusFilter('all');
      setDateFilter('all');
    }
  };

  const handleArchiveDelivery = async (deliveryId: string) => {
    try {
      console.log('🔵 Archiving delivery:', deliveryId);
      
      const { error } = await supabase
        .from('logistics_deliveries')
        .update({ 
          status: 'archived',
          archived_at: new Date().toISOString()
        })
        .eq('id', deliveryId);

      if (error) {
        console.error('🔴 Error archiving delivery:', error);
        Alert.alert('Error', error.message);
      } else {
        console.log('✅ Delivery archived successfully');
        Alert.alert('Success', 'Delivery archived successfully');
        loadData();
      }
    } catch (err) {
      console.error('🔴 Unexpected error:', err);
      Alert.alert('Error', 'Failed to archive delivery');
    }
  };


  return (
    <View style={styles.container}>
      {/* Draft Saved Indicator */}
      {isEnabled && <DraftSavedIndicator visible={showDraftIndicator} style={styles.draftIndicator} />}
      
      <View style={styles.header}>
        <View style={styles.headerRow}>
          <Text style={styles.title}>Logistics</Text>
          <View style={styles.headerRight}>
            {/* Refresh button */}
            <TouchableOpacity onPress={handleRefresh} disabled={refreshing} style={[styles.addBtnHeader, refreshing && { opacity: 0.5 }]}>
              <Ionicons name="refresh" size={20} color="white" />
            </TouchableOpacity>
            {/* For request-only users, show only Request button; for full access, show choice modal */}
            {activeTab !== 'completed' && (
              isRequestOnly ? (
                <TouchableOpacity onPress={() => setShowRequestModal(true)} style={styles.addBtnHeader}>
                  <Ionicons name="add" size={24} color="white" />
                </TouchableOpacity>
              ) : (
                <TouchableOpacity onPress={() => setShowChoiceModal(true)} style={styles.addBtnHeader}>
                  <Ionicons name="add" size={24} color="white" />
                </TouchableOpacity>
              )
            )}
            {/* Hide report and menu buttons for request-only users */}
            {/* Hide report and menu buttons for request-only users */}
            {!isRequestOnly && (
              <>
                <TouchableOpacity onPress={handleSendDailyReport} disabled={sendingReport} style={[styles.reportBtn, sendingReport && { opacity: 0.5 }]}>
                  <Ionicons name="document-text" size={20} color="white" />
                </TouchableOpacity>
                <TouchableOpacity onPress={handleEmailReport} disabled={sendingEmail} style={[styles.emailBtn, sendingEmail && { opacity: 0.5 }]}>
                  <Ionicons name="mail" size={20} color="white" />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => setShowOptionsMenu(!showOptionsMenu)} style={styles.menuBtn}>
                  <Ionicons name="ellipsis-vertical" size={24} color="white" />
                </TouchableOpacity>
              </>
            )}

          </View>
        </View>
        {showOptionsMenu && !isRequestOnly && (
          <View style={styles.optionsMenu}>
            <TouchableOpacity style={styles.optionItem} onPress={() => { setShowOptionsMenu(false); router.push('/delivery-archive'); }}>
              <Text style={styles.optionText}>Archive</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.optionItem} onPress={() => { setShowOptionsMenu(false); setShowConfigureModal(true); }}>
              <Text style={styles.optionText}>Configure</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Compact Stats Row - hide requests stat for request-only users */}
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>Active</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{stats.inTransit}</Text>
            <Text style={styles.statLabel}>Transit</Text>
          </View>
          {!isRequestOnly && (
            <>
              <View style={styles.statCard}>
                <Text style={styles.statValue}>{stats.completed}</Text>
                <Text style={styles.statLabel}>Done</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statValue}>{stats.requests}</Text>
                <Text style={styles.statLabel}>Req</Text>
              </View>
            </>
          )}
        </View>

        {/* Show tabs - include Requests tab for users with canViewRequests permission */}
        <View style={styles.tabsRow2}>
          <TouchableOpacity style={[styles.tab, activeTab === 'active' && styles.tabActive]} onPress={() => setActiveTab('active')}>
            <Text style={[styles.tabText, activeTab === 'active' && styles.tabTextActive]}>Active</Text>
          </TouchableOpacity>
          {/* Show Completed tab for non-request-only users OR users with canViewCompletedDeliveries */}
          {(!isRequestOnly || canViewCompleted) && (
            <TouchableOpacity style={[styles.tab, activeTab === 'completed' && styles.tabActive]} onPress={() => setActiveTab('completed')}>
              <Text style={[styles.tabText, activeTab === 'completed' && styles.tabTextActive]}>Completed</Text>
            </TouchableOpacity>
          )}
          {/* Show Requests tab for users with canViewRequests permission */}
          {canViewRequests && (
            <TouchableOpacity style={[styles.tab, activeTab === 'requests' && styles.tabActive]} onPress={() => setActiveTab('requests')}>
              <Text style={[styles.tabText, activeTab === 'requests' && styles.tabTextActive]}>Requests ({stats.requests})</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      <ScrollView style={styles.content}>


        {activeTab === 'active' && (
          <>
            {/* Status Filter Bar */}
            <View style={styles.filterContainer}>
              <TouchableOpacity style={styles.filterChevron} onPress={scrollDateLeft}>
                <Ionicons name="chevron-back" size={16} color="#6b7280" />
              </TouchableOpacity>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterRow}>
                {['all', 'scheduled', 'in_transit'].map(status => (
                  <TouchableOpacity key={status} style={[styles.filterChip, statusFilter === status && styles.filterChipActive]} onPress={() => setStatusFilter(status)}>
                    <Text style={[styles.filterText, statusFilter === status && styles.filterTextActive]}>
                      {status === 'all' ? 'All' : status === 'in_transit' ? 'In Transit' : 'Scheduled'}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
              <TouchableOpacity style={styles.filterChevron} onPress={scrollDateRight}>
                <Ionicons name="chevron-forward" size={16} color="#6b7280" />
              </TouchableOpacity>
            </View>

            {/* Date Filter Bar */}
            {uniqueDates.length > 0 && (
              <View style={styles.dateFilterContainer}>
                <TouchableOpacity style={styles.dateChevron} onPress={scrollDateLeft}>
                  <Ionicons name="chevron-back" size={16} color="#2563eb" />
                </TouchableOpacity>
                <ScrollView ref={dateScrollRef} horizontal showsHorizontalScrollIndicator={false} style={styles.dateFilterRow}>
                  <TouchableOpacity 
                    style={[styles.dateChip, dateFilter === 'all' && styles.dateChipActive]} 
                    onPress={() => setDateFilter('all')}
                  >
                    <Text style={[styles.dateText, dateFilter === 'all' && styles.dateTextActive]}>All Dates</Text>
                  </TouchableOpacity>
                  {uniqueDates.map(date => (
                    <TouchableOpacity 
                      key={date} 
                      style={[styles.dateChip, dateFilter === date && styles.dateChipActive]} 
                      onPress={() => setDateFilter(date)}
                    >
                      <Text style={[styles.dateText, dateFilter === date && styles.dateTextActive]}>
                        {formatDateLabel(date)}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
                <TouchableOpacity style={styles.dateChevron} onPress={scrollDateRight}>
                  <Ionicons name="chevron-forward" size={16} color="#2563eb" />
                </TouchableOpacity>
              </View>
            )}
          </>
        )}




        {filtered.map(d => {
          const driver = drivers.find(dr => dr.id === d.driver_id);
          const vehicle = vehicles.find(v => v.id === d.vehicle_id);
          const isExpanded = expandedCard === d.id;

          // Access job data from the joined result
          const jobInfo = d.job;
          
          // Calculate total kgs from job_items if available
          const totalKgs = d.job_items?.reduce((sum, item) => sum + parseFloat(item.weightKg || '0'), 0) || 0;

          // Get status color
          const getStatusColor = (status: string) => {
            switch(status) {
              case 'completed': return { bg: '#dcfce7', text: '#166534' };
              case 'in_transit': return { bg: '#fef3c7', text: '#92400e' };
              case 'scheduled': return { bg: '#dbeafe', text: '#1e40af' };
              case 'pending': return { bg: '#f3f4f6', text: '#4b5563' };
              default: return { bg: '#f3f4f6', text: '#4b5563' };
            }
          };
          const statusColors = getStatusColor(d.status);

          // Get card background color based on delivery type - MORE PROMINENT COLORS
          const getCardBgColor = (type: string) => {
            switch(type?.toLowerCase()) {
              case 'delivery': return { bg: '#bfdbfe', border: '#2563eb' }; // Strong Blue
              case 'pickup': return { bg: '#fde68a', border: '#d97706' }; // Strong Amber/Yellow
              case 'request': return { bg: '#e9d5ff', border: '#9333ea' }; // Strong Purple
              default: return { bg: '#bbf7d0', border: '#16a34a' }; // Strong Green for others
            }
          };
          const cardColors = getCardBgColor(d.delivery_type);

          return (
            <TouchableOpacity 
              key={d.id} 
              style={[styles.card, { backgroundColor: cardColors.bg, borderLeftWidth: 5, borderLeftColor: cardColors.border }]}
              onPress={() => {
                if (activeTab === 'requests' && !isRequestOnly) {
                  setSelectedRequest(d);
                  setShowApproveModal(true);
                } else if (isRequestOnly && !canUpdateStatus) {
                  setExpandedCard(isExpanded ? null : d.id);
                } else {
                  setShowStatusPicker(d.id);
                }
              }}
              activeOpacity={0.8}
            >



              <View style={styles.cardTop}>
                <View style={styles.cardLeft}>
                  <View style={styles.cardHeader}>
                    <Text style={styles.cardTitle}>{d.delivery_number}</Text>
                    <View style={[styles.statusBadge, { backgroundColor: statusColors.bg }]}>
                      <Text style={[styles.statusText, { color: statusColors.text }]}>
                        {d.status?.replace('_', ' ') || 'Unknown'}
                      </Text>
                    </View>
                  </View>
                  {d.delivery_type && (
                    <View style={styles.typeBadge}>
                      <Ionicons 
                        name={d.delivery_type === 'pickup' ? 'arrow-up-circle' : d.delivery_type === 'delivery' ? 'arrow-down-circle' : 'ellipse'} 
                        size={14} 
                        color="#6b7280" 
                      />
                      <Text style={styles.typeText}>{d.delivery_type}</Text>
                    </View>
                  )}
                  {d.customer_name && (
                    <Text style={styles.customerNameText}>
                      <Ionicons name="person-outline" size={12} color="#059669" /> {d.customer_name}
                    </Text>
                  )}
                  <Text style={styles.cardSubtitle} numberOfLines={1}>{d.delivery_address}</Text>
                  <Text style={styles.cardDate}>
                    <Ionicons name="calendar-outline" size={12} color="#9ca3af" /> {d.scheduled_date}
                  </Text>
                  {jobInfo && (
                    <Text style={styles.jobLink}>
                      <Ionicons name="briefcase-outline" size={12} color="#2563eb" /> {jobInfo.jobNumber} - {jobInfo.customerName || 'N/A'}
                    </Text>
                  )}
                </View>

                {/* Hide action menu for request-only users */}
                {!isRequestOnly && (
                  <TouchableOpacity onPress={(e) => { e.stopPropagation(); setShowActionMenu(d.id); }} style={styles.actionMenuBtn}>
                    <Ionicons name="ellipsis-horizontal" size={24} color="#6b7280" />
                  </TouchableOpacity>
                )}
              </View>

              {isExpanded && (
                <View style={styles.expandedInfo}>
                  <Text style={styles.sectionTitle}>Delivery Details</Text>
                  <View style={styles.infoGrid}>
                    <View style={styles.infoItem}>
                      <Text style={styles.infoLabel}>Address</Text>
                      <Text style={styles.infoValue}>{d.delivery_address || 'Not specified'}</Text>
                    </View>
                    <View style={styles.infoItem}>
                      <Text style={styles.infoLabel}>Scheduled Date</Text>
                      <Text style={styles.infoValue}>{d.scheduled_date || 'Not set'}</Text>
                    </View>
                    <View style={styles.infoItem}>
                      <Text style={styles.infoLabel}>Type</Text>
                      <Text style={styles.infoValue}>{d.delivery_type || 'Not specified'}</Text>
                    </View>
                    <View style={styles.infoItem}>
                      <Text style={styles.infoLabel}>Status</Text>
                      <Text style={styles.infoValue}>{d.status?.replace('_', ' ') || 'Unknown'}</Text>
                    </View>
                  </View>

                  {(driver || vehicle) && (
                    <>
                      <Text style={styles.sectionTitle}>Assignment</Text>
                      <View style={styles.infoGrid}>
                        <View style={styles.infoItem}>
                          <Text style={styles.infoLabel}>Driver</Text>
                          <Text style={styles.infoValue}>{driver?.name || driver?.full_name || 'Unassigned'}</Text>
                        </View>
                        <View style={styles.infoItem}>
                          <Text style={styles.infoLabel}>Vehicle</Text>
                          <Text style={styles.infoValue}>{vehicle?.registration_number || vehicle?.vehicle_number || 'Unassigned'}</Text>
                        </View>
                      </View>
                    </>
                  )}

                  {jobInfo && (
                    <>
                      <Text style={styles.sectionTitle}>Job Information</Text>
                      <View style={styles.jobInfoBox}>
                        <Text style={styles.jobInfoText}>Job #: {jobInfo.jobNumber || 'N/A'}</Text>
                        <Text style={styles.jobInfoText}>Customer: {jobInfo.customerName || 'N/A'}</Text>
                        {jobInfo.notes && <Text style={styles.jobInfoText}>Job Notes: {jobInfo.notes}</Text>}
                        {d.job_items && d.job_items.length > 0 && (
                          <>
                            <Text style={styles.itemsHeader}>Items ({d.job_items.length}) - Total: {totalKgs.toFixed(2)}kg</Text>
                            {d.job_items.map((item, idx) => (
                              <Text key={idx} style={styles.itemLine}>
                                - {item.descriptionOfWorks || item.description || 'Item'} - {item.weightKg || 0}kg
                              </Text>
                            ))}
                          </>
                        )}
                      </View>
                    </>
                  )}

                  {d.description && (
                    <View style={styles.infoItem}>
                      <Text style={styles.infoLabel}>Description</Text>
                      <Text style={styles.infoValue}>{d.description}</Text>
                    </View>
                  )}

                  {d.notes && (
                    <View style={styles.infoItem}>
                      <Text style={styles.infoLabel}>Notes</Text>
                      <Text style={styles.infoValue}>{d.notes}</Text>
                    </View>
                  )}

                  <View style={styles.timestampSection}>
                    <Text style={styles.timestampText}>Created: {d.created_at ? new Date(d.created_at).toLocaleString() : 'N/A'}</Text>
                    {d.completed_at && (
                      <Text style={styles.timestampText}>Completed: {new Date(d.completed_at).toLocaleString()}</Text>
                    )}
                  </View>
                </View>
              )}

              <TouchableOpacity onPress={(e) => { e.stopPropagation(); setExpandedCard(isExpanded ? null : d.id); }} style={styles.expandBtn}>
                <Text style={styles.expandText}>{isExpanded ? 'Show Less' : 'Show More'}</Text>
                <Ionicons name={isExpanded ? 'chevron-up' : 'chevron-down'} size={16} color="#2563eb" />
              </TouchableOpacity>

              <DeliveryCardActionMenu 
                visible={showActionMenu === d.id}
                onClose={() => setShowActionMenu(null)}
                onEdit={() => { setSelectedDeliveryId(d.id); setShowManageModal(true); }}
                onArchive={() => handleArchiveDelivery(d.id)}
                onViewHistory={() => {}}
                deliveryNumber={d.delivery_number}
              />

            </TouchableOpacity>
          );
        })}

      </ScrollView>

      {/* Status Picker Modal */}
      <Modal visible={showStatusPicker !== null} transparent animationType="fade">
        <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setShowStatusPicker(null)}>
          <View style={styles.statusPickerModal}>
            <Text style={styles.statusPickerTitle}>Update Status</Text>
            <Text style={styles.statusPickerSubtitle}>Tap to change delivery status</Text>
            
            {[
              { value: 'requested', label: 'Requested', icon: 'help-circle-outline', color: '#8b5cf6' },
              { value: 'scheduled', label: 'Scheduled', icon: 'calendar-outline', color: '#2563eb' },
              { value: 'in_transit', label: 'In Transit', icon: 'car-outline', color: '#d97706' },
              { value: 'completed', label: 'Completed', icon: 'checkmark-circle-outline', color: '#16a34a' },
              { value: 'cancelled', label: 'Cancelled', icon: 'close-circle-outline', color: '#dc2626' },
            ]
              // Filter status options for user JS - only allow 'In Transit' and 'Completed'
              .filter(status => {
                if (user?.username === 'JS') {
                  return status.value === 'in_transit' || status.value === 'completed';
                }
                return true;
              })
              .map((status) => (
              <TouchableOpacity
                key={status.value}
                style={[styles.statusOption, { borderLeftColor: status.color }]}
                onPress={() => handleUpdateStatus(showStatusPicker!, status.value)}
              >
                <Ionicons name={status.icon as any} size={22} color={status.color} />
                <Text style={[styles.statusOptionText, { color: status.color }]}>{status.label}</Text>
              </TouchableOpacity>
            ))}
            

            <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowStatusPicker(null)}>
              <Text style={styles.cancelBtnText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>


      <Modal visible={sendingReport} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.progressModal}>
            <ActivityIndicator size="large" color="#2563eb" />
            <Text style={styles.progressText}>Sending Daily Report...</Text>
            <Text style={styles.progressSubtext}>Please wait</Text>
          </View>
        </View>
      </Modal>

      {/* Email Progress Modal */}
      <Modal visible={sendingEmail} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.progressModal}>
            <ActivityIndicator size="large" color="#16a34a" />
            <Text style={styles.progressText}>Sending Email Report...</Text>
            <Text style={styles.progressSubtext}>Please wait</Text>
          </View>
        </View>
      </Modal>


      <DeliveryActionChoiceModal visible={showChoiceModal} onClose={() => setShowChoiceModal(false)} onAddDelivery={() => setShowDeliveryModal(true)} onRequestDelivery={() => setShowRequestModal(true)} />

      <AddDeliveryModal visible={showDeliveryModal} onClose={() => setShowDeliveryModal(false)} onSuccess={loadData} />
      <RequestDeliveryModal visible={showRequestModal} onClose={() => setShowRequestModal(false)} onSuccess={loadData} />
      <ManageDeliveryModal visible={showManageModal} onClose={() => setShowManageModal(false)} deliveryId={selectedDeliveryId} onSuccess={loadData} />
      <ConfigureLogisticsModal visible={showConfigureModal} onClose={() => setShowConfigureModal(false)} />
      <ApproveDeliveryRequestModal 
        visible={showApproveModal} 
        onClose={() => { setShowApproveModal(false); setSelectedRequest(null); }} 
        onSuccess={loadData} 
        delivery={selectedRequest} 
      />
      <SelectEmailRecipientsModal
        visible={showEmailRecipientsModal}
        onClose={() => setShowEmailRecipientsModal(false)}
        onSend={sendEmailToSelectedRecipients}
        sending={sendingEmail}
      />


    </View>
  );
}



const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { backgroundColor: '#2563eb', paddingTop: 50, paddingBottom: 10, paddingHorizontal: 16 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  title: { fontSize: 22, fontWeight: 'bold', color: 'white' },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  addBtnHeader: { padding: 4, backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 6 },
  reportBtn: { padding: 4 },
  emailBtn: { padding: 4 },
  menuBtn: { padding: 4 },
  draftIndicator: { position: 'absolute', top: 110, right: 16, zIndex: 100 },

  optionsMenu: { position: 'absolute', top: 90, right: 16, backgroundColor: 'white', borderRadius: 8, padding: 6, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 4, elevation: 5, zIndex: 1000 },
  optionItem: { padding: 10 },
  optionText: { fontSize: 14, color: '#1f2937' },
  statsRow: { flexDirection: 'row', gap: 4, marginBottom: 8 },
  statCard: { flex: 1, backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 6, paddingVertical: 6, paddingHorizontal: 4, alignItems: 'center' },
  statValue: { fontSize: 16, fontWeight: 'bold', color: 'white' },
  statLabel: { fontSize: 9, color: 'rgba(255,255,255,0.9)', marginTop: 1 },
  tabsRow2: { flexDirection: 'row', gap: 6 },
  tab: { flex: 1, paddingVertical: 8, borderRadius: 6, alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.2)' },
  tabActive: { backgroundColor: 'white' },
  tabText: { fontSize: 13, fontWeight: '600', color: 'rgba(255,255,255,0.8)' },
  tabTextActive: { color: '#2563eb' },
  content: { flex: 1, padding: 12 },
  filterContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  filterChevron: { paddingHorizontal: 4 },
  filterRow: { flex: 1 },
  filterChip: { paddingHorizontal: 12, paddingVertical: 6, marginRight: 6, borderRadius: 16, backgroundColor: '#f3f4f6', borderWidth: 1, borderColor: '#e5e7eb' },
  filterChipActive: { backgroundColor: '#2563eb', borderColor: '#2563eb' },
  filterText: { fontSize: 12, fontWeight: '600', color: '#4b5563' },
  filterTextActive: { color: 'white' },
  dateFilterContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 10, backgroundColor: '#eff6ff', borderRadius: 8, paddingVertical: 4 },
  dateChevron: { paddingHorizontal: 6 },
  dateFilterRow: { flex: 1 },
  dateChip: { paddingHorizontal: 10, paddingVertical: 5, marginRight: 6, borderRadius: 14, backgroundColor: 'white', borderWidth: 1, borderColor: '#bfdbfe' },
  dateChipActive: { backgroundColor: '#2563eb', borderColor: '#2563eb' },
  dateText: { fontSize: 11, fontWeight: '600', color: '#2563eb' },
  dateTextActive: { color: 'white' },
  card: { backgroundColor: 'white', padding: 12, borderRadius: 8, marginBottom: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.1, shadowRadius: 2, elevation: 2 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between' },
  cardLeft: { flex: 1 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 3, flexWrap: 'wrap' },
  cardTitle: { fontSize: 15, fontWeight: 'bold' },
  statusBadge: { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 10 },
  statusText: { fontSize: 10, fontWeight: '600', textTransform: 'capitalize' },
  typeBadge: { flexDirection: 'row', alignItems: 'center', gap: 3, marginBottom: 3 },
  typeText: { fontSize: 11, color: '#6b7280', textTransform: 'capitalize' },
  cardSubtitle: { fontSize: 13, color: '#6b7280', marginBottom: 2 },
  cardDate: { fontSize: 12, color: '#9ca3af', marginBottom: 2 },
  jobLink: { fontSize: 12, color: '#2563eb', marginTop: 2 },
  actionMenuBtn: { padding: 4 },
  expandedInfo: { marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderTopColor: '#e5e7eb' },
  sectionTitle: { fontSize: 13, fontWeight: '700', color: '#1f2937', marginTop: 8, marginBottom: 6 },
  infoGrid: { gap: 6 },
  infoItem: { marginBottom: 6 },
  infoLabel: { fontSize: 11, color: '#6b7280', marginBottom: 1 },
  infoValue: { fontSize: 13, color: '#1f2937' },
  jobInfoBox: { backgroundColor: '#f9fafb', padding: 10, borderRadius: 6, borderWidth: 1, borderColor: '#e5e7eb' },
  jobInfoText: { fontSize: 13, color: '#1f2937', marginBottom: 3 },
  itemsHeader: { fontSize: 12, fontWeight: '600', color: '#374151', marginTop: 6, marginBottom: 3 },
  itemLine: { fontSize: 12, color: '#6b7280', marginLeft: 6, marginBottom: 2 },
  timestampSection: { marginTop: 10, paddingTop: 6, borderTopWidth: 1, borderTopColor: '#e5e7eb' },
  timestampText: { fontSize: 11, color: '#9ca3af', marginBottom: 2 },
  expandBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 8, gap: 3 },
  expandText: { fontSize: 12, color: '#2563eb', fontWeight: '600' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  progressModal: { backgroundColor: 'white', borderRadius: 10, padding: 24, alignItems: 'center', minWidth: 180 },
  progressText: { fontSize: 15, fontWeight: '600', color: '#1f2937', marginTop: 12 },
  progressSubtext: { fontSize: 13, color: '#6b7280', marginTop: 4 },
  statusPickerModal: { backgroundColor: 'white', borderRadius: 14, padding: 16, width: '85%', maxWidth: 320 },
  statusPickerTitle: { fontSize: 17, fontWeight: '700', color: '#1f2937', textAlign: 'center', marginBottom: 3 },
  statusPickerSubtitle: { fontSize: 12, color: '#6b7280', textAlign: 'center', marginBottom: 12 },
  statusOption: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12, backgroundColor: '#f9fafb', borderRadius: 8, marginBottom: 6, borderLeftWidth: 4 },
  statusOptionText: { fontSize: 14, fontWeight: '600' },
  cancelBtn: { marginTop: 6, padding: 12, alignItems: 'center', backgroundColor: '#f3f4f6', borderRadius: 8 },
  cancelBtnText: { fontSize: 14, fontWeight: '600', color: '#6b7280' },
  customerNameText: { fontSize: 13, color: '#059669', fontWeight: '600', marginBottom: 2 }
});
