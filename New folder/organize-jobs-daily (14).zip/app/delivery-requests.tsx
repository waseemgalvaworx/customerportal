import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { supabase } from './lib/supabase';
import { useRouter } from 'expo-router';
import ConfirmationModal from '../components/ConfirmationModal';
import logger from '../utils/logger';
import errorHandler from '../utils/errorHandler';
import { LogisticsDelivery } from '../types/database';

const MODULE = 'DeliveryRequests';

export default function DeliveryRequestsScreen() {
  const [requests, setRequests] = useState<LogisticsDelivery[]>([]);
  const [loading, setLoading] = useState(false);
  const [confirmModal, setConfirmModal] = useState<{
    visible: boolean;
    type: 'approve' | 'reject' | null;
    requestId: string | null;
  }>({ visible: false, type: null, requestId: null });
  const router = useRouter();

  const loadRequests = useCallback(async () => {
    setLoading(true);
    try {
      logger.debug(MODULE, 'Loading delivery requests');
      const { data, error } = await supabase
        .from('logistics_deliveries')
        .select('*')
        .eq('status', 'requested')
        .order('scheduled_date', { ascending: true });
      
      if (error) {
        errorHandler.handle(error, { module: MODULE, action: 'loadRequests' });
        return;
      }
      logger.info(MODULE, `Loaded ${data?.length || 0} requests`);
      setRequests(data || []);
    } catch (err) {
      errorHandler.handle(err, { module: MODULE, action: 'loadRequests' });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadRequests();
  }, [loadRequests]);

  const handleApprove = useCallback((id: string) => {
    logger.debug(MODULE, 'Approve button pressed', { id });
    setConfirmModal({ visible: true, type: 'approve', requestId: id });
  }, []);

  const handleReject = useCallback((id: string) => {
    logger.debug(MODULE, 'Reject button pressed', { id });
    setConfirmModal({ visible: true, type: 'reject', requestId: id });
  }, []);

  const executeApprove = useCallback(async () => {
    const id = confirmModal.requestId;
    setConfirmModal({ visible: false, type: null, requestId: null });
    
    try {
      const { error } = await supabase
        .from('logistics_deliveries')
        .update({ status: 'scheduled' })
        .eq('id', id)
        .select();
      
      if (error) {
        errorHandler.handle(error, { module: MODULE, action: 'approveRequest' });
        return;
      }
      logger.info(MODULE, 'Request approved successfully', { id });
      loadRequests();
    } catch (err) {
      errorHandler.handle(err, { module: MODULE, action: 'approveRequest' });
    }
  }, [confirmModal.requestId, loadRequests]);

  const executeReject = useCallback(async () => {
    const id = confirmModal.requestId;
    setConfirmModal({ visible: false, type: null, requestId: null });
    
    try {
      const { error } = await supabase
        .from('logistics_deliveries')
        .delete()
        .eq('id', id);
      
      if (error) {
        errorHandler.handle(error, { module: MODULE, action: 'rejectRequest' });
        return;
      }
      logger.info(MODULE, 'Request rejected successfully', { id });
      loadRequests();
    } catch (err) {
      errorHandler.handle(err, { module: MODULE, action: 'rejectRequest' });
    }
  }, [confirmModal.requestId, loadRequests]);

  const handleConfirm = useCallback(() => {
    if (confirmModal.type === 'approve') {
      executeApprove();
    } else if (confirmModal.type === 'reject') {
      executeReject();
    }
  }, [confirmModal.type, executeApprove, executeReject]);

  const handleCancel = useCallback(() => {
    setConfirmModal({ visible: false, type: null, requestId: null });
  }, []);





  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Delivery Requests</Text>
      </View>

      <ScrollView style={styles.content}>
        {loading && <Text style={styles.loadingText}>Loading...</Text>}
        {!loading && requests.length === 0 && (
          <Text style={styles.emptyText}>No pending delivery requests</Text>
        )}
        {requests.map(req => (
          <View key={req.id} style={styles.card}>
            <View style={styles.cardHeader}>
              <Text style={styles.cardTitle}>{req.delivery_number}</Text>
              <View style={styles.badge}>
                <Text style={styles.badgeText}>REQUESTED</Text>
              </View>
            </View>
            <Text style={styles.cardText}>Client: {req.client_name}</Text>
            <Text style={styles.cardText}>Address: {req.delivery_address}</Text>
            <Text style={styles.cardText}>Requested: {req.scheduled_date}</Text>
            {req.contact_phone && <Text style={styles.cardText}>Phone: {req.contact_phone}</Text>}
            {req.notes && <Text style={styles.cardNotes}>Notes: {req.notes}</Text>}
            
            <View style={styles.actions}>
              <TouchableOpacity 
                style={styles.approveBtn} 
                onPress={() => handleApprove(req.id)}
                activeOpacity={0.7}
              >
                <Text style={styles.approveBtnText}>Approve</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.rejectBtn} 
                onPress={() => handleReject(req.id)}
                activeOpacity={0.7}
              >
                <Text style={styles.rejectBtnText}>Reject</Text>
              </TouchableOpacity>
            </View>



          </View>
        ))}
      </ScrollView>


      <ConfirmationModal
        visible={confirmModal.visible}
        title={confirmModal.type === 'approve' ? 'Approve Request' : 'Reject Request'}
        message={
          confirmModal.type === 'approve'
            ? 'Convert this request to a scheduled delivery?'
            : 'Are you sure you want to reject this delivery request?'
        }
        confirmText={confirmModal.type === 'approve' ? 'Approve' : 'Reject'}
        cancelText="Cancel"
        confirmStyle={confirmModal.type === 'reject' ? 'destructive' : 'default'}
        onConfirm={handleConfirm}
        onCancel={handleCancel}
      />
    </View>
  );
}


const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { backgroundColor: '#2563eb', padding: 20, paddingTop: 60 },
  backBtn: { marginBottom: 10 },
  backText: { color: 'white', fontSize: 16 },
  title: { fontSize: 24, fontWeight: 'bold', color: 'white' },
  content: { flex: 1, padding: 15 },
  loadingText: { textAlign: 'center', marginTop: 20, color: '#6b7280' },
  emptyText: { textAlign: 'center', marginTop: 40, fontSize: 16, color: '#6b7280' },
  card: { backgroundColor: 'white', padding: 15, borderRadius: 8, marginBottom: 12, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.1, shadowRadius: 2, elevation: 2 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  cardTitle: { fontSize: 18, fontWeight: 'bold', color: '#1f2937' },
  badge: { backgroundColor: '#fbbf24', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  badgeText: { fontSize: 11, fontWeight: '600', color: '#78350f' },
  cardText: { fontSize: 14, color: '#4b5563', marginBottom: 4 },
  cardNotes: { fontSize: 13, color: '#6b7280', marginTop: 8, fontStyle: 'italic' },
  actions: { flexDirection: 'row', marginTop: 12 },
  approveBtn: { flex: 1, backgroundColor: '#10b981', padding: 12, borderRadius: 6, marginRight: 5 },
  approveBtnText: { color: 'white', textAlign: 'center', fontWeight: '600' },
  rejectBtn: { flex: 1, backgroundColor: '#ef4444', padding: 12, borderRadius: 6, marginLeft: 5 },
  rejectBtnText: { color: 'white', textAlign: 'center', fontWeight: '600' }
});
