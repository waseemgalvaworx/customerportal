import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, SafeAreaView } from 'react-native';
import { supabase } from '@/app/lib/supabase';
import { TIME_SLOTS, DEPARTMENTS } from '@/utils/hourlyProductionTrackerV2';

interface Snapshot {
  id: string;
  date: string;
  shift_name: string;
  data: any;
  saved_at: string;
  notes: string;
}

export default function HourlyProductionArchive() {
  const [snapshots, setSnapshots] = useState<Snapshot[]>([]);
  const [selectedSnapshot, setSelectedSnapshot] = useState<Snapshot | null>(null);

  useEffect(() => {
    loadSnapshots();
  }, []);

  const loadSnapshots = async () => {
    const { data, error } = await supabase
      .from('hourly_production_snapshots')
      .select('*')
      .order('saved_at', { ascending: false });

    if (!error && data) {
      setSnapshots(data);
    }
  };

  const renderSnapshotItem = ({ item }: { item: Snapshot }) => (
    <TouchableOpacity
      style={styles.snapshotCard}
      onPress={() => setSelectedSnapshot(item)}
    >
      <Text style={styles.snapshotTitle}>{item.shift_name}</Text>
      <Text style={styles.snapshotDate}>{new Date(item.date).toLocaleDateString()}</Text>
      {item.notes && <Text style={styles.snapshotNotes}>{item.notes}</Text>}
    </TouchableOpacity>
  );

  if (selectedSnapshot) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => setSelectedSnapshot(null)}>
            <Text style={styles.backButton}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.title}>{selectedSnapshot.shift_name}</Text>
          <Text style={styles.subtitle}>{new Date(selectedSnapshot.date).toLocaleDateString()}</Text>
        </View>
        <View style={styles.tableContainer}>
          <View style={styles.headerRow}>
            <Text style={styles.headerCell}>Time</Text>
            {DEPARTMENTS.map(dept => (
              <Text key={dept} style={styles.headerCell}>{dept.toUpperCase()}</Text>
            ))}
          </View>
          <FlatList
            data={TIME_SLOTS}
            keyExtractor={(item) => item}
            renderItem={({ item: slot }) => (
              <View style={styles.dataRow}>
                <Text style={styles.timeCell}>{slot}</Text>
                {DEPARTMENTS.map(dept => (
                  <Text key={dept} style={styles.dataCell}>
                    {selectedSnapshot.data[slot]?.[dept]?.toFixed(1) || '0.0'}
                  </Text>
                ))}
              </View>
            )}
          />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Saved Hourly Production Data</Text>
      </View>
      <FlatList
        data={snapshots}
        keyExtractor={(item) => item.id}
        renderItem={renderSnapshotItem}
        contentContainerStyle={styles.list}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f3f4f6' },
  header: { padding: 16, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#e5e7eb' },
  backButton: { fontSize: 16, color: '#6366f1', marginBottom: 8 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#111827' },
  subtitle: { fontSize: 14, color: '#6b7280', marginTop: 4 },
  list: { padding: 16 },
  snapshotCard: { backgroundColor: 'white', padding: 16, borderRadius: 8, marginBottom: 12 },
  snapshotTitle: { fontSize: 18, fontWeight: 'bold', color: '#111827' },
  snapshotDate: { fontSize: 14, color: '#6b7280', marginTop: 4 },
  snapshotNotes: { fontSize: 14, color: '#374151', marginTop: 8 },
  tableContainer: { flex: 1 },
  headerRow: { flexDirection: 'row', backgroundColor: '#6366f1', paddingVertical: 12 },
  headerCell: { flex: 1, color: 'white', fontWeight: 'bold', textAlign: 'center' },
  dataRow: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: '#e5e7eb' },
  timeCell: { flex: 1, paddingVertical: 12, fontWeight: '600', textAlign: 'center' },
  dataCell: { flex: 1, paddingVertical: 12, textAlign: 'center' }
});
