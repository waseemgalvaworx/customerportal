# Setting Up Admin Access

## How to Make Yourself an Admin

The **User Management** screen only appears for users with the `admin` role. Here's how to set it up:

### Step 1: Access Supabase Dashboard
1. Go to https://app.supabase.com
2. Select your project
3. Click on **Table Editor** in the left sidebar

### Step 2: Update Your Role in the Profiles Table
1. Find and click on the **`profiles`** table
2. Locate your user row (find your username)
3. Click on the **`role`** column for your user
4. Change the value to: **`admin`**
5. Click the checkmark or press Enter to save

### Step 3: Restart the App
1. Close the app completely
2. Reopen it and log in again
3. You should now see **"User Management"** on the home screen

## Where to Find User Management

Once you have admin role, you'll see:
- **Home Screen**: A new card called "User Management" with a person-add icon (red color)
- Click it to access the User Management screen

## What You Can Do as Admin

In the User Management screen, you can:
- ✅ **Create New Users**: Click "+ Add User" button
  - Set username, password, full name
  - Assign role: Admin, Manager, Operator, or Viewer
  
- ✅ **Edit Users**: Click "Edit" on any user card
  - Change role
  - Update full name
  - Reset password
  
- ✅ **Delete Users**: Click "Delete" on any user card
  - Confirmation dialog prevents accidents
  - Cannot delete yourself

## Role Permissions

- **Admin**: Full access to everything including user management
- **Manager**: Can manage jobs and customers
- **Operator**: Can view and update jobs
- **Viewer**: Read-only access

## Troubleshooting

### Still don't see User Management?
1. Make sure you saved the role change in Supabase
2. Completely close and reopen the app
3. Check the home screen - it should be the last card in the list
4. Verify your role shows as "ADMIN" (red badge) under your name on home screen

### Can't access Supabase?
- You need access to the Supabase project dashboard
- Ask the project owner to grant you access or update your role for you
