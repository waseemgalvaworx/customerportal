import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TouchableOpacity, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../app/lib/supabase';

interface Recipient {
  id: string;
  email: string;
  name?: string;
}

interface Props {
  visible: boolean;
  onClose: () => void;
  onSend: (selectedEmails: string[]) => void;
  sending?: boolean;
}

export default function SelectEmailRecipientsModal({ visible, onClose, onSend, sending }: Props) {
  const [recipients, setRecipients] = useState<Recipient[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (visible) {
      loadRecipients();
    }
  }, [visible]);

  const loadRecipients = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.from('email_recipients').select('*');
      if (error) throw error;
      setRecipients(data || []);
      // Start with no recipients selected - user must manually select
      setSelectedIds(new Set());
    } catch (err) {
      console.error('Error loading recipients:', err);
    }
    setLoading(false);
  };


  const toggleRecipient = (id: string) => {
    const newSet = new Set(selectedIds);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setSelectedIds(newSet);
  };

  const toggleAll = () => {
    if (selectedIds.size === recipients.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(recipients.map(r => r.id)));
    }
  };

  const handleSend = () => {
    const selectedEmails = recipients.filter(r => selectedIds.has(r.id)).map(r => r.email);
    onSend(selectedEmails);
  };

  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <View style={styles.header}>
            <Text style={styles.title}>Select Recipients</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
              <Ionicons name="close" size={24} color="#6b7280" />
            </TouchableOpacity>
          </View>

          {loading ? (
            <ActivityIndicator size="large" color="#2563eb" style={{ marginVertical: 30 }} />
          ) : recipients.length === 0 ? (
            <Text style={styles.emptyText}>No email recipients configured. Add recipients in Email Settings.</Text>
          ) : (
            <>
              <TouchableOpacity style={styles.selectAllRow} onPress={toggleAll}>
                <Ionicons name={selectedIds.size === recipients.length ? 'checkbox' : 'square-outline'} size={22} color="#2563eb" />
                <Text style={styles.selectAllText}>Select All ({recipients.length})</Text>
              </TouchableOpacity>

              <ScrollView style={styles.list}>
                {recipients.map(r => (
                  <TouchableOpacity key={r.id} style={styles.recipientRow} onPress={() => toggleRecipient(r.id)}>
                    <Ionicons name={selectedIds.has(r.id) ? 'checkbox' : 'square-outline'} size={22} color={selectedIds.has(r.id) ? '#2563eb' : '#9ca3af'} />
                    <View style={styles.recipientInfo}>
                      {r.name && <Text style={styles.recipientName}>{r.name}</Text>}
                      <Text style={styles.recipientEmail}>{r.email}</Text>
                    </View>
                  </TouchableOpacity>
                ))}
              </ScrollView>

              <View style={styles.footer}>
                <Text style={styles.selectedCount}>{selectedIds.size} recipient(s) selected</Text>
                <View style={styles.btnRow}>
                  <TouchableOpacity style={styles.cancelBtn} onPress={onClose}>
                    <Text style={styles.cancelText}>Cancel</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={[styles.sendBtn, (selectedIds.size === 0 || sending) && styles.sendBtnDisabled]} onPress={handleSend} disabled={selectedIds.size === 0 || sending}>
                    {sending ? <ActivityIndicator size="small" color="white" /> : <Ionicons name="send" size={18} color="white" />}
                    <Text style={styles.sendText}>{sending ? 'Sending...' : 'Send'}</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modal: { backgroundColor: 'white', borderRadius: 12, width: '90%', maxWidth: 400, maxHeight: '80%' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderBottomColor: '#e5e7eb' },
  title: { fontSize: 18, fontWeight: '700', color: '#1f2937' },
  closeBtn: { padding: 4 },
  emptyText: { padding: 20, textAlign: 'center', color: '#6b7280', fontSize: 14 },
  selectAllRow: { flexDirection: 'row', alignItems: 'center', padding: 12, borderBottomWidth: 1, borderBottomColor: '#f3f4f6', gap: 10 },
  selectAllText: { fontSize: 14, fontWeight: '600', color: '#2563eb' },
  list: { maxHeight: 300 },
  recipientRow: { flexDirection: 'row', alignItems: 'center', padding: 12, borderBottomWidth: 1, borderBottomColor: '#f3f4f6', gap: 10 },
  recipientInfo: { flex: 1 },
  recipientName: { fontSize: 14, fontWeight: '600', color: '#1f2937' },
  recipientEmail: { fontSize: 13, color: '#6b7280' },
  footer: { padding: 16, borderTopWidth: 1, borderTopColor: '#e5e7eb' },
  selectedCount: { fontSize: 12, color: '#6b7280', marginBottom: 10, textAlign: 'center' },
  btnRow: { flexDirection: 'row', gap: 10 },
  cancelBtn: { flex: 1, padding: 12, borderRadius: 8, backgroundColor: '#f3f4f6', alignItems: 'center' },
  cancelText: { fontSize: 14, fontWeight: '600', color: '#6b7280' },
  sendBtn: { flex: 1, flexDirection: 'row', padding: 12, borderRadius: 8, backgroundColor: '#16a34a', alignItems: 'center', justifyContent: 'center', gap: 6 },
  sendBtnDisabled: { backgroundColor: '#9ca3af' },
  sendText: { fontSize: 14, fontWeight: '600', color: 'white' }
});
