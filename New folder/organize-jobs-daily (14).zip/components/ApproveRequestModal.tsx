import React, { useState } from 'react';
import { Modal, View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { supabase } from '@/app/lib/supabase';
import { usePasswordAuth } from '@/contexts/PasswordAuthContext';
import { getUserIdFromUsername } from '@/utils/userMapping';
import { checkUserNotificationPermission } from '@/utils/notificationHelper';

interface ApproveRequestModalProps {
  visible: boolean;
  onClose: () => void;
  request: any;
  onSuccess: () => void;
}

export default function ApproveRequestModal({ visible, onClose, request, onSuccess }: ApproveRequestModalProps) {
  const { user } = usePasswordAuth();
  const [loading, setLoading] = useState(false);

  const sendNotificationWithPermissionCheck = async (
    userId: string, title: string, message: string, type: string
  ) => {
    const hasPermission = await checkUserNotificationPermission(userId, type, title, message);
    if (!hasPermission) {
      console.log(`🚫 User ${userId} has disabled ${type} notifications, skipping`);
      return false;
    }
    const { error } = await supabase.from('notifications').insert({
      user_id: userId, title, message, type, created_at: new Date().toISOString()
    });
    if (error) console.error('❌ Error sending notification:', error);
    return !error;
  };

  const handleApprove = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.from('stock_requests').update({
        status: 'approved',
        approved_by: user?.username || user?.email || 'Unknown',
        approved_at: new Date().toISOString()
      }).eq('id', request.id);
      if (error) throw error;

      const { error: transError } = await supabase.from('inventory_transactions').insert({
        item_id: request.item_id,
        transaction_type: 'out',
        quantity: request.quantity_requested,
        notes: `Stock request approved for ${request.requested_by}. Ref: ${request.ref || 'N/A'}`,
        reason: request.reason || 'Stock request'
      });
      if (transError) throw transError;

      const { data: itemData } = await supabase
        .from('inventory_items').select('quantity').eq('id', request.item_id).single();
      if (itemData) {
        const newQty = (itemData.quantity || 0) - request.quantity_requested;
        await supabase.from('inventory_items').update({ quantity: newQty }).eq('id', request.item_id);
      }

      // Notify requester with permission check
      const requesterUserId = getUserIdFromUsername(request.requested_by);
      if (requesterUserId) {
        await sendNotificationWithPermissionCheck(
          requesterUserId,
          'Stock Request Approved',
          `Your request for ${request.quantity_requested} ${request.inventory_items?.unit} of ${request.inventory_items?.item_name} has been approved.`,
          'stock_request_approved'
        );
      }

      // Notify managers with permission check
      const targets = ['admin', 'Lovena', 'KH', 'Ashok'].filter(t => t !== request.requested_by);
      for (const target of targets) {
        const targetId = getUserIdFromUsername(target);
        if (targetId) {
          await sendNotificationWithPermissionCheck(
            targetId,
            'Stock Request Approved',
            `${user?.username || 'Admin'} approved ${request.requested_by}'s request for ${request.quantity_requested} ${request.inventory_items?.unit} of ${request.inventory_items?.item_name}`,
            'stock_request_approved'
          );
        }
      }

      Alert.alert('Success', 'Request approved and inventory updated.');
      onSuccess();
      onClose();
    } catch (error: any) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleReject = async () => {
    Alert.alert('Reject Request', 'Are you sure?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Reject', style: 'destructive',
        onPress: async () => {
          try {
            await supabase.from('stock_requests').update({
              status: 'rejected',
              approved_by: user?.username || user?.email || 'Unknown',
              approved_at: new Date().toISOString()
            }).eq('id', request.id);

            const requesterUserId = getUserIdFromUsername(request.requested_by);
            if (requesterUserId) {
              await sendNotificationWithPermissionCheck(
                requesterUserId,
                'Stock Request Rejected',
                `Your request for ${request.quantity_requested} ${request.inventory_items?.unit} of ${request.inventory_items?.item_name} has been rejected`,
                'stock_request_approved'
              );
            }

            const targets = ['admin', 'Lovena', 'KH', 'Ashok'].filter(t => t !== request.requested_by);
            for (const target of targets) {
              const targetId = getUserIdFromUsername(target);
              if (targetId) {
                await sendNotificationWithPermissionCheck(
                  targetId,
                  'Stock Request Rejected',
                  `${user?.username || 'Admin'} rejected ${request.requested_by}'s request`,
                  'stock_request_approved'
                );
              }
            }
            onSuccess();
            onClose();
          } catch (error: any) {
            Alert.alert('Error', error.message);
          }
        }
      }
    ]);
  };

  if (!request) return null;

  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <Text style={styles.title}>Approve Stock Request</Text>
          <View style={styles.info}><Text style={styles.label}>Item:</Text><Text style={styles.value}>{request.inventory_items?.item_name}</Text></View>
          <View style={styles.info}><Text style={styles.label}>Quantity:</Text><Text style={styles.value}>{request.quantity_requested} {request.inventory_items?.unit}</Text></View>
          <View style={styles.info}><Text style={styles.label}>Requested by:</Text><Text style={styles.value}>{request.requested_by}</Text></View>
          {request.reason && <View style={styles.info}><Text style={styles.label}>Reason:</Text><Text style={styles.value}>{request.reason}</Text></View>}
          {request.ref && <View style={styles.info}><Text style={styles.label}>Ref:</Text><Text style={styles.value}>{request.ref}</Text></View>}
          <View style={styles.buttons}>
            <TouchableOpacity style={styles.rejectBtn} onPress={handleReject}><Text style={styles.rejectText}>Reject</Text></TouchableOpacity>
            <TouchableOpacity style={styles.approveBtn} onPress={handleApprove} disabled={loading}><Text style={styles.approveText}>{loading ? 'Approving...' : 'Approve'}</Text></TouchableOpacity>
          </View>
          <TouchableOpacity style={styles.cancelBtn} onPress={onClose}><Text style={styles.cancelText}>Cancel</Text></TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: '#fff', borderRadius: 12, padding: 20 },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 16 },
  info: { marginBottom: 12 },
  label: { fontSize: 12, color: '#666', marginBottom: 2 },
  value: { fontSize: 16, fontWeight: '600' },
  buttons: { flexDirection: 'row', gap: 10, marginTop: 20 },
  rejectBtn: { flex: 1, padding: 12, borderRadius: 8, backgroundColor: '#FF3B30' },
  rejectText: { textAlign: 'center', fontSize: 16, color: '#fff', fontWeight: '600' },
  approveBtn: { flex: 1, padding: 12, borderRadius: 8, backgroundColor: '#34C759' },
  approveText: { textAlign: 'center', fontSize: 16, color: '#fff', fontWeight: '600' },
  cancelBtn: { marginTop: 10, padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#ddd' },
  cancelText: { textAlign: 'center', fontSize: 16 }
});
