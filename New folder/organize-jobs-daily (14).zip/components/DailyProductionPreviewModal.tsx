import React from 'react';
import { Modal, View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';

interface Job {
  id: string;
  job_number: string;
  customer_name: string;
  date_of_entry: string;
  completed_date?: string;
  items: Array<{
    description: string;
    weight: number;
    paint_varnish?: boolean;
    galva?: boolean;
    light_galva?: boolean;
    light_paint?: boolean;
    rusty?: boolean;
  }>;
}

interface Props {
  visible: boolean;
  onClose: () => void;
  jobs: Job[];
  onExport: () => void;
}

const formatDateForReport = (date: Date) => {
  const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
  const months = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'];
  return `${days[date.getDay()]} ${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`;
};

export default function DailyProductionPreviewModal({ visible, onClose, jobs, onExport }: Props) {
  const handleExport = () => {
    onExport();
    onClose();
  };

  const reportDate = formatDateForReport(new Date());
  
  // Calculate total weight
  const totalWeight = jobs.reduce((total, job) => {
    const jobWeight = job.items.reduce((sum, item) => sum + item.weight, 0);
    return total + jobWeight;
  }, 0);

  return (
    <Modal visible={visible} animationType="slide" transparent={true}>
      <View style={styles.overlay}>
        <View style={styles.container}>
          <ScrollView style={styles.preview}>
            <View style={styles.header}>
              <Text style={styles.headerTitle}>Production Sheet</Text>
              <Text style={styles.headerDate}>{reportDate}</Text>
            </View>
            
            <View style={styles.table}>

              <View style={styles.tableHeader}>
                <Text style={[styles.headerCell, styles.jobNoCol]}>JOB NO</Text>
                <Text style={[styles.headerCell, styles.dateCol]}>DATE OF ENTRY</Text>
                <Text style={[styles.headerCell, styles.customerCol]}>CUSTOMER NAME</Text>
                <Text style={[styles.headerCell, styles.detailsCol]}>DETAILS OF WORK</Text>
                <Text style={[styles.headerCell, styles.weightCol]}>WEIGHT (KGS)</Text>
                <Text style={[styles.headerCell, styles.readyCol]}>READY DATE</Text>
              </View>

              {jobs.map((job) => {
                return (
                  <View key={job.id} style={styles.tableRow}>
                    <Text style={[styles.cell, styles.jobNoCol, styles.centerAlign]}>{job.job_number}</Text>
                    <Text style={[styles.cell, styles.dateCol, styles.centerAlign]}>
                      {new Date(job.date_of_entry).toLocaleDateString('en-GB')}
                    </Text>
                    <Text style={[styles.cell, styles.customerCol]}>{job.customer_name}</Text>
                    <View style={[styles.cell, styles.detailsCol]}>
                      {job.items.map((item, i) => {
                        const opts = [];
                        if (item.paint_varnish) opts.push('Paint/Varnish');
                        if (item.galva) opts.push('Galva');
                        if (item.light_galva) opts.push('Light Galva');
                        if (item.light_paint) opts.push('Light Paint');
                        if (item.rusty) opts.push('Rusty');
                        return (
                          <Text key={i} style={styles.itemText}>
                            • {item.description}{opts.length > 0 ? ` - ${opts.join(', ')}` : ''}
                          </Text>
                        );
                      })}
                    </View>
                    <View style={[styles.cell, styles.weightCol]}>
                      {job.items.map((item, i) => (
                        <Text key={i} style={[styles.itemText, styles.rightAlign]}>
                          {item.weight > 0 ? item.weight.toFixed(2) : ''}
                        </Text>
                      ))}
                    </View>
                    <Text style={[styles.cell, styles.readyCol, styles.centerAlign]}>
                      {job.completed_date ? new Date(job.completed_date).toLocaleDateString('en-GB') : ''}
                    </Text>
                  </View>
                );
              })}
              
              <View style={[styles.tableRow, styles.totalRow]}>
                <View style={[styles.cell, styles.totalLabelCell]}>
                  <Text style={styles.totalLabel}>TOTAL PRODUCTION:</Text>
                </View>
                <Text style={[styles.cell, styles.weightCol, styles.rightAlign, styles.totalText]}>
                  {totalWeight.toFixed(2)}
                </Text>
                <Text style={[styles.cell, styles.readyCol]}></Text>
              </View>
            </View>

          </ScrollView>

          <View style={styles.buttons}>
            <TouchableOpacity style={styles.cancelButton} onPress={onClose}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.exportButton} onPress={handleExport}>
              <Text style={styles.exportText}>Export PDF</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  container: { backgroundColor: 'white', borderRadius: 12, maxHeight: '90%', padding: 20 },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 16, textAlign: 'center' },
  preview: { flex: 1, borderWidth: 1, borderColor: '#e5e7eb', borderRadius: 8, padding: 12, marginBottom: 16 },
  header: { marginBottom: 12, paddingBottom: 8, borderBottomWidth: 1, borderBottomColor: '#e5e7eb' },
  headerTitle: { fontSize: 14, fontWeight: 'bold', textAlign: 'center', marginBottom: 4 },
  headerDate: { fontSize: 10, textAlign: 'center', color: '#666' },
  table: { borderWidth: 1, borderColor: '#000' },

  tableHeader: { flexDirection: 'row', backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#000' },
  headerCell: { fontSize: 9, fontWeight: 'bold', padding: 4, borderRightWidth: 1, borderRightColor: '#000', textAlign: 'center' },
  tableRow: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: '#000' },
  cell: { fontSize: 8, padding: 3, borderRightWidth: 1, borderRightColor: '#000' },
  itemText: { fontSize: 8, lineHeight: 12, marginBottom: 1 },
  rightAlign: { textAlign: 'right' },
  centerAlign: { textAlign: 'center' },
  jobNoCol: { width: '7%' },
  dateCol: { width: '9%' },
  customerCol: { width: '16%' },
  detailsCol: { width: '48%' },
  weightCol: { width: '10%' },
  readyCol: { width: '10%' },
  totalRow: { backgroundColor: '#f3f4f6' },
  totalLabelCell: { width: '80%', justifyContent: 'center', alignItems: 'flex-end', paddingRight: 5 },
  totalLabel: { fontSize: 9, fontWeight: 'bold' },
  totalText: { fontSize: 9, fontWeight: 'bold' },
  buttons: { flexDirection: 'row', gap: 12 },
  cancelButton: { flex: 1, padding: 14, backgroundColor: '#f3f4f6', borderRadius: 8, alignItems: 'center' },
  cancelText: { fontSize: 16, fontWeight: '600', color: '#374151' },
  exportButton: { flex: 1, padding: 14, backgroundColor: '#6366F1', borderRadius: 8, alignItems: 'center' },
  exportText: { fontSize: 16, fontWeight: '600', color: 'white' },
});

