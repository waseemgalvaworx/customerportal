import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TextInput, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';
import { supabase } from '../app/lib/supabase';
import { useCustomers } from '../contexts/CustomerContext';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import { Ionicons } from '@expo/vector-icons';
import DateTimePicker from './DateTimePicker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ALLOWED_TASK_USERS } from '../contexts/TaskContext';

interface AddDeliveryModalProps {
  visible: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const DRAFT_KEY = 'add_delivery_draft';

interface DraftData {
  deliveryType: string;
  customerName: string;
  deliveryAddress: string;
  description: string;
  scheduledDate: string;
  savedAt: number;
}

export default function AddDeliveryModal({ visible, onClose, onSuccess }: AddDeliveryModalProps) {
  const { getCustomerById } = useCustomers();
  const { user } = usePasswordAuth();
  const [deliveryNumber, setDeliveryNumber] = useState('');
  const [jobs, setJobs] = useState([]);
  const [selectedJob, setSelectedJob] = useState(null);
  const [showJobList, setShowJobList] = useState(false);
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [scheduledDate, setScheduledDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deliveryType, setDeliveryType] = useState('pickup');
  const [description, setDescription] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [drivers, setDrivers] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [selectedDriver, setSelectedDriver] = useState(null);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [showDriverList, setShowDriverList] = useState(false);
  const [showVehicleList, setShowVehicleList] = useState(false);
  const [showDraftIndicator, setShowDraftIndicator] = useState(false);
  const [hasDraft, setHasDraft] = useState(false);

  // Check if user is allowed to use draft feature
  const canUseDrafts = ALLOWED_TASK_USERS.includes(user?.username || '');

  useEffect(() => {
    if (visible) {
      loadJobs();
      loadDriversAndVehicles();
      generateDeliveryNumber();
      setScheduledDate(new Date());
      
      // Load draft for allowed users
      if (canUseDrafts) {
        loadDraft();
      }
    }
  }, [visible, canUseDrafts]);

  // Auto-save draft when form changes
  useEffect(() => {
    if (visible && canUseDrafts && hasFormData()) {
      const timeout = setTimeout(() => {
        saveDraft();
      }, 1000); // Debounce 1 second
      return () => clearTimeout(timeout);
    }
  }, [deliveryType, customerName, deliveryAddress, description, visible]);

  const hasFormData = () => {
    return customerName.trim() || deliveryAddress.trim() || description.trim();
  };

  const loadDraft = async () => {
    try {
      const draftStr = await AsyncStorage.getItem(DRAFT_KEY);
      if (draftStr) {
        const draft: DraftData = JSON.parse(draftStr);
        // Only load if draft is less than 24 hours old
        if (Date.now() - draft.savedAt < 24 * 60 * 60 * 1000) {
          setDeliveryType(draft.deliveryType || 'pickup');
          setCustomerName(draft.customerName || '');
          setDeliveryAddress(draft.deliveryAddress || '');
          setDescription(draft.description || '');
          if (draft.scheduledDate) {
            setScheduledDate(new Date(draft.scheduledDate));
          }
          setHasDraft(true);
        } else {
          // Clear old draft
          await AsyncStorage.removeItem(DRAFT_KEY);
        }
      }
    } catch (error) {
      console.error('Error loading draft:', error);
    }
  };

  const saveDraft = async () => {
    try {
      const draft: DraftData = {
        deliveryType,
        customerName,
        deliveryAddress,
        description,
        scheduledDate: scheduledDate.toISOString(),
        savedAt: Date.now()
      };
      await AsyncStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
      setShowDraftIndicator(true);
      setHasDraft(true);
      setTimeout(() => setShowDraftIndicator(false), 2000);
    } catch (error) {
      console.error('Error saving draft:', error);
    }
  };

  const clearDraft = async () => {
    try {
      await AsyncStorage.removeItem(DRAFT_KEY);
      setHasDraft(false);
    } catch (error) {
      console.error('Error clearing draft:', error);
    }
  };

  const loadDriversAndVehicles = async () => {
    try {
      const [driversRes, vehiclesRes] = await Promise.all([
        supabase.from('drivers').select('*').eq('status', 'active').order('full_name'),
        supabase.from('vehicles').select('*').eq('status', 'active').order('vehicle_number')
      ]);
      setDrivers(driversRes.data || []);
      setVehicles(vehiclesRes.data || []);
    } catch (err) {
      console.error('Error loading drivers/vehicles:', err);
    }
  };


  const generateDeliveryNumber = async () => {
    try {
      const today = new Date();
      const datePrefix = `${String(today.getDate()).padStart(2, '0')}${String(today.getMonth() + 1).padStart(2, '0')}${String(today.getFullYear()).slice(-2)}`;
      const { data } = await supabase.from('logistics_deliveries').select('delivery_number').like('delivery_number', `GAL-${datePrefix}%`).order('created_at', { ascending: false }).limit(1);
      let seq = 1;
      if (data?.length > 0) seq = parseInt(data[0].delivery_number.split(datePrefix)[1] || '0') + 1;
      setDeliveryNumber(`GAL-${datePrefix}${String(seq).padStart(2, '0')}`);
    } catch (err) {
      setDeliveryNumber(`GAL-${Date.now().toString().slice(-6)}`);
    }
  };

  const loadJobs = async () => {
    const { data } = await supabase.from('jobs').select('id, jobNumber, customerId, customerName, items, status').order('jobNumber', { ascending: false });
    setJobs(data || []);
  };

  const filteredJobs = jobs.filter(job => {
    if (!searchTerm.trim()) return true;
    const s = searchTerm.toLowerCase();
    return job.jobNumber?.toLowerCase().includes(s) || job.customerName?.toLowerCase().includes(s);
  });

  const handleSave = async () => {
    if (!deliveryAddress.trim()) { Alert.alert('Error', 'Please fill in delivery address'); return; }
    setSaving(true);
    const { error } = await supabase.from('logistics_deliveries').insert({
      delivery_number: deliveryNumber,
      job_id: selectedJob?.id || null,
      job_items: selectedJob?.items || null,
      client_name: selectedJob?.customerId || null,
      customer_name: (deliveryType === 'pickup' || deliveryType === 'delivery') ? customerName.trim() || null : null,
      delivery_address: deliveryAddress.trim(),
      scheduled_date: scheduledDate.toISOString().split('T')[0],
      status: 'scheduled',
      delivery_type: deliveryType,
      description: description.trim() || null,
      driver_id: selectedDriver?.id || null,
      vehicle_id: selectedVehicle?.id || null
    }).select();
    setSaving(false);
    if (error) Alert.alert('Error', error.message);
    else { 
      // Clear draft on successful save
      await clearDraft();
      Alert.alert('Success', 'Delivery added'); 
      resetForm(); 
      onSuccess(); 
      onClose(); 
    }
  };

  const resetForm = () => {
    setDeliveryNumber(''); setSelectedJob(null); setDeliveryAddress(''); setScheduledDate(new Date());
    setDeliveryType('pickup'); setDescription(''); setSearchTerm(''); setCustomerName('');
    setSelectedDriver(null); setSelectedVehicle(null); setHasDraft(false);
  };

  const handleClearDraft = () => {
    Alert.alert(
      'Clear Draft',
      'Are you sure you want to clear the saved draft?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Clear', 
          style: 'destructive',
          onPress: async () => {
            await clearDraft();
            setCustomerName('');
            setDeliveryAddress('');
            setDescription('');
            setDeliveryType('pickup');
          }
        }
      ]
    );
  };

  const formatDate = (d: Date) => `${['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <ScrollView>
            <View style={styles.headerRow}>
              <Text style={styles.title}>Add New Delivery</Text>
              {canUseDrafts && showDraftIndicator && (
                <View style={styles.draftIndicator}>
                  <Ionicons name="cloud-done" size={14} color="#10B981" />
                  <Text style={styles.draftIndicatorText}>Draft saved</Text>
                </View>
              )}
            </View>
            
            {canUseDrafts && hasDraft && (
              <TouchableOpacity style={styles.draftBanner} onPress={handleClearDraft}>
                <Ionicons name="document-text-outline" size={16} color="#3B82F6" />
                <Text style={styles.draftBannerText}>Draft restored from previous session</Text>
                <Ionicons name="close-circle" size={18} color="#6B7280" />
              </TouchableOpacity>
            )}
            
            <Text style={styles.label}>Delivery Number</Text>
            <View style={[styles.input, styles.readOnly]}><Text>{deliveryNumber}</Text></View>

            <Text style={styles.label}>Delivery Type</Text>
            <View style={styles.tabContainer}>
              {['pickup', 'delivery', 'others'].map(t => (
                <TouchableOpacity key={t} style={[styles.tab, deliveryType === t && styles.tabActive]} onPress={() => setDeliveryType(t)}>
                  <Text style={[styles.tabText, deliveryType === t && styles.tabTextActive]}>{t === 'pickup' ? 'Pick up' : t.charAt(0).toUpperCase() + t.slice(1)}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {(deliveryType === 'pickup' || deliveryType === 'delivery') && (
              <>
                <Text style={styles.label}>Customer Name</Text>
                <TextInput style={styles.input} placeholder="Enter customer name" value={customerName} onChangeText={setCustomerName} />
              </>
            )}
            
            {deliveryType === 'delivery' && (
              <>
                <Text style={styles.label}>Select Job (Optional)</Text>
                <TouchableOpacity style={styles.input} onPress={() => setShowJobList(!showJobList)}>
                  <Text>{selectedJob ? `${selectedJob.jobNumber} - ${selectedJob.customerName || 'Unknown'}` : 'Select Job'}</Text>
                </TouchableOpacity>
                {showJobList && (
                  <View style={styles.jobList}>
                    <TextInput style={styles.searchInput} placeholder="Search..." value={searchTerm} onChangeText={setSearchTerm} />
                    <ScrollView style={styles.jobScroll}>
                      {filteredJobs.map(j => (
                        <TouchableOpacity key={j.id} style={styles.jobItem} onPress={() => { setSelectedJob(j); setShowJobList(false); setSearchTerm(''); }}>
                          <Text style={styles.jobNumber}>{j.jobNumber}</Text>
                          <Text style={styles.jobCustomer}>{j.customerName || 'Unknown'}</Text>
                        </TouchableOpacity>
                      ))}
                    </ScrollView>
                  </View>
                )}
              </>
            )}

            {!selectedJob && <><Text style={styles.label}>Description</Text><TextInput style={[styles.input, styles.textArea]} placeholder="Enter description" value={description} onChangeText={setDescription} multiline numberOfLines={2} /></>}

            <Text style={styles.label}>Delivery Address *</Text>
            <TextInput style={[styles.input, styles.textArea]} placeholder="Enter address" value={deliveryAddress} onChangeText={setDeliveryAddress} multiline numberOfLines={2} />

            <Text style={styles.label}>Assign Driver</Text>
            <TouchableOpacity style={styles.input} onPress={() => setShowDriverList(!showDriverList)}>
              <Text style={selectedDriver ? styles.selectedValue : styles.placeholderText}>
                {selectedDriver ? selectedDriver.full_name : 'Select Driver (Optional)'}
              </Text>
            </TouchableOpacity>
            {showDriverList && (
              <View style={styles.listBox}>
                <TouchableOpacity style={styles.listItem} onPress={() => { setSelectedDriver(null); setShowDriverList(false); }}>
                  <Text style={styles.listItemText}>None</Text>
                </TouchableOpacity>
                {drivers.map(d => (
                  <TouchableOpacity key={d.id} style={styles.listItem} onPress={() => { setSelectedDriver(d); setShowDriverList(false); }}>
                    <Text style={styles.listItemText}>{d.full_name}</Text>
                  </TouchableOpacity>
                ))}
                {drivers.length === 0 && (
                  <View style={styles.listItem}><Text style={styles.emptyText}>No active drivers found</Text></View>
                )}
              </View>
            )}

            <Text style={styles.label}>Assign Vehicle</Text>
            <TouchableOpacity style={styles.input} onPress={() => setShowVehicleList(!showVehicleList)}>
              <Text style={selectedVehicle ? styles.selectedValue : styles.placeholderText}>
                {selectedVehicle ? `${selectedVehicle.vehicle_number} - ${selectedVehicle.license_plate}` : 'Select Vehicle (Optional)'}
              </Text>
            </TouchableOpacity>
            {showVehicleList && (
              <View style={styles.listBox}>
                <TouchableOpacity style={styles.listItem} onPress={() => { setSelectedVehicle(null); setShowVehicleList(false); }}>
                  <Text style={styles.listItemText}>None</Text>
                </TouchableOpacity>
                {vehicles.map(v => (
                  <TouchableOpacity key={v.id} style={styles.listItem} onPress={() => { setSelectedVehicle(v); setShowVehicleList(false); }}>
                    <Text style={styles.listItemText}>{v.vehicle_number} - {v.license_plate}</Text>
                  </TouchableOpacity>
                ))}
                {vehicles.length === 0 && (
                  <View style={styles.listItem}><Text style={styles.emptyText}>No active vehicles found</Text></View>
                )}
              </View>
            )}


            <Text style={styles.label}>Scheduled Date *</Text>
            <TouchableOpacity style={styles.dateInput} onPress={() => setShowDatePicker(true)}>
              <Text style={styles.dateText}>{formatDate(scheduledDate)}</Text>
              <Ionicons name="calendar-outline" size={20} color="#6b7280" />
            </TouchableOpacity>
            {showDatePicker && <DateTimePicker value={scheduledDate} mode="date" onChange={setScheduledDate} onClose={() => setShowDatePicker(false)} />}

            <View style={styles.buttons}>
              <TouchableOpacity style={styles.cancelButton} onPress={onClose}><Text style={styles.cancelText}>Cancel</Text></TouchableOpacity>
              <TouchableOpacity style={styles.saveButton} onPress={handleSave} disabled={saving}><Text style={styles.saveText}>{saving ? 'Saving...' : 'Save'}</Text></TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: 'white', borderRadius: 12, padding: 20, maxHeight: '90%' },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
  title: { fontSize: 20, fontWeight: 'bold' },
  draftIndicator: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#ECFDF5', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  draftIndicatorText: { fontSize: 11, color: '#059669', fontWeight: '500' },
  draftBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#EFF6FF', padding: 10, borderRadius: 8, marginBottom: 15 },
  draftBannerText: { flex: 1, fontSize: 12, color: '#3B82F6', fontWeight: '500' },
  label: { fontSize: 14, fontWeight: '600', marginBottom: 5, color: '#374151' },
  input: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, padding: 12, marginBottom: 12, fontSize: 16 },
  readOnly: { backgroundColor: '#f9fafb' },
  textArea: { height: 60, textAlignVertical: 'top' },
  tabContainer: { flexDirection: 'row', marginBottom: 12, borderRadius: 8, overflow: 'hidden', borderWidth: 1, borderColor: '#d1d5db' },
  tab: { flex: 1, padding: 10, backgroundColor: '#f9fafb', alignItems: 'center' },
  tabActive: { backgroundColor: '#2563eb' },
  tabText: { fontSize: 13, fontWeight: '600', color: '#6b7280' },
  tabTextActive: { color: 'white' },
  jobList: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, marginBottom: 12, maxHeight: 180 },
  searchInput: { borderBottomWidth: 1, borderBottomColor: '#e5e7eb', padding: 10, fontSize: 14 },
  jobScroll: { maxHeight: 130 },
  jobItem: { padding: 10, borderBottomWidth: 1, borderBottomColor: '#f3f4f6' },
  jobNumber: { fontSize: 14, fontWeight: '600' },
  jobCustomer: { fontSize: 12, color: '#2563eb' },
  listBox: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, marginBottom: 12, maxHeight: 150 },
  listItem: { padding: 12, borderBottomWidth: 1, borderBottomColor: '#f3f4f6' },
  listItemText: { fontSize: 14 },
  emptyText: { fontSize: 14, color: '#9ca3af', fontStyle: 'italic' },
  placeholderText: { color: '#9ca3af' },
  selectedValue: { color: '#1f2937' },
  dateInput: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, padding: 12, marginBottom: 12 },
  dateText: { fontSize: 16, color: '#1f2937' },
  buttons: { flexDirection: 'row', gap: 10, marginTop: 10 },
  cancelButton: { flex: 1, padding: 14, borderRadius: 8, borderWidth: 1, borderColor: '#d1d5db' },
  cancelText: { textAlign: 'center', fontSize: 16, color: '#6b7280' },
  saveButton: { flex: 1, padding: 14, borderRadius: 8, backgroundColor: '#2563eb' },
  saveText: { textAlign: 'center', fontSize: 16, color: 'white', fontWeight: '600' }
});
