import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';

interface QCArchivePreviewProps {
  qcRecords: any[];
  reportDate: string;
}

export const QCArchivePreview: React.FC<QCArchivePreviewProps> = ({ qcRecords, reportDate }) => {
  if (!qcRecords || qcRecords.length === 0) {
    return (
      <View style={s.empty}>
        <Text style={s.emptyText}>No QC records for this date</Text>
      </View>
    );
  }

  return (
    <ScrollView style={s.container}>
      <View style={s.header}>
        <Text style={s.title}>Quality Control Archive</Text>
        <Text style={s.date}>{reportDate}</Text>
      </View>

      {qcRecords.map((record, idx) => (
        <View key={record.id || idx} style={s.card}>
          <View style={s.cardHeader}>
            <Text style={s.jobNum}>Job ID: {record.job_id || 'N/A'}</Text>
            <Text style={s.item}>{record.item_name}</Text>
          </View>
          
          <View style={s.section}>
            <Text style={s.sectionTitle}>Workshop</Text>
            <Text style={s.detail}>Surface: {(record.workshop_surface_condition || []).join(', ') || 'N/A'}</Text>
            <Text style={s.detail}>Drilling: {record.workshop_drilling_done ? 'Yes' : 'No'}</Text>
            <Text style={s.detail}>Welding: {record.workshop_welding_quality || 'N/A'}</Text>
          </View>

          <View style={s.section}>
            <Text style={s.sectionTitle}>Acid Department</Text>
            <Text style={s.detail}>Good Condition: {record.acid_forward_good_condition ? 'Yes' : 'No'}</Text>
            <Text style={s.detail}>Surface: {(record.acid_surface_condition || []).join(', ') || 'N/A'}</Text>
          </View>

          <View style={s.section}>
            <Text style={s.sectionTitle}>Zinc Department</Text>
            <Text style={s.detail}>Good Condition: {record.zinc_forward_good_condition ? 'Yes' : 'No'}</Text>
            <Text style={s.detail}>Coating: {record.zinc_coating_condition || 'N/A'}</Text>
          </View>

          <View style={s.section}>
            <Text style={s.sectionTitle}>Finishing</Text>
            <Text style={s.detail}>Surface: {(record.finishing_surface_condition || []).join(', ') || 'N/A'}</Text>
            <Text style={s.detail}>Coating Thickness: {record.finishing_coating_thickness_microns || 'N/A'} microns</Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
};


const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { padding: 20, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#ddd' },
  title: { fontSize: 20, fontWeight: 'bold', color: '#333' },
  date: { fontSize: 14, color: '#666', marginTop: 4 },
  empty: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  emptyText: { fontSize: 16, color: '#999' },
  card: { backgroundColor: '#fff', margin: 12, padding: 16, borderRadius: 12, borderWidth: 1, borderColor: '#e0e0e0' },
  cardHeader: { marginBottom: 12, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  jobNum: { fontSize: 16, fontWeight: 'bold', color: '#333' },
  item: { fontSize: 14, color: '#666', marginTop: 4 },
  section: { marginTop: 12 },
  sectionTitle: { fontSize: 14, fontWeight: '600', color: '#8B5CF6', marginBottom: 4 },
  detail: { fontSize: 13, color: '#555', marginBottom: 2 },
});
