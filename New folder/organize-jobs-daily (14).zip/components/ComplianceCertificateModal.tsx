import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Modal, ScrollView, TouchableOpacity, Image, TextInput, Alert, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../app/lib/supabase';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { logAction } from '../utils/auditLogger';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ALLOWED_TASK_USERS } from '../contexts/TaskContext';

interface ComplianceCertificateModalProps {
  visible: boolean;
  onClose: () => void;
  jobId: string;
  jobNumber: string;
  customerName: string;
  items: Array<{ descriptionOfWorks: string; weightKg: string; coatingThickness?: string; id: string }>;
}

interface DraftData {
  jobId: string;
  editableJobNumber: string;
  editableCustomerName: string;
  editableReference: string;
  editableItems: string[];
  coatingThickness: string[];
  savedAt: number;
}

const getDraftKey = (jobId: string) => `compliance_certificate_draft_${jobId}`;

export default function ComplianceCertificateModal({
  visible, onClose, jobId, jobNumber, customerName, items
}: ComplianceCertificateModalProps) {
  const { user } = usePasswordAuth();
  const [editableJobNumber, setEditableJobNumber] = useState(jobNumber);
  const [editableCustomerName, setEditableCustomerName] = useState(customerName);
  const [editableReference, setEditableReference] = useState('N/A');
  const [editableItems, setEditableItems] = useState(items.map(item => item.descriptionOfWorks));
  const [coatingThickness, setCoatingThickness] = useState(items.map(item => item.coatingThickness || ''));
  const [galvanizedDates, setGalvanizedDates] = useState<string[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  
  // Draft-related state
  const [showDraftIndicator, setShowDraftIndicator] = useState(false);
  const [hasDraft, setHasDraft] = useState(false);
  const [draftRestoredBanner, setDraftRestoredBanner] = useState(false);
  const initialLoadDone = useRef(false);

  // Check if user is allowed to use draft feature
  const canUseDrafts = ALLOWED_TASK_USERS.includes(user?.username || '');

  // Load draft when modal opens
  useEffect(() => {
    if (visible && canUseDrafts && !initialLoadDone.current) {
      loadDraft();
      initialLoadDone.current = true;
    }
    if (!visible) {
      initialLoadDone.current = false;
    }
  }, [visible, canUseDrafts, jobId]);

  // Auto-save draft when form changes (only when editing)
  useEffect(() => {
    if (visible && canUseDrafts && isEditing && hasFormChanges()) {
      const timeout = setTimeout(() => {
        saveDraft();
      }, 1000); // Debounce 1 second
      return () => clearTimeout(timeout);
    }
  }, [editableJobNumber, editableCustomerName, editableReference, editableItems, coatingThickness, visible, isEditing]);

  const hasFormChanges = () => {
    // Check if any editable field differs from original
    if (editableJobNumber !== jobNumber) return true;
    if (editableCustomerName !== customerName) return true;
    if (editableReference !== 'N/A') return true;
    for (let i = 0; i < items.length; i++) {
      if (editableItems[i] !== items[i].descriptionOfWorks) return true;
      if (coatingThickness[i] !== (items[i].coatingThickness || '')) return true;
    }
    return false;
  };

  const loadDraft = async () => {
    try {
      const draftStr = await AsyncStorage.getItem(getDraftKey(jobId));
      if (draftStr) {
        const draft: DraftData = JSON.parse(draftStr);
        // Only load if draft is less than 24 hours old and matches this job
        if (Date.now() - draft.savedAt < 24 * 60 * 60 * 1000 && draft.jobId === jobId) {
          setEditableJobNumber(draft.editableJobNumber || jobNumber);
          setEditableCustomerName(draft.editableCustomerName || customerName);
          setEditableReference(draft.editableReference || 'N/A');
          if (draft.editableItems && draft.editableItems.length === items.length) {
            setEditableItems(draft.editableItems);
          }
          if (draft.coatingThickness && draft.coatingThickness.length === items.length) {
            setCoatingThickness(draft.coatingThickness);
          }
          setHasDraft(true);
          setDraftRestoredBanner(true);
          // Auto-enable editing mode when draft is restored
          setIsEditing(true);
        } else {
          // Clear old or mismatched draft
          await AsyncStorage.removeItem(getDraftKey(jobId));
        }
      }
    } catch (error) {
      console.error('Error loading compliance draft:', error);
    }
  };

  const saveDraft = async () => {
    try {
      const draft: DraftData = {
        jobId,
        editableJobNumber,
        editableCustomerName,
        editableReference,
        editableItems,
        coatingThickness,
        savedAt: Date.now()
      };
      await AsyncStorage.setItem(getDraftKey(jobId), JSON.stringify(draft));
      setShowDraftIndicator(true);
      setHasDraft(true);
      setTimeout(() => setShowDraftIndicator(false), 2000);
    } catch (error) {
      console.error('Error saving compliance draft:', error);
    }
  };

  const clearDraft = async () => {
    try {
      await AsyncStorage.removeItem(getDraftKey(jobId));
      setHasDraft(false);
      setDraftRestoredBanner(false);
    } catch (error) {
      console.error('Error clearing compliance draft:', error);
    }
  };

  const handleClearDraft = () => {
    Alert.alert(
      'Discard Draft',
      'Are you sure you want to discard your unsaved changes?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Discard', 
          style: 'destructive',
          onPress: async () => {
            await clearDraft();
            // Reset to original values
            setEditableJobNumber(jobNumber);
            setEditableCustomerName(customerName);
            setEditableReference('N/A');
            setEditableItems(items.map(item => item.descriptionOfWorks));
            setCoatingThickness(items.map(item => item.coatingThickness || ''));
            setIsEditing(false);
          }
        }
      ]
    );
  };

  useEffect(() => {
    const fetchGalvanizedDates = async () => {
      const dates = await Promise.all(items.map(async (item) => {
        const { data: finishingData } = await supabase
          .from('finishing_records')
          .select('recorded_date')
          .eq('item_id', item.id)
          .order('recorded_date', { ascending: false })
          .limit(1);
        
        if (finishingData && finishingData.length > 0) {
          return new Date(finishingData[0].recorded_date).toLocaleDateString('en-GB');
        }
        
        const { data: archivedData } = await supabase
          .from('archived_finishing_reports')
          .select('records, report_date')
          .order('report_date', { ascending: false });
        
        if (archivedData && archivedData.length > 0) {
          for (const archive of archivedData) {
            const records = archive.records as any[];
            const matchingRecord = records?.find((r: any) => r.item_id === item.id);
            if (matchingRecord) {
              return new Date(matchingRecord.recorded_date).toLocaleDateString('en-GB');
            }
          }
        }
        return '';
      }));
      setGalvanizedDates(dates);
    };
    
    if (visible) {
      fetchGalvanizedDates();
      // Only reset if no draft is being loaded
      if (!canUseDrafts || !hasDraft) {
        setEditableJobNumber(jobNumber);
        setEditableCustomerName(customerName);
        setEditableItems(items.map(item => item.descriptionOfWorks));
        setCoatingThickness(items.map(item => item.coatingThickness || ''));
      }
    }
  }, [jobNumber, customerName, items, visible]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const updatedItems = items.map((item, index) => ({
        ...item,
        descriptionOfWorks: editableItems[index] || item.descriptionOfWorks,
        coatingThickness: coatingThickness[index] || ''
      }));
      const { error } = await supabase
        .from('jobs')
        .update({ jobNumber: editableJobNumber, customerName: editableCustomerName, items: updatedItems })
        .eq('id', jobId);
      if (error) throw error;
      
      // Clear draft on successful save
      await clearDraft();
      
      Alert.alert('Success', 'Certificate saved successfully');
      setIsEditing(false);
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  const currentDate = new Date().toLocaleDateString('en-GB');

  const handleDownload = async () => {
    try {
      if (user) {
        await logAction({
          userId: user.id, username: user.username, actionType: 'COMPLIANCE_DOWNLOADED',
          actionDescription: `Downloaded compliance certificate for job ${editableJobNumber}`,
          entityType: 'job', entityId: jobId,
          metadata: { jobNumber: editableJobNumber, customerName: editableCustomerName }
        });
      }

      const itemsList = editableItems.map((item, i) => `
        <tr>
          <td style="padding: 8px; border: 1px solid #ddd;">${i + 1}</td>
          <td style="padding: 8px; border: 1px solid #ddd;">${item}</td>
          <td style="padding: 8px; border: 1px solid #ddd;">${coatingThickness[i] || '-'}</td>
          <td style="padding: 8px; border: 1px solid #ddd;">${galvanizedDates[i] || '-'}</td>
        </tr>
      `).join('');

      const html = `<!DOCTYPE html><html><head><meta charset="UTF-8">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: Arial, sans-serif; padding: 30px; background: white; }
  .cert { border: 3px solid #000; padding: 30px; max-width: 800px; margin: 0 auto; }
  .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 15px; margin-bottom: 20px; }
  .logo { font-size: 28px; font-weight: bold; }
  h1 { text-align: center; font-size: 16px; margin: 20px 0; text-decoration: underline; }
  .body-text { font-size: 13px; text-align: center; margin: 10px 0; }
  .customer { font-size: 18px; font-weight: bold; text-align: center; margin: 15px 0; }
  .details { margin: 20px 0; }
  .details p { font-size: 12px; margin: 5px 0; }
  table { width: 100%; border-collapse: collapse; margin: 15px 0; font-size: 11px; }
  th { background: #f5f5f5; padding: 8px; border: 1px solid #ddd; text-align: left; }
  .note { font-size: 10px; color: #666; font-style: italic; margin: 20px 0 10px 0; }
  .equipment { font-size: 11px; margin: 8px 0; }
  .date-line { font-size: 12px; font-weight: bold; margin: 15px 0; }
  .footer { text-align: center; margin: 20px 0; }
  .footer p { font-weight: bold; font-size: 11px; margin: 3px 0; }
  .address { font-size: 10px; color: #666; text-align: center; margin-top: 15px; }
</style></head><body>
<div class="cert">
  <div class="header"><div class="logo">GALVABOND LTD</div></div>
  <h1>TO WHOM IT MAY CONCERN</h1>
  <p class="body-text">This is to certify that the below mentioned items were hot dip galvanized for</p>
  <p class="customer">${editableCustomerName}</p>
  <p class="body-text">and comply to MS ISO 1461 Standards</p>
  <div class="details">
    <p><strong>Job No:</strong> ${editableJobNumber}</p>
    <p><strong>Reference:</strong> ${editableReference}</p>
  </div>
  <table>
    <thead><tr><th>#</th><th>Item Description</th><th>Coating Thickness</th><th>Date Galvanized</th></tr></thead>
    <tbody>${itemsList}</tbody>
  </table>
  <p class="note">This document is electronically generated and does not require any signature</p>
  <p class="equipment">Testing equipment: Elcometer MTG Ultrasonic Material Thickness Gauge</p>
  <p class="date-line">Date: ${currentDate}</p>
  <div class="footer"><p>HIGH QUALITY</p><p>ON TIME</p><p>EVERY TIME</p></div>
  <p class="address">La Tour Koenig Industrial Zone Port Louis, Mauritius<br>www.galvabondltd.com</p>
</div></body></html>`;

      if (Platform.OS === 'web') {
        await Print.printAsync({ html });
        Alert.alert('Success', 'Certificate ready for printing');
      } else {
        const result = await Print.printToFileAsync({ html, base64: false });
        if (!result || !result.uri) {
          throw new Error('Failed to generate PDF file');
        }
        const isAvailable = await Sharing.isAvailableAsync();
        if (!isAvailable) {
          Alert.alert('Error', 'Sharing is not available on this device');
          return;
        }
        await Sharing.shareAsync(result.uri, {
          mimeType: 'application/pdf',
          dialogTitle: `Compliance_Certificate_${editableJobNumber}.pdf`,
          UTI: 'com.adobe.pdf'
        });
        Alert.alert('Success', 'Certificate downloaded');
      }
    } catch (err: any) {
      console.error('Download error:', err);
      Alert.alert('Error', err.message || 'Failed to download certificate');
    }
  };

  const updateItem = (index: number, value: string) => {
    const newItems = [...editableItems];
    newItems[index] = value;
    setEditableItems(newItems);
  };

  const updateCoatingThickness = (index: number, value: string) => {
    const newThickness = [...coatingThickness];
    newThickness[index] = value;
    setCoatingThickness(newThickness);
  };

  const handleClose = () => {
    // Don't clear draft on close - keep it for later
    setDraftRestoredBanner(false);
    onClose();
  };



  return (
    <Modal visible={visible} animationType="slide" onRequestClose={handleClose}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Compliance Certificate</Text>
          <View style={styles.headerActions}>
            {canUseDrafts && showDraftIndicator && (
              <View style={styles.draftIndicator}>
                <Ionicons name="cloud-done" size={14} color="#10B981" />
                <Text style={styles.draftIndicatorText}>Saved</Text>
              </View>
            )}
            {isEditing ? (
              <TouchableOpacity onPress={handleSave} style={styles.saveBtn} disabled={saving}>
                <Ionicons name="checkmark" size={24} color="#10B981" />
              </TouchableOpacity>
            ) : (
              <>
                <TouchableOpacity onPress={handleDownload} style={styles.downloadBtn}>
                  <Ionicons name="download" size={24} color="#8B5CF6" />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => setIsEditing(true)} style={styles.editBtn}>
                  <Ionicons name="pencil" size={24} color="#3B82F6" />
                </TouchableOpacity>
              </>
            )}
            <TouchableOpacity onPress={handleClose}>
              <Ionicons name="close" size={28} color="#374151" />
            </TouchableOpacity>
          </View>
        </View>

        {canUseDrafts && draftRestoredBanner && (
          <TouchableOpacity style={styles.draftBanner} onPress={handleClearDraft}>
            <Ionicons name="document-text-outline" size={16} color="#F59E0B" />
            <Text style={styles.draftBannerText}>Unsaved changes restored - tap to discard</Text>
            <Ionicons name="close-circle" size={18} color="#6B7280" />
          </TouchableOpacity>
        )}

        <ScrollView style={styles.content}>
          <View style={styles.certificate}>
            <View style={styles.companyHeader}>
              <Image 
                source={{ uri: 'https://d64gsuwffb70l.cloudfront.net/6826def9056908ac6c0eb35d_1761130497603_97cac741.jpg' }}
                style={styles.logo}
                resizeMode="contain"
              />
            </View>



            <Text style={styles.heading}>TO WHOM IT MAY CONCERN</Text>
            <Text style={styles.body}>This is to certify that the below mentioned items were hot dip galvanized for</Text>

            {isEditing ? (
              <TextInput style={[styles.customerName, styles.input]} value={editableCustomerName} onChangeText={setEditableCustomerName} />
            ) : (
              <Text style={styles.customerName}>{editableCustomerName}</Text>
            )}

            <Text style={styles.body}>and comply to MS ISO 1461 Standards</Text>

            <View style={styles.detailsSection}>
              {isEditing ? (
                <>
                  <TextInput style={[styles.detailText, styles.input]} value={`Job No: ${editableJobNumber}`} onChangeText={(text) => setEditableJobNumber(text.replace('Job No: ', ''))} />
                  <TextInput style={[styles.detailText, styles.input]} value={`Reference: ${editableReference}`} onChangeText={(text) => setEditableReference(text.replace('Reference: ', ''))} />
                </>
              ) : (
                <>
                  <Text style={styles.detailText}>Job No: {editableJobNumber}</Text>
                  <Text style={styles.detailText}>Reference: {editableReference}</Text>
                </>
              )}
            </View>

            <Text style={styles.itemsHeading}>Item Description:</Text>
            {editableItems.map((item, index) => (
              <View key={index} style={styles.itemContainer}>
                {isEditing ? (
                  <>
                    <TextInput 
                      style={[styles.itemText, styles.input]} 
                      value={`${index + 1}. ${item}`} 
                      onChangeText={(text) => updateItem(index, text.replace(`${index + 1}. `, ''))} 
                      multiline 
                    />
                    <TextInput 
                      style={[styles.coatingInput, styles.input]} 
                      value={coatingThickness[index]} 
                      onChangeText={(text) => updateCoatingThickness(index, text)}
                      placeholder="Average Coating Thickness (e.g., 85 microns)"
                      placeholderTextColor="#9CA3AF"
                    />
                  </>
                ) : (
                  <>
                    <Text style={styles.itemText}>{index + 1}. {item}</Text>
                    {coatingThickness[index] ? (
                      <Text style={styles.coatingText}>Average Coating Thickness: {coatingThickness[index]}</Text>
                    ) : null}
                    {galvanizedDates[index] ? (
                      <Text style={styles.coatingText}>Date Galvanized: {galvanizedDates[index]}</Text>
                    ) : null}
                  </>
                )}
              </View>
             ))}

            <Text style={styles.electronicDoc}>This document is electronically generated and does not require any signature</Text>
            <Text style={styles.testingEquipment}>Testing equipment: Elcometer MTG Ultrasonic Material Thickness Gauge</Text>
            <Text style={styles.dateSection}>Date: {currentDate}</Text>


            <View style={styles.footer}>
              <Text style={styles.footerTagline}>HIGH QUALITY</Text>
              <Text style={styles.footerTagline}>ON TIME</Text>
              <Text style={styles.footerTagline}>EVERY TIME</Text>
            </View>

            <Text style={styles.address}>La Tour Koenig Industrial Zone Port Louis{'\n'}Mauritius{'\n'}www.galvabondltd.com</Text>
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
}


const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: '#1F2937' },
  headerActions: { flexDirection: 'row', gap: 16, alignItems: 'center' },
  editBtn: { padding: 4 },
  saveBtn: { padding: 4 },
  downloadBtn: { padding: 4 },
  draftIndicator: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#ECFDF5', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  draftIndicatorText: { fontSize: 11, color: '#059669', fontWeight: '500' },
  draftBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#FEF3C7', padding: 12, marginHorizontal: 16, marginTop: 12, borderRadius: 8, borderWidth: 1, borderColor: '#FCD34D' },
  draftBannerText: { flex: 1, fontSize: 12, color: '#92400E', fontWeight: '500' },
  content: { flex: 1, padding: 16 },
  certificate: { backgroundColor: 'white', padding: 24, borderRadius: 8, borderWidth: 2, borderColor: '#000' },
  companyHeader: { alignItems: 'center', justifyContent: 'center', marginBottom: 24, paddingBottom: 16, borderBottomWidth: 2, borderBottomColor: '#000' },
  logo: { width: 250, height: 80 },
  headerDate: { fontSize: 12, fontWeight: 'bold', color: '#000', marginTop: 8 },
  heading: { fontSize: 16, fontWeight: 'bold', textAlign: 'center', marginVertical: 20, textDecorationLine: 'underline' },
  body: { fontSize: 12, textAlign: 'center', marginVertical: 8 },
  customerName: { fontSize: 16, fontWeight: 'bold', textAlign: 'center', marginVertical: 12 },
  detailsSection: { marginVertical: 16 },
  detailText: { fontSize: 11, marginVertical: 2 },
  itemsHeading: { fontSize: 12, fontWeight: 'bold', marginTop: 16, marginBottom: 8 },
  itemContainer: { marginBottom: 12 },
  itemText: { fontSize: 11, marginVertical: 3 },
  coatingInput: { fontSize: 10, marginTop: 4, marginLeft: 16 },
  coatingText: { fontSize: 10, marginTop: 2, marginLeft: 16, color: '#6B7280', fontStyle: 'italic' },
  electronicDoc: { fontSize: 11, marginTop: 30, marginBottom: 8, textAlign: 'left', fontStyle: 'italic', color: '#6B7280' },
  testingEquipment: { fontSize: 11, marginBottom: 10, textAlign: 'left', color: '#000' },
  dateSection: { fontSize: 12, marginBottom: 20, textAlign: 'left', fontWeight: 'bold', color: '#000' },
  footer: { alignItems: 'center', marginVertical: 16 },
  footerTagline: { fontSize: 12, fontWeight: 'bold', color: '#000' },
  address: { fontSize: 10, textAlign: 'center', color: '#666', marginTop: 12 },
  input: { borderWidth: 1, borderColor: '#3B82F6', backgroundColor: '#EFF6FF', padding: 4, borderRadius: 4 }

});
