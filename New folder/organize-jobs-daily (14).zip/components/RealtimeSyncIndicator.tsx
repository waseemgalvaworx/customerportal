import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { useRealtime } from '@/contexts/RealtimeContext';

export const RealtimeSyncIndicator: React.FC = () => {
  const { isConnected, lastUpdate } = useRealtime();
  const [showUpdate, setShowUpdate] = useState(false);
  const fadeAnim = useState(new Animated.Value(0))[0];

  useEffect(() => {
    if (lastUpdate) {
      setShowUpdate(true);
      Animated.sequence([
        Animated.timing(fadeAnim, { toValue: 1, duration: 300, useNativeDriver: true }),
        Animated.delay(2000),
        Animated.timing(fadeAnim, { toValue: 0, duration: 300, useNativeDriver: true })
      ]).start(() => setShowUpdate(false));
    }
  }, [lastUpdate]);

  return (
    <View style={styles.container}>
      <View style={[styles.dot, isConnected ? styles.connected : styles.disconnected]} />
      {showUpdate && (
        <Animated.View style={[styles.updateBadge, { opacity: fadeAnim }]}>
          <Text style={styles.updateText}>Synced</Text>
        </Animated.View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flexDirection: 'row', alignItems: 'center', marginRight: 10 },
  dot: { width: 8, height: 8, borderRadius: 4, marginRight: 6 },
  connected: { backgroundColor: '#10b981' },
  disconnected: { backgroundColor: '#ef4444' },
  updateBadge: { backgroundColor: '#10b981', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  updateText: { color: '#fff', fontSize: 11, fontWeight: '600' }
});
