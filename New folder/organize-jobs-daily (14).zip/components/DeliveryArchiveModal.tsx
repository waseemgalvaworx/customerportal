import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TouchableOpacity, StyleSheet, ScrollView, Alert } from 'react-native';
import { supabase } from '../app/lib/supabase';

interface DeliveryArchiveModalProps {
  visible: boolean;
  onClose: () => void;
}

export default function DeliveryArchiveModal({ visible, onClose }: DeliveryArchiveModalProps) {
  const [archivedDeliveries, setArchivedDeliveries] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (visible) {
      loadArchive();
    }
  }, [visible]);

  const loadArchive = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('logistics_deliveries')
      .select('*')
      .eq('status', 'completed')
      .order('completed_at', { ascending: false });
    setArchivedDeliveries(data || []);
    setLoading(false);
  };

  const handleRestore = async (id: string) => {
    Alert.alert('Restore Delivery', 'Restore this delivery to active list?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Restore',
        onPress: async () => {
          const { error } = await supabase
            .from('logistics_deliveries')
            .update({ status: 'scheduled', completed_at: null })
            .eq('id', id);
          if (!error) {
            Alert.alert('Success', 'Delivery restored');
            loadArchive();
          }
        }
      }
    ]);
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <Text style={styles.title}>Delivery Archive</Text>
          
          <ScrollView style={styles.list}>
            {loading ? (
              <Text style={styles.loading}>Loading...</Text>
            ) : archivedDeliveries.length === 0 ? (
              <Text style={styles.empty}>No archived deliveries</Text>
            ) : (
              archivedDeliveries.map(d => (
                <View key={d.id} style={styles.card}>
                  <Text style={styles.cardTitle}>{d.delivery_number}</Text>
                  <Text style={styles.cardText}>Address: {d.delivery_address}</Text>
                  <Text style={styles.cardText}>Completed: {new Date(d.completed_at).toLocaleDateString()}</Text>
                  <TouchableOpacity style={styles.restoreBtn} onPress={() => handleRestore(d.id)}>
                    <Text style={styles.restoreText}>Restore</Text>
                  </TouchableOpacity>
                </View>
              ))
            )}
          </ScrollView>

          <TouchableOpacity style={styles.closeButton} onPress={onClose}>
            <Text style={styles.closeText}>Close</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: 'white', borderRadius: 12, padding: 20, maxHeight: '80%' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 20 },
  list: { marginBottom: 15 },
  loading: { textAlign: 'center', color: '#6b7280', padding: 20 },
  empty: { textAlign: 'center', color: '#6b7280', padding: 20 },
  card: { backgroundColor: '#f9fafb', padding: 15, borderRadius: 8, marginBottom: 10 },
  cardTitle: { fontSize: 16, fontWeight: 'bold', marginBottom: 5 },
  cardText: { fontSize: 14, color: '#6b7280', marginBottom: 3 },
  restoreBtn: { marginTop: 10, padding: 10, backgroundColor: '#2563eb', borderRadius: 6 },
  restoreText: { color: 'white', textAlign: 'center', fontWeight: '600' },
  closeButton: { padding: 15, borderRadius: 8, backgroundColor: '#6b7280' },
  closeText: { textAlign: 'center', fontSize: 16, color: 'white', fontWeight: '600' }
});
