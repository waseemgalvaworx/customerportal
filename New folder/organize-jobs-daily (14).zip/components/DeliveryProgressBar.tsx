import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

interface DeliveryProgressBarProps {
  status: string;
}

export default function DeliveryProgressBar({ status }: DeliveryProgressBarProps) {
  const stages = ['scheduled', 'in_transit', 'completed'];
  const currentIndex = stages.indexOf(status);

  return (
    <View style={styles.container}>
      {stages.map((stage, index) => {
        const isActive = index <= currentIndex;
        const isLast = index === stages.length - 1;
        
        return (
          <View key={stage} style={styles.stageContainer}>
            <View style={styles.stageContent}>
              <View style={[styles.dot, isActive && styles.dotActive]} />
              <Text style={[styles.stageText, isActive && styles.stageTextActive]}>
                {stage.replace('_', ' ')}
              </Text>
            </View>
            {!isLast && <View style={[styles.line, isActive && styles.lineActive]} />}
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flexDirection: 'row', alignItems: 'center', marginVertical: 12 },
  stageContainer: { flex: 1, flexDirection: 'row', alignItems: 'center' },
  stageContent: { alignItems: 'center' },
  dot: { width: 12, height: 12, borderRadius: 6, backgroundColor: '#e5e7eb', borderWidth: 2, borderColor: '#d1d5db' },
  dotActive: { backgroundColor: '#3b82f6', borderColor: '#2563eb' },
  line: { flex: 1, height: 2, backgroundColor: '#e5e7eb', marginHorizontal: 4 },
  lineActive: { backgroundColor: '#3b82f6' },
  stageText: { fontSize: 9, color: '#9ca3af', marginTop: 4, textTransform: 'capitalize' },
  stageTextActive: { color: '#2563eb', fontWeight: '600' }
});
