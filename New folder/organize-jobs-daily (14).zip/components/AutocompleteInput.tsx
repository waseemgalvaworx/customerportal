import React, { useState, useEffect } from 'react';
import { View, TextInput, FlatList, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { supabase } from '@/app/lib/supabase';

const PREDEFINED_ITEMS = [
  'Large sliding door', 'Large frame/fix', 'Medium sliding door', 'Medium door/ frame fix',
  'Small door/ frame fix', 'Frame', 'Frame grating', 'Gratings', 'Flat bar', 'Round bar',
  'Square bar', 'Tube', 'Angle bar', 'Pipe', 'Channel', 'I-beam', 'Handrails', 'Metal shoes',
  'Metal plate', 'Expanded metal', 'Metal sheet', 'Columns', 'Deco reels', 'Deco lys',
  'Deco fbar', 'Deco leaves', 'Cleats', 'Plate', 'Round plate', 'Hinge- hinge pin',
  'Lock- door lock', 'Burglar BNS', 'Vents', 'Rails', 'Tee bar', 'Washer', 'Welded mesh',
  'Wired mesh', 'Bracings', 'Guide', 'Gutter', 'Wall barriers', 'Ring', 'Flange', 'Ladder',
  'Mortise lock', 'Steps', 'Platform', 'Staircase', 'Bracket', 'Cable tray', 'Caster wheels',
  'Support caster wheels', 'Triangular', 'Perforated', 'Anchor', 'Chain', 'Threaded rod',
  'Hook', 'Chequered plate', 'Spacer', 'Hollow section', 'Door stopper', 'Rafter',
  'Fish cage/ accessories', 'Saddle'
];

interface Props {
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  field: 'descriptionOfWorks' | 'customerName';
  style?: any;
}


export default function AutocompleteInput({ value, onChangeText, placeholder, field, style }: Props) {
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  useEffect(() => {
    if (value.length >= 1) {
      fetchSuggestions(value);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [value]);

  const fetchSuggestions = async (query: string) => {
    if (field === 'descriptionOfWorks') {
      const filtered = PREDEFINED_ITEMS.filter(item =>
        item.toLowerCase().startsWith(query.toLowerCase())
      );
      setSuggestions(filtered.slice(0, 8));
      setShowSuggestions(filtered.length > 0);

    } else if (field === 'customerName') {
      const { data } = await supabase
        .from('jobs')
        .select('customerName')
        .ilike('customerName', `%${query}%`)
        .limit(5);
      if (data) {
        const uniqueCustomers = [...new Set(data.map(j => j.customerName))];
        setSuggestions(uniqueCustomers);
        setShowSuggestions(true);
      }
    }
  };

  const handleSelect = (suggestion: string) => {
    onChangeText(suggestion);
    setShowSuggestions(false);
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={[styles.input, style]}
        placeholder={placeholder}
        value={value}
        onChangeText={onChangeText}
        onFocus={() => value.length >= 1 && suggestions.length > 0 && setShowSuggestions(true)}
      />
      {showSuggestions && suggestions.length > 0 && (
        <View style={styles.suggestionsContainer}>
          <FlatList
            data={suggestions}
            keyExtractor={(item, index) => `${item}-${index}`}
            renderItem={({ item }) => (
              <TouchableOpacity 
                style={styles.suggestionItem}
                onPress={() => handleSelect(item)}
              >
                <Text style={styles.suggestionText}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { position: 'relative', marginBottom: 16 },
  input: { borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, padding: 12, fontSize: 16, backgroundColor: '#F9FAFB' },
  suggestionsContainer: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, marginTop: -8, maxHeight: 200, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  suggestionItem: { padding: 12, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  suggestionText: { fontSize: 15, color: '#374151' }
});
