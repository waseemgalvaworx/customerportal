import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { dieselHeightToVolume } from '../utils/dieselConversion';

interface DieselInventoryCardProps {
  height: number;
  lastUpdated: string | null;
  lowStockThreshold?: number;
}

export const DieselInventoryCard: React.FC<DieselInventoryCardProps> = ({
  height,
  lastUpdated,
  lowStockThreshold = 500
}) => {
  const volume = dieselHeightToVolume(height);
  const isLowStock = volume < lowStockThreshold;
  
  const needsUpdate = (): boolean => {
    if (!lastUpdated) return true;
    const today = new Date();
    if (today.getDay() === 0) return false; // Sunday
    
    const lastUpdate = new Date(lastUpdated);
    const diffDays = Math.floor((today.getTime() - lastUpdate.getTime()) / (1000 * 60 * 60 * 24));
    return diffDays >= 1;
  };

  const showUpdateReminder = needsUpdate();

  return (
    <View style={styles.container}>
      <View style={styles.mainDisplay}>
        <Text style={styles.volumeLabel}>Current Volume</Text>
        <Text style={styles.volumeValue}>{volume.toLocaleString()} L</Text>
        <Text style={styles.heightValue}>Height: {height} cm</Text>
      </View>

      {isLowStock && (
        <View style={styles.warningBox}>
          <Text style={styles.warningText}>⚠️ LOW STOCK WARNING</Text>
          <Text style={styles.warningSubtext}>Volume below {lowStockThreshold}L</Text>
        </View>
      )}

      {showUpdateReminder && (
        <View style={styles.reminderBox}>
          <Text style={styles.reminderText}>📝 Update Reminder</Text>
          <Text style={styles.reminderSubtext}>No recording today</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { backgroundColor: '#f0f9ff', padding: 16, borderRadius: 12, marginVertical: 8 },
  mainDisplay: { alignItems: 'center', marginBottom: 12 },
  volumeLabel: { fontSize: 14, color: '#64748b', marginBottom: 4 },
  volumeValue: { fontSize: 36, fontWeight: 'bold', color: '#0f172a' },
  heightValue: { fontSize: 14, color: '#64748b', marginTop: 4 },
  warningBox: { backgroundColor: '#fef2f2', padding: 12, borderRadius: 8, borderLeftWidth: 4, borderLeftColor: '#ef4444', marginBottom: 8 },
  warningText: { fontSize: 14, fontWeight: 'bold', color: '#dc2626' },
  warningSubtext: { fontSize: 12, color: '#991b1b', marginTop: 2 },
  reminderBox: { backgroundColor: '#fffbeb', padding: 12, borderRadius: 8, borderLeftWidth: 4, borderLeftColor: '#f59e0b' },
  reminderText: { fontSize: 14, fontWeight: 'bold', color: '#d97706' },
  reminderSubtext: { fontSize: 12, color: '#92400e', marginTop: 2 }
});
