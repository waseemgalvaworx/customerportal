import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TouchableOpacity, Switch, StyleSheet, ScrollView, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '@/app/lib/supabase';

interface NotificationPermissionsModalProps {
  visible: boolean;
  userId: string;
  username: string;
  onClose: () => void;
}

const NOTIFICATION_TYPES = [
  { key: 'job_created', label: 'Job Created', desc: 'New job notifications' },
  { key: 'job_updated', label: 'Job Updated', desc: 'Job status changes' },
  { key: 'job_completed', label: 'Job Completed', desc: 'Job completion alerts' },
  { key: 'job_archived', label: 'Job Archived', desc: 'Archive notifications' },
  { key: 'messages', label: 'Messages', desc: 'Direct messages' },
  { key: 'stock_request_created', label: 'Stock Request Created', desc: 'New stock requests' },
  { key: 'stock_request_approved', label: 'Stock Request Approved', desc: 'Approved requests' },
  { key: 'stock_request_acknowledged', label: 'Stock Request Acknowledged', desc: 'Acknowledged requests' },
  { key: 'inventory_stock_movements', label: 'Stock Movements', desc: 'Stock in/out operations' },
  { key: 'inventory_low_stock', label: 'Low Stock Alerts', desc: 'Low stock warnings' },
  { key: 'inventory_new_items', label: 'New Items', desc: 'New inventory items' },
  { key: 'inventory_diesel', label: 'Diesel Operations', desc: 'Diesel refills and consumption' },
  { key: 'daily_report', label: 'Daily Reports', desc: 'Daily summary emails' },
  { key: 'system_alerts', label: 'System Alerts', desc: 'Critical system messages' }
];


export default function NotificationPermissionsModal({ visible, userId, username, onClose }: NotificationPermissionsModalProps) {
  const [permissions, setPermissions] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (visible && userId) {
      loadPermissions();
    }
  }, [visible, userId]);

  const loadPermissions = async () => {
    const { data, error } = await supabase
      .from('profiles')
      .select('notification_permissions')
      .eq('id', userId)
      .single();

    if (error) {
      console.error('Error loading permissions:', error);
      return;
    }

    setPermissions(data?.notification_permissions || {});
  };

  const handleToggle = (key: string) => {
    setPermissions(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ notification_permissions: permissions })
        .eq('id', userId);

      if (error) throw error;
      Alert.alert('Success', 'Notification permissions updated');
      onClose();
    } catch (error: any) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <View style={styles.header}>
            <Text style={styles.title}>Notification Permissions</Text>
            <TouchableOpacity onPress={onClose}>
              <Ionicons name="close" size={28} color="#333" />
            </TouchableOpacity>
          </View>
          <Text style={styles.subtitle}>{username}</Text>

          <ScrollView style={styles.content}>
            {NOTIFICATION_TYPES.map(type => (
              <View key={type.key} style={styles.item}>
                <View style={styles.itemInfo}>
                  <Text style={styles.itemLabel}>{type.label}</Text>
                  <Text style={styles.itemDesc}>{type.desc}</Text>
                </View>
                <Switch
                  value={permissions[type.key] || false}
                  onValueChange={() => handleToggle(type.key)}
                  trackColor={{ false: '#ccc', true: '#4CAF50' }}
                />
              </View>
            ))}
          </ScrollView>

          <View style={styles.buttons}>
            <TouchableOpacity style={[styles.button, styles.cancelButton]} onPress={onClose}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.button, styles.saveButton]} onPress={handleSave} disabled={loading}>
              <Text style={styles.saveText}>{loading ? 'Saving...' : 'Save'}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: '#fff', borderRadius: 12, maxHeight: '80%' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, borderBottomWidth: 1, borderBottomColor: '#eee' },
  title: { fontSize: 20, fontWeight: 'bold', color: '#333' },
  subtitle: { fontSize: 16, color: '#666', paddingHorizontal: 20, paddingTop: 12 },
  content: { padding: 20 },
  item: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  itemInfo: { flex: 1 },
  itemLabel: { fontSize: 16, fontWeight: '500', color: '#333', marginBottom: 4 },
  itemDesc: { fontSize: 14, color: '#666' },
  buttons: { flexDirection: 'row', gap: 10, padding: 20, borderTopWidth: 1, borderTopColor: '#eee' },
  button: { flex: 1, padding: 14, borderRadius: 8, alignItems: 'center' },
  cancelButton: { backgroundColor: '#f5f5f5' },
  saveButton: { backgroundColor: '#007AFF' },
  cancelText: { color: '#333', fontWeight: '600' },
  saveText: { color: '#fff', fontWeight: '600' }
});
