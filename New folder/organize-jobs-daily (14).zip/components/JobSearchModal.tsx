import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TouchableOpacity, TextInput, ScrollView, StyleSheet, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../app/lib/supabase';
import JobDetailsViewModal from './JobDetailsViewModal';

interface JobSearchModalProps {
  visible: boolean;
  onClose: () => void;
}

export default function JobSearchModal({ visible, onClose }: JobSearchModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searching, setSearching] = useState(false);
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [detailsModalVisible, setDetailsModalVisible] = useState(false);


  useEffect(() => {
    if (searchQuery) {
      const timer = setTimeout(() => searchJobs(searchQuery), 500);
      return () => clearTimeout(timer);
    } else {
      setSearchResults([]);
    }
  }, [searchQuery]);

  const searchJobs = async (query: string) => {
    setSearching(true);
    try {
      const { data, error } = await supabase.from('jobs').select('*').or(`jobNumber.ilike.%${query}%,customerName.ilike.%${query}%`).order('createdAt', { ascending: false });
      if (error) throw error;
      setSearchResults(data || []);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setSearching(false);
    }
  };


  const handleJobClick = (jobId: string) => {
    setSelectedJobId(jobId);
    setDetailsModalVisible(true);
  };

  const getStatusColor = (status: string) => {
    const colors: any = {
      pending: '#F59E0B', planning: '#6366F1', galva: '#8B5CF6',
      wip: '#3B82F6', done: '#10B981', archived: '#6B7280'
    };
    return colors[status] || '#9CA3AF';
  };


  return (
    <Modal visible={visible} animationType="slide" transparent={false}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>🔍 Search All Jobs</Text>
          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <Ionicons name="close" size={28} color="#1F2937" />
          </TouchableOpacity>
        </View>

        <View style={styles.searchBar}>
          <Ionicons name="search" size={20} color="#6B7280" />
          <TextInput style={styles.searchInput} placeholder="Search by job number or customer..." value={searchQuery} onChangeText={setSearchQuery} autoFocus />
          {searching && <ActivityIndicator size="small" color="#6366F1" />}
        </View>
        <ScrollView style={styles.resultsScroll} contentContainerStyle={styles.resultsContent}>
          {searchResults.length > 0 ? (
            searchResults.map(job => (
              <TouchableOpacity key={job.id} style={styles.jobTile} onPress={() => handleJobClick(job.id)}>
                <View style={styles.jobHeader}>
                  <Text style={styles.jobNumber}>Job #{job.jobNumber}</Text>
                  <View style={[styles.statusBadge, { backgroundColor: getStatusColor(job.status) }]}>
                    <Text style={styles.statusText}>{job.status}</Text>
                  </View>
                </View>
                <Text style={styles.customer}>Customer: {job.customerName}</Text>
                {job.notes && <Text style={styles.notes}>Notes: {job.notes}</Text>}
              </TouchableOpacity>
            ))
          ) : searchQuery ? (
            <Text style={styles.noResults}>No jobs found</Text>
          ) : (
            <Text style={styles.noResults}>Enter search term to find jobs</Text>
          )}
        </ScrollView>

        <JobDetailsViewModal
          visible={detailsModalVisible}
          onClose={() => setDetailsModalVisible(false)}
          jobId={selectedJobId}
        />
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6', paddingTop: 50 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  title: { fontSize: 22, fontWeight: 'bold', color: '#1F2937' },
  closeButton: { padding: 4 },
  searchBar: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', margin: 16, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 12, gap: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  searchInput: { flex: 1, fontSize: 16, color: '#1F2937' },
  resultsScroll: { flex: 1 },
  resultsContent: { padding: 16, gap: 12 },
  jobTile: { backgroundColor: '#fff', padding: 16, borderRadius: 12, borderLeftWidth: 4, borderLeftColor: '#6366F1', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 4, elevation: 2 },
  jobHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  jobNumber: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  statusText: { fontSize: 12, fontWeight: '600', color: '#fff', textTransform: 'uppercase' },
  customer: { fontSize: 16, fontWeight: '600', color: '#374151', marginBottom: 6 },
  detail: { fontSize: 14, color: '#4B5563', marginTop: 4 },
  notes: { fontSize: 13, color: '#6B7280', marginTop: 6, fontStyle: 'italic' },
  editButton: { padding: 6, backgroundColor: '#EEF2FF', borderRadius: 8 },
  noResults: { fontSize: 16, color: '#9CA3AF', textAlign: 'center', marginTop: 40 },
  editTitle: { fontSize: 18, fontWeight: 'bold', color: '#6366F1', marginBottom: 16 },
  label: { fontSize: 14, fontWeight: '600', color: '#374151', marginTop: 12, marginBottom: 6 },
  input: { backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, padding: 12, fontSize: 15, color: '#1F2937' },
  statusPicker: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8 },
  statusOption: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#D1D5DB' },
  statusOptionSelected: { backgroundColor: '#6366F1', borderColor: '#6366F1' },
  statusOptionText: { fontSize: 12, fontWeight: '600', color: '#6B7280' },
  statusOptionTextSelected: { color: '#fff' },
  editActions: { flexDirection: 'row', gap: 12, marginTop: 16 },
  cancelButton: { flex: 1, padding: 14, borderRadius: 10, backgroundColor: '#F3F4F6', alignItems: 'center' },
  cancelButtonText: { fontSize: 16, fontWeight: '600', color: '#6B7280' },
  saveButton: { flex: 1, padding: 14, borderRadius: 10, backgroundColor: '#6366F1', alignItems: 'center' },
  saveButtonText: { fontSize: 16, fontWeight: '600', color: '#fff' },
});
