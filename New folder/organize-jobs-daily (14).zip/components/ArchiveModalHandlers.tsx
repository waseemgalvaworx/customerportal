import { Alert } from 'react-native';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { generateFinishingHTML } from '../utils/finishingExport';
import { generateDailyProductionHTML } from '../utils/dailyProductionExport';
import { generateCompletedItemsHTML, generateDeliveredItemsHTML } from '../utils/completedItemsExport';
import { supabase } from '../app/lib/supabase';
import { Job } from '../contexts/JobContext';

export const handleViewPDF = async (
  selectedReportType: 'completed' | 'finishing' | 'delivered' | null,
  selectedData: any,
  selectedDate?: string | null,
  includeTime: boolean = true
) => {
  if (!selectedReportType || !selectedData) return;
  try {
    let html: string;
    let title: string;
    if (selectedReportType === 'finishing') {
      if (!selectedData.records || selectedData.records.length === 0) {
        Alert.alert('No Data', 'No finishing records available');
        return;
      }
      const jobsFromRecords = convertFinishingRecordsToJobs(selectedData.records);
      html = generateFinishingHTML(jobsFromRecords, selectedDate || undefined, includeTime);
      title = 'Finishing Report';
    } else if (selectedReportType === 'delivered') {
      if (!Array.isArray(selectedData) || selectedData.length === 0) {
        Alert.alert('No Data', 'No delivered items available');
        return;
      }
      html = generateDeliveredItemsHTML(selectedData, selectedDate || undefined, includeTime);
      title = 'Delivered Items Report';
    } else {
      if (!Array.isArray(selectedData) || selectedData.length === 0) {
        Alert.alert('No Data', 'No completed items available');
        return;
      }
      html = generateCompletedItemsHTML(selectedData, selectedDate || undefined, includeTime);
      title = 'Completed Items Report';
    }
    const { uri } = await Print.printToFileAsync({ html });
    await Sharing.shareAsync(uri, { dialogTitle: title });
  } catch (error) {
    Alert.alert('Error', 'Failed to generate PDF');
  }
};

export const handleEmailReport = async (
  selectedReportType: 'completed' | 'finishing' | 'delivered' | null,
  selectedData: any,
  selectedDate: string | null,
  emailRecipients: string[],
  setEmailingReport: (val: boolean) => void,
  includeTime: boolean = true
) => {
  if (!selectedReportType || !selectedData) {
    Alert.alert('Error', 'No data available');
    return;
  }
  if (emailRecipients.length === 0) {
    Alert.alert('No Recipients', 'Please select at least one email recipient');
    return;
  }
  setEmailingReport(true);
  try {
    let htmlContent: string;
    let subject: string;
    if (selectedReportType === 'finishing') {
      const jobsFromRecords = convertFinishingRecordsToJobs(selectedData.records);
      htmlContent = generateFinishingHTML(jobsFromRecords, selectedDate || undefined, includeTime);
      subject = `Finishing Report - ${selectedDate}`;
    } else if (selectedReportType === 'delivered') {
      htmlContent = generateDeliveredItemsHTML(selectedData, selectedDate || undefined, includeTime);
      subject = `Delivered Items Report - ${selectedDate}`;
    } else {
      htmlContent = generateCompletedItemsHTML(selectedData, selectedDate || undefined, includeTime);
      subject = `Completed Items Report - ${selectedDate}`;
    }
    const { data: emailSettings } = await supabase
      .from('email_settings')
      .select('from_email, is_verified')
      .order('created_at', { ascending: false })
      .limit(1)
      .single();
    const fromEmail = emailSettings?.from_email || 'onboarding@resend.dev';
    const { error } = await supabase.functions.invoke('send-daily-report', {
      body: { recipients: emailRecipients, subject, htmlContent, fromEmail }
    });
    if (error) throw error;
    Alert.alert('Success', `Report emailed to ${emailRecipients.length} recipient(s)`);
  } catch (error: any) {
    Alert.alert('Error', error.message || 'Failed to send email');
  } finally {
    setEmailingReport(false);
  }
};

function convertFinishingRecordsToJobs(records: any[]): Job[] {
  const jobMap: { [key: string]: Job } = {};
  records.forEach((rec: any) => {
    if (!jobMap[rec.job_number]) {
      jobMap[rec.job_number] = {
        id: rec.job_number, jobNumber: rec.job_number, customerName: rec.customer_name,
        dateOfEntry: rec.recorded_date || new Date().toISOString(), status: 'archived', items: []
      } as Job;
    }
    jobMap[rec.job_number].items.push({ descriptionOfWorks: rec.item_description, weightKg: rec.weight_kg, status: 'Finishing' } as any);
  });
  return Object.values(jobMap);
}
