import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TouchableOpacity, TextInput, StyleSheet, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '@/app/lib/supabase';

interface EmailRecipientsModalProps {
  visible: boolean;
  onClose: () => void;
  recipients: string[];
  onSave: (recipients: string[]) => void;
}

export default function EmailRecipientsModal({ visible, onClose, recipients, onSave }: EmailRecipientsModalProps) {
  const [localRecipients, setLocalRecipients] = useState<Array<{id: string, email: string, name?: string}>>([]);
  const [newEmail, setNewEmail] = useState('');
  const [newName, setNewName] = useState('');
  const [loading, setLoading] = useState(false);

  // Load recipients from database when modal opens
  useEffect(() => {
    if (visible) {
      loadRecipients();
    }
  }, [visible]);

  const loadRecipients = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('email_recipients')
        .select('*')
        .order('created_at', { ascending: true });

      if (error) throw error;

      setLocalRecipients(data || []);
    } catch (error) {
      console.error('Error loading recipients:', error);
      Alert.alert('Error', 'Failed to load email recipients');
    } finally {
      setLoading(false);
    }
  };

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleAddEmail = async () => {
    const trimmedEmail = newEmail.trim();
    const trimmedName = newName.trim();
    
    if (!trimmedEmail) return;
    
    if (!validateEmail(trimmedEmail)) {
      Alert.alert('Invalid Email', 'Please enter a valid email address');
      return;
    }
    
    if (localRecipients.some(r => r.email === trimmedEmail)) {
      Alert.alert('Duplicate Email', 'This email is already in the list');
      return;
    }
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('email_recipients')
        .insert([{ email: trimmedEmail, name: trimmedName || null }])
        .select()
        .single();

      if (error) throw error;

      setLocalRecipients([...localRecipients, data]);
      setNewEmail('');
      setNewName('');
      Alert.alert('Success', 'Email recipient added');
    } catch (error: any) {
      console.error('Error adding recipient:', error);
      Alert.alert('Error', error.message || 'Failed to add email recipient');
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveEmail = async (id: string, email: string) => {
    Alert.alert(
      'Remove Recipient',
      `Remove ${email} from the list?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            setLoading(true);
            try {
              const { error } = await supabase
                .from('email_recipients')
                .delete()
                .eq('id', id);

              if (error) throw error;

              setLocalRecipients(localRecipients.filter(r => r.id !== id));
              Alert.alert('Success', 'Email recipient removed');
            } catch (error) {
              console.error('Error removing recipient:', error);
              Alert.alert('Error', 'Failed to remove email recipient');
            } finally {
              setLoading(false);
            }
          }
        }
      ]
    );
  };

  const handleSave = async () => {
    // If there's unsaved data in the text fields, save it first
    const trimmedEmail = newEmail.trim();
    if (trimmedEmail) {
      if (!validateEmail(trimmedEmail)) {
        Alert.alert('Invalid Email', 'Please enter a valid email address or clear the field');
        return;
      }
      
      if (localRecipients.some(r => r.email === trimmedEmail)) {
        Alert.alert('Duplicate Email', 'This email is already in the list. Clear the field or add it first.');
        return;
      }
      
      // Save the unsaved email
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('email_recipients')
          .insert([{ email: trimmedEmail, name: newName.trim() || null }])
          .select()
          .single();

        if (error) throw error;

        const updatedRecipients = [...localRecipients, data];
        const emailList = updatedRecipients.map(r => r.email);
        onSave(emailList);
        onClose();
      } catch (error: any) {
        console.error('Error saving recipient:', error);
        Alert.alert('Error', error.message || 'Failed to save email recipient');
      } finally {
        setLoading(false);
      }
    } else {
      // No unsaved data, just close
      const emailList = localRecipients.map(r => r.email);
      onSave(emailList);
      onClose();
    }
  };



  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <View style={styles.header}>
            <Text style={styles.title}>Email Recipients</Text>
            <TouchableOpacity onPress={onClose}>
              <Ionicons name="close" size={28} color="#333" />
            </TouchableOpacity>
          </View>

          <View style={styles.inputContainer}>
            <View style={styles.inputColumn}>
              <TextInput
                style={styles.input}
                placeholder="Name (optional)"
                value={newName}
                onChangeText={setNewName}
                autoCapitalize="words"
              />
              <TextInput
                style={styles.input}
                placeholder="Email address"
                value={newEmail}
                onChangeText={setNewEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                onSubmitEditing={handleAddEmail}
              />
            </View>
            <TouchableOpacity 
              style={[styles.addButton, loading && styles.addButtonDisabled]} 
              onPress={handleAddEmail}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color="#fff" size="small" />
              ) : (
                <Ionicons name="add" size={24} color="#fff" />
              )}
            </TouchableOpacity>
          </View>

          {loading && localRecipients.length === 0 ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#007AFF" />
              <Text style={styles.loadingText}>Loading recipients...</Text>
            </View>
          ) : (
            <ScrollView style={styles.list}>
              {localRecipients.map((recipient) => (
                <View key={recipient.id} style={styles.emailItem}>
                  <View style={styles.emailInfo}>
                    {recipient.name && (
                      <Text style={styles.emailName}>{recipient.name}</Text>
                    )}
                    <Text style={styles.emailText}>{recipient.email}</Text>
                  </View>
                  <TouchableOpacity 
                    onPress={() => handleRemoveEmail(recipient.id, recipient.email)}
                    disabled={loading}
                  >
                    <Ionicons name="trash-outline" size={20} color="#FF3B30" />
                  </TouchableOpacity>
                </View>
              ))}
              {localRecipients.length === 0 && (
                <Text style={styles.emptyText}>No recipients added yet</Text>
              )}
            </ScrollView>
          )}


          <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
            <Text style={styles.saveButtonText}>Save Recipients</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modal: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, maxHeight: '80%' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, borderBottomWidth: 1, borderBottomColor: '#eee' },
  title: { fontSize: 24, fontWeight: 'bold', color: '#333' },
  inputContainer: { flexDirection: 'row', padding: 20, gap: 10, alignItems: 'flex-start' },
  inputColumn: { flex: 1, gap: 10 },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, paddingHorizontal: 16, paddingVertical: 12, fontSize: 16 },
  addButton: { backgroundColor: '#4CAF50', width: 48, height: 48, borderRadius: 8, justifyContent: 'center', alignItems: 'center', marginTop: 0 },
  addButtonDisabled: { backgroundColor: '#A5D6A7', opacity: 0.7 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: 40 },
  loadingText: { marginTop: 12, fontSize: 16, color: '#666' },
  list: { flex: 1, paddingHorizontal: 20 },
  emailItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  emailInfo: { flex: 1 },
  emailName: { fontSize: 16, fontWeight: '600', color: '#333', marginBottom: 2 },
  emailText: { fontSize: 14, color: '#666' },
  emptyText: { textAlign: 'center', color: '#999', marginTop: 20, fontSize: 16 },
  saveButton: { backgroundColor: '#007AFF', margin: 20, padding: 16, borderRadius: 12, alignItems: 'center' },
  saveButtonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
});

