import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TouchableOpacity, Switch, StyleSheet, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSettings, SaveLocation } from '../contexts/SettingsContext';
import { useJobs } from '../contexts/JobContext';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import EmailRecipientsModal from './EmailRecipientsModal';
import EditUserModal from './EditUserModal';
import UserManagementSection from './UserManagementSection';
import { supabase } from '@/app/lib/supabase';
import { getRecentReports, autoFixMissingRecords, cleanupOrphanRecords, runReconciliation } from '@/utils/dataReconciliation';
// Optional imports for OTA updates
let Updates: any = null;
try {
  Updates = require('expo-updates');
} catch (e) {
  console.log('expo-updates not installed');
}
import Constants from 'expo-constants';



interface SettingsModalProps {
  visible: boolean;
  onClose: () => void;
}

export default function SettingsModal({ visible, onClose }: SettingsModalProps) {
  const { autoArchiveEnabled, autoArchiveTime, pdfSaveLocation, emailRecipients, newBadgeEnabled, setAutoArchiveEnabled, setAutoArchiveTime, setPdfSaveLocation, setEmailRecipients, setNewBadgeEnabled } = useSettings();

  const { user } = usePasswordAuth();
  const { jobs, checkAndArchiveDoneJobs } = useJobs();

  const [showTimePicker, setShowTimePicker] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [deliveredJobs, setDeliveredJobs] = useState<any[]>([]);
  const [deliveredWeight, setDeliveredWeight] = useState(0);
  const [showEditUserModal, setShowEditUserModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  
  // Update states
  const [isCheckingUpdate, setIsCheckingUpdate] = useState(false);
  const [updateStatus, setUpdateStatus] = useState<string>('');

  // Reconciliation states
  const [isRunningReconciliation, setIsRunningReconciliation] = useState(false);
  const [reconciliationStatus, setReconciliationStatus] = useState<string>('');
  const [lastReportInfo, setLastReportInfo] = useState<{ mismatches: number; date: string } | null>(null);

  // Check if user has limited access (only manual archive)
  const isLimitedUser = user?.username === 'KH' || user?.username === 'Lovena';
  const canAccessManualArchive = user?.role === 'admin' || isLimitedUser;




  // Fetch delivered jobs and reconciliation info when modal opens
  useEffect(() => {
    if (visible) {
      loadDeliveredJobs();
      loadLastReconciliationReport();
    }
  }, [visible, jobs]);

  const loadLastReconciliationReport = async () => {
    try {
      const reports = await getRecentReports(1);
      if (reports.length > 0) {
        const report = reports[0];
        const totalMismatches = (report.finishing_mismatches || 0) + (report.completed_mismatches || 0);
        setLastReportInfo({
          mismatches: totalMismatches,
          date: new Date(report.created_at).toLocaleDateString(),
        });
      }
    } catch (error) {
      console.error('Error loading reconciliation report:', error);
    }
  };

  const handleRunReconciliation = async () => {
    try {
      setIsRunningReconciliation(true);
      setReconciliationStatus('Running reconciliation check...');

      // First, run a fresh reconciliation to get current mismatches
      const result = await runReconciliation(user?.username || 'Admin');
      
      const totalMismatches = result.finishingMismatches + result.completedMismatches;
      
      if (totalMismatches === 0) {
        setReconciliationStatus('No mismatches found. Data is in sync!');
        Alert.alert('Data Reconciliation', 'No mismatches found. Your data is already in sync!');
      } else {
        setReconciliationStatus(`Found ${totalMismatches} mismatches. Fixing...`);
        
        // Auto-fix missing records
        const fixResult = await autoFixMissingRecords(
          result.missingFinishingRecords,
          result.missingCompletedRecords
        );
        
        // Cleanup orphan records
        const cleanupResult = await cleanupOrphanRecords(
          result.orphanFinishingRecords,
          result.orphanCompletedRecords
        );
        
        const totalFixed = fixResult.fixedFinishing + fixResult.fixedCompleted;
        const totalCleaned = cleanupResult.cleanedFinishing + cleanupResult.cleanedCompleted;
        const allErrors = [...fixResult.errors, ...cleanupResult.errors];
        
        if (allErrors.length > 0) {
          setReconciliationStatus(`Completed with ${allErrors.length} error(s)`);
          Alert.alert(
            'Reconciliation Complete',
            `Fixed ${totalFixed} missing record(s)\nCleaned ${totalCleaned} orphan record(s)\n\nErrors:\n${allErrors.slice(0, 3).join('\n')}${allErrors.length > 3 ? `\n...and ${allErrors.length - 3} more` : ''}`
          );
        } else {
          setReconciliationStatus('Reconciliation complete!');
          Alert.alert(
            'Reconciliation Complete',
            `Successfully fixed ${totalFixed} missing record(s) and cleaned ${totalCleaned} orphan record(s).`
          );
        }
      }
      
      // Reload the report info
      await loadLastReconciliationReport();
      
    } catch (error: any) {
      console.error('Reconciliation error:', error);
      setReconciliationStatus('Error during reconciliation');
      Alert.alert('Error', `Reconciliation failed: ${error.message}`);
    } finally {
      setIsRunningReconciliation(false);
      setTimeout(() => setReconciliationStatus(''), 5000);
    }
  };

  const loadDeliveredJobs = async () => {
    const completedJobs = jobs.filter(job => job.status === 'done');
    if (completedJobs.length === 0) {
      setDeliveredJobs([]);
      setDeliveredWeight(0);
      return;
    }

    const jobIds = completedJobs.map(j => j.id);
    const { data, error } = await supabase
      .from('completed_jobs')
      .select('job_id, delivered')
      .in('job_id', jobIds);

    if (error) {
      console.error('Error loading delivered status:', error);
      return;
    }

    const deliveredMap = new Map<string, boolean>();
    data?.forEach(item => {
      deliveredMap.set(item.job_id, item.delivered || false);
    });

    const delivered = completedJobs.filter(job => deliveredMap.get(job.id) === true);
    const weight = delivered.reduce((sum, job) => 
      sum + job.items.reduce((itemSum, item) => itemSum + parseFloat(item.weightKg || '0'), 0), 0
    );

    setDeliveredJobs(delivered);
    setDeliveredWeight(weight);
  };





  const hours = Array.from({ length: 24 }, (_, i) => i.toString().padStart(2, '0'));
  const minutes = ['00', '15', '30', '45'];

  const [selectedHour, selectedMinute] = autoArchiveTime.split(':');

  const handleTimeChange = (hour: string, minute: string) => {
    setAutoArchiveTime(`${hour}:${minute}`);
    setShowTimePicker(false);
  };

  const handleRunArchiveNow = () => {
    if (deliveredJobs.length === 0) {
      Alert.alert('No Jobs to Archive', 'There are no delivered jobs to archive. Please mark jobs as delivered first.');
      return;
    }
    setShowConfirmation(true);
  };


  const confirmArchive = async () => {
    setShowConfirmation(false);
    
    // Call the updated checkAndArchiveDoneJobs which now filters by delivered status
    await checkAndArchiveDoneJobs();
    
    // Reload delivered jobs after archiving
    await loadDeliveredJobs();
    
    // Show success message
    Alert.alert('Archive Complete', 'Delivered jobs have been archived successfully. Non-delivered jobs remain in completed jobs.');
  };

  // Check for updates function
  const checkForUpdates = async () => {
    if (!Updates) {
      Alert.alert('Setup Required', 'Please install expo-updates package to enable OTA updates. Run: npx expo install expo-updates');
      return;
    }

    if (__DEV__) {
      Alert.alert('Development Mode', 'Updates are only available in production builds. Please build and install the app to test updates.');
      return;
    }


    try {
      setIsCheckingUpdate(true);
      setUpdateStatus('Checking for updates...');

      const update = await Updates.checkForUpdateAsync();
      
      if (update.isAvailable) {
        setUpdateStatus('Update available! Downloading...');
        await Updates.fetchUpdateAsync();
        
        Alert.alert(
          'Update Ready',
          'A new version has been downloaded. The app will restart now to apply the update.',
          [
            {
              text: 'Restart Now',
              onPress: async () => {
                await Updates.reloadAsync();
              }
            }
          ]
        );
      } else {
        setUpdateStatus('App is up to date!');
        Alert.alert('No Updates', 'You are already running the latest version.');
      }
    } catch (error) {
      console.error('Error checking for updates:', error);
      setUpdateStatus('Error checking for updates');
      Alert.alert('Update Error', 'Failed to check for updates. Please try again later.');
    } finally {
      setIsCheckingUpdate(false);
      setTimeout(() => setUpdateStatus(''), 3000);
    }
  };



  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <View style={styles.header}>
            <Text style={styles.title}>Settings</Text>
            <TouchableOpacity onPress={onClose}>
              <Ionicons name="close" size={28} color="#333" />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.content}>
            {/* For limited users (KH and Lovena), show ONLY Manual Archive section */}
            {isLimitedUser ? (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Manual Archive</Text>
                <TouchableOpacity 
                  style={styles.archiveButton}
                  onPress={handleRunArchiveNow}
                >
                  <Ionicons name="archive" size={24} color="#fff" />
                  <Text style={styles.archiveButtonText}>Archive Delivered Jobs</Text>
                </TouchableOpacity>
                <Text style={styles.archiveInfo}>
                  {deliveredJobs.length} delivered job(s) • {deliveredWeight.toFixed(1)} kg
                </Text>
              </View>
            ) : (
              <>
                {/* For admin and other users, show all sections */}
                <View style={styles.section}>
                  <Text style={styles.sectionTitle}>Auto-Archive</Text>
                  
                  <View style={styles.setting}>
                    <View style={styles.settingInfo}>
                      <Text style={styles.settingLabel}>Enable Auto-Archive</Text>
                      <Text style={styles.settingDesc}>Automatically archive completed jobs</Text>
                    </View>
                    <Switch
                      value={autoArchiveEnabled}
                      onValueChange={setAutoArchiveEnabled}
                      trackColor={{ false: '#ccc', true: '#4CAF50' }}
                    />
                  </View>

                  <View style={[styles.setting, !autoArchiveEnabled && styles.disabled]}>
                    <View style={styles.settingInfo}>
                      <Text style={styles.settingLabel}>Archive Time</Text>
                      <Text style={styles.settingDesc}>Daily archive at {autoArchiveTime}</Text>
                    </View>
                    <TouchableOpacity
                      onPress={() => autoArchiveEnabled && setShowTimePicker(true)}
                      disabled={!autoArchiveEnabled}
                      style={styles.timeButton}
                    >
                      <Text style={styles.timeText}>{autoArchiveTime}</Text>
                      <Ionicons name="chevron-forward" size={20} color="#666" />
                    </TouchableOpacity>
                  </View>
                </View>

                <View style={styles.section}>
                  <Text style={styles.sectionTitle}>Email Settings</Text>
                  
                  <TouchableOpacity style={styles.setting} onPress={() => setShowEmailModal(true)}>
                    <View style={styles.settingInfo}>
                      <Text style={styles.settingLabel}>Email Recipients</Text>
                      <Text style={styles.settingDesc}>
                        {emailRecipients.length === 0 ? 'No recipients configured' : `${emailRecipients.length} recipient(s)`}
                      </Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color="#666" />
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={styles.setting} 
                    onPress={() => {
                      onClose();
                      // Navigate to email settings screen
                      const { router } = require('expo-router');
                      router.push('/email-settings');
                    }}
                  >
                    <View style={styles.settingInfo}>
                      <Text style={styles.settingLabel}>Domain Verification</Text>
                      <Text style={styles.settingDesc}>Configure sender email and verify domain</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color="#666" />
                  </TouchableOpacity>
                </View>


                <View style={styles.section}>
                  <Text style={styles.sectionTitle}>Completed Jobs</Text>
                  
                  <View style={styles.setting}>
                    <View style={styles.settingInfo}>
                      <Text style={styles.settingLabel}>Show "NEW" Badges</Text>
                      <Text style={styles.settingDesc}>Display badges for unviewed completed jobs</Text>
                    </View>
                    <Switch
                      value={newBadgeEnabled}
                      onValueChange={setNewBadgeEnabled}
                      trackColor={{ false: '#ccc', true: '#4CAF50' }}
                    />
                  </View>
                </View>

                <View style={styles.section}>
                  <Text style={styles.sectionTitle}>App Updates</Text>
                  
                  <View style={styles.setting}>
                    <View style={styles.settingInfo}>
                      <Text style={styles.settingLabel}>Current Version</Text>
                      <Text style={styles.settingDesc}>
                        {Constants.expoConfig?.version || '1.0.0'}
                      </Text>
                    </View>
                  </View>

                  <TouchableOpacity 
                    style={[styles.updateButton, isCheckingUpdate && styles.updateButtonDisabled]}
                    onPress={checkForUpdates}
                    disabled={isCheckingUpdate}
                  >
                    {isCheckingUpdate ? (
                      <ActivityIndicator color="#fff" size="small" />
                    ) : (
                      <Ionicons name="cloud-download-outline" size={24} color="#fff" />
                    )}
                    <Text style={styles.updateButtonText}>
                      {isCheckingUpdate ? 'Checking...' : 'Check for Updates'}
                    </Text>
                  </TouchableOpacity>

                  {updateStatus !== '' && (
                    <Text style={styles.updateStatus}>{updateStatus}</Text>
                  )}
                </View>

                {/* Manual Archive section - only for admin */}
                {user?.role === 'admin' && (
                  <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Manual Archive</Text>
                    <TouchableOpacity 
                      style={styles.archiveButton}
                      onPress={handleRunArchiveNow}
                    >
                      <Ionicons name="archive" size={24} color="#fff" />
                      <Text style={styles.archiveButtonText}>Archive Delivered Jobs</Text>
                    </TouchableOpacity>
                    <Text style={styles.archiveInfo}>
                      {deliveredJobs.length} delivered job(s) • {deliveredWeight.toFixed(1)} kg
                    </Text>
                  </View>
                )}

                {/* Data Reconciliation section - only for admin */}
                {user?.role === 'admin' && (
                  <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Data Reconciliation</Text>
                    
                    {lastReportInfo && (
                      <View style={styles.setting}>
                        <View style={styles.settingInfo}>
                          <Text style={styles.settingLabel}>Last Check</Text>
                          <Text style={styles.settingDesc}>
                            {lastReportInfo.date} • {lastReportInfo.mismatches} mismatch(es)
                          </Text>
                        </View>
                      </View>
                    )}
                    
                    <TouchableOpacity 
                      style={[styles.reconcileButton, isRunningReconciliation && styles.reconcileButtonDisabled]}
                      onPress={handleRunReconciliation}
                      disabled={isRunningReconciliation}
                    >
                      {isRunningReconciliation ? (
                        <ActivityIndicator color="#fff" size="small" />
                      ) : (
                        <Ionicons name="sync" size={24} color="#fff" />
                      )}
                      <Text style={styles.reconcileButtonText}>
                        {isRunningReconciliation ? 'Running...' : 'Run Reconciliation & Fix'}
                      </Text>
                    </TouchableOpacity>
                    
                    {reconciliationStatus !== '' && (
                      <Text style={styles.reconciliationStatus}>{reconciliationStatus}</Text>
                    )}
                    
                    <Text style={styles.reconcileInfo}>
                      Checks for missing records and orphan entries, then auto-fixes them.
                    </Text>
                  </View>
                )}

                <View style={styles.section}>
                  <UserManagementSection />
                </View>

              </>
            )}
          </ScrollView>


          {showTimePicker && (
            <View style={styles.timePicker}>
              <Text style={styles.pickerTitle}>Select Time</Text>
              <View style={styles.pickerRow}>
                <ScrollView style={styles.pickerColumn}>
                  {hours.map(h => (
                    <TouchableOpacity
                      key={h}
                      onPress={() => handleTimeChange(h, selectedMinute)}
                      style={[styles.pickerItem, h === selectedHour && styles.pickerItemSelected]}
                    >
                      <Text style={h === selectedHour ? styles.pickerTextSelected : styles.pickerText}>{h}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
                <Text style={styles.pickerSeparator}>:</Text>
                <ScrollView style={styles.pickerColumn}>
                  {minutes.map(m => (
                    <TouchableOpacity
                      key={m}
                      onPress={() => handleTimeChange(selectedHour, m)}
                      style={[styles.pickerItem, m === selectedMinute && styles.pickerItemSelected]}
                    >
                      <Text style={m === selectedMinute ? styles.pickerTextSelected : styles.pickerText}>{m}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </View>
              <TouchableOpacity onPress={() => setShowTimePicker(false)} style={styles.pickerClose}>
                <Text style={styles.pickerCloseText}>Done</Text>
              </TouchableOpacity>
            </View>
          )}

        </View>
      </View>

      <Modal visible={showConfirmation} animationType="fade" transparent>
        <View style={styles.confirmOverlay}>
          <View style={styles.confirmModal}>
            <Ionicons name="warning" size={48} color="#FF9800" style={styles.confirmIcon} />
            <Text style={styles.confirmTitle}>Archive Delivered Jobs?</Text>
            <Text style={styles.confirmMessage}>
              This will archive {deliveredJobs.length} delivered job(s) with a total weight of {deliveredWeight.toFixed(1)} kg. Non-delivered jobs will remain in completed jobs.
            </Text>

            <View style={styles.confirmButtons}>
              <TouchableOpacity 
                style={[styles.confirmButton, styles.cancelButton]}
                onPress={() => setShowConfirmation(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.confirmButton, styles.archiveConfirmButton]}
                onPress={confirmArchive}
              >
                <Text style={styles.archiveConfirmButtonText}>Archive</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <EmailRecipientsModal
        visible={showEmailModal}
        onClose={() => setShowEmailModal(false)}
        recipients={emailRecipients}
        onSave={setEmailRecipients}
      />
    </Modal>

  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modal: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, maxHeight: '80%' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, borderBottomWidth: 1, borderBottomColor: '#eee' },
  title: { fontSize: 24, fontWeight: 'bold', color: '#333' },
  content: { padding: 20 },
  section: { marginBottom: 24 },
  sectionTitle: { fontSize: 18, fontWeight: '600', color: '#333', marginBottom: 16 },
  setting: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  settingInfo: { flex: 1 },
  settingLabel: { fontSize: 16, fontWeight: '500', color: '#333', marginBottom: 4 },
  settingDesc: { fontSize: 14, color: '#666' },
  disabled: { opacity: 0.5 },
  timeButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f5f5f5', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8 },
  timeText: { fontSize: 16, fontWeight: '600', color: '#333', marginRight: 8 },
  archiveButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#2196F3', padding: 16, borderRadius: 12, gap: 8 },
  archiveButtonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  archiveInfo: { textAlign: 'center', marginTop: 12, fontSize: 14, color: '#666' },
  timePicker: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#ddd', padding: 20 },
  pickerTitle: { fontSize: 18, fontWeight: '600', textAlign: 'center', marginBottom: 16 },
  pickerRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', height: 200 },
  pickerColumn: { width: 80, height: 200 },
  pickerItem: { padding: 12, alignItems: 'center' },
  pickerItemSelected: { backgroundColor: '#4CAF50', borderRadius: 8 },
  pickerText: { fontSize: 18, color: '#333' },
  pickerTextSelected: { fontSize: 18, color: '#fff', fontWeight: 'bold' },
  pickerSeparator: { fontSize: 24, fontWeight: 'bold', marginHorizontal: 16 },
  pickerClose: { marginTop: 16, backgroundColor: '#4CAF50', padding: 16, borderRadius: 8, alignItems: 'center' },
  pickerCloseText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  confirmOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  confirmModal: { backgroundColor: '#fff', borderRadius: 16, padding: 24, width: '100%', maxWidth: 400, alignItems: 'center' },
  confirmIcon: { marginBottom: 16 },
  confirmTitle: { fontSize: 20, fontWeight: 'bold', color: '#333', marginBottom: 12, textAlign: 'center' },
  confirmMessage: { fontSize: 16, color: '#666', textAlign: 'center', marginBottom: 24, lineHeight: 24 },
  confirmButtons: { flexDirection: 'row', gap: 12, width: '100%' },
  confirmButton: { flex: 1, padding: 14, borderRadius: 8, alignItems: 'center' },
  cancelButton: { backgroundColor: '#f5f5f5' },
  cancelButtonText: { fontSize: 16, fontWeight: '600', color: '#333' },
  archiveConfirmButton: { backgroundColor: '#2196F3' },
  archiveConfirmButtonText: { fontSize: 16, fontWeight: '600', color: '#fff' },
  locationButtons: { flexDirection: 'row', gap: 8 },
  locationButton: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8, backgroundColor: '#f5f5f5', borderWidth: 1, borderColor: '#e0e0e0' },
  locationButtonActive: { backgroundColor: '#4CAF50', borderColor: '#4CAF50' },
  locationButtonText: { fontSize: 14, fontWeight: '600', color: '#666' },
  locationButtonTextActive: { color: '#fff' },
  updateButton: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'center', 
    backgroundColor: '#2196F3', 
    padding: 16, 
    borderRadius: 12, 
    gap: 8,
    marginTop: 8,
  },
  updateButtonDisabled: { 
    backgroundColor: '#90CAF9',
    opacity: 0.7,
  },
  updateButtonText: { 
    color: '#fff', 
    fontSize: 16, 
    fontWeight: '600',
  },
  updateStatus: { 
    textAlign: 'center', 
    marginTop: 12, 
    fontSize: 14, 
    color: '#4CAF50',
    fontWeight: '500',
  },
  reconcileButton: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'center', 
    backgroundColor: '#9C27B0', 
    padding: 16, 
    borderRadius: 12, 
    gap: 8,
    marginTop: 8,
  },
  reconcileButtonDisabled: { 
    backgroundColor: '#CE93D8',
    opacity: 0.7,
  },
  reconcileButtonText: { 
    color: '#fff', 
    fontSize: 16, 
    fontWeight: '600',
  },
  reconciliationStatus: { 
    textAlign: 'center', 
    marginTop: 12, 
    fontSize: 14, 
    color: '#9C27B0',
    fontWeight: '500',
  },
  reconcileInfo: { 
    textAlign: 'center', 
    marginTop: 8, 
    fontSize: 12, 
    color: '#999',
  },
});


