import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TextInput, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';
import { supabase } from '../app/lib/supabase';

interface DriverDetailsModalProps {
  visible: boolean;
  onClose: () => void;
  driverId: string | null;
  onSuccess: () => void;
}

export default function DriverDetailsModal({ visible, onClose, driverId, onSuccess }: DriverDetailsModalProps) {
  const [fullName, setFullName] = useState('');
  const [licenseNumber, setLicenseNumber] = useState('');
  const [phone, setPhone] = useState('');
  const [status, setStatus] = useState('active');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (visible && driverId) {
      loadDriver();
    } else if (!visible) {
      resetForm();
    }
  }, [visible, driverId]);

  const resetForm = () => {
    setFullName('');
    setLicenseNumber('');
    setPhone('');
    setStatus('active');
    setNotes('');
  };

  const loadDriver = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('drivers')
        .select('*')
        .eq('id', driverId)
        .single();
      
      if (error) throw error;
      
      if (data) {
        setFullName(data.full_name || '');
        setLicenseNumber(data.license_number || '');
        setPhone(data.phone || '');
        setStatus(data.status || 'active');
        setNotes(data.notes || '');
      }
    } catch (error) {
      console.error('Error loading driver:', error);
      Alert.alert('Error', 'Failed to load driver details');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!fullName.trim() || !licenseNumber.trim()) {
      Alert.alert('Error', 'Name and license number are required');
      return;
    }

    setSaving(true);
    try {
      const updateData = {
        full_name: fullName.trim(),
        license_number: licenseNumber.trim(),
        phone: phone.trim(),
        status: status,
        notes: notes.trim(),
        updated_at: new Date().toISOString()
      };

      console.log('Updating driver:', driverId, updateData);

      const { data, error } = await supabase
        .from('drivers')
        .update(updateData)
        .eq('id', driverId)
        .select();

      if (error) throw error;

      console.log('Update result:', data);

      await onSuccess();
      onClose();
      
      setTimeout(() => {
        Alert.alert('Success', 'Driver updated successfully');
      }, 300);
    } catch (error) {
      console.error('Error saving driver:', error);
      Alert.alert('Error', 'Failed to save: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <ScrollView>
            <Text style={styles.title}>Driver Details</Text>
            
            {loading ? (
              <Text style={styles.loadingText}>Loading...</Text>
            ) : (
              <>
                <Text style={styles.label}>Full Name *</Text>
                <TextInput 
                  style={styles.input} 
                  value={fullName} 
                  onChangeText={setFullName}
                  editable={!saving}
                />
                
                <Text style={styles.label}>License Number *</Text>
                <TextInput 
                  style={styles.input} 
                  value={licenseNumber} 
                  onChangeText={setLicenseNumber}
                  editable={!saving}
                />
                
                <Text style={styles.label}>Phone</Text>
                <TextInput 
                  style={styles.input} 
                  value={phone} 
                  onChangeText={setPhone} 
                  keyboardType="phone-pad"
                  editable={!saving}
                />
                
                <Text style={styles.label}>Status</Text>
                <View style={styles.statusRow}>
                  <TouchableOpacity 
                    style={[styles.statusBtn, status === 'active' && styles.statusActive]} 
                    onPress={() => setStatus('active')}
                    disabled={saving}
                  >
                    <Text style={[styles.statusText, status === 'active' && styles.statusTextActive]}>Active</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={[styles.statusBtn, status === 'on_leave' && styles.statusActive]} 
                    onPress={() => setStatus('on_leave')}
                    disabled={saving}
                  >
                    <Text style={[styles.statusText, status === 'on_leave' && styles.statusTextActive]}>On Leave</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={[styles.statusBtn, status === 'inactive' && styles.statusActive]} 
                    onPress={() => setStatus('inactive')}
                    disabled={saving}
                  >
                    <Text style={[styles.statusText, status === 'inactive' && styles.statusTextActive]}>Inactive</Text>
                  </TouchableOpacity>
                </View>
                
                <Text style={styles.label}>Notes</Text>
                <TextInput 
                  style={[styles.input, styles.textArea]} 
                  value={notes} 
                  onChangeText={setNotes} 
                  multiline 
                  numberOfLines={3}
                  editable={!saving}
                />

                <View style={styles.buttons}>
                  <TouchableOpacity 
                    style={styles.cancelButton} 
                    onPress={onClose}
                    disabled={saving}
                  >
                    <Text style={styles.cancelText}>Cancel</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={[styles.saveButton, saving && styles.saveButtonDisabled]} 
                    onPress={handleSave} 
                    disabled={saving}
                  >
                    <Text style={styles.saveText}>{saving ? 'Saving...' : 'Save Changes'}</Text>
                  </TouchableOpacity>
                </View>
              </>
            )}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: 'white', borderRadius: 12, padding: 20, maxHeight: '80%' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 20 },
  loadingText: { textAlign: 'center', padding: 20, color: '#6b7280' },
  label: { fontSize: 14, fontWeight: '600', marginBottom: 5, color: '#374151' },
  input: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, padding: 12, marginBottom: 15, fontSize: 16 },
  textArea: { height: 80, textAlignVertical: 'top' },
  statusRow: { flexDirection: 'row', gap: 10, marginBottom: 15 },
  statusBtn: { flex: 1, padding: 10, borderRadius: 8, borderWidth: 1, borderColor: '#d1d5db', alignItems: 'center' },
  statusActive: { backgroundColor: '#2563eb', borderColor: '#2563eb' },
  statusText: { fontSize: 14, color: '#374151' },
  statusTextActive: { color: 'white', fontWeight: '600' },
  buttons: { flexDirection: 'row', gap: 10, marginTop: 10 },
  cancelButton: { flex: 1, padding: 15, borderRadius: 8, borderWidth: 1, borderColor: '#d1d5db' },
  cancelText: { textAlign: 'center', fontSize: 16, color: '#6b7280' },
  saveButton: { flex: 1, padding: 15, borderRadius: 8, backgroundColor: '#2563eb' },
  saveButtonDisabled: { backgroundColor: '#93c5fd' },
  saveText: { textAlign: 'center', fontSize: 16, color: 'white', fontWeight: '600' }
});
