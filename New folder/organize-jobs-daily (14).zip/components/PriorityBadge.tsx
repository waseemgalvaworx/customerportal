import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Priority } from '../contexts/JobContext';

interface PriorityBadgeProps {
  priority?: Priority;
  galvaXpress?: boolean;
  size?: 'small' | 'medium' | 'large';
}

export default function PriorityBadge({ priority, galvaXpress, size = 'medium' }: PriorityBadgeProps) {
  if (!priority && !galvaXpress) return null;

  const colors = {
    high: '#EF4444',
    medium: '#F59E0B',
    low: '#10B981'
  };

  const priorityColor = priority ? colors[priority] : '#6B7280';
  const iconSize = size === 'small' ? 14 : size === 'large' ? 20 : 16;
  const textSize = size === 'small' ? 10 : size === 'large' ? 14 : 12;

  return (
    <View style={styles.container}>
      {galvaXpress && (
        <View style={[styles.badge, styles.galvaXpress]}>
          <Ionicons name="flash" size={iconSize} color="white" />
          <Text style={[styles.text, { fontSize: textSize }]}>GalvXpress</Text>
        </View>
      )}
      {priority && (
        <View style={[styles.badge, { backgroundColor: priorityColor }]}>
          <Ionicons 
            name={priority === 'high' ? 'alert-circle' : priority === 'medium' ? 'warning' : 'checkmark-circle'} 
            size={iconSize} 
            color="white" 
          />
          <Text style={[styles.text, { fontSize: textSize }]}>{priority.toUpperCase()}</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flexDirection: 'row', gap: 6, alignItems: 'center' },
  badge: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12, gap: 4 },
  galvaXpress: { backgroundColor: '#DC2626' },
  text: { color: 'white', fontWeight: 'bold' }
});
