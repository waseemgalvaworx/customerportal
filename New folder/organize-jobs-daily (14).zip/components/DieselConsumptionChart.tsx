import React from 'react';
import { View, Text, StyleSheet, ScrollView, Dimensions } from 'react-native';
import { ConsumptionTrend } from '../utils/dieselAnalytics';

interface DieselConsumptionChartProps {
  data: ConsumptionTrend[];
  title: string;
  color?: string;
}

export default function DieselConsumptionChart({ 
  data, 
  title, 
  color = '#007AFF' 
}: DieselConsumptionChartProps) {
  if (!data || data.length === 0) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.noData}>No data available</Text>
      </View>
    );
  }

  const maxConsumption = Math.max(...data.map(d => d.consumption), 1);
  const chartWidth = Dimensions.get('window').width - 80;
  const barWidth = Math.max(30, chartWidth / data.length - 10);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <View style={styles.chartContainer}>
          <View style={styles.barsContainer}>
            {data.map((item, index) => {
              const height = (item.consumption / maxConsumption) * 150;
              return (
                <View key={index} style={styles.barWrapper}>
                  <View style={styles.barColumn}>
                    <Text style={styles.valueText}>
                      {item.consumption.toFixed(0)}L
                    </Text>
                    <View 
                      style={[
                        styles.bar, 
                        { height: Math.max(height, 5), backgroundColor: color, width: barWidth }
                      ]} 
                    />
                  </View>
                  <Text style={styles.labelText} numberOfLines={1}>
                    {formatLabel(item.date)}
                  </Text>
                  <Text style={styles.costText}>
                    Rs {item.cost.toFixed(0)}
                  </Text>
                </View>
              );
            })}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const formatLabel = (date: string): string => {
  if (date.includes('W')) return date.split('-')[1];
  const d = new Date(date);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
};

const styles = StyleSheet.create({
  container: { marginVertical: 16, backgroundColor: '#fff', padding: 16, borderRadius: 12, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  title: { fontSize: 18, fontWeight: '700', marginBottom: 16, color: '#333' },
  noData: { textAlign: 'center', color: '#999', paddingVertical: 20 },
  chartContainer: { paddingVertical: 10 },
  barsContainer: { flexDirection: 'row', alignItems: 'flex-end', gap: 8 },
  barWrapper: { alignItems: 'center' },
  barColumn: { alignItems: 'center', justifyContent: 'flex-end', height: 170 },
  bar: { borderRadius: 6, minHeight: 5 },
  valueText: { fontSize: 11, fontWeight: '600', color: '#333', marginBottom: 4 },
  labelText: { fontSize: 10, color: '#666', marginTop: 6, maxWidth: 60, textAlign: 'center' },
  costText: { fontSize: 9, color: '#999', marginTop: 2 }
});
