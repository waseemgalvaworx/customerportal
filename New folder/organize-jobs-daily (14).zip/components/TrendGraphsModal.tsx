import React from 'react';
import { View, Text, Modal, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface Props {
  visible: boolean;
  onClose: () => void;
}

export default function TrendGraphsModal({ visible, onClose }: Props) {
  return (
    <Modal visible={visible} animationType="slide">
      <View style={{ flex: 1, backgroundColor: '#f3f4f6' }}>
        <View style={{ padding: 20, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#e5e7eb' }}>
          <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#1f2937' }}>Advanced Analytics</Text>
          <Text style={{ fontSize: 14, color: '#6b7280', marginTop: 4 }}>View Trends</Text>
        </View>

        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 }}>
          <View style={{ 
            backgroundColor: '#FEF3C7', 
            padding: 30, 
            borderRadius: 20, 
            alignItems: 'center',
            borderWidth: 2,
            borderColor: '#F59E0B',
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.1,
            shadowRadius: 8,
            elevation: 5,
          }}>
            <Ionicons name="construct" size={80} color="#F59E0B" />
            <Text style={{ 
              fontSize: 28, 
              fontWeight: 'bold', 
              color: '#92400E', 
              marginTop: 20,
              textAlign: 'center'
            }}>
              Under Construction
            </Text>
            <Text style={{ 
              fontSize: 16, 
              color: '#B45309', 
              marginTop: 12,
              textAlign: 'center',
              lineHeight: 24
            }}>
              We're working on improving{'\n'}this feature. Check back soon!
            </Text>
          </View>
        </View>

        <TouchableOpacity 
          onPress={onClose} 
          style={{ 
            margin: 20, 
            padding: 15, 
            backgroundColor: '#007AFF', 
            borderRadius: 10, 
            alignItems: 'center' 
          }}
        >
          <Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>Close</Text>
        </TouchableOpacity>
      </View>
    </Modal>
  );
}
