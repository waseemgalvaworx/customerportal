import React, { useState } from 'react';
import { View, Text, Modal, TextInput, TouchableOpacity, Alert } from 'react-native';
import { supabase } from '@/app/lib/supabase';
import { heightToVolume } from '@/utils/dieselConversion';
import { checkLowDieselAlert } from '@/utils/dieselAlerts';
import { notifyAllUsers } from '@/utils/notificationHelper';
import { usePasswordAuth } from '@/contexts/PasswordAuthContext';

interface DieselReadingModalProps {
  visible: boolean;
  onClose: () => void;
  onSuccess: () => void | Promise<void>;
}


export default function DieselReadingModal({ visible, onClose, onSuccess }: DieselReadingModalProps) {
  const { user } = usePasswordAuth();
  const [readingDate, setReadingDate] = useState(new Date().toISOString().split('T')[0]);
  const [height, setHeight] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const heightNum = height ? parseFloat(height) : 0;
  const volume = !isNaN(heightNum) ? heightToVolume(heightNum) : 0;


  const handleSubmit = async () => {
    if (!height) {
      Alert.alert('Error', 'Please enter tank height');
      return;
    }

    const heightNum = parseFloat(height);
    if (heightNum < 1 || heightNum > 210) {
      Alert.alert('Error', 'Height must be between 1 and 210 cm');
      return;
    }

    setLoading(true);
    try {
      console.log('Starting diesel reading save...', { heightNum, volume, readingDate });
      
      // Save to diesel_consumption_logs for history
      const { data: logData, error: logError } = await supabase.from('diesel_consumption_logs').insert({
        log_type: 'reading',
        log_date: readingDate,
        height_cm: heightNum,
        volume_liters: volume,
        notes: notes || null,
      }).select();



      if (logError) {
        console.error('Log insert error:', logError);
        throw new Error(`Failed to save reading: ${logError.message}`);
      }
      console.log('Log saved successfully:', logData);

      // Update inventory_items table with new height (stored in quantity field)
      const { data: updateData, error: updateError } = await supabase
        .from('inventory_items')
        .update({ 
          quantity: heightNum,
          updated_at: new Date().toISOString()
        })
        .ilike('item_name', 'diesel')
        .select();

      if (updateError) {
        console.error('Inventory update error:', updateError);
        throw new Error(`Failed to update inventory: ${updateError.message}`);
      }
      
      if (!updateData || updateData.length === 0) {
        console.error('No diesel item found to update');
        throw new Error('Diesel item not found in inventory');
      }
      
      
      console.log('Inventory updated successfully:', updateData);

      // Send notification about diesel reading
      await notifyAllUsers({
        title: 'Diesel Tank Reading Updated',
        message: `Tank height: ${heightNum} cm, Volume: ${volume.toFixed(2)} L by ${user?.username || 'Unknown'}`,
        type: 'inventory',
        priority: 'normal'
      });

      // Check for low diesel alert
      await checkLowDieselAlert(volume);


      // Success - reset loading state first
      setLoading(false);
      
      // Show success message
      Alert.alert('Success', 'Tank reading logged successfully');
      
      // Reset form and close modal
      resetForm();
      onClose();
      
      // Refresh parent data in background
      setTimeout(async () => {
        try {
          await onSuccess();
          console.log('Parent refresh completed');
        } catch (refreshError) {
          console.error('Refresh error:', refreshError);
        }
      }, 100);

    } catch (error: any) {
      console.error('Submit error:', error);
      setLoading(false);
      Alert.alert('Error', error.message || 'Failed to log tank reading');
    }
  };




  const resetForm = () => {
    setReadingDate(new Date().toISOString().split('T')[0]);
    setHeight('');
    setNotes('');
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 }}>
        <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 20 }}>
          <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 20 }}>Log Tank Reading</Text>
          
          <Text style={{ fontSize: 14, fontWeight: '600', marginBottom: 5 }}>Reading Date</Text>
          <TextInput
            value={readingDate}
            onChangeText={setReadingDate}
            placeholder="YYYY-MM-DD"
            style={{ borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, marginBottom: 15 }}
          />

          <Text style={{ fontSize: 14, fontWeight: '600', marginBottom: 5 }}>Tank Height (cm)</Text>
          <TextInput
            value={height}
            onChangeText={setHeight}
            placeholder="Enter height (1-210 cm)"
            keyboardType="decimal-pad"
            style={{ borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, marginBottom: 15 }}
          />

          <View style={{ backgroundColor: '#f0fdf4', padding: 15, borderRadius: 8, marginBottom: 15 }}>
            <Text style={{ fontSize: 14, color: '#166534', marginBottom: 5 }}>
              Height: {height || '0'} cm
            </Text>
            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#15803d' }}>
              Volume: {volume.toFixed(2)} litres
            </Text>
          </View>

          <Text style={{ fontSize: 14, fontWeight: '600', marginBottom: 5 }}>Notes (Optional)</Text>
          <TextInput
            value={notes}
            onChangeText={setNotes}
            placeholder="Additional notes"
            multiline
            numberOfLines={2}
            style={{ borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, marginBottom: 20 }}
          />

          <View style={{ flexDirection: 'row', gap: 10 }}>
            <TouchableOpacity
              onPress={onClose}
              style={{ flex: 1, backgroundColor: '#e5e7eb', padding: 15, borderRadius: 8, alignItems: 'center' }}
            >
              <Text style={{ color: '#374151', fontWeight: '600' }}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={handleSubmit}
              disabled={loading}
              style={{ flex: 1, backgroundColor: '#10b981', padding: 15, borderRadius: 8, alignItems: 'center' }}
            >
              <Text style={{ color: 'white', fontWeight: '600' }}>{loading ? 'Saving...' : 'Log Reading'}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}
