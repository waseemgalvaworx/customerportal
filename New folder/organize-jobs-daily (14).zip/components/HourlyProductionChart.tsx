import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

interface HourlyData {
  hour: number;
  workshop: number;
  acid: number;
  galva: number;
  finishing: number;
  ready: number;
}

const STATUS_COLORS = {
  workshop: '#3b82f6',
  acid: '#eab308',
  galva: '#22c55e',
  finishing: '#a855f7',
  ready: '#f97316',
};

export default function HourlyProductionChart({ data }: { data: HourlyData[] }) {
  const maxTotal = Math.max(...data.map(d => 
    d.workshop + d.acid + d.galva + d.finishing + d.ready
  ), 1);
  
  const peakHour = data.reduce((max, d) => {
    const total = d.workshop + d.acid + d.galva + d.finishing + d.ready;
    const maxTotal = max.workshop + max.acid + max.galva + max.finishing + max.ready;
    return total > maxTotal ? d : max;
  }, data[0]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Hourly Production (KGs)</Text>
      
      <View style={styles.legend}>
        {Object.entries(STATUS_COLORS).map(([key, color]) => (
          <View key={key} style={styles.legendItem}>
            <View style={[styles.legendColor, { backgroundColor: color }]} />
            <Text style={styles.legendText}>{key.charAt(0).toUpperCase() + key.slice(1)}</Text>
          </View>
        ))}
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <View style={styles.chartContainer}>
          {data.map((row) => {
            const total = row.workshop + row.acid + row.galva + row.finishing + row.ready;
            const isPeak = row.hour === peakHour?.hour;
            
            return (
              <View key={row.hour} style={styles.barContainer}>
                <View style={styles.barWrapper}>
                  {total > 0 && (
                    <View style={[styles.barStack, isPeak && styles.peakBar]}>
                      {row.workshop > 0 && (
                        <View 
                          style={[
                            styles.barSegment,
                            { 
                              height: (row.workshop / maxTotal) * 150,
                              backgroundColor: STATUS_COLORS.workshop 
                            }
                          ]} 
                        />
                      )}
                      {row.acid > 0 && (
                        <View 
                          style={[
                            styles.barSegment,
                            { 
                              height: (row.acid / maxTotal) * 150,
                              backgroundColor: STATUS_COLORS.acid 
                            }
                          ]} 
                        />
                      )}
                      {row.galva > 0 && (
                        <View 
                          style={[
                            styles.barSegment,
                            { 
                              height: (row.galva / maxTotal) * 150,
                              backgroundColor: STATUS_COLORS.galva 
                            }
                          ]} 
                        />
                      )}
                      {row.finishing > 0 && (
                        <View 
                          style={[
                            styles.barSegment,
                            { 
                              height: (row.finishing / maxTotal) * 150,
                              backgroundColor: STATUS_COLORS.finishing 
                            }
                          ]} 
                        />
                      )}
                      {row.ready > 0 && (
                        <View 
                          style={[
                            styles.barSegment,
                            { 
                              height: (row.ready / maxTotal) * 150,
                              backgroundColor: STATUS_COLORS.ready 
                            }
                          ]} 
                        />
                      )}
                    </View>
                  )}
                  {isPeak && <Text style={styles.peakLabel}>★ Peak</Text>}
                  {total > 0 && <Text style={styles.totalLabel}>{total.toFixed(0)}</Text>}
                </View>
                <Text style={styles.hourLabel}>{row.hour}:00</Text>
              </View>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 15, backgroundColor: '#fff', borderRadius: 8, marginBottom: 15 },
  title: { fontSize: 16, fontWeight: 'bold', marginBottom: 10 },
  legend: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 15 },
  legendItem: { flexDirection: 'row', alignItems: 'center', marginRight: 15, marginBottom: 5 },
  legendColor: { width: 12, height: 12, borderRadius: 2, marginRight: 5 },
  legendText: { fontSize: 11, color: '#666' },
  chartContainer: { flexDirection: 'row', alignItems: 'flex-end', paddingTop: 20 },
  barContainer: { alignItems: 'center', marginHorizontal: 8 },
  barWrapper: { alignItems: 'center', height: 180 },
  barStack: { flexDirection: 'column-reverse', width: 30, borderRadius: 4, overflow: 'hidden' },
  peakBar: { borderWidth: 2, borderColor: '#dc2626', shadowColor: '#dc2626', shadowOpacity: 0.3, shadowRadius: 4 },
  barSegment: { width: '100%' },
  peakLabel: { fontSize: 9, color: '#dc2626', fontWeight: 'bold', marginTop: 2 },
  totalLabel: { fontSize: 10, fontWeight: 'bold', color: '#333', marginTop: 2 },
  hourLabel: { fontSize: 10, color: '#666', marginTop: 5 },
});
