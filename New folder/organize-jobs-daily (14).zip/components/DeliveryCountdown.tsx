import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface DeliveryCountdownProps {
  deliveryDate?: string | null;
  scheduledDate?: string | null;
}

export default function DeliveryCountdown({ deliveryDate, scheduledDate }: DeliveryCountdownProps) {
  const dateToUse = deliveryDate || scheduledDate;
  
  const getTimeUntilDelivery = () => {
    // Handle missing or invalid date
    if (!dateToUse) {
      return { text: 'No date', color: '#9CA3AF', icon: 'calendar-outline' };
    }
    
    const now = new Date();
    const scheduled = new Date(dateToUse);
    
    // Check if date is valid
    if (isNaN(scheduled.getTime())) {
      return { text: 'No date', color: '#9CA3AF', icon: 'calendar-outline' };
    }
    
    const diffMs = scheduled.getTime() - now.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);

    if (diffHours < 0) return { text: 'Overdue', color: '#ef4444', icon: 'alert-circle' };
    if (diffHours < 24) return { text: `${diffHours}h left`, color: '#f59e0b', icon: 'time' };
    if (diffDays < 3) return { text: `${diffDays}d left`, color: '#3b82f6', icon: 'calendar' };
    return { text: `${diffDays}d left`, color: '#10b981', icon: 'calendar-outline' };
  };

  const countdown = getTimeUntilDelivery();

  return (
    <View style={[styles.container, { backgroundColor: countdown.color + '15' }]}>
      <Ionicons name={countdown.icon as any} size={14} color={countdown.color} />
      <Text style={[styles.text, { color: countdown.color }]}>{countdown.text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12, gap: 4 },
  text: { fontSize: 11, fontWeight: '700' }
});
