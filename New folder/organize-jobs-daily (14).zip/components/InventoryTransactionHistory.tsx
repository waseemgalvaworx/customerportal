import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, ActivityIndicator, TextInput } from 'react-native';
import { supabase } from '@/app/lib/supabase';

interface InventoryTransactionHistoryProps {
  refreshKey: number;
}

export default function InventoryTransactionHistory({ refreshKey }: InventoryTransactionHistoryProps) {
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchTransactions();
  }, [refreshKey]);

  const fetchTransactions = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('inventory_transactions')
      .select(`
        *,
        inventory_items (item_name, unit, category)
      `)
      .order('transaction_date', { ascending: false })
      .limit(100);
    
    // Filter out transactions for deleted items
    if (!error && data) {
      setTransactions(data.filter(t => t.inventory_items !== null));
    }
    setLoading(false);
  };


  const filteredTransactions = transactions.filter(t => 
    t.inventory_items?.item_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.notes?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.username?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getTypeColor = (type: string) => {
    if (type === 'stock_in') return '#4CAF50';
    if (type === 'stock_out') return '#f44336';
    return '#FF9800';
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleString();
  };

  if (loading) return <ActivityIndicator size="large" style={{ marginTop: 50 }} />;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Transaction History</Text>
      
      <TextInput
        style={styles.searchInput}
        placeholder="Search transactions..."
        value={searchQuery}
        onChangeText={setSearchQuery}
      />

      {filteredTransactions.map(transaction => (
        <View key={transaction.id} style={styles.transactionCard}>
          <View style={styles.transactionHeader}>
            <Text style={styles.itemName}>{transaction.inventory_items?.item_name}</Text>
            <Text style={[styles.typeBadge, { backgroundColor: getTypeColor(transaction.transaction_type) }]}>
              {transaction.transaction_type.replace('_', ' ').toUpperCase()}
            </Text>
          </View>
          
          <View style={styles.transactionDetails}>
            <Text style={styles.detailText}>Quantity: {transaction.quantity} {transaction.inventory_items?.unit}</Text>
            {transaction.unit_cost && <Text style={styles.detailText}>Unit Cost: ${transaction.unit_cost}</Text>}
            {transaction.total_value && <Text style={styles.detailText}>Total Value: ${transaction.total_value.toFixed(2)}</Text>}
            {transaction.reference_type && (
              <Text style={styles.detailText}>Ref: {transaction.reference_type} {transaction.reference_id}</Text>
            )}
            <Text style={styles.detailText}>By: {transaction.username}</Text>
            <Text style={styles.detailText}>Date: {formatDate(transaction.transaction_date)}</Text>
            {transaction.notes && <Text style={styles.notes}>{transaction.notes}</Text>}
          </View>
        </View>
      ))}

      {filteredTransactions.length === 0 && (
        <Text style={styles.emptyText}>No transactions found</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16 },
  title: { fontSize: 18, fontWeight: 'bold', marginBottom: 16 },
  searchInput: { backgroundColor: '#fff', padding: 12, borderRadius: 8, marginBottom: 16, borderWidth: 1, borderColor: '#ddd' },
  transactionCard: { backgroundColor: '#fff', padding: 16, borderRadius: 8, marginBottom: 12, borderWidth: 1, borderColor: '#ddd' },
  transactionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  itemName: { fontSize: 16, fontWeight: 'bold', flex: 1 },
  typeBadge: { color: '#fff', padding: 6, borderRadius: 4, fontSize: 10, fontWeight: 'bold' },
  transactionDetails: { gap: 4 },
  detailText: { fontSize: 14, color: '#666' },
  notes: { fontSize: 14, color: '#999', fontStyle: 'italic', marginTop: 8 },
  emptyText: { textAlign: 'center', color: '#999', marginTop: 50, fontSize: 16 }
});
