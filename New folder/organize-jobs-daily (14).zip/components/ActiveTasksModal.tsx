import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TouchableOpacity,
  ScrollView,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useTasks, ActiveTask } from '../contexts/TaskContext';

interface ActiveTasksModalProps {
  visible: boolean;
  onClose: () => void;
}

export default function ActiveTasksModal({ visible, onClose }: ActiveTasksModalProps) {
  const router = useRouter();
  const { activeTasks, removeTask, setCurrentTask, clearAllTasks } = useTasks();

  const handleTaskPress = (task: ActiveTask) => {
    setCurrentTask(task.id);
    onClose();
    router.push(task.route as any);
  };

  const handleRemoveTask = (task: ActiveTask) => {
    if (task.hasUnsavedChanges) {
      Alert.alert(
        'Unsaved Changes',
        `"${task.title}" has unsaved changes. Are you sure you want to close it?`,
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'Close Anyway', 
            style: 'destructive',
            onPress: () => removeTask(task.id)
          },
        ]
      );
    } else {
      removeTask(task.id);
    }
  };

  const handleClearAll = () => {
    const hasUnsaved = activeTasks.some(t => t.hasUnsavedChanges);
    if (hasUnsaved) {
      Alert.alert(
        'Unsaved Changes',
        'Some tasks have unsaved changes. Are you sure you want to close all?',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'Close All', 
            style: 'destructive',
            onPress: () => {
              clearAllTasks();
              onClose();
            }
          },
        ]
      );
    } else {
      clearAllTasks();
      onClose();
    }
  };

  const formatTimestamp = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return new Date(timestamp).toLocaleDateString();
  };

  const formatSavedTime = (timestamp: number | undefined) => {
    if (!timestamp) return null;
    const now = Date.now();
    const diff = now - timestamp;
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(diff / 60000);
    
    if (seconds < 60) return 'Draft saved just now';
    if (minutes < 60) return `Draft saved ${minutes}m ago`;
    return `Draft saved ${formatTimestamp(timestamp)}`;
  };

  const getFormTypeLabel = (formType: string | undefined) => {
    switch (formType) {
      case 'form': return 'Form data';
      case 'filter': return 'Filters';
      case 'search': return 'Search';
      default: return null;
    }
  };

  const sortedTasks = [...activeTasks].sort((a, b) => b.lastAccessed - a.lastAccessed);

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.container}>
          {/* Header */}
          <View style={styles.header}>
            <View style={styles.headerLeft}>
              <Ionicons name="layers-outline" size={24} color="#3B82F6" />
              <Text style={styles.headerTitle}>Active Tasks</Text>
              <View style={styles.countBadge}>
                <Text style={styles.countText}>{activeTasks.length}</Text>
              </View>
            </View>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Ionicons name="close" size={24} color="#6B7280" />
            </TouchableOpacity>
          </View>

          {/* Description */}
          <Text style={styles.description}>
            Switch between screens without losing your work. Tasks with unsaved changes are marked.
          </Text>

          {/* Task List */}
          <ScrollView style={styles.taskList} showsVerticalScrollIndicator={false}>
            {sortedTasks.length === 0 ? (
              <View style={styles.emptyState}>
                <Ionicons name="file-tray-outline" size={48} color="#D1D5DB" />
                <Text style={styles.emptyTitle}>No Active Tasks</Text>
                <Text style={styles.emptyText}>
                  Navigate to different screens to start tracking your work sessions.
                </Text>
              </View>
            ) : (
              sortedTasks.map((task) => (
                <TouchableOpacity
                  key={task.id}
                  style={[
                    styles.taskCard,
                    task.hasUnsavedChanges && styles.taskCardUnsaved
                  ]}
                  onPress={() => handleTaskPress(task)}
                  activeOpacity={0.7}
                >
                  <View style={[styles.taskIcon, { backgroundColor: task.color + '20' }]}>
                    <Ionicons name={task.icon as any} size={24} color={task.color} />
                  </View>
                  
                  <View style={styles.taskInfo}>
                    <View style={styles.taskTitleRow}>
                      <Text style={styles.taskTitle}>{task.title}</Text>
                      {task.hasUnsavedChanges && (
                        <View style={styles.unsavedBadge}>
                          <Ionicons name="ellipse" size={8} color="#F59E0B" />
                          <Text style={styles.unsavedText}>Unsaved</Text>
                        </View>
                      )}
                    </View>
                    <Text style={styles.taskTime}>
                      Last accessed: {formatTimestamp(task.lastAccessed)}
                    </Text>
                    
                    {/* Draft saved indicator */}
                    {task.lastSavedAt && Object.keys(task.formData).length > 0 && (
                      <View style={styles.draftSavedRow}>
                        <Ionicons name="cloud-done-outline" size={12} color="#10B981" />
                        <Text style={styles.draftSavedText}>
                          {formatSavedTime(task.lastSavedAt)}
                        </Text>
                      </View>
                    )}
                    
                    {/* Form data info */}
                    {Object.keys(task.formData).length > 0 && (
                      <View style={styles.dataInfoRow}>
                        <Text style={styles.taskDataInfo}>
                          {Object.keys(task.formData).length} field(s) saved
                          {task.formType && ` • ${getFormTypeLabel(task.formType)}`}
                        </Text>
                      </View>
                    )}
                  </View>

                  <TouchableOpacity
                    style={styles.removeButton}
                    onPress={(e) => {
                      e.stopPropagation();
                      handleRemoveTask(task);
                    }}
                  >
                    <Ionicons name="close-circle" size={24} color="#EF4444" />
                  </TouchableOpacity>
                </TouchableOpacity>
              ))
            )}
          </ScrollView>

          {/* Footer Actions */}
          {activeTasks.length > 0 && (
            <View style={styles.footer}>
              <TouchableOpacity
                style={styles.clearAllButton}
                onPress={handleClearAll}
              >
                <Ionicons name="trash-outline" size={18} color="#EF4444" />
                <Text style={styles.clearAllText}>Clear All Tasks</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  container: {
    backgroundColor: 'white',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '80%',
    paddingBottom: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1F2937',
  },
  countBadge: {
    backgroundColor: '#3B82F6',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  countText: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
  },
  closeButton: {
    padding: 4,
  },
  description: {
    fontSize: 14,
    color: '#6B7280',
    paddingHorizontal: 20,
    paddingVertical: 12,
    backgroundColor: '#F9FAFB',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  taskList: {
    paddingHorizontal: 16,
    paddingTop: 12,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#374151',
    marginTop: 16,
  },
  emptyText: {
    fontSize: 14,
    color: '#9CA3AF',
    textAlign: 'center',
    marginTop: 8,
    paddingHorizontal: 40,
  },
  taskCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  taskCardUnsaved: {
    borderColor: '#F59E0B',
    backgroundColor: '#FFFBEB',
  },
  taskIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  taskInfo: {
    flex: 1,
  },
  taskTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  taskTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
  },
  unsavedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#FEF3C7',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
  },
  unsavedText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#92400E',
  },
  taskTime: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 4,
  },
  draftSavedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
  },
  draftSavedText: {
    fontSize: 11,
    color: '#10B981',
    fontWeight: '500',
  },
  dataInfoRow: {
    marginTop: 2,
  },
  taskDataInfo: {
    fontSize: 11,
    color: '#3B82F6',
  },
  removeButton: {
    padding: 4,
    marginLeft: 8,
  },
  footer: {
    paddingHorizontal: 20,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
  },
  clearAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    backgroundColor: '#FEE2E2',
    borderRadius: 10,
  },
  clearAllText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#EF4444',
  },
});
