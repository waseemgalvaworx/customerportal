import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../app/lib/supabase';

interface DeliveredCheckboxProps {
  jobId: string;
  onDeliveryStatusChange?: (delivered: boolean, deliveryDate: string | null) => void;
  onToggle?: () => void;
}


export default function DeliveredCheckbox({ jobId, onDeliveryStatusChange, onToggle }: DeliveredCheckboxProps) {

  const [delivered, setDelivered] = useState(false);
  const [deliveryDate, setDeliveryDate] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadDeliveryStatus();
  }, [jobId]);

  const loadDeliveryStatus = async () => {
    try {
      // Load from jobs table first (primary source of truth)
      const { data: jobData, error: jobError } = await supabase
        .from('jobs')
        .select('delivered, delivered_at')
        .eq('id', jobId)
        .single();

      if (jobError && jobError.code !== 'PGRST116') {
        console.error('Error loading delivery status from jobs:', jobError);
      }

      if (jobData) {
        setDelivered(jobData.delivered || false);
        setDeliveryDate(jobData.delivered_at);
      } else {
        // Fallback to completed_jobs table if jobs table doesn't have the data
        const { data: completedData, error: completedError } = await supabase
          .from('completed_jobs')
          .select('delivered, delivery_date, delivered_at')
          .eq('job_id', jobId)
          .single();

        if (completedError && completedError.code !== 'PGRST116') {
          console.error('Error loading delivery status from completed_jobs:', completedError);
          return;
        }

        if (completedData) {
          setDelivered(completedData.delivered || false);
          setDeliveryDate(completedData.delivered_at || completedData.delivery_date);
        }
      }
    } catch (error) {
      console.error('Error loading delivery status:', error);
    }
  };


  const toggleDelivered = async () => {
    if (loading) return;
    
    // Call onToggle callback to mark as viewed
    onToggle?.();
    
    const newDelivered = !delivered;
    const newDeliveryDate = newDelivered ? new Date().toISOString() : null;
    
    // Store previous state for rollback
    const prevDelivered = delivered;
    const prevDeliveryDate = deliveryDate;
    
    // Optimistic update
    setDelivered(newDelivered);
    setDeliveryDate(newDeliveryDate);
    setLoading(true);


    try {
      // Update both completed_jobs AND jobs tables for proper persistence
      const { error: completedJobsError } = await supabase
        .from('completed_jobs')
        .update({ 
          delivered: newDelivered,
          delivery_date: newDeliveryDate,
          delivered_at: newDeliveryDate
        })
        .eq('job_id', jobId);

      if (completedJobsError) throw completedJobsError;

      // Also update the jobs table so it persists across page refreshes
      const { error: jobsError } = await supabase
        .from('jobs')
        .update({ 
          delivered: newDelivered,
          delivered_at: newDeliveryDate
        })
        .eq('id', jobId);

      if (jobsError) throw jobsError;

      // Verify the update by reloading
      await loadDeliveryStatus();
      onDeliveryStatusChange?.(newDelivered, newDeliveryDate);
      
    } catch (error) {
      console.error('Error updating delivery status:', error);
      // Rollback on error
      setDelivered(prevDelivered);
      setDeliveryDate(prevDeliveryDate);
      Alert.alert('Error', 'Failed to update delivery status. Please try again.');
    } finally {
      setLoading(false);
    }
  };


  return (
    <View style={styles.container}>
      <TouchableOpacity 
        style={[styles.checkbox, delivered && styles.checkboxChecked]} 
        onPress={toggleDelivered}
        disabled={loading}
      >
        {delivered && <Ionicons name="checkmark" size={18} color="#fff" />}
      </TouchableOpacity>
      <View style={styles.textContainer}>
        <Text style={styles.label}>Delivered</Text>
        {deliveryDate && (
          <Text style={styles.dateText}>
            {new Date(deliveryDate).toLocaleString('en-GB', {
              day: '2-digit',
              month: '2-digit',
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            })}
          </Text>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  checkbox: { width: 24, height: 24, borderWidth: 2, borderColor: '#D1D5DB', borderRadius: 6, alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff' },
  checkboxChecked: { backgroundColor: '#10B981', borderColor: '#10B981' },
  textContainer: { flex: 1 },
  label: { fontSize: 13, fontWeight: '600', color: '#374151' },
  dateText: { fontSize: 11, color: '#10B981', marginTop: 2 }
});
