import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Modal, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '@/app/lib/supabase';
import HourlyProductionChart from './HourlyProductionChart';

interface HourlyData {
  hour: number;
  workshop: number;
  acid: number;
  galva: number;
  finishing: number;
  ready: number;
}

interface Props {
  visible: boolean;
  onClose: () => void;
  selectedDate: string | null;
}

export default function ArchivedHourlyProductionModal({ visible, onClose, selectedDate }: Props) {
  const [hourlyData, setHourlyData] = useState<HourlyData[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'chart' | 'table'>('chart');

  useEffect(() => {
    if (visible && selectedDate) {
      loadArchivedData();
    }
  }, [visible, selectedDate]);

  const loadArchivedData = async () => {
    if (!selectedDate) return;
    
    try {
      setLoading(true);
      const [day, month, year] = selectedDate.split('/');
      const dateString = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;

      const { data, error } = await supabase
        .from('hourly_production_stats')
        .select('*')
        .eq('date', dateString);

      if (error) throw error;

      const hourMap = new Map<number, HourlyData>();
      
      for (let h = 7; h <= 20; h++) {
        hourMap.set(h, { hour: h, workshop: 0, acid: 0, galva: 0, finishing: 0, ready: 0 });
      }

      data?.forEach((record: any) => {
        const hourData = hourMap.get(record.hour);
        if (hourData) {
          const status = record.status.toLowerCase();
          if (status in hourData) {
            (hourData as any)[status] = record.kgs_produced || 0;
          }
        }
      });

      setHourlyData(Array.from(hourMap.values()));
    } catch (error) {
      console.error('Error loading archived hourly data:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Hourly Production - {selectedDate}</Text>
          <TouchableOpacity onPress={onClose}>
            <Ionicons name="close" size={28} color="#333" />
          </TouchableOpacity>
        </View>

        <View style={styles.toggleContainer}>
          <TouchableOpacity
            style={[styles.toggleButton, viewMode === 'chart' && styles.activeToggle]}
            onPress={() => setViewMode('chart')}
          >
            <Text style={[styles.toggleText, viewMode === 'chart' && styles.activeToggleText]}>
              Chart View
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.toggleButton, viewMode === 'table' && styles.activeToggle]}
            onPress={() => setViewMode('table')}
          >
            <Text style={[styles.toggleText, viewMode === 'table' && styles.activeToggleText]}>
              Table View
            </Text>
          </TouchableOpacity>
        </View>

        {loading ? (
          <Text style={styles.loading}>Loading...</Text>
        ) : viewMode === 'chart' ? (
          <ScrollView style={styles.content}>
            <HourlyProductionChart data={hourlyData} />
          </ScrollView>
        ) : (
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <ScrollView style={styles.content}>
              <View style={styles.tableContainer}>
                <View style={styles.headerRow}>
                  <Text style={styles.headerCell}>Hour</Text>
                  <Text style={styles.headerCell}>W</Text>
                  <Text style={styles.headerCell}>A</Text>
                  <Text style={styles.headerCell}>G</Text>
                  <Text style={styles.headerCell}>F</Text>
                  <Text style={styles.headerCell}>R</Text>
                  <Text style={styles.headerCell}>Total</Text>
                </View>
                {hourlyData.map((row) => {
                  const total = row.workshop + row.acid + row.galva + row.finishing + row.ready;
                  return (
                    <View key={row.hour} style={styles.dataRow}>
                      <Text style={styles.hourCell}>{row.hour}:00</Text>
                      <Text style={styles.dataCell}>{row.workshop.toFixed(1)}</Text>
                      <Text style={styles.dataCell}>{row.acid.toFixed(1)}</Text>
                      <Text style={styles.dataCell}>{row.galva.toFixed(1)}</Text>
                      <Text style={styles.dataCell}>{row.finishing.toFixed(1)}</Text>
                      <Text style={styles.dataCell}>{row.ready.toFixed(1)}</Text>
                      <Text style={[styles.dataCell, styles.totalCell]}>{total.toFixed(1)}</Text>
                    </View>
                  );
                })}
              </View>
            </ScrollView>
          </ScrollView>
        )}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  title: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  toggleContainer: { flexDirection: 'row', justifyContent: 'center', padding: 15, gap: 10, backgroundColor: '#fff' },
  toggleButton: { paddingVertical: 10, paddingHorizontal: 20, borderRadius: 8, backgroundColor: '#e9ecef', borderWidth: 1, borderColor: '#dee2e6' },
  activeToggle: { backgroundColor: '#007bff', borderColor: '#007bff' },
  toggleText: { fontSize: 14, fontWeight: '600', color: '#495057' },
  activeToggleText: { color: '#fff' },
  content: { flex: 1, padding: 16 },
  loading: { padding: 20, textAlign: 'center', color: '#666' },
  tableContainer: { padding: 10 },
  headerRow: { flexDirection: 'row', borderBottomWidth: 2, borderColor: '#333', paddingBottom: 8 },
  headerCell: { width: 60, fontWeight: 'bold', textAlign: 'center', fontSize: 12 },
  dataRow: { flexDirection: 'row', paddingVertical: 6, borderBottomWidth: 1, borderColor: '#ddd' },
  hourCell: { width: 60, textAlign: 'center', fontSize: 11 },
  dataCell: { width: 60, textAlign: 'center', fontSize: 11 },
  totalCell: { fontWeight: 'bold', backgroundColor: '#e9ecef' },
});
