import React, { useState } from 'react';
import { View, Text, Modal, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { supabase } from '../app/lib/supabase';

interface AddVehicleModalProps {
  visible: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function AddVehicleModal({ visible, onClose, onSuccess }: AddVehicleModalProps) {
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [licensePlate, setLicensePlate] = useState('');
  const [make, setMake] = useState('');
  const [model, setModel] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!vehicleNumber.trim() || !licensePlate.trim() || !make.trim() || !model.trim()) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    setSaving(true);
    const { error } = await supabase.from('vehicles').insert({
      vehicle_number: vehicleNumber.trim(),
      license_plate: licensePlate.trim(),
      make: make.trim(),
      model: model.trim(),
      status: 'active'
    });

    setSaving(false);
    if (error) {
      Alert.alert('Error', error.message);
    } else {
      Alert.alert('Success', 'Vehicle added successfully');
      setVehicleNumber('');
      setLicensePlate('');
      setMake('');
      setModel('');
      onSuccess();
      onClose();
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <Text style={styles.title}>Add New Vehicle</Text>
          
          <TextInput
            style={styles.input}
            placeholder="Vehicle Number"
            value={vehicleNumber}
            onChangeText={setVehicleNumber}
          />
          
          <TextInput
            style={styles.input}
            placeholder="License Plate"
            value={licensePlate}
            onChangeText={setLicensePlate}
          />
          
          <TextInput
            style={styles.input}
            placeholder="Make (e.g., Toyota)"
            value={make}
            onChangeText={setMake}
          />
          
          <TextInput
            style={styles.input}
            placeholder="Model (e.g., Hilux)"
            value={model}
            onChangeText={setModel}
          />

          <View style={styles.buttons}>
            <TouchableOpacity style={styles.cancelButton} onPress={onClose}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.saveButton} onPress={handleSave} disabled={saving}>
              <Text style={styles.saveText}>{saving ? 'Saving...' : 'Save'}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: 'white', borderRadius: 12, padding: 20 },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 20 },
  input: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, padding: 12, marginBottom: 15, fontSize: 16 },
  buttons: { flexDirection: 'row', gap: 10, marginTop: 10 },
  cancelButton: { flex: 1, padding: 15, borderRadius: 8, borderWidth: 1, borderColor: '#d1d5db' },
  cancelText: { textAlign: 'center', fontSize: 16, color: '#6b7280' },
  saveButton: { flex: 1, padding: 15, borderRadius: 8, backgroundColor: '#2563eb' },
  saveText: { textAlign: 'center', fontSize: 16, color: 'white', fontWeight: '600' }
});
