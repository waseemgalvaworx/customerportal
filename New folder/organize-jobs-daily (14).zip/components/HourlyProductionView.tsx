import React, { useState, useEffect, useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { supabase } from '@/app/lib/supabase';
import HourlyProductionChart from './HourlyProductionChart';


interface HourlyData {
  hour: number;
  workshop: number;
  acid: number;
  galva: number;
  finishing: number;
  ready: number;
}

export default function HourlyProductionView({ date }: { date: Date }) {
  const [hourlyData, setHourlyData] = useState<HourlyData[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'chart' | 'table'>('chart');

  // Memoize the date string to prevent infinite re-renders
  const dateString = useMemo(() => date.toISOString().split('T')[0], [date.getTime()]);

  useEffect(() => {
    loadHourlyData();

    // OPTIMIZED: Realtime subscription with date filter
    // Using unique channel name with date to prevent conflicts
    const channelName = `hourly_prod_${dateString}`;
    const channel = supabase
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'hourly_production_stats',
          filter: `date=eq.${dateString}`
        },
        () => loadHourlyData()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [dateString]);



  const loadHourlyData = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('hourly_production_stats')
        .select('*')
        .eq('date', dateString);

      if (error) throw error;

      // Aggregate data by hour
      const hourMap = new Map<number, HourlyData>();
      
      // Initialize all work hours (7am-8pm)
      for (let h = 7; h <= 20; h++) {
        hourMap.set(h, {
          hour: h,
          workshop: 0,
          acid: 0,
          galva: 0,
          finishing: 0,
          ready: 0,
        });
      }

      // Fill in actual data
      data?.forEach((record: any) => {
        const hourData = hourMap.get(record.hour);
        if (hourData) {
          const status = record.status.toLowerCase();
          if (status in hourData) {
            (hourData as any)[status] = record.kgs_produced || 0;
          }
        }
      });

      setHourlyData(Array.from(hourMap.values()));
    } catch (error) {
      console.error('Error loading hourly data:', error);
    } finally {
      setLoading(false);
    }
  };

  const isBreakTime = (hour: number) => {
    return hour === 9 || hour === 11 || hour === 14; // Tea breaks and lunch
  };

  const isOvertimeHour = (hour: number) => {
    return hour >= 16 && hour <= 20; // 4pm-8pm
  };

  if (loading) {
    return <Text style={styles.loading}>Loading hourly data...</Text>;
  }

  return (
    <View style={styles.wrapper}>
      {/* Toggle Buttons */}
      <View style={styles.toggleContainer}>
        <TouchableOpacity
          style={[styles.toggleButton, viewMode === 'chart' && styles.activeToggle]}
          onPress={() => setViewMode('chart')}
        >
          <Text style={[styles.toggleText, viewMode === 'chart' && styles.activeToggleText]}>
            Chart View
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.toggleButton, viewMode === 'table' && styles.activeToggle]}
          onPress={() => setViewMode('table')}
        >
          <Text style={[styles.toggleText, viewMode === 'table' && styles.activeToggleText]}>
            Table View
          </Text>
        </TouchableOpacity>
      </View>

      {/* Conditional Rendering */}
      {viewMode === 'chart' ? (
        <HourlyProductionChart data={hourlyData} />
      ) : (
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View style={styles.container}>
            <View style={styles.headerRow}>
              <Text style={styles.headerCell}>Hour</Text>
              <Text style={styles.headerCell}>W</Text>
              <Text style={styles.headerCell}>A</Text>
              <Text style={styles.headerCell}>G</Text>
              <Text style={styles.headerCell}>F</Text>
              <Text style={styles.headerCell}>R</Text>
              <Text style={styles.headerCell}>Total</Text>
            </View>
            {hourlyData.map((row) => {
              const total = row.workshop + row.acid + row.galva + row.finishing + row.ready;
              const isBreak = isBreakTime(row.hour);
              const isOvertime = isOvertimeHour(row.hour);
              
              return (
                <View 
                  key={row.hour} 
                  style={[
                    styles.dataRow,
                    isBreak && styles.breakRow,
                    isOvertime && styles.overtimeRow
                  ]}
                >
                  <Text style={styles.hourCell}>
                    {row.hour}:00 {isBreak ? '☕' : ''} {isOvertime ? '⏰' : ''}
                  </Text>
                  <Text style={styles.dataCell}>{row.workshop.toFixed(1)}</Text>
                  <Text style={styles.dataCell}>{row.acid.toFixed(1)}</Text>
                  <Text style={styles.dataCell}>{row.galva.toFixed(1)}</Text>
                  <Text style={styles.dataCell}>{row.finishing.toFixed(1)}</Text>
                  <Text style={styles.dataCell}>{row.ready.toFixed(1)}</Text>
                  <Text style={[styles.dataCell, styles.totalCell]}>{total.toFixed(1)}</Text>
                </View>
              );
            })}
          </View>
        </ScrollView>
      )}
    </View>
  );

}

const styles = StyleSheet.create({
  wrapper: { flex: 1 },
  toggleContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 15,
    gap: 10,
  },
  toggleButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
    backgroundColor: '#e9ecef',
    borderWidth: 1,
    borderColor: '#dee2e6',
  },
  activeToggle: {
    backgroundColor: '#007bff',
    borderColor: '#007bff',
  },
  toggleText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#495057',
  },
  activeToggleText: {
    color: '#fff',
  },
  container: { padding: 10 },
  loading: { padding: 20, textAlign: 'center', color: '#666' },
  headerRow: { flexDirection: 'row', borderBottomWidth: 2, borderColor: '#333', paddingBottom: 8 },
  headerCell: { width: 60, fontWeight: 'bold', textAlign: 'center', fontSize: 12 },
  dataRow: { flexDirection: 'row', paddingVertical: 6, borderBottomWidth: 1, borderColor: '#ddd' },
  breakRow: { backgroundColor: '#fff3cd' },
  overtimeRow: { backgroundColor: '#d1ecf1' },
  hourCell: { width: 60, textAlign: 'center', fontSize: 11 },
  dataCell: { width: 60, textAlign: 'center', fontSize: 11 },
  totalCell: { fontWeight: 'bold', backgroundColor: '#e9ecef' },
});
