import React, { useState } from 'react';
import { View, Text, Modal, TouchableOpacity, StyleSheet, ScrollView, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { JobItem, ItemStatus } from '../contexts/JobContext';

interface SelectiveRevertModalProps {
  visible: boolean;
  jobNumber: string;
  items: JobItem[];
  onConfirm: (selectedItemIds: string[], targetStatus: ItemStatus) => void;
  onCancel: () => void;
}

const wipStatuses: ItemStatus[] = ['Pending', 'Workshop', 'Acid', 'Galva', 'Finishing', 'Ready'];
const statusColors: Record<ItemStatus, string> = {
  'Pending': '#9CA3AF', 'Workshop': '#3B82F6', 'Acid': '#F59E0B',
  'Galva': '#8B5CF6', 'Finishing': '#EC4899', 'Ready': '#059669'
};

export default function SelectiveRevertModal({ visible, jobNumber, items, onConfirm, onCancel }: SelectiveRevertModalProps) {
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [showStatusPicker, setShowStatusPicker] = useState(false);

  const toggleItem = (itemId: string) => {
    setSelectedItems(prev => {
      const newSet = new Set(prev);
      if (newSet.has(itemId)) newSet.delete(itemId);
      else newSet.add(itemId);
      return newSet;
    });
  };

  const handleNext = () => {
    if (selectedItems.size === 0) {
      Alert.alert('No Items Selected', 'Please select at least one item to revert');
      return;
    }
    setShowStatusPicker(true);
  };

  const handleStatusSelect = (status: ItemStatus) => {
    onConfirm(Array.from(selectedItems), status);
    setSelectedItems(new Set());
    setShowStatusPicker(false);
  };

  const handleCancel = () => {
    setSelectedItems(new Set());
    setShowStatusPicker(false);
    onCancel();
  };

  if (showStatusPicker) {
    return (
      <Modal animationType="slide" transparent={true} visible={visible} onRequestClose={handleCancel}>
        <View style={styles.overlay}>
          <View style={styles.content}>
            <Text style={styles.title}>Select WIP Status</Text>
            <Text style={styles.subtitle}>Choose status for {selectedItems.size} item(s)</Text>
            <ScrollView style={styles.statusList}>
              {wipStatuses.map(status => (
                <TouchableOpacity key={status} style={[styles.statusOption, { borderLeftColor: statusColors[status] }]}
                  onPress={() => handleStatusSelect(status)}>
                  <Text style={styles.statusText}>{status}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowStatusPicker(false)}>
              <Text style={styles.cancelText}>Back</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    );
  }

  return (
    <Modal animationType="slide" transparent={true} visible={visible} onRequestClose={handleCancel}>
      <View style={styles.overlay}>
        <View style={styles.content}>
          <Text style={styles.title}>Select Items to Revert</Text>
          <Text style={styles.subtitle}>Job {jobNumber}</Text>
          <ScrollView style={styles.itemList}>
            {items.map(item => (
              <TouchableOpacity key={item.id} style={styles.itemRow} onPress={() => toggleItem(item.id)}>
                <View style={styles.checkbox}>
                  {selectedItems.has(item.id) && <Ionicons name="checkmark" size={18} color="#fff" />}
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.itemDesc}>{item.descriptionOfWorks}</Text>
                  <Text style={styles.itemWeight}>{item.weightKg} kg</Text>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
          <View style={styles.btnRow}>
            <TouchableOpacity style={styles.cancelBtn} onPress={handleCancel}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.nextBtn} onPress={handleNext}>
              <Text style={styles.nextText}>Next ({selectedItems.size})</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  content: { backgroundColor: 'white', borderRadius: 20, padding: 20, width: '85%', maxHeight: '80%' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 8, textAlign: 'center', color: '#1F2937' },
  subtitle: { fontSize: 14, color: '#6B7280', marginBottom: 16, textAlign: 'center' },
  itemList: { maxHeight: 400 },
  itemRow: { flexDirection: 'row', alignItems: 'center', padding: 12, backgroundColor: '#F9FAFB', borderRadius: 8, marginBottom: 8 },
  checkbox: { width: 24, height: 24, borderRadius: 6, borderWidth: 2, borderColor: '#3B82F6', marginRight: 12, backgroundColor: '#3B82F6', justifyContent: 'center', alignItems: 'center' },
  itemDesc: { fontSize: 14, color: '#374151', fontWeight: '500' },
  itemWeight: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  btnRow: { flexDirection: 'row', gap: 12, marginTop: 16 },
  cancelBtn: { flex: 1, padding: 12, alignItems: 'center', backgroundColor: '#F3F4F6', borderRadius: 8 },
  cancelText: { color: '#6B7280', fontSize: 16, fontWeight: '600' },
  nextBtn: { flex: 1, padding: 12, alignItems: 'center', backgroundColor: '#3B82F6', borderRadius: 8 },
  nextText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  statusList: { maxHeight: 400 },
  statusOption: { padding: 16, borderLeftWidth: 4, marginBottom: 8, backgroundColor: '#F9FAFB', borderRadius: 8 },
  statusText: { fontSize: 16, color: '#374151', fontWeight: '500' }
});
