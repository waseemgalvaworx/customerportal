import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TouchableOpacity, ScrollView, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { listBackups, downloadBackup, restoreBackup } from '../utils/backupManager';

interface BackupRestoreModalProps {
  visible: boolean;
  onClose: () => void;
}

export default function BackupRestoreModal({ visible, onClose }: BackupRestoreModalProps) {
  const [backups, setBackups] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedBackup, setSelectedBackup] = useState<any>(null);
  const [previewData, setPreviewData] = useState<any>(null);
  const [restoring, setRestoring] = useState(false);

  useEffect(() => {
    if (visible) {
      loadBackups();
    }
  }, [visible]);

  const loadBackups = async () => {
    setLoading(true);
    try {
      const data = await listBackups();
      setBackups(data);
    } catch (error) {
      Alert.alert('Error', 'Failed to load backups');
    } finally {
      setLoading(false);
    }
  };

  const handlePreview = async (backup: any) => {
    setLoading(true);
    try {
      const data = await downloadBackup(backup.name);
      setPreviewData(data);
      setSelectedBackup(backup);
    } catch (error) {
      Alert.alert('Error', 'Failed to load backup preview');
    } finally {
      setLoading(false);
    }
  };

  const handleRestore = () => {
    Alert.alert(
      'Confirm Restore',
      'This will replace all current data with the backup. Are you sure?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Restore', style: 'destructive', onPress: performRestore }
      ]
    );
  };

  const performRestore = async () => {
    if (!previewData) return;
    
    setRestoring(true);
    try {
      const results = await restoreBackup(previewData);
      Alert.alert(
        'Restore Complete',
        `Success: ${results.success.length} tables\nFailed: ${results.failed.length} tables`
      );
      onClose();
    } catch (error) {
      Alert.alert('Error', 'Failed to restore backup');
    } finally {
      setRestoring(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <View style={styles.header}>
            <Text style={styles.title}>Restore Backup</Text>
            <TouchableOpacity onPress={onClose}>
              <Ionicons name="close" size={28} color="#111827" />
            </TouchableOpacity>
          </View>

          {loading && <ActivityIndicator size="large" color="#6366F1" style={styles.loader} />}

          {!previewData ? (
            <ScrollView style={styles.list}>
              {backups.map((backup, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.backupItem}
                  onPress={() => handlePreview(backup)}
                >
                  <Ionicons name="document" size={24} color="#6366F1" />
                  <View style={styles.backupInfo}>
                    <Text style={styles.backupName}>{backup.name}</Text>
                    <Text style={styles.backupDate}>
                      {new Date(backup.created_at).toLocaleString()}
                    </Text>
                  </View>
                  <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
                </TouchableOpacity>
              ))}
            </ScrollView>
          ) : (
            <View style={styles.preview}>
              <Text style={styles.previewTitle}>Backup Preview</Text>
              <ScrollView style={styles.previewScroll}>
                <Text style={styles.previewText}>
                  Timestamp: {previewData.timestamp}
                </Text>
                <Text style={styles.previewText}>
                  Version: {previewData.version}
                </Text>
                <Text style={styles.previewText}>Tables:</Text>
                {Object.keys(previewData.tables).map((table, i) => (
                  <Text key={i} style={styles.tableItem}>
                    • {table}: {previewData.tables[table]?.length || 0} records
                  </Text>
                ))}
              </ScrollView>
              <View style={styles.actions}>
                <TouchableOpacity
                  style={styles.backButton}
                  onPress={() => setPreviewData(null)}
                >
                  <Text style={styles.backButtonText}>Back</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.restoreButton, restoring && styles.restoreButtonDisabled]}
                  onPress={handleRestore}
                  disabled={restoring}
                >
                  {restoring ? (
                    <ActivityIndicator size="small" color="#fff" />
                  ) : (
                    <Text style={styles.restoreButtonText}>Restore</Text>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: '#fff', borderRadius: 16, maxHeight: '80%', overflow: 'hidden' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  title: { fontSize: 20, fontWeight: 'bold', color: '#111827' },
  loader: { padding: 40 },
  list: { maxHeight: 400 },
  backupItem: { flexDirection: 'row', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  backupInfo: { flex: 1, marginLeft: 12 },
  backupName: { fontSize: 16, fontWeight: '600', color: '#111827' },
  backupDate: { fontSize: 14, color: '#6B7280', marginTop: 4 },
  preview: { padding: 20 },
  previewTitle: { fontSize: 18, fontWeight: 'bold', color: '#111827', marginBottom: 12 },
  previewScroll: { maxHeight: 300, marginBottom: 20 },
  previewText: { fontSize: 14, color: '#374151', marginBottom: 8 },
  tableItem: { fontSize: 14, color: '#6B7280', marginLeft: 16, marginBottom: 4 },
  actions: { flexDirection: 'row', gap: 12 },
  backButton: { flex: 1, padding: 14, backgroundColor: '#E5E7EB', borderRadius: 8, alignItems: 'center' },
  backButtonText: { fontSize: 16, fontWeight: '600', color: '#374151' },
  restoreButton: { flex: 1, padding: 14, backgroundColor: '#EF4444', borderRadius: 8, alignItems: 'center' },
  restoreButtonDisabled: { backgroundColor: '#9CA3AF' },
  restoreButtonText: { fontSize: 16, fontWeight: '600', color: '#fff' },
});
