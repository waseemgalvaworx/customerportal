import React, { useState, useEffect, useRef } from 'react';
import { View, Text, Modal, TouchableOpacity, TextInput, ScrollView, StyleSheet, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '@/app/lib/supabase';
import { usePasswordAuth } from '@/contexts/PasswordAuthContext';
import { logInventoryAction } from '@/utils/inventoryLogger';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ALLOWED_TASK_USERS } from '@/contexts/TaskContext';

interface EditInventoryItemModalProps {
  visible: boolean;
  onClose: () => void;
  item: any;
  onSuccess: () => void;
}

const DRAFT_KEY_PREFIX = 'edit_inventory_item_draft_';

interface DraftData {
  itemName: string;
  initialQuantity: string;
  unit: string;
  reorderLevel: string;
  supplier: string;
  costPerUnit: string;
  sellingPrice: string;
  location: string;
  notes: string;
  itemId: string;
  savedAt: number;
}

export default function EditInventoryItemModal({ visible, onClose, item, onSuccess }: EditInventoryItemModalProps) {
  const { user } = usePasswordAuth();
  const [itemName, setItemName] = useState('');
  const [initialQuantity, setInitialQuantity] = useState('');
  const [unit, setUnit] = useState('');
  const [reorderLevel, setReorderLevel] = useState('');
  const [supplier, setSupplier] = useState('');
  const [costPerUnit, setCostPerUnit] = useState('');
  const [sellingPrice, setSellingPrice] = useState('');
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [showDraftIndicator, setShowDraftIndicator] = useState(false);
  const [hasDraft, setHasDraft] = useState(false);
  const initialLoadDone = useRef(false);

  // Check if user is allowed to use draft feature
  const canUseDrafts = ALLOWED_TASK_USERS.includes(user?.username || '');
  
  // Get draft key for this specific item
  const getDraftKey = () => `${DRAFT_KEY_PREFIX}${item?.id || 'unknown'}`;

  // Load item data or draft when modal opens
  useEffect(() => {
    if (item && visible) {
      initialLoadDone.current = false;
      if (canUseDrafts) {
        loadDraftOrItemData();
      } else {
        loadItemData();
      }
    }
  }, [item, visible, canUseDrafts]);

  // Auto-save draft when form changes (only after initial load)
  useEffect(() => {
    if (visible && canUseDrafts && initialLoadDone.current && hasFormChanges()) {
      const timeout = setTimeout(() => {
        saveDraft();
      }, 1000); // Debounce 1 second
      return () => clearTimeout(timeout);
    }
  }, [itemName, initialQuantity, unit, reorderLevel, supplier, costPerUnit, sellingPrice, location, notes, visible]);

  const loadItemData = () => {
    setItemName(item.item_name || '');
    setInitialQuantity(item.initial_quantity?.toString() || '0');
    setUnit(item.unit || '');
    setReorderLevel(item.reorder_level?.toString() || '');
    setSupplier(item.supplier || '');
    setCostPerUnit(item.cost_per_unit?.toString() || '');
    setSellingPrice(item.selling_price?.toString() || '');
    setLocation(item.location || '');
    setNotes(item.notes || '');
    setTimeout(() => { initialLoadDone.current = true; }, 100);
  };

  const loadDraftOrItemData = async () => {
    try {
      const draftStr = await AsyncStorage.getItem(getDraftKey());
      if (draftStr) {
        const draft: DraftData = JSON.parse(draftStr);
        // Only load if draft is less than 24 hours old and for the same item
        if (Date.now() - draft.savedAt < 24 * 60 * 60 * 1000 && draft.itemId === item.id) {
          setItemName(draft.itemName || '');
          setInitialQuantity(draft.initialQuantity || '0');
          setUnit(draft.unit || '');
          setReorderLevel(draft.reorderLevel || '');
          setSupplier(draft.supplier || '');
          setCostPerUnit(draft.costPerUnit || '');
          setSellingPrice(draft.sellingPrice || '');
          setLocation(draft.location || '');
          setNotes(draft.notes || '');
          setHasDraft(true);
          setTimeout(() => { initialLoadDone.current = true; }, 100);
          return;
        } else {
          // Clear old or different item draft
          await AsyncStorage.removeItem(getDraftKey());
        }
      }
      // No valid draft, load from item
      loadItemData();
    } catch (error) {
      console.error('Error loading draft:', error);
      loadItemData();
    }
  };

  const hasFormChanges = () => {
    if (!item) return false;
    return (
      itemName !== (item.item_name || '') ||
      initialQuantity !== (item.initial_quantity?.toString() || '0') ||
      unit !== (item.unit || '') ||
      reorderLevel !== (item.reorder_level?.toString() || '') ||
      supplier !== (item.supplier || '') ||
      costPerUnit !== (item.cost_per_unit?.toString() || '') ||
      sellingPrice !== (item.selling_price?.toString() || '') ||
      location !== (item.location || '') ||
      notes !== (item.notes || '')
    );
  };

  const saveDraft = async () => {
    try {
      const draft: DraftData = {
        itemName,
        initialQuantity,
        unit,
        reorderLevel,
        supplier,
        costPerUnit,
        sellingPrice,
        location,
        notes,
        itemId: item.id,
        savedAt: Date.now()
      };
      await AsyncStorage.setItem(getDraftKey(), JSON.stringify(draft));
      setShowDraftIndicator(true);
      setHasDraft(true);
      setTimeout(() => setShowDraftIndicator(false), 2000);
    } catch (error) {
      console.error('Error saving draft:', error);
    }
  };

  const clearDraft = async () => {
    try {
      await AsyncStorage.removeItem(getDraftKey());
      setHasDraft(false);
    } catch (error) {
      console.error('Error clearing draft:', error);
    }
  };

  const handleClearDraft = () => {
    Alert.alert(
      'Discard Changes',
      'Are you sure you want to discard your changes and restore the original values?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Discard', 
          style: 'destructive',
          onPress: async () => {
            await clearDraft();
            loadItemData();
          }
        }
      ]
    );
  };


  const handleSave = async () => {
    console.log('🔴 [EDIT ITEM] handleSave CALLED');
    if (!itemName.trim()) {
      Alert.alert('Required', 'Item name is required');
      return;
    }

    setSaving(true);
    
    const updates = {
      item_name: itemName.trim(),
      initial_quantity: parseFloat(initialQuantity) || 0,
      unit: unit.trim() || 'units',
      reorder_level: reorderLevel ? parseFloat(reorderLevel) : null,
      supplier: supplier.trim() || null,
      cost_per_unit: costPerUnit ? parseFloat(costPerUnit) : null,
      selling_price: sellingPrice ? parseFloat(sellingPrice) : null,
      location: location.trim() || null,
      notes: notes.trim() || null
    };

    
    console.log('📤 [EDIT ITEM] Updating:', updates);

    
    try {
      const { error } = await supabase.from('inventory_items').update(updates).eq('id', item.id);
      
      setSaving(false);
      
      if (error) {
        console.error('❌ [EDIT ITEM] Error:', error);
        Alert.alert('Error', error.message);
      } else {
        console.log('✅ [EDIT ITEM] Success');
        
        // Log the action
        const categoryDisplay = item.category === 'raw_materials' ? 'Raw Materials'
                              : item.category === 'finished_goods' ? 'Direct Sale'
                              : 'By Products';
        
        await logInventoryAction({
          action: 'edit',
          item_id: item.id,
          item_name: itemName.trim(),
          category: categoryDisplay,
          old_value: item,
          new_value: updates,
          notes: `Updated item details`,
          performed_by: user?.username || 'Unknown'
        });
        
        // Clear draft on successful save
        await clearDraft();
        
        Alert.alert('Success', 'Item updated');
        onSuccess();
        onClose();
      }

    } catch (err) {
      console.error('💥 [EDIT ITEM] Exception:', err);
      setSaving(false);
      Alert.alert('Error', 'Failed to update');
    }
  };

  const handleClose = () => {
    // Don't clear draft on close - keep it for later
    onClose();
  };

  if (!visible || !item) return null;

  return (
    <Modal visible={true} animationType="slide" onRequestClose={handleClose}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Edit Item</Text>
          <View style={styles.headerRight}>
            {canUseDrafts && showDraftIndicator && (
              <View style={styles.draftIndicator}>
                <Ionicons name="cloud-done" size={14} color="#10B981" />
                <Text style={styles.draftIndicatorText}>Saved</Text>
              </View>
            )}
            <TouchableOpacity onPress={handleClose}>
              <Ionicons name="close" size={24} color="#666" />
            </TouchableOpacity>
          </View>
        </View>
        
        {canUseDrafts && hasDraft && (
          <TouchableOpacity style={styles.draftBanner} onPress={handleClearDraft}>
            <Ionicons name="document-text-outline" size={16} color="#3B82F6" />
            <Text style={styles.draftBannerText}>Unsaved changes restored - tap to discard</Text>
            <Ionicons name="close-circle" size={18} color="#6B7280" />
          </TouchableOpacity>
        )}
        
        <ScrollView contentContainerStyle={styles.form} keyboardShouldPersistTaps="handled">
          <Text style={styles.label}>Item Name *</Text>
          <TextInput style={styles.input} value={itemName} onChangeText={setItemName} />
          
          <Text style={styles.label}>Initial Quantity (for report opening balance)</Text>
          <TextInput style={styles.input} value={initialQuantity} onChangeText={setInitialQuantity} keyboardType="decimal-pad" placeholder="Starting balance for reports" />
          
          <Text style={styles.label}>Unit (defaults to 'units' if empty)</Text>
          <TextInput style={styles.input} value={unit} onChangeText={setUnit} placeholder="e.g., kg, pcs, L, units" />


          
          <Text style={styles.label}>Reorder Level</Text>
          <TextInput style={styles.input} value={reorderLevel} onChangeText={setReorderLevel} keyboardType="decimal-pad" />
          
          <Text style={styles.label}>Supplier</Text>
          <TextInput style={styles.input} value={supplier} onChangeText={setSupplier} />
          
          <Text style={styles.label}>Cost Per Unit</Text>
          <TextInput style={styles.input} value={costPerUnit} onChangeText={setCostPerUnit} keyboardType="decimal-pad" />
          
          <Text style={styles.label}>Selling Price</Text>
          <TextInput style={styles.input} value={sellingPrice} onChangeText={setSellingPrice} keyboardType="decimal-pad" />
          
          <Text style={styles.label}>Location</Text>
          <TextInput style={styles.input} value={location} onChangeText={setLocation} />
          
          <Text style={styles.label}>Notes</Text>
          <TextInput style={[styles.input, styles.textArea]} value={notes} onChangeText={setNotes} multiline numberOfLines={3} />
          
          <View style={{ height: 100 }} />
        </ScrollView>
        
        <View style={styles.footer} pointerEvents="box-none">
          <TouchableOpacity 
            onPress={handleSave}
            style={[styles.saveButton, saving && styles.disabled]} 
            disabled={saving}
          >
            <Text style={styles.saveButtonText}>{saving ? 'Saving...' : 'Update Item'}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#ddd' },
  title: { fontSize: 20, fontWeight: 'bold' },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  draftIndicator: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#ECFDF5', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  draftIndicatorText: { fontSize: 11, color: '#059669', fontWeight: '500' },
  draftBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#EFF6FF', padding: 12, marginHorizontal: 16, marginTop: 12, borderRadius: 8 },
  draftBannerText: { flex: 1, fontSize: 12, color: '#3B82F6', fontWeight: '500' },
  closeText: { fontSize: 24, color: '#666', padding: 8 },
  form: { padding: 16, paddingBottom: 120 },
  label: { fontSize: 14, fontWeight: '600', marginBottom: 8, marginTop: 12, color: '#333' },
  input: { backgroundColor: '#fff', padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#ddd', fontSize: 16 },
  textArea: { height: 80, textAlignVertical: 'top' },
  footer: { 
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#fff', 
    padding: 16, 
    borderTopWidth: 1, 
    borderTopColor: '#ddd',
    zIndex: 1000
  },
  saveButton: { 
    backgroundColor: '#007AFF', 
    padding: 16, 
    borderRadius: 8,
    alignItems: 'center'
  },
  disabled: { backgroundColor: '#999' },
  saveButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 }
});
