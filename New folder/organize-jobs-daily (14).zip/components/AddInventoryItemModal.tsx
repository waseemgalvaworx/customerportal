import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TouchableOpacity, TextInput, ScrollView, StyleSheet, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '@/app/lib/supabase';
import { usePasswordAuth } from '@/contexts/PasswordAuthContext';
import { logInventoryAction } from '@/utils/inventoryLogger';
import { notifyAllUsers } from '@/utils/notificationHelper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ALLOWED_TASK_USERS } from '@/contexts/TaskContext';

interface AddInventoryItemModalProps {
  visible: boolean;
  onClose: () => void;
  category: string;
  onSuccess: () => void;
}

const DRAFT_KEY = 'add_inventory_item_draft';

interface DraftData {
  itemName: string;
  initialQuantity: string;
  unit: string;
  reorderLevel: string;
  supplier: string;
  costPerUnit: string;
  sellingPrice: string;
  location: string;
  notes: string;
  category: string;
  savedAt: number;
}

export default function AddInventoryItemModal({ visible, onClose, category, onSuccess }: AddInventoryItemModalProps) {
  const { user } = usePasswordAuth();
  const [itemName, setItemName] = useState('');
  const [initialQuantity, setInitialQuantity] = useState('');
  const [unit, setUnit] = useState('');
  const [reorderLevel, setReorderLevel] = useState('');
  const [supplier, setSupplier] = useState('');
  const [costPerUnit, setCostPerUnit] = useState('');
  const [sellingPrice, setSellingPrice] = useState('');
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [showDraftIndicator, setShowDraftIndicator] = useState(false);
  const [hasDraft, setHasDraft] = useState(false);

  // Check if user is allowed to use draft feature
  const canUseDrafts = ALLOWED_TASK_USERS.includes(user?.username || '');

  useEffect(() => {
    console.log('🔵 [ADD ITEM] Modal visible changed:', visible);
    if (visible && canUseDrafts) {
      loadDraft();
    }
  }, [visible, canUseDrafts]);

  // Auto-save draft when form changes
  useEffect(() => {
    if (visible && canUseDrafts && hasFormData()) {
      const timeout = setTimeout(() => {
        saveDraft();
      }, 1000); // Debounce 1 second
      return () => clearTimeout(timeout);
    }
  }, [itemName, initialQuantity, unit, reorderLevel, supplier, costPerUnit, sellingPrice, location, notes, visible]);

  const hasFormData = () => {
    return itemName.trim() || initialQuantity.trim() || unit.trim() || supplier.trim() || notes.trim() || location.trim();
  };

  const loadDraft = async () => {
    try {
      const draftStr = await AsyncStorage.getItem(DRAFT_KEY);
      if (draftStr) {
        const draft: DraftData = JSON.parse(draftStr);
        // Only load if draft is less than 24 hours old and same category
        if (Date.now() - draft.savedAt < 24 * 60 * 60 * 1000 && draft.category === category) {
          setItemName(draft.itemName || '');
          setInitialQuantity(draft.initialQuantity || '');
          setUnit(draft.unit || '');
          setReorderLevel(draft.reorderLevel || '');
          setSupplier(draft.supplier || '');
          setCostPerUnit(draft.costPerUnit || '');
          setSellingPrice(draft.sellingPrice || '');
          setLocation(draft.location || '');
          setNotes(draft.notes || '');
          setHasDraft(true);
        } else {
          // Clear old or different category draft
          await AsyncStorage.removeItem(DRAFT_KEY);
        }
      }
    } catch (error) {
      console.error('Error loading draft:', error);
    }
  };

  const saveDraft = async () => {
    try {
      const draft: DraftData = {
        itemName,
        initialQuantity,
        unit,
        reorderLevel,
        supplier,
        costPerUnit,
        sellingPrice,
        location,
        notes,
        category,
        savedAt: Date.now()
      };
      await AsyncStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
      setShowDraftIndicator(true);
      setHasDraft(true);
      setTimeout(() => setShowDraftIndicator(false), 2000);
    } catch (error) {
      console.error('Error saving draft:', error);
    }
  };

  const clearDraft = async () => {
    try {
      await AsyncStorage.removeItem(DRAFT_KEY);
      setHasDraft(false);
    } catch (error) {
      console.error('Error clearing draft:', error);
    }
  };

  const handleClearDraft = () => {
    Alert.alert(
      'Clear Draft',
      'Are you sure you want to clear the saved draft?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Clear', 
          style: 'destructive',
          onPress: async () => {
            await clearDraft();
            resetForm();
          }
        }
      ]
    );
  };

  const resetForm = () => {
    setItemName('');
    setInitialQuantity('');
    setUnit('');
    setReorderLevel('');
    setSupplier('');
    setCostPerUnit('');
    setSellingPrice('');
    setLocation('');
    setNotes('');
    setHasDraft(false);
  };

  const handleSave = async () => {
    console.log('🔴 [ADD ITEM] handleSave CALLED');
    if (!itemName.trim()) {
      Alert.alert('Required', 'Item name is required');
      return;
    }

    setSaving(true);
    
    // Convert display category to database format
    const dbCategory = category === 'Raw Materials' ? 'raw_materials' 
                     : category === 'Direct Sale' ? 'finished_goods'
                     : 'by_products';
    
    const initialQty = parseFloat(initialQuantity) || 0;
    
    const itemData = {
      item_name: itemName.trim(),
      category: dbCategory,
      initial_quantity: initialQty,
      quantity: initialQty, // Set current stock to initial quantity
      unit: unit.trim() || 'units',
      reorder_level: reorderLevel ? parseFloat(reorderLevel) : null,
      supplier: supplier.trim() || null,
      cost_per_unit: costPerUnit ? parseFloat(costPerUnit) : null,
      selling_price: sellingPrice ? parseFloat(sellingPrice) : null,
      location: location.trim() || null,
      notes: notes.trim() || null
    };



    
    console.log('📤 [ADD ITEM] Inserting:', itemData);

    
    try {
      const { data, error } = await supabase.from('inventory_items').insert(itemData).select();
      
      if (error) {
        console.error('❌ [ADD ITEM] Error:', error);
        setSaving(false);
        Alert.alert('Error', error.message);
        return;
      }
      
      console.log('✅ [ADD ITEM] Success');
      
      // Create opening balance transaction if quantity > 0
      if (initialQty > 0 && data && data[0]) {
        const newItem = data[0];
        const { error: transError } = await supabase
          .from('inventory_transactions')
          .insert({
            item_id: newItem.id,
            transaction_type: 'in',
            quantity: initialQty,
            notes: 'Opening Balance'
            // performed_by removed to avoid foreign key constraint error
          });
        
        if (transError) {
          console.error('❌ [ADD ITEM] Opening balance transaction error:', transError);
          Alert.alert('Warning', 'Item created but opening balance transaction failed. Please add stock manually.');
        } else {
          console.log('✅ [ADD ITEM] Opening balance transaction created:', initialQty, data[0].unit);
        }
      }





      
      // Log the action
      if (data && data[0]) {
        await logInventoryAction({
          action: 'add',
          item_id: data[0].id,
          item_name: itemName.trim(),
          category: category,
          new_quantity: initialQty,
          notes: `Added new item with initial quantity`,
          performed_by: user?.username || 'Unknown'
        });
      }
      
      // Send notification to all users
      await notifyAllUsers({
        title: 'New Inventory Item Added',
        message: `${itemName.trim()} has been added to ${category} by ${user?.username || 'Unknown'}`,
        type: 'inventory',
        priority: 'normal'
      });
      
      // Clear draft on successful save
      await clearDraft();
      
      setSaving(false);
      Alert.alert('Success', 'Item added');
      resetForm();

      onSuccess();
      onClose();



    } catch (err) {
      console.error('💥 [ADD ITEM] Exception:', err);
      setSaving(false);
      Alert.alert('Error', 'Failed to save');
    }
  };

  const handleClose = () => {
    // Don't clear draft on close - keep it for later
    onClose();
  };

  if (!visible) return null;

  return (
    <Modal visible={true} animationType="slide" onRequestClose={handleClose}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Add Item - {category}</Text>
          <View style={styles.headerRight}>
            {canUseDrafts && showDraftIndicator && (
              <View style={styles.draftIndicator}>
                <Ionicons name="cloud-done" size={14} color="#10B981" />
                <Text style={styles.draftIndicatorText}>Saved</Text>
              </View>
            )}
            <TouchableOpacity onPress={handleClose}>
              <Ionicons name="close" size={24} color="#666" />
            </TouchableOpacity>
          </View>
        </View>
        
        {canUseDrafts && hasDraft && (
          <TouchableOpacity style={styles.draftBanner} onPress={handleClearDraft}>
            <Ionicons name="document-text-outline" size={16} color="#3B82F6" />
            <Text style={styles.draftBannerText}>Draft restored from previous session</Text>
            <Ionicons name="close-circle" size={18} color="#6B7280" />
          </TouchableOpacity>
        )}
        
        <ScrollView contentContainerStyle={styles.form} keyboardShouldPersistTaps="handled">
          <Text style={styles.label}>Item Name *</Text>
          <TextInput style={styles.input} value={itemName} onChangeText={setItemName} />
          
          <Text style={styles.label}>Initial Stock Quantity</Text>
          <TextInput 
            style={styles.input} 
            value={initialQuantity} 
            onChangeText={setInitialQuantity} 
            keyboardType="decimal-pad" 
            placeholder="Enter starting quantity" 
          />
          
          <Text style={styles.label}>Unit (defaults to 'units' if empty)</Text>
          <TextInput style={styles.input} value={unit} onChangeText={setUnit} placeholder="e.g., kg, pcs, L, units" />

          <Text style={styles.label}>Reorder Level</Text>
          <TextInput style={styles.input} value={reorderLevel} onChangeText={setReorderLevel} keyboardType="decimal-pad" />
          
          <Text style={styles.label}>Supplier</Text>
          <TextInput style={styles.input} value={supplier} onChangeText={setSupplier} />
          
          <Text style={styles.label}>Cost Per Unit</Text>
          <TextInput style={styles.input} value={costPerUnit} onChangeText={setCostPerUnit} keyboardType="decimal-pad" />
          
          <Text style={styles.label}>Selling Price</Text>
          <TextInput style={styles.input} value={sellingPrice} onChangeText={setSellingPrice} keyboardType="decimal-pad" />
          
          <Text style={styles.label}>Location</Text>
          <TextInput style={styles.input} value={location} onChangeText={setLocation} />
          
          <Text style={styles.label}>Notes</Text>
          <TextInput style={[styles.input, styles.textArea]} value={notes} onChangeText={setNotes} multiline numberOfLines={3} />
          
          <View style={{ height: 100 }} />
        </ScrollView>

        
        <View style={styles.footer} pointerEvents="box-none">
          <TouchableOpacity 
            onPress={handleSave}
            style={[styles.saveButton, saving && styles.disabled]} 
            disabled={saving}
          >
            <Text style={styles.saveButtonText}>{saving ? 'Saving...' : 'Save Item'}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#ddd' },
  title: { fontSize: 20, fontWeight: 'bold' },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  draftIndicator: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#ECFDF5', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  draftIndicatorText: { fontSize: 11, color: '#059669', fontWeight: '500' },
  draftBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#EFF6FF', padding: 12, marginHorizontal: 16, marginTop: 12, borderRadius: 8 },
  draftBannerText: { flex: 1, fontSize: 12, color: '#3B82F6', fontWeight: '500' },
  closeText: { fontSize: 24, color: '#666', padding: 8 },
  form: { padding: 16, paddingBottom: 120 },
  label: { fontSize: 14, fontWeight: '600', marginBottom: 8, marginTop: 12, color: '#333' },
  input: { backgroundColor: '#fff', padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#ddd', fontSize: 16 },
  textArea: { height: 80, textAlignVertical: 'top' },
  footer: { 
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#fff', 
    padding: 16, 
    borderTopWidth: 1, 
    borderTopColor: '#ddd',
    zIndex: 1000
  },
  saveButton: { 
    backgroundColor: '#007AFF', 
    padding: 16, 
    borderRadius: 8,
    alignItems: 'center'
  },
  disabled: { backgroundColor: '#999' },
  saveButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 }
});
