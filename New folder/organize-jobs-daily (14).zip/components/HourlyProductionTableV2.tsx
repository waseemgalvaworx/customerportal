import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, TextInput } from 'react-native';
import { supabase } from '@/app/lib/supabase';
import { TIME_SLOTS, DEPARTMENTS } from '@/utils/hourlyProductionTrackerV2';

interface HourlyData {
  [hourSlot: string]: {
    [department: string]: number;
  };
}

export default function HourlyProductionTableV2() {
  const [data, setData] = useState<HourlyData>({});
  const [loading, setLoading] = useState(true);
  const [shiftName, setShiftName] = useState('');
  const [notes, setNotes] = useState('');
  const today = new Date().toISOString().split('T')[0];

  useEffect(() => {
    loadTodayData();
    
    // OPTIMIZED: Unique channel name with date filter
    const channelName = `hourly_prod_table_${today}`;
    const subscription = supabase
      .channel(channelName)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'hourly_production_stats',
        filter: `date=eq.${today}`
      }, () => loadTodayData())
      .subscribe();

    return () => {
      supabase.removeChannel(subscription);
    };
  }, []);


  const loadTodayData = async () => {
    const { data: stats, error } = await supabase
      .from('hourly_production_stats')
      .select('*')
      .eq('date', today);

    if (error) {
      console.error('Error loading hourly stats:', error);
      setLoading(false);
      return;
    }

    const organized: HourlyData = {};
    TIME_SLOTS.forEach(slot => {
      organized[slot] = {};
      DEPARTMENTS.forEach(dept => {
        organized[slot][dept] = 0;
      });
    });

    stats?.forEach(stat => {
      if (organized[stat.hour_slot]) {
        organized[stat.hour_slot][stat.department] = 
          (organized[stat.hour_slot][stat.department] || 0) + parseFloat(stat.weight_kg || 0);
      }
    });

    setData(organized);
    setLoading(false);
  };

  const saveSnapshot = async () => {
    if (!shiftName.trim()) {
      Alert.alert('Error', 'Please enter a shift name');
      return;
    }

    const { data: user } = await supabase.auth.getUser();
    
    const { error } = await supabase
      .from('hourly_production_snapshots')
      .insert({
        date: today,
        shift_name: shiftName,
        data: data,
        saved_by: user.user?.id,
        notes: notes.trim() || null
      });

    if (error) {
      Alert.alert('Error', 'Failed to save snapshot');
      console.error(error);
    } else {
      Alert.alert('Success', 'Shift data saved successfully');
      setShiftName('');
      setNotes('');
    }
  };

  if (loading) return <Text style={styles.loading}>Loading...</Text>;

  return (
    <View style={styles.container}>
      <ScrollView horizontal>
        <View>
          <View style={styles.headerRow}>
            <Text style={styles.headerCell}>Time</Text>
            {DEPARTMENTS.map(dept => (
              <Text key={dept} style={styles.headerCell}>{dept.toUpperCase()}</Text>
            ))}
          </View>
          <ScrollView>
            {TIME_SLOTS.map(slot => (
              <View key={slot} style={styles.dataRow}>
                <Text style={styles.timeCell}>{slot}</Text>
                {DEPARTMENTS.map(dept => (
                  <Text key={dept} style={styles.dataCell}>
                    {data[slot]?.[dept]?.toFixed(1) || '0.0'}
                  </Text>
                ))}
              </View>
            ))}
          </ScrollView>
        </View>
      </ScrollView>
      
      <View style={styles.saveSection}>
        <TextInput
          style={styles.input}
          placeholder="Shift Name (e.g., Morning Shift)"
          value={shiftName}
          onChangeText={setShiftName}
        />
        <TextInput
          style={styles.input}
          placeholder="Notes (optional)"
          value={notes}
          onChangeText={setNotes}
        />
        <TouchableOpacity style={styles.saveButton} onPress={saveSnapshot}>
          <Text style={styles.saveButtonText}>Save Shift Data</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  loading: { textAlign: 'center', marginTop: 20 },
  headerRow: { flexDirection: 'row', backgroundColor: '#6366f1', paddingVertical: 12 },
  headerCell: { width: 100, color: 'white', fontWeight: 'bold', textAlign: 'center', paddingHorizontal: 8 },
  dataRow: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: '#e5e7eb' },
  timeCell: { width: 100, paddingVertical: 12, paddingHorizontal: 8, fontWeight: '600' },
  dataCell: { width: 100, paddingVertical: 12, paddingHorizontal: 8, textAlign: 'center' },
  saveSection: { marginTop: 20, padding: 16, backgroundColor: '#f9fafb', borderRadius: 8 },
  input: { backgroundColor: 'white', padding: 12, borderRadius: 6, marginBottom: 12, borderWidth: 1, borderColor: '#d1d5db' },
  saveButton: { backgroundColor: '#6366f1', padding: 14, borderRadius: 6, alignItems: 'center' },
  saveButtonText: { color: 'white', fontWeight: 'bold', fontSize: 16 }
});
