import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ActivityIndicator, Alert, ScrollView } from 'react-native';
import { supabase } from '@/app/lib/supabase';
import EditInventoryItemModal from './EditInventoryItemModal';
import { DieselInventoryCard } from './DieselInventoryCard';
import { isDieselItem, dieselHeightToVolume } from '../utils/dieselConversion';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import { calculateCurrentStock } from '@/utils/inventoryCalculations';
import { createDebouncedRefresh } from '@/utils/realtimeHelpers';

interface InventoryItemsListProps {
  category: string;
  onStockMovement: (item: any) => void;
  refreshKey: number;
}




export default function InventoryItemsList({ category, onStockMovement, refreshKey }: InventoryItemsListProps) {
  const { user } = usePasswordAuth();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editItem, setEditItem] = useState<any>(null);
  const isLimitedAccess = user?.permissions?.inventoryLimited || false;
  const debouncedRefreshRef = useRef<{ trigger: () => void; cancel: () => void } | null>(null);

  useEffect(() => {
    fetchItems();
    
    // OPTIMIZED: Create debounced refresh to batch rapid inventory updates
    debouncedRefreshRef.current = createDebouncedRefresh(fetchItems, 500);
    
    // OPTIMIZED: Single subscription for inventory updates with debouncing
    // Use category-specific channel to reduce unnecessary updates
    const dbCategory = category === 'Raw Materials' ? 'raw_materials' 
                     : category === 'Direct Sale' ? 'finished_goods' : 'by_products';
    
    const itemsSub = supabase.channel(`inv_items_${dbCategory}`)
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'inventory_items',
        filter: `category=eq.${dbCategory}`
      }, () => {
        // Use debounced refresh instead of immediate fetch
        debouncedRefreshRef.current?.trigger();
      })
      .on('postgres_changes', { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'inventory_transactions' 
      }, () => {
        // Use debounced refresh for transactions too
        debouncedRefreshRef.current?.trigger();
      })
      .subscribe();
    
    return () => { 
      debouncedRefreshRef.current?.cancel();
      supabase.removeChannel(itemsSub);
    };
  }, [category, refreshKey]);


  const fetchItems = async () => {
    setLoading(true);
    const dbCategory = category === 'Raw Materials' ? 'raw_materials' 
                     : category === 'Direct Sale' ? 'finished_goods' : 'by_products';
    
    const { data, error } = await supabase.from('inventory_items').select('*').eq('category', dbCategory).order('item_name');
    
    if (!error && data) {
      const filteredData = data.filter(item => !isDieselItem(item.item_name));
      const { data: allTrans } = await supabase.from('inventory_transactions').select('*').order('created_at', { ascending: true });
      
      const itemsWithStock = filteredData.map(item => {
        const itemTrans = (allTrans || []).filter(t => t.item_id === item.id);
        // Pass item to calculateCurrentStock for initial_quantity fallback
        const calculatedStock = calculateCurrentStock(itemTrans, item);
        return { ...item, current_stock: calculatedStock, quantity: calculatedStock };
      });
      
      setItems(itemsWithStock);
    }
    setLoading(false);
  };





  const handleDelete = async (item: any) => {
    if (!user?.permissions?.admin) {
      Alert.alert('Access Denied', 'Only administrators can delete inventory items.');
      return;
    }
    Alert.alert('Delete Item', `Delete "${item.item_name}"? This will also delete all transactions.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
        const backup = items.find(i => i.id === item.id);
        setItems(prev => prev.filter(i => i.id !== item.id));
        try {
          await supabase.from('inventory_transactions').delete().eq('item_id', item.id);
          await supabase.from('inventory_items').delete().eq('id', item.id);
          Alert.alert('Success', 'Item deleted');
        } catch (err: any) {
          if (backup) setItems(prev => [...prev, backup]);
          Alert.alert('Error', `Failed: ${err.message}`);
        }
      }}
    ]);
  };

  const getCategoryLabel = () => {
    if (category === 'Raw Materials') return 'Raw Materials';
    if (category === 'Direct Sale') return 'Direct Sale Items';
    return 'By Products';
  };

  if (loading) return <ActivityIndicator size="large" style={{ marginTop: 50 }} />;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.scrollContent}>
      <View style={styles.header}><Text style={styles.headerTitle}>{getCategoryLabel()}</Text></View>
      {items.map(item => {
        if (isDieselItem(item.item_name)) {
          return (
            <View key={item.id}>
              <DieselInventoryCard height={item.quantity} lastUpdated={item.updated_at} lowStockThreshold={item.reorder_level || 500} />
              <View style={styles.itemActions}>
                {!isLimitedAccess && <TouchableOpacity onPress={() => onStockMovement(item)} style={styles.actionButton}><Text style={styles.actionButtonText}>Update Level</Text></TouchableOpacity>}
                {!isLimitedAccess && <TouchableOpacity onPress={() => setEditItem(item)} style={[styles.actionButton, styles.editButton]}><Text style={styles.actionButtonText}>Edit</Text></TouchableOpacity>}
              </View>
            </View>
          );
        }
        const isLowStock = item.reorder_level && item.quantity <= item.reorder_level;
        return (
          <View key={item.id} style={[styles.itemCard, isLowStock && styles.lowStockCard]}>
            <View style={styles.itemHeader}>
              <Text style={styles.itemName}>{item.item_name}</Text>
              {isLowStock && <Text style={styles.lowStockBadge}>LOW STOCK</Text>}
            </View>
            <View style={styles.itemDetails}>
              <Text style={styles.itemText}>Stock: {item.quantity} {item.unit}</Text>
              {item.reorder_level && <Text style={styles.reorderText}>Reorder at: {item.reorder_level} {item.unit}</Text>}
              {item.supplier && <Text style={styles.itemText}>Supplier: {item.supplier}</Text>}
            </View>
            <View style={styles.itemActions}>
              {!isLimitedAccess && <TouchableOpacity onPress={() => onStockMovement(item)} style={styles.actionButton}><Text style={styles.actionButtonText}>Stock In/Out</Text></TouchableOpacity>}
              {!isLimitedAccess && <TouchableOpacity onPress={() => setEditItem(item)} style={[styles.actionButton, styles.editButton]}><Text style={styles.actionButtonText}>Edit</Text></TouchableOpacity>}
              {!isLimitedAccess && <TouchableOpacity onPress={() => handleDelete(item)} style={[styles.actionButton, styles.deleteButton]}><Text style={styles.actionButtonText}>Delete</Text></TouchableOpacity>}
            </View>
          </View>
        );
      })}
      {items.length === 0 && <Text style={styles.emptyText}>No items found.</Text>}
      <EditInventoryItemModal visible={!!editItem} onClose={() => setEditItem(null)} item={editItem} onSuccess={fetchItems} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 }, scrollContent: { padding: 16 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  headerTitle: { fontSize: 18, fontWeight: 'bold' },
  itemCard: { backgroundColor: '#fff', padding: 16, borderRadius: 8, marginBottom: 12, borderWidth: 1, borderColor: '#ddd' },
  lowStockCard: { borderColor: '#ff9800', borderWidth: 2 },
  itemHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  itemName: { fontSize: 16, fontWeight: 'bold' },
  lowStockBadge: { backgroundColor: '#ff9800', color: '#fff', padding: 4, borderRadius: 4, fontSize: 10, fontWeight: 'bold' },
  itemDetails: { marginBottom: 12 },
  itemText: { fontSize: 14, color: '#666', marginBottom: 4 },
  reorderText: { fontSize: 14, color: '#EF4444', marginBottom: 4, fontWeight: '600' },
  itemActions: { flexDirection: 'row', gap: 8 },
  actionButton: { backgroundColor: '#4CAF50', padding: 8, borderRadius: 6, flex: 1 },
  editButton: { backgroundColor: '#007AFF' }, deleteButton: { backgroundColor: '#EF4444' },
  actionButtonText: { color: '#fff', textAlign: 'center', fontWeight: 'bold', fontSize: 12 },
  emptyText: { textAlign: 'center', color: '#999', marginTop: 50, fontSize: 16 }
});
