import React, { useState, useEffect } from 'react';
import { View, Text, Modal, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '@/app/lib/supabase';

interface DieselRefillRecordsModalProps {
  visible: boolean;
  onClose: () => void;
}

export default function DieselRefillRecordsModal({ visible, onClose }: DieselRefillRecordsModalProps) {
  const [refills, setRefills] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (visible) fetchRefills();
  }, [visible]);

  const fetchRefills = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('diesel_refills')
        .select('*')
        .order('refill_date', { ascending: false });
      
      if (error) throw error;
      setRefills(data || []);
    } catch (err) {
      console.error('Error fetching refills:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' }}>
        <View style={{ backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, maxHeight: '85%' }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, borderBottomWidth: 1, borderBottomColor: '#ddd' }}>
            <Text style={{ fontSize: 20, fontWeight: 'bold' }}>Refill Records</Text>
            <TouchableOpacity onPress={onClose}>
              <Ionicons name="close" size={28} color="#333" />
            </TouchableOpacity>
          </View>
          
          <ScrollView style={{ padding: 20 }}>
            {loading ? (
              <ActivityIndicator size="large" color="#28a745" />
            ) : refills.length === 0 ? (
              <Text style={{ textAlign: 'center', color: '#999', marginTop: 20 }}>No refill records found</Text>
            ) : (
              refills.map((refill) => (
                <View key={refill.id} style={{ backgroundColor: '#f9f9f9', padding: 15, borderRadius: 10, marginBottom: 12, borderLeftWidth: 4, borderLeftColor: '#28a745' }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
                    <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#333' }}>
                      {new Date(refill.refill_date).toLocaleDateString()}
                    </Text>
                    <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#28a745' }}>
                      {refill.quantity_received} L
                    </Text>
                  </View>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
                    <Text style={{ color: '#666' }}>Cost/L:</Text>
                    <Text style={{ fontWeight: '600' }}>Rs {refill.cost_per_litre?.toFixed(2) || '0.00'}</Text>

                  </View>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
                    <Text style={{ color: '#666' }}>Total:</Text>
                    <Text style={{ fontWeight: '600' }}>Rs {refill.total_cost?.toFixed(2) || '0.00'}</Text>

                  </View>
                   {refill.purchase_order_number && (
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
                      <Text style={{ color: '#666' }}>PO #:</Text>
                      <Text style={{ fontWeight: '600' }}>{refill.purchase_order_number}</Text>
                    </View>
                  )}
                  {refill.notes && (
                    <View style={{ marginTop: 8, paddingTop: 8, borderTopWidth: 1, borderTopColor: '#e0e0e0' }}>
                      <Text style={{ color: '#666', fontSize: 12 }}>{refill.notes}</Text>
                    </View>
                  )}
                </View>

              ))
            )}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}
