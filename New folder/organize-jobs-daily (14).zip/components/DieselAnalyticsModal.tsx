import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TouchableOpacity, ScrollView, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getDieselAnalytics, DieselAnalytics } from '../utils/dieselAnalytics';
import DieselConsumptionChart from './DieselConsumptionChart';
import { generateDieselReport } from '../utils/dieselReportExport';
import DateRangePicker from './DateRangePicker';


interface DieselAnalyticsModalProps {
  visible: boolean;
  onClose: () => void;
}

export default function DieselAnalyticsModal({ visible, onClose }: DieselAnalyticsModalProps) {
  const [analytics, setAnalytics] = useState<DieselAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [periodType, setPeriodType] = useState<'preset' | 'custom'>('preset');
  const [presetDays, setPresetDays] = useState<7 | 30 | 90>(30);
  const [startDate, setStartDate] = useState(new Date(new Date().setDate(new Date().getDate() - 30)));
  const [endDate, setEndDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);

  useEffect(() => {
    if (visible) {
      loadAnalytics();
    }
  }, [visible, periodType, presetDays, startDate, endDate]);

  const loadAnalytics = async () => {
    setLoading(true);
    try {
      let start: Date, end: Date;
      if (periodType === 'preset') {
        end = new Date();
        start = new Date();
        start.setDate(start.getDate() - presetDays);
      } else {
        start = startDate;
        end = endDate;
      }
      const data = await getDieselAnalytics(start, end);
      setAnalytics(data);
    } catch (err) {
      console.error('Error loading analytics:', err);
    } finally {
      setLoading(false);
    }
  };


  const handleExportReport = async () => {
    try {
      await generateDieselReport(presetDays);
      Alert.alert('Success', 'Report exported successfully');
    } catch (err) {
      Alert.alert('Error', 'Failed to export report');
    }
  };

  const handleDateRangeApply = (start: Date, end: Date) => {
    setStartDate(start);
    setEndDate(end);
    setShowDatePicker(false);
  };

  return (
    <Modal visible={visible} animationType="slide">
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Diesel Analytics</Text>
          <View style={{flexDirection: 'row', gap: 12}}>
            <TouchableOpacity onPress={handleExportReport}>
              <Ionicons name="download" size={28} color="#007AFF" />
            </TouchableOpacity>
            <TouchableOpacity onPress={onClose}>
              <Ionicons name="close" size={28} color="#333" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Period Type Selector */}
        <View style={styles.periodTypeSelector}>
          <TouchableOpacity
            style={[styles.periodTypeButton, periodType === 'preset' && styles.periodTypeActive]}
            onPress={() => setPeriodType('preset')}
          >
            <Text style={[styles.periodTypeText, periodType === 'preset' && styles.periodTypeTextActive]}>
              Quick Select
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.periodTypeButton, periodType === 'custom' && styles.periodTypeActive]}
            onPress={() => setPeriodType('custom')}
          >
            <Text style={[styles.periodTypeText, periodType === 'custom' && styles.periodTypeTextActive]}>
              Custom Range
            </Text>
          </TouchableOpacity>
        </View>

        {/* Preset Days Selector */}
        {periodType === 'preset' && (
          <View style={styles.periodSelector}>
            {[7, 30, 90].map((p) => (
              <TouchableOpacity
                key={p}
                style={[styles.periodButton, presetDays === p && styles.periodButtonActive]}
                onPress={() => setPresetDays(p as 7 | 30 | 90)}
              >
                <Text style={[styles.periodText, presetDays === p && styles.periodTextActive]}>
                  {p} Days
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Custom Date Range Selector */}
        {periodType === 'custom' && (
          <View style={styles.customDateContainer}>
            <TouchableOpacity style={styles.dateRangeButton} onPress={() => setShowDatePicker(true)}>
              <Ionicons name="calendar" size={20} color="#007AFF" />
              <Text style={styles.dateRangeText}>
                {startDate.toLocaleDateString()} - {endDate.toLocaleDateString()}
              </Text>
            </TouchableOpacity>
          </View>
        )}


        {loading ? (
          <ActivityIndicator size="large" color="#007AFF" style={styles.loader} />
        ) : analytics ? (
          <ScrollView style={styles.content}>
            <View style={styles.statsGrid}>
              <View style={styles.statCard}>
                <Text style={styles.statValue}>{analytics.totalConsumption.toFixed(0)} L</Text>
                <Text style={styles.statLabel}>Total Consumption</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statValue}>Rs {analytics.totalCost.toFixed(0)}</Text>
                <Text style={styles.statLabel}>Total Cost</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statValue}>{analytics.avgDailyConsumption.toFixed(1)} L</Text>
                <Text style={styles.statLabel}>Avg Daily</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statValue}>Rs {analytics.avgCostPerLiter.toFixed(2)}</Text>
                <Text style={styles.statLabel}>Avg Cost/L</Text>
              </View>
            </View>

            <DieselConsumptionChart data={analytics.daily} title="Daily Consumption" color="#007AFF" />
            <DieselConsumptionChart data={analytics.weekly} title="Weekly Consumption" color="#28a745" />
            <DieselConsumptionChart data={analytics.monthly} title="Monthly Consumption" color="#ff6b6b" />

            <View style={styles.refillSection}>
              <Text style={styles.sectionTitle}>Recent Refills</Text>
              {analytics.refillHistory.slice(0, 10).map((refill) => (
                <View key={refill.id} style={styles.refillCard}>
                  <View style={styles.refillHeader}>
                    <Text style={styles.refillDate}>
                      {new Date(refill.refill_date).toLocaleDateString()}
                    </Text>
                    <Text style={styles.refillVolume}>{refill.quantity_received.toFixed(0)} L</Text>
                  </View>
                  <Text style={styles.refillCost}>
                    Cost: Rs {refill.total_cost.toFixed(2)} @ Rs {refill.cost_per_litre.toFixed(2)}/L
                  </Text>
                  {refill.purchase_order_number && (
                    <Text style={styles.refillPO}>PO: {refill.purchase_order_number}</Text>
                  )}
                  {refill.notes && <Text style={styles.refillNotes}>{refill.notes}</Text>}
                </View>
              ))}

            </View>
          </ScrollView>
        ) : (
          <Text style={styles.noData}>No data available</Text>
        )}

        {showDatePicker && (
          <DateRangePicker
            visible={showDatePicker}
            startDate={startDate}
            endDate={endDate}
            onApply={handleDateRangeApply}
            onClose={() => setShowDatePicker(false)}
          />
        )}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#eee' },
  title: { fontSize: 24, fontWeight: '700', color: '#333' },
  periodTypeSelector: { flexDirection: 'row', padding: 12, backgroundColor: '#fff', gap: 8, borderBottomWidth: 1, borderBottomColor: '#eee' },
  periodTypeButton: { flex: 1, padding: 10, borderRadius: 8, backgroundColor: '#f0f0f0', alignItems: 'center' },
  periodTypeActive: { backgroundColor: '#007AFF' },
  periodTypeText: { fontSize: 14, fontWeight: '600', color: '#666' },
  periodTypeTextActive: { color: '#fff' },
  periodSelector: { flexDirection: 'row', padding: 12, backgroundColor: '#fff', gap: 8 },
  periodButton: { flex: 1, padding: 10, borderRadius: 8, backgroundColor: '#f0f0f0', alignItems: 'center' },
  periodButtonActive: { backgroundColor: '#007AFF' },
  periodText: { fontSize: 14, fontWeight: '600', color: '#666' },
  periodTextActive: { color: '#fff' },
  customDateContainer: { padding: 12, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#eee' },
  dateRangeButton: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 12, backgroundColor: '#f0f0f0', borderRadius: 8 },
  dateRangeText: { fontSize: 14, fontWeight: '600', color: '#333' },
  loader: { marginTop: 40 },
  content: { flex: 1, padding: 16 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 16 },
  statCard: { flex: 1, minWidth: '45%', backgroundColor: '#fff', padding: 16, borderRadius: 12, alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  statValue: { fontSize: 20, fontWeight: '700', color: '#007AFF', marginBottom: 4 },
  statLabel: { fontSize: 12, color: '#666', textAlign: 'center' },
  refillSection: { marginTop: 16 },
  sectionTitle: { fontSize: 18, fontWeight: '700', marginBottom: 12, color: '#333' },
  refillCard: { backgroundColor: '#fff', padding: 12, borderRadius: 8, marginBottom: 8 },
  refillHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  refillDate: { fontSize: 14, color: '#666' },
  refillVolume: { fontSize: 14, fontWeight: '700', color: '#007AFF' },
  refillCost: { fontSize: 13, color: '#28a745', marginTop: 2 },
  refillPO: { fontSize: 12, color: '#666', marginTop: 2 },
  refillNotes: { fontSize: 12, color: '#999', marginTop: 4, fontStyle: 'italic' },
  noData: { textAlign: 'center', color: '#999', marginTop: 40 }
});
