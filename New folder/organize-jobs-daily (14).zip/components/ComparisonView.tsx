import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

type ComparisonProps = {
  period1Stats: any;
  period2Stats: any;
  period1Label: string;
  period2Label: string;
};

export default function ComparisonView({ period1Stats, period2Stats, period1Label, period2Label }: ComparisonProps) {
  const calcChange = (val1: number, val2: number) => {
    if (val2 === 0) return 0;
    return ((val1 - val2) / val2) * 100;
  };

  const renderMetric = (label: string, val1: number, val2: number, unit: string) => {
    const change = calcChange(val1, val2);
    const isPositive = change > 0;
    const isNeutral = change === 0;

    return (
      <View style={styles.metricCard}>
        <Text style={styles.metricLabel}>{label}</Text>
        <View style={styles.metricRow}>
          <View style={styles.metricCol}>
            <Text style={styles.metricPeriod}>{period1Label}</Text>
            <Text style={styles.metricValue}>{val1.toFixed(1)} {unit}</Text>
          </View>
          <View style={styles.metricCol}>
            <Text style={styles.metricPeriod}>{period2Label}</Text>
            <Text style={styles.metricValue}>{val2.toFixed(1)} {unit}</Text>
          </View>
        </View>
        {!isNeutral && (
          <View style={[styles.changeRow, { backgroundColor: isPositive ? '#D1FAE5' : '#FEE2E2' }]}>
            <Ionicons name={isPositive ? 'trending-up' : 'trending-down'} size={16} color={isPositive ? '#10B981' : '#EF4444'} />
            <Text style={[styles.changeText, { color: isPositive ? '#10B981' : '#EF4444' }]}>
              {Math.abs(change).toFixed(1)}% {isPositive ? 'increase' : 'decrease'}
            </Text>
          </View>
        )}
      </View>
    );
  };

  return (
    <View>
      {renderMetric('Total Jobs', period1Stats.totalJobs, period2Stats.totalJobs, 'jobs')}
      {renderMetric('Total Weight', period1Stats.totalWeight, period2Stats.totalWeight, 'kg')}
      {renderMetric('Avg Turnaround', period1Stats.avgTurnaround, period2Stats.avgTurnaround, 'days')}
    </View>
  );
}

const styles = StyleSheet.create({
  metricCard: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 12 },
  metricLabel: { fontSize: 16, fontWeight: 'bold', color: '#1F2937', marginBottom: 12 },
  metricRow: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 8 },
  metricCol: { alignItems: 'center' },
  metricPeriod: { fontSize: 12, color: '#6B7280', marginBottom: 4 },
  metricValue: { fontSize: 20, fontWeight: 'bold', color: '#1F2937' },
  changeRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: 8, borderRadius: 6, marginTop: 4 },
  changeText: { fontSize: 14, fontWeight: '600', marginLeft: 4 },
});
