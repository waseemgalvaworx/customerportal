import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Job, ItemStatus } from '../contexts/JobContext';
import PriorityBadge from './PriorityBadge';
import DeliveryCountdown from './DeliveryCountdown';

interface WipJobCardProps {
  job: Job;
  status: ItemStatus;
}

export default function WipJobCard({ job, status }: WipJobCardProps) {
  const itemsInStatus = job.items.filter(item => item.status === status);
  const totalItems = job.items.length;
  const progressPercent = Math.round((itemsInStatus.length / totalItems) * 100);

  const borderColor = job.galvaXpress ? '#DC2626' : job.priority === 'high' ? '#EF4444' : job.priority === 'medium' ? '#F59E0B' : '#E5E7EB';
  const bgColor = job.galvaXpress ? '#FEF2F2' : job.priority === 'high' ? '#FEF2F2' : '#FAFAFA';

  return (
    <View style={[styles.card, { borderLeftColor: borderColor, borderLeftWidth: 4, backgroundColor: bgColor }]}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Text style={styles.jobNumber}>{job.jobNumber}</Text>
          <Text style={styles.customerName}>{job.customerName}</Text>
        </View>
        <View style={styles.headerRight}>
          <PriorityBadge priority={job.priority} galvaXpress={job.galvaXpress} size="small" />
          <DeliveryCountdown deliveryDate={job.deliveryDate} />
        </View>
      </View>
      <View style={styles.progress}>
        <Text style={styles.progressText}>{itemsInStatus.length}/{totalItems} items • {progressPercent}%</Text>
      </View>
      {itemsInStatus.map((item, idx) => (
        <View key={idx} style={styles.itemRow}>
          <View style={styles.itemInfo}>
            {item.itemCount && (
              <Text style={styles.itemCount}>Qty: {item.itemCount}</Text>
            )}
            <Text style={styles.itemDesc}>{item.descriptionOfWorks}</Text>
          </View>
          <Text style={styles.itemWeight}>{parseFloat(item.weightKg || '0').toFixed(2)} kg</Text>
        </View>
      ))}

    </View>
  );
}

const styles = StyleSheet.create({
  card: { padding: 12, borderTopWidth: 1, borderTopColor: '#E5E7EB', borderRadius: 8, marginBottom: 8 },
  header: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8, alignItems: 'flex-start' },
  headerLeft: { flex: 1 },
  headerRight: { gap: 4, alignItems: 'flex-end' },
  jobNumber: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' },
  customerName: { fontSize: 12, fontWeight: '600', color: '#6B7280', marginTop: 2 },
  progress: { marginBottom: 8 },
  progressText: { fontSize: 11, color: '#6B7280', fontWeight: '600' },
  itemRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4, paddingLeft: 8, alignItems: 'flex-start' },
  itemInfo: { flex: 1 },
  itemCount: { fontSize: 11, color: '#3B82F6', fontWeight: '600', marginBottom: 2 },
  itemDesc: { fontSize: 13, color: '#374151' },
  itemWeight: { fontSize: 13, fontWeight: 'bold', color: '#1F2937', marginLeft: 8 }
});

