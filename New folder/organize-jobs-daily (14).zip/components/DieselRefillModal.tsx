import React, { useState } from 'react';
import { View, Text, Modal, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { supabase } from '@/app/lib/supabase';
import { notifyAllUsers } from '@/utils/notificationHelper';
import { usePasswordAuth } from '@/contexts/PasswordAuthContext';

interface DieselRefillModalProps {
  visible: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function DieselRefillModal({ visible, onClose, onSuccess }: DieselRefillModalProps) {
  const { user } = usePasswordAuth();
  const [refillDate, setRefillDate] = useState(new Date().toISOString().split('T')[0]);
  const [quantityReceived, setQuantityReceived] = useState('');
  const [costPerLitre, setCostPerLitre] = useState('');
  const [purchaseOrderNumber, setPurchaseOrderNumber] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const totalCost = (parseFloat(quantityReceived) || 0) * (parseFloat(costPerLitre) || 0);

  const handleSubmit = async () => {
    if (!quantityReceived || !costPerLitre) {
      Alert.alert('Error', 'Please enter quantity and cost per litre');
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.from('diesel_refills').insert({
        refill_date: refillDate,
        quantity_received: parseFloat(quantityReceived),
        cost_per_litre: parseFloat(costPerLitre),
        purchase_order_number: purchaseOrderNumber || null,
        notes: notes || null,
      });




      if (error) throw error;

      // Send notification to all users
      await notifyAllUsers({
        title: 'Diesel Refill Recorded',
        message: `${parseFloat(quantityReceived).toLocaleString()} litres of diesel refilled at Rs ${parseFloat(costPerLitre).toFixed(2)}/L (Total: Rs ${totalCost.toFixed(2)}) by ${user?.username || 'Unknown'}`,
        type: 'inventory',
        priority: 'normal'
      });

      Alert.alert('Success', 'Diesel refill recorded successfully');
      resetForm();
      onSuccess();
      onClose();

    } catch (error: any) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setRefillDate(new Date().toISOString().split('T')[0]);
    setQuantityReceived('');
    setCostPerLitre('');
    setPurchaseOrderNumber('');
    setNotes('');
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 }}>
        <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 20, maxHeight: '80%' }}>
          <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 20 }}>Record Diesel Refill</Text>
          
          <ScrollView>
            <Text style={{ fontSize: 14, fontWeight: '600', marginBottom: 5 }}>Refill Date</Text>
            <TextInput
              value={refillDate}
              onChangeText={setRefillDate}
              placeholder="YYYY-MM-DD"
              style={{ borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, marginBottom: 15 }}
            />

            <Text style={{ fontSize: 14, fontWeight: '600', marginBottom: 5 }}>Quantity Received (Litres)</Text>
            <TextInput
              value={quantityReceived}
              onChangeText={setQuantityReceived}
              placeholder="Enter litres"
              keyboardType="decimal-pad"
              style={{ borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, marginBottom: 15 }}
            />

            <Text style={{ fontSize: 14, fontWeight: '600', marginBottom: 5 }}>Cost per Litre (Rs)</Text>
            <TextInput
              value={costPerLitre}
              onChangeText={setCostPerLitre}
              placeholder="Enter cost"
              keyboardType="decimal-pad"
              style={{ borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, marginBottom: 15 }}
            />

            <Text style={{ fontSize: 14, fontWeight: '600', marginBottom: 5 }}>Purchase Order Number</Text>
            <TextInput
              value={purchaseOrderNumber}
              onChangeText={setPurchaseOrderNumber}
              placeholder="Enter PO number (optional)"
              style={{ borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, marginBottom: 15 }}
            />

            <Text style={{ fontSize: 14, fontWeight: '600', marginBottom: 5 }}>Notes (Optional)</Text>
            <TextInput
              value={notes}
              onChangeText={setNotes}
              placeholder="Additional notes"
              multiline
              numberOfLines={3}
              style={{ borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, marginBottom: 15 }}
            />

            <View style={{ backgroundColor: '#f0f9ff', padding: 15, borderRadius: 8, marginBottom: 20 }}>
              <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#0369a1' }}>
                Total Cost: Rs {totalCost.toFixed(2)}
              </Text>
            </View>

            <View style={{ flexDirection: 'row', gap: 10 }}>
              <TouchableOpacity
                onPress={onClose}
                style={{ flex: 1, backgroundColor: '#e5e7eb', padding: 15, borderRadius: 8, alignItems: 'center' }}
              >
                <Text style={{ color: '#374151', fontWeight: '600' }}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleSubmit}
                disabled={loading}
                style={{ flex: 1, backgroundColor: '#3b82f6', padding: 15, borderRadius: 8, alignItems: 'center' }}
              >
                <Text style={{ color: 'white', fontWeight: '600' }}>{loading ? 'Saving...' : 'Save Refill'}</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}
