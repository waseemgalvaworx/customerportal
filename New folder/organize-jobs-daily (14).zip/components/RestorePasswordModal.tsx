import React, { useState } from 'react';
import { View, Text, Modal, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

interface RestorePasswordModalProps {
  visible: boolean;
  jobNumber: string;
  onConfirm: (password: string) => void;
  onCancel: () => void;
}

export default function RestorePasswordModal({ visible, jobNumber, onConfirm, onCancel }: RestorePasswordModalProps) {
  const [password, setPassword] = useState('');

  const handleConfirm = () => {
    console.log('🔐 Password submitted:', password);
    onConfirm(password);
    setPassword('');
  };


  const handleCancel = () => {
    setPassword('');
    onCancel();
  };

  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <Text style={styles.title}>Restore to WIP</Text>
          <Text style={styles.message}>
            Enter password to restore job {jobNumber} back to WIP status
          </Text>

          <TextInput
            style={styles.input}
            value={password}
            onChangeText={setPassword}
            placeholder="Enter password"
            secureTextEntry
            autoFocus
          />
          <View style={styles.buttons}>
            <TouchableOpacity style={styles.cancelBtn} onPress={handleCancel}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.confirmBtn} onPress={handleConfirm}>
              <Text style={styles.confirmText}>Restore</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modal: { backgroundColor: 'white', borderRadius: 12, padding: 24, width: '85%', maxWidth: 400 },
  title: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', marginBottom: 8 },
  message: { fontSize: 14, color: '#6B7280', marginBottom: 16 },
  input: { borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, padding: 12, fontSize: 16, marginBottom: 16 },
  buttons: { flexDirection: 'row', gap: 12 },
  cancelBtn: { flex: 1, padding: 12, borderRadius: 8, backgroundColor: '#F3F4F6', alignItems: 'center' },
  cancelText: { fontSize: 16, fontWeight: '600', color: '#6B7280' },
  confirmBtn: { flex: 1, padding: 12, borderRadius: 8, backgroundColor: '#F59E0B', alignItems: 'center' },
  confirmText: { fontSize: 16, fontWeight: '600', color: '#fff' }
});
