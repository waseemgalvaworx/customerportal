import React, { useState, useEffect, useRef } from 'react';
import { View, Text, Modal, TouchableOpacity, StyleSheet, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '@/app/lib/supabase';
import CalendarPicker from './CalendarPicker';
import { calculatePeriodMovements, getPeriodTransactions } from '@/utils/inventoryCalculations';
import SelectEmailRecipientsModal from './SelectEmailRecipientsModal';

const categoryOrder = { 'Raw Materials': 1, 'Direct Sale': 2, 'By Products': 3 };

export default function InventoryReportModal({ visible, onClose }: any) {
  const scrollViewRef = useRef<ScrollView>(null);
  const [loading, setLoading] = useState(false);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [items, setItems] = useState<any[]>([]);
  const [selectedItem, setSelectedItem] = useState<string>('all');
  const [period, setPeriod] = useState<'daily' | 'weekly' | 'monthly' | 'custom'>('daily');
  const [summaryData, setSummaryData] = useState<any[]>([]);
  const [customStartDate, setCustomStartDate] = useState<Date | null>(null);
  const [customEndDate, setCustomEndDate] = useState<Date | null>(null);
  const [showStartPicker, setShowStartPicker] = useState(false);
  const [showEndPicker, setShowEndPicker] = useState(false);
  const [showLeftChevron, setShowLeftChevron] = useState(false);
  const [showRightChevron, setShowRightChevron] = useState(true);
  const [scrollPosition, setScrollPosition] = useState(0);
  
  // Email states
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [sendingEmail, setSendingEmail] = useState(false);

  useEffect(() => {
    if (visible) fetchData();
  }, [visible, period, selectedItem, customStartDate, customEndDate]);

  const getDateRange = (): { startDate: Date; endDate: Date } => {
    const endDate = new Date();
    endDate.setHours(23, 59, 59, 999);
    let startDate: Date;
    if (period === 'custom' && customStartDate && customEndDate) {
      startDate = new Date(customStartDate);
      startDate.setHours(0, 0, 0, 0);
      const customEnd = new Date(customEndDate);
      customEnd.setHours(23, 59, 59, 999);
      return { startDate, endDate: customEnd };
    }
    startDate = new Date();
    startDate.setHours(0, 0, 0, 0);
    if (period === 'daily') startDate.setDate(startDate.getDate() - 1);
    else if (period === 'weekly') startDate.setDate(startDate.getDate() - 7);
    else startDate.setMonth(startDate.getMonth() - 1);
    return { startDate, endDate };
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      const { startDate, endDate } = getDateRange();
      const { data: itemsData } = await supabase.from('inventory_items').select('*').neq('item_name', 'Diesel');
      const uniqueItems = (itemsData || []).sort((a, b) => {
        const catA = categoryOrder[a.category as keyof typeof categoryOrder] || 99;
        const catB = categoryOrder[b.category as keyof typeof categoryOrder] || 99;
        return catA !== catB ? catA - catB : a.item_name.localeCompare(b.item_name);
      });
      setItems(uniqueItems);
      const { data: allTrans } = await supabase.from('inventory_transactions').select('*').order('created_at', { ascending: true });

      if (selectedItem === 'all') {
        const summary = uniqueItems.map(item => {
          const itemTrans = (allTrans || []).filter(t => t.item_id === item.id);
          const { opening, inQty, outQty, closing } = calculatePeriodMovements(itemTrans, startDate, endDate, item);
          return { item, opening, inQty, outQty, closing };
        });
        setSummaryData(summary);
        setTransactions([]);
      } else {
        const item = uniqueItems.find(i => i.item_name === selectedItem);
        if (item) {
          const itemTrans = (allTrans || []).filter(t => t.item_id === item.id);
          const { opening, inQty, outQty, closing } = calculatePeriodMovements(itemTrans, startDate, endDate, item);
          const periodTrans = getPeriodTransactions(itemTrans, startDate, endDate);
          setSummaryData([{ item, opening, inQty, outQty, closing }]);
          setTransactions(periodTrans.map(t => ({ ...t, inventory_items: { item_name: item.item_name, unit: item.unit } })));
        }
      }
    } catch (error: any) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (date: Date | null) => date ? date.toLocaleDateString() : 'Select';

  const handleScroll = (event: any) => {
    const { contentOffset, contentSize, layoutMeasurement } = event.nativeEvent;
    setScrollPosition(contentOffset.x);
    setShowLeftChevron(contentOffset.x > 10);
    setShowRightChevron(contentOffset.x < contentSize.width - layoutMeasurement.width - 10);
  };

  // Generate HTML content for email - minified to avoid Quoted-Printable encoding issues
  const generateEmailHtml = () => {
    const { startDate, endDate } = getDateRange();
    const periodLabel = period === 'custom' 
      ? `${customStartDate?.toLocaleDateString()} - ${customEndDate?.toLocaleDateString()}`
      : period.charAt(0).toUpperCase() + period.slice(1);
    
    const now = new Date().toLocaleString();
    
    let tableRows = '';
    
    if (selectedItem === 'all') {
      // Summary view for all items
      tableRows = summaryData.map(s => 
        `<tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:12px;font-weight:600;color:#1f2937;">${s.item.item_name}</td><td style="padding:12px;text-align:center;">${s.opening} ${s.item.unit}</td><td style="padding:12px;text-align:center;color:#10b981;font-weight:600;">+${s.inQty}</td><td style="padding:12px;text-align:center;color:#ef4444;font-weight:600;">-${s.outQty}</td><td style="padding:12px;text-align:center;font-weight:700;color:#1f2937;">${s.closing} ${s.item.unit}</td></tr>`
      ).join('');
    } else {
      // Transaction view for single item
      tableRows = transactions.map((t, idx) => 
        `<tr style="border-bottom:1px solid #e5e7eb;${idx % 2 === 0 ? 'background-color:#f9fafb;' : ''}"><td style="padding:12px;font-size:13px;color:#6b7280;">${new Date(t.created_at).toLocaleString()}</td><td style="padding:12px;text-align:center;font-weight:600;color:${t.transaction_type === 'in' ? '#10b981' : '#ef4444'};">${t.transaction_type.toUpperCase()}</td><td style="padding:12px;text-align:center;">${t.quantity} ${t.inventory_items?.unit || ''}</td><td style="padding:12px;font-size:13px;color:#6b7280;">${t.notes || '-'}</td></tr>`
      ).join('');
    }

    // Build stock summary section for single item view
    let stockSummaryHtml = '';
    if (selectedItem !== 'all' && summaryData.length > 0) {
      stockSummaryHtml = `<div style="display:flex;gap:16px;margin-bottom:16px;"><div style="flex:1;background:#f0f9ff;padding:16px;border-radius:8px;text-align:center;"><div style="font-size:13px;color:#6b7280;">Opening Stock</div><div style="font-size:20px;font-weight:700;color:#007AFF;">${summaryData[0].opening} ${summaryData[0].item.unit}</div></div><div style="flex:1;background:#f0f9ff;padding:16px;border-radius:8px;text-align:center;"><div style="font-size:13px;color:#6b7280;">Closing Stock</div><div style="font-size:20px;font-weight:700;color:#007AFF;">${summaryData[0].closing} ${summaryData[0].item.unit}</div></div></div>`;
    }

    // Build table header based on view type
    const tableHeader = selectedItem === 'all' 
      ? `<tr><th style="background:#f8fafc;padding:14px 12px;text-align:left;font-weight:600;color:#374151;border-bottom:2px solid #e5e7eb;">Item</th><th style="background:#f8fafc;padding:14px 12px;text-align:center;font-weight:600;color:#374151;border-bottom:2px solid #e5e7eb;">Opening</th><th style="background:#f8fafc;padding:14px 12px;text-align:center;font-weight:600;color:#374151;border-bottom:2px solid #e5e7eb;">In</th><th style="background:#f8fafc;padding:14px 12px;text-align:center;font-weight:600;color:#374151;border-bottom:2px solid #e5e7eb;">Out</th><th style="background:#f8fafc;padding:14px 12px;text-align:center;font-weight:600;color:#374151;border-bottom:2px solid #e5e7eb;">Closing</th></tr>`
      : `<tr><th style="background:#f8fafc;padding:14px 12px;text-align:left;font-weight:600;color:#374151;border-bottom:2px solid #e5e7eb;">Date/Time</th><th style="background:#f8fafc;padding:14px 12px;text-align:center;font-weight:600;color:#374151;border-bottom:2px solid #e5e7eb;">Type</th><th style="background:#f8fafc;padding:14px 12px;text-align:center;font-weight:600;color:#374151;border-bottom:2px solid #e5e7eb;">Quantity</th><th style="background:#f8fafc;padding:14px 12px;text-align:left;font-weight:600;color:#374151;border-bottom:2px solid #e5e7eb;">Notes</th></tr>`;

    // Build the complete HTML without extra whitespace
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;margin:0;padding:20px;background-color:#f3f4f6;}.container{max-width:800px;margin:0 auto;background:white;border-radius:12px;box-shadow:0 4px 6px rgba(0,0,0,0.1);overflow:hidden;}.header{background:linear-gradient(135deg,#007AFF,#5856D6);padding:24px;color:white;}.header h1{margin:0 0 8px 0;font-size:24px;}.header p{margin:0;opacity:0.9;font-size:14px;}.content{padding:24px;}.info-row{display:flex;gap:16px;margin-bottom:20px;flex-wrap:wrap;}.info-box{background:#f0f9ff;padding:12px 16px;border-radius:8px;border-left:4px solid #007AFF;}.info-label{font-size:12px;color:#6b7280;margin-bottom:4px;}.info-value{font-size:16px;font-weight:600;color:#1f2937;}table{width:100%;border-collapse:collapse;margin-top:16px;}.footer{padding:16px 24px;background:#f8fafc;border-top:1px solid #e5e7eb;font-size:12px;color:#6b7280;text-align:center;}</style></head><body><div class="container"><div class="header"><h1>Inventory Report</h1><p>Generated on ${now}</p></div><div class="content"><div class="info-row"><div class="info-box"><div class="info-label">Period</div><div class="info-value">${periodLabel}</div></div><div class="info-box"><div class="info-label">Item</div><div class="info-value">${selectedItem === 'all' ? 'All Items' : selectedItem}</div></div><div class="info-box"><div class="info-label">Date Range</div><div class="info-value">${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}</div></div></div>${stockSummaryHtml}<table><thead>${tableHeader}</thead><tbody>${tableRows || '<tr><td colspan="5" style="padding:24px;text-align:center;color:#9ca3af;">No data available for this period</td></tr>'}</tbody></table></div><div class="footer">This report was automatically generated by the Job Management System</div></div></body></html>`;
    
    return html;
  };


  // Send email to selected recipients
  const sendEmailToRecipients = async (selectedEmails: string[]) => {
    if (selectedEmails.length === 0) {
      Alert.alert('No Recipients', 'Please select at least one recipient.');
      return;
    }

    setSendingEmail(true);
    
    try {
      const { startDate, endDate } = getDateRange();
      const periodLabel = period === 'custom' 
        ? `${customStartDate?.toLocaleDateString()} - ${customEndDate?.toLocaleDateString()}`
        : period.charAt(0).toUpperCase() + period.slice(1);
      
      const itemLabel = selectedItem === 'all' ? 'All Items' : selectedItem;
      const subject = `Inventory Report - ${itemLabel} (${periodLabel})`;
      const htmlContent = generateEmailHtml();
      
      // Get email settings for from_email
      const { data: emailSettings } = await supabase
        .from('email_settings')
        .select('from_email')
        .single();
      
      const fromEmail = emailSettings?.from_email || 'onboarding@resend.dev';
      
      const { data, error } = await supabase.functions.invoke('send-daily-report', {
        body: {
          recipients: selectedEmails,
          subject,
          htmlContent,
          fromEmail
        }
      });

      if (error) throw error;

      Alert.alert('Success', `Inventory report sent to ${selectedEmails.length} recipient(s)`);
      setShowEmailModal(false);
    } catch (error: any) {
      console.error('Error sending email:', error);
      Alert.alert('Error', `Failed to send email: ${error.message}`);
    } finally {
      setSendingEmail(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <View style={styles.header}>
            <Text style={styles.title}>Inventory Report</Text>
            <View style={styles.headerActions}>
              <TouchableOpacity style={styles.emailBtn} onPress={() => setShowEmailModal(true)}>
                <Ionicons name="mail" size={22} color="#007AFF" />
              </TouchableOpacity>
              <TouchableOpacity onPress={onClose}>
                <Ionicons name="close" size={28} color="#333" />
              </TouchableOpacity>
            </View>
          </View>
          <View style={styles.periodSelector}>
            {['daily', 'weekly', 'monthly', 'custom'].map(p => (
              <TouchableOpacity key={p} style={[styles.periodBtn, period === p && styles.periodBtnActive]} onPress={() => setPeriod(p as any)}>
                <Text style={[styles.periodText, period === p && styles.periodTextActive]}>{p.charAt(0).toUpperCase() + p.slice(1)}</Text>
              </TouchableOpacity>
            ))}
          </View>
          {period === 'custom' && (
            <View style={styles.dateRow}>
              <TouchableOpacity style={styles.dateBtn} onPress={() => setShowStartPicker(true)}>
                <Ionicons name="calendar" size={16} color="#007AFF" />
                <Text style={styles.dateText}>From: {formatDate(customStartDate)}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.dateBtn} onPress={() => setShowEndPicker(true)}>
                <Ionicons name="calendar" size={16} color="#007AFF" />
                <Text style={styles.dateText}>To: {formatDate(customEndDate)}</Text>
              </TouchableOpacity>
            </View>
          )}
          <View style={styles.itemSelectorContainer}>
            {showLeftChevron && (
              <TouchableOpacity 
                style={styles.chevronBtn} 
                onPress={() => scrollViewRef.current?.scrollTo({ x: Math.max(0, scrollPosition - 150), animated: true })}
                activeOpacity={0.7}
              >
                <Ionicons name="chevron-back" size={20} color="#007AFF" />
              </TouchableOpacity>
            )}
            <ScrollView 
              ref={scrollViewRef} 
              horizontal 
              showsHorizontalScrollIndicator={false} 
              onScroll={handleScroll} 
              scrollEventThrottle={16}
              nestedScrollEnabled={true}
              bounces={true}
              decelerationRate={0.95}
              style={styles.itemScrollView}
              contentContainerStyle={styles.itemScrollContent}
            >
              <TouchableOpacity 
                style={[styles.itemBtn, selectedItem === 'all' && styles.itemBtnActive]} 
                onPress={() => setSelectedItem('all')}
                activeOpacity={0.7}
              >
                <Text style={[styles.itemText, selectedItem === 'all' && styles.itemTextActive]}>All</Text>
              </TouchableOpacity>
              {items.map((item, idx) => (
                <TouchableOpacity 
                  key={idx} 
                  style={[styles.itemBtn, selectedItem === item.item_name && styles.itemBtnActive]} 
                  onPress={() => setSelectedItem(item.item_name)}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.itemText, selectedItem === item.item_name && styles.itemTextActive]} numberOfLines={1}>{item.item_name}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            {showRightChevron && items.length > 2 && (
              <TouchableOpacity 
                style={styles.chevronBtn} 
                onPress={() => scrollViewRef.current?.scrollTo({ x: scrollPosition + 150, animated: true })}
                activeOpacity={0.7}
              >
                <Ionicons name="chevron-forward" size={20} color="#007AFF" />
              </TouchableOpacity>
            )}
          </View>

          {loading ? <ActivityIndicator size="large" color="#007AFF" style={{ marginTop: 20 }} /> : (
            <ScrollView style={styles.content}>
              {selectedItem === 'all' ? summaryData.map((s, idx) => (
                <View key={idx} style={styles.summaryCard}>
                  <Text style={styles.summaryTitle}>{s.item.item_name}</Text>
                  <Text style={styles.summaryLabel}>Opening: <Text style={styles.summaryValue}>{s.opening} {s.item.unit}</Text></Text>
                  <View style={styles.summaryRow}><Text style={styles.inText}>+{s.inQty}</Text><Text style={styles.outText}>-{s.outQty}</Text></View>
                  <Text style={styles.summaryLabel}>Closing: <Text style={styles.summaryValue}>{s.closing} {s.item.unit}</Text></Text>
                </View>
              )) : (
                <>
                  {summaryData.length > 0 && (
                    <View style={styles.stockRow}>
                      <Text style={styles.stockLabel}>Opening: {summaryData[0].opening} {summaryData[0].item.unit}</Text>
                      <Text style={styles.stockLabel}>Closing: {summaryData[0].closing} {summaryData[0].item.unit}</Text>
                    </View>
                  )}
                  {transactions.length === 0 ? <Text style={styles.noData}>No transactions in this period</Text> : transactions.map((t, idx) => (
                    <View key={idx} style={styles.card}>
                      <Text style={styles.cardValueSmall}>{new Date(t.created_at).toLocaleString()}</Text>
                      <Text style={[t.transaction_type === 'in' ? styles.inText : styles.outText]}>{t.transaction_type.toUpperCase()} {t.quantity} {t.inventory_items?.unit}</Text>
                      {t.notes && <Text style={styles.cardValueSmall}>{t.notes}</Text>}
                    </View>
                  ))}
                </>
              )}
            </ScrollView>
          )}
        </View>
      </View>
      <CalendarPicker visible={showStartPicker} selectedDate={customStartDate} onSelectDate={setCustomStartDate} onClose={() => setShowStartPicker(false)} />
      <CalendarPicker visible={showEndPicker} selectedDate={customEndDate} onSelectDate={setCustomEndDate} onClose={() => setShowEndPicker(false)} />
      
      <SelectEmailRecipientsModal
        visible={showEmailModal}
        onClose={() => setShowEmailModal(false)}
        onSend={sendEmailToRecipients}
        sending={sendingEmail}
      />
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 10 },
  modal: { backgroundColor: '#fff', borderRadius: 16, maxHeight: '95%', flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderBottomColor: '#ddd' },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  emailBtn: { padding: 4 },
  title: { fontSize: 20, fontWeight: 'bold' },
  periodSelector: { flexDirection: 'row', padding: 8, gap: 6 },
  periodBtn: { flex: 1, padding: 8, backgroundColor: '#f0f0f0', borderRadius: 8, alignItems: 'center' },
  periodBtnActive: { backgroundColor: '#007AFF' },
  periodText: { fontSize: 12, color: '#666' },
  periodTextActive: { color: '#fff', fontWeight: '600' },
  dateRow: { flexDirection: 'row', paddingHorizontal: 12, gap: 8, marginBottom: 8 },
  dateBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 6, padding: 10, backgroundColor: '#f0f9ff', borderRadius: 8, borderWidth: 1, borderColor: '#007AFF' },
  dateText: { fontSize: 13, color: '#007AFF', fontWeight: '500' },
  itemSelectorContainer: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    paddingHorizontal: 4, 
    marginBottom: 8,
    minHeight: 50,
  },
  itemScrollView: { 
    flexGrow: 1,
    flexShrink: 1,
  },
  itemScrollContent: { 
    paddingHorizontal: 8, 
    paddingVertical: 6,
    alignItems: 'center',
    flexDirection: 'row',
  },
  itemBtn: { 
    paddingHorizontal: 14, 
    paddingVertical: 8, 
    backgroundColor: '#f0f0f0', 
    borderRadius: 8, 
    marginRight: 8,
    minWidth: 60,
  },
  itemBtnActive: { backgroundColor: '#8B5CF6' },
  itemText: { fontSize: 12, color: '#666', textAlign: 'center' },
  itemTextActive: { color: '#fff', fontWeight: '600' },
  chevronBtn: { 
    padding: 8, 
    backgroundColor: '#e8f4ff', 
    borderRadius: 6,
    marginHorizontal: 2,
  },
  summaryCard: { backgroundColor: '#f8f9fa', padding: 12, borderRadius: 10, marginBottom: 8, borderLeftWidth: 4, borderLeftColor: '#007AFF' },
  summaryTitle: { fontSize: 15, fontWeight: 'bold', marginBottom: 6 },
  summaryRow: { flexDirection: 'row', gap: 16, marginVertical: 4 },
  summaryLabel: { fontSize: 13, color: '#666' },
  summaryValue: { fontWeight: 'bold', color: '#333' },
  stockRow: { flexDirection: 'row', justifyContent: 'space-around', padding: 12, backgroundColor: '#f0f9ff', marginBottom: 8, borderRadius: 8 },
  stockLabel: { fontSize: 14, fontWeight: 'bold', color: '#007AFF' },
  content: { flex: 1, padding: 12 },
  card: { backgroundColor: '#f8f9fa', padding: 12, borderRadius: 8, marginBottom: 8 },
  cardValueSmall: { fontSize: 11, color: '#666' },
  inText: { color: '#34C759', fontWeight: 'bold' },
  outText: { color: '#FF3B30', fontWeight: 'bold' },
  noData: { textAlign: 'center', color: '#999', marginTop: 20 }
});
