import React from 'react';
import { Modal, View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';

interface FinishingRecord {
  id: string;
  job_number: string;
  customer_name: string;
  item_description: string;
  weight_kg: string;
  item_options?: any;
}

interface Props {
  visible: boolean;
  onClose: () => void;
  records: FinishingRecord[];
  onExport: () => void;
}

const formatDateForReport = (date: Date) => {
  const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
  const months = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'];
  return `${days[date.getDay()]} ${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`;
};

export default function FinishingPreviewModal({ visible, onClose, records, onExport }: Props) {
  const reportDate = formatDateForReport(new Date());
  
  const totalWeight = records.reduce((sum, rec) => sum + parseFloat(rec.weight_kg || '0'), 0);

  const groupedByJob = records.reduce((acc, rec) => {
    if (!acc[rec.job_number]) {
      acc[rec.job_number] = { customer_name: rec.customer_name, items: [] };
    }
    acc[rec.job_number].items.push(rec);
    return acc;
  }, {} as Record<string, { customer_name: string; items: FinishingRecord[] }>);

  return (
    <Modal visible={visible} animationType="slide" transparent={true}>
      <View style={styles.overlay}>
        <View style={styles.container}>
          <ScrollView style={styles.preview}>
            <View style={styles.header}>
              <Text style={styles.headerTitle}>FINISHING - Work Shift Report</Text>
              <Text style={styles.headerDate}>{reportDate}</Text>
            </View>
            
            <View style={styles.table}>
              <View style={styles.tableHeader}>
                <Text style={[styles.headerCell, styles.jobCol]}>JOB NO</Text>
                <Text style={[styles.headerCell, styles.customerCol]}>CUSTOMER</Text>
                <Text style={[styles.headerCell, styles.descCol]}>ITEM DESCRIPTION</Text>
                <Text style={[styles.headerCell, styles.weightCol]}>WEIGHT (KG)</Text>
              </View>

              {Object.entries(groupedByJob).map(([jobNum, data]) => (
                data.items.map((rec, idx) => (
                  <View key={rec.id} style={styles.tableRow}>
                    <Text style={[styles.cell, styles.jobCol, styles.centerAlign]}>
                      {idx === 0 ? jobNum : ''}
                    </Text>
                    <Text style={[styles.cell, styles.customerCol]}>
                      {idx === 0 ? data.customer_name : ''}
                    </Text>
                    <Text style={[styles.cell, styles.descCol]}>{rec.item_description}</Text>
                    <Text style={[styles.cell, styles.weightCol, styles.rightAlign]}>
                      {parseFloat(rec.weight_kg || '0').toFixed(2)}
                    </Text>
                  </View>
                ))
              ))}
              
              <View style={[styles.tableRow, styles.totalRow]}>
                <View style={[styles.cell, styles.totalLabelCell]}>
                  <Text style={styles.totalLabel}>SHIFT TOTAL:</Text>
                </View>
                <Text style={[styles.cell, styles.weightCol, styles.rightAlign, styles.totalText]}>
                  {totalWeight.toFixed(2)}
                </Text>
              </View>
            </View>
          </ScrollView>

          <View style={styles.buttons}>
            <TouchableOpacity style={styles.cancelButton} onPress={onClose}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.exportButton} onPress={onExport}>
              <Text style={styles.exportText}>Export PDF</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  container: { backgroundColor: 'white', borderRadius: 12, maxHeight: '90%', padding: 20 },
  preview: { flex: 1, borderWidth: 1, borderColor: '#e5e7eb', borderRadius: 8, padding: 12, marginBottom: 16 },
  header: { marginBottom: 12, paddingBottom: 8, borderBottomWidth: 2, borderBottomColor: '#10B981' },
  headerTitle: { fontSize: 14, fontWeight: 'bold', textAlign: 'center', marginBottom: 4, color: '#10B981' },
  headerDate: { fontSize: 10, textAlign: 'center', color: '#666' },
  table: { borderWidth: 1, borderColor: '#000' },
  tableHeader: { flexDirection: 'row', backgroundColor: '#10B981', borderBottomWidth: 1, borderBottomColor: '#000' },
  headerCell: { fontSize: 9, fontWeight: 'bold', padding: 4, borderRightWidth: 1, borderRightColor: '#000', textAlign: 'center', color: 'white' },
  tableRow: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: '#000' },
  cell: { fontSize: 8, padding: 3, borderRightWidth: 1, borderRightColor: '#000' },
  rightAlign: { textAlign: 'right' },
  centerAlign: { textAlign: 'center' },
  jobCol: { width: '12%' },
  customerCol: { width: '23%' },
  descCol: { width: '50%' },
  weightCol: { width: '15%' },
  totalRow: { backgroundColor: '#10B981' },
  totalLabelCell: { width: '85%', justifyContent: 'center', alignItems: 'flex-end', paddingRight: 5 },
  totalLabel: { fontSize: 9, fontWeight: 'bold', color: 'white' },
  totalText: { fontSize: 9, fontWeight: 'bold', color: 'white' },
  buttons: { flexDirection: 'row', gap: 12 },
  cancelButton: { flex: 1, padding: 14, backgroundColor: '#f3f4f6', borderRadius: 8, alignItems: 'center' },
  cancelText: { fontSize: 16, fontWeight: '600', color: '#374151' },
  exportButton: { flex: 1, padding: 14, backgroundColor: '#10B981', borderRadius: 8, alignItems: 'center' },
  exportText: { fontSize: 16, fontWeight: '600', color: 'white' },
});
