import React from 'react';
import { Modal, View, Text, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';

interface ConflictResolutionModalProps {
  visible: boolean;
  localVersion: any;
  serverVersion: any;
  onResolve: (resolution: 'local' | 'server' | 'merge') => void;
  onCancel: () => void;
}

export default function ConflictResolutionModal({
  visible,
  localVersion,
  serverVersion,
  onResolve,
  onCancel
}: ConflictResolutionModalProps) {
  const renderDifferences = () => {
    if (!localVersion || !serverVersion) return null;

    const keys = new Set([...Object.keys(localVersion), ...Object.keys(serverVersion)]);
    const differences: any[] = [];

    keys.forEach(key => {
      if (key === 'updated_at' || key === 'created_at') return;
      if (JSON.stringify(localVersion[key]) !== JSON.stringify(serverVersion[key])) {
        differences.push({ key, local: localVersion[key], server: serverVersion[key] });
      }
    });

    return differences;
  };

  const differences = renderDifferences();

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <Text style={styles.title}>Sync Conflict Detected</Text>
          <Text style={styles.subtitle}>
            This job was modified by another user while you were offline.
          </Text>

          <ScrollView style={styles.diffContainer}>
            {differences?.map((diff, idx) => (
              <View key={idx} style={styles.diffRow}>
                <Text style={styles.diffKey}>{diff.key}:</Text>
                <View style={styles.versions}>
                  <View style={styles.versionBox}>
                    <Text style={styles.versionLabel}>Your Changes</Text>
                    <Text style={styles.versionValue}>{String(diff.local)}</Text>
                  </View>
                  <View style={styles.versionBox}>
                    <Text style={styles.versionLabel}>Server Version</Text>
                    <Text style={styles.versionValue}>{String(diff.server)}</Text>
                  </View>
                </View>
              </View>
            ))}
          </ScrollView>

          <View style={styles.actions}>
            <TouchableOpacity style={styles.btnLocal} onPress={() => onResolve('local')}>
              <Text style={styles.btnText}>Keep My Changes</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.btnServer} onPress={() => onResolve('server')}>
              <Text style={styles.btnText}>Use Server Version</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.btnCancel} onPress={onCancel}>
              <Text style={styles.btnCancelText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: '#fff', borderRadius: 12, padding: 20, maxHeight: '80%' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 8 },
  subtitle: { fontSize: 14, color: '#666', marginBottom: 16 },
  diffContainer: { maxHeight: 300, marginBottom: 16 },
  diffRow: { marginBottom: 16, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: '#eee' },
  diffKey: { fontSize: 16, fontWeight: '600', marginBottom: 8 },
  versions: { flexDirection: 'row', gap: 12 },
  versionBox: { flex: 1, backgroundColor: '#f5f5f5', padding: 10, borderRadius: 8 },
  versionLabel: { fontSize: 12, fontWeight: '600', color: '#666', marginBottom: 4 },
  versionValue: { fontSize: 14, color: '#333' },
  actions: { gap: 10 },
  btnLocal: { backgroundColor: '#2563eb', padding: 14, borderRadius: 8, alignItems: 'center' },
  btnServer: { backgroundColor: '#16a34a', padding: 14, borderRadius: 8, alignItems: 'center' },
  btnCancel: { backgroundColor: '#fff', padding: 14, borderRadius: 8, alignItems: 'center', borderWidth: 1, borderColor: '#ddd' },
  btnText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  btnCancelText: { color: '#333', fontSize: 16, fontWeight: '600' }
});
