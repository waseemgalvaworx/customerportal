import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Modal, StyleSheet, ScrollView, Alert } from 'react-native';
import { supabase } from '@/app/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';


interface AddUserModalProps {
  visible: boolean;
  onClose: () => void;
  onUserAdded: () => void;
}

const ROLES = [
  { value: 'admin', label: 'Admin' },
  { value: 'manager', label: 'Manager' },
  { value: 'operator', label: 'Operator' },
  { value: 'viewer', label: 'Viewer' },
  { value: 'data_entry_officer', label: 'Data Entry Officer' }
];

export default function AddUserModal({ visible, onClose, onUserAdded }: AddUserModalProps) {
  const { user } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState('operator');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    console.log('Create User button clicked');
    
    if (!username || !password || !fullName) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }
    
    if (password.length < 6) {
      Alert.alert('Error', 'Password must be at least 6 characters');
      return;
    }

    if (!user?.id) {
      Alert.alert('Error', 'Not authenticated');
      return;
    }
    
    setLoading(true);
    console.log('Calling create-user function with:', { username, full_name: fullName, role, adminUserId: user.id });
    
    try {
      const { data, error } = await supabase.functions.invoke('create-user', {
        body: { 
          username, 
          password, 
          full_name: fullName, 
          role,
          adminUserId: user.id
        }
      });
      
      console.log('Function response:', { data, error });
      
      if (error) {
        console.error('Function error:', error);
        throw error;
      }
      
      if (data?.error) {
        console.error('Data error:', data.error);
        throw new Error(data.error);
      }
      
      Alert.alert('Success', 'User created successfully');
      setUsername('');
      setPassword('');
      setFullName('');
      setRole('operator');
      onUserAdded();
      onClose();
    } catch (error: any) {
      console.error('Catch error:', error);
      Alert.alert('Error', error.message || 'Failed to create user');
    } finally {
      setLoading(false);
    }
  };




  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <Text style={styles.title}>Add New User</Text>
          <ScrollView>
            <TextInput style={styles.input} placeholder="Username" value={username} onChangeText={setUsername} autoCapitalize="none" />
            <TextInput style={styles.input} placeholder="Password (min 6 chars)" value={password} onChangeText={setPassword} secureTextEntry />
            <TextInput style={styles.input} placeholder="Full Name" value={fullName} onChangeText={setFullName} />
            <Text style={styles.label}>Role</Text>
            {ROLES.map(r => (
              <TouchableOpacity key={r.value} style={[styles.roleOption, role === r.value && styles.roleSelected]} onPress={() => setRole(r.value)}>
                <Text style={[styles.roleText, role === r.value && styles.roleTextSelected]}>{r.label}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
          <View style={styles.buttons}>
            <TouchableOpacity style={[styles.button, styles.cancelButton]} onPress={onClose} disabled={loading}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.button, styles.submitButton, loading && styles.buttonDisabled]} onPress={handleSubmit} disabled={loading}>
              <Text style={styles.submitText}>{loading ? 'Creating...' : 'Create User'}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: '#fff', borderRadius: 12, padding: 20, maxHeight: '80%' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 20 },
  input: { backgroundColor: '#f5f5f5', padding: 12, borderRadius: 8, marginBottom: 12, borderWidth: 1, borderColor: '#ddd' },
  label: { fontSize: 14, fontWeight: '600', marginBottom: 8, marginTop: 8 },
  roleOption: { padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#ddd', marginBottom: 8 },
  roleSelected: { backgroundColor: '#007AFF', borderColor: '#007AFF' },
  roleText: { fontSize: 14, color: '#333' },
  roleTextSelected: { color: '#fff', fontWeight: '600' },
  buttons: { flexDirection: 'row', gap: 10, marginTop: 20 },
  button: { flex: 1, padding: 12, borderRadius: 8, alignItems: 'center' },
  cancelButton: { backgroundColor: '#f5f5f5' },
  submitButton: { backgroundColor: '#007AFF' },
  buttonDisabled: { backgroundColor: '#ccc' },
  cancelText: { color: '#333', fontWeight: '600' },
  submitText: { color: '#fff', fontWeight: '600' }
});
