import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';

interface CompletedItem {
  id: string;
  job_id: string;
  job_number: string;
  customer_name: string;
  item_id: string;
  item_description: string;
  weight_kg: number;
  item_options: any;
  ready_date: string;
}

interface CompletedItemsPreviewProps {
  items: CompletedItem[];
  reportDate: string;
}

export const CompletedItemsPreview: React.FC<CompletedItemsPreviewProps> = ({ items, reportDate }) => {
  if (!items || items.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No completed items for this date</Text>
      </View>
    );
  }

  // Group by job
  const groupedByJob = items.reduce((acc: any, item) => {
    if (!acc[item.job_number]) {
      acc[item.job_number] = { customer_name: item.customer_name, items: [] };
    }
    acc[item.job_number].items.push(item);
    return acc;
  }, {});

  const totalWeight = items.reduce((sum, item) => sum + parseFloat(String(item.weight_kg || 0)), 0);

  return (
    <ScrollView style={styles.previewScroll}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Completed Items Report</Text>
        <Text style={styles.headerSubtitle}>Items moved from Finishing to Ready</Text>
        <Text style={styles.headerDate}>{reportDate}</Text>
      </View>
      
      <View style={styles.table}>
        <View style={styles.tableHeader}>
          <Text style={[styles.headerCell, styles.jobCol]}>JOB NO</Text>
          <Text style={[styles.headerCell, styles.customerCol]}>CUSTOMER</Text>
          <Text style={[styles.headerCell, styles.descCol]}>ITEM DESCRIPTION</Text>
          <Text style={[styles.headerCell, styles.optionsCol]}>OPTIONS</Text>
          <Text style={[styles.headerCell, styles.weightCol]}>WEIGHT (KG)</Text>
        </View>

        {Object.entries(groupedByJob).map(([jobNum, data]: [string, any]) => (
          data.items.map((item: CompletedItem, idx: number) => {
            const opts = [];
            if (item.item_options?.paintVarnish) opts.push('Paint/Varnish');
            if (item.item_options?.galva) opts.push('Galva');
            if (item.item_options?.lightGalva) opts.push('Light Galva');
            if (item.item_options?.lightPaint) opts.push('Light Paint');
            if (item.item_options?.rusty) opts.push('Rusty');
            
            return (
              <View key={item.id || `${item.job_id}-${item.item_id}`} style={styles.tableRow}>
                <Text style={[styles.cell, styles.jobCol, styles.centerAlign]}>
                  {idx === 0 ? jobNum : ''}
                </Text>
                <Text style={[styles.cell, styles.customerCol]}>
                  {idx === 0 ? data.customer_name : ''}
                </Text>
                <Text style={[styles.cell, styles.descCol]}>{item.item_description}</Text>
                <Text style={[styles.cell, styles.optionsCol, styles.smallText]}>{opts.join(', ') || '-'}</Text>
                <Text style={[styles.cell, styles.weightCol, styles.rightAlign]}>
                  {parseFloat(String(item.weight_kg || 0)).toFixed(2)}
                </Text>
              </View>
            );
          })
        ))}
        
        <View style={[styles.tableRow, styles.totalRow]}>
          <View style={[styles.cell, styles.totalLabelCell]}>
            <Text style={styles.totalLabel}>TOTAL COMPLETED:</Text>
          </View>
          <Text style={[styles.cell, styles.weightCol, styles.rightAlign, styles.totalText]}>
            {totalWeight.toFixed(2)}
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  previewScroll: { flex: 1, backgroundColor: '#fff', padding: 12 },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  emptyText: { fontSize: 16, color: '#999', textAlign: 'center' },
  header: { marginBottom: 8, paddingBottom: 8, borderBottomWidth: 2, borderBottomColor: '#007AFF' },
  headerTitle: { fontSize: 14, fontWeight: 'bold', textAlign: 'center', marginBottom: 2, color: '#007AFF' },
  headerSubtitle: { fontSize: 10, textAlign: 'center', color: '#666', marginBottom: 4 },
  headerDate: { fontSize: 10, textAlign: 'center', color: '#666' },
  table: { borderWidth: 1, borderColor: '#000' },
  tableHeader: { flexDirection: 'row', backgroundColor: '#007AFF', borderBottomWidth: 1, borderBottomColor: '#000' },
  headerCell: { fontSize: 8, fontWeight: 'bold', padding: 4, borderRightWidth: 1, borderRightColor: '#000', textAlign: 'center', color: 'white' },
  tableRow: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: '#000' },
  cell: { fontSize: 8, padding: 3, borderRightWidth: 1, borderRightColor: '#000' },
  smallText: { fontSize: 7 },
  rightAlign: { textAlign: 'right' },
  centerAlign: { textAlign: 'center' },
  jobCol: { width: '10%' },
  customerCol: { width: '18%' },
  descCol: { width: '38%' },
  optionsCol: { width: '20%' },
  weightCol: { width: '14%' },
  totalRow: { backgroundColor: '#007AFF' },
  totalLabelCell: { width: '86%', justifyContent: 'center', alignItems: 'flex-end', paddingRight: 5 },
  totalLabel: { fontSize: 9, fontWeight: 'bold', color: 'white' },
  totalText: { fontSize: 9, fontWeight: 'bold', color: 'white' },
});
