import React, { useState, useEffect } from 'react';
import { Modal, View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Alert } from 'react-native';
import { supabase } from '@/app/lib/supabase';
import { usePasswordAuth } from '@/contexts/PasswordAuthContext';
import { getUserIdFromUsername } from '@/utils/userMapping';
import { checkUserNotificationPermission } from '@/utils/notificationHelper';

interface RequestStockModalProps {
  visible: boolean;
  onClose: () => void;
  inventoryItems: any[];
  onSuccess: () => void;
}

export default function RequestStockModal({ visible, onClose, inventoryItems, onSuccess }: RequestStockModalProps) {
  const { user } = usePasswordAuth();
  const [selectedItemId, setSelectedItemId] = useState('');
  const [quantity, setQuantity] = useState('');
  const [reason, setReason] = useState('');
  const [ref, setRef] = useState('');
  const [loading, setLoading] = useState(false);

  const rawMaterialItems = inventoryItems
    .filter(item => item.category === 'raw_materials' && item.item_name.toLowerCase() !== 'diesel')
    .filter((item, index, self) => index === self.findIndex((t) => t.item_name === item.item_name));

  const handleSubmit = async () => {
    if (!selectedItemId || !quantity || parseFloat(quantity) <= 0) {
      Alert.alert('Error', 'Please select an item and enter a valid quantity');
      return;
    }
    if (!user) {
      Alert.alert('Error', 'User not authenticated');
      return;
    }
    if (loading) return;

    setLoading(true);
    try {
      const { data, error } = await supabase.from('stock_requests').insert({
        item_id: selectedItemId,
        requested_by: user?.username || user?.email || 'Unknown',
        quantity_requested: parseFloat(quantity),
        reason: reason || null,
        ref: ref || null,
        status: 'pending'
      }).select();

      if (error) throw error;

      const selectedItem = rawMaterialItems.find(item => item.id === selectedItemId);
      const itemName = selectedItem?.item_name || 'Unknown Item';
      const notificationTargets = ['admin', 'Lovena', 'KH', 'Ashok'];
      
      // Send notifications with permission check
      for (const target of notificationTargets) {
        const targetUserId = getUserIdFromUsername(target);
        if (!targetUserId) continue;
        
        const hasPermission = await checkUserNotificationPermission(
          targetUserId, 'stock_request_created', 'New Stock Request', ''
        );
        if (!hasPermission) {
          console.log(`🚫 User ${target} has disabled stock_request_created notifications`);
          continue;
        }
        
        await supabase.from('notifications').insert({
          user_id: targetUserId,
          title: 'New Stock Request',
          message: `${user?.username || 'User'} requested ${quantity} ${selectedItem?.unit || 'units'} of ${itemName}. Reason: ${reason || 'None'}`,
          type: 'stock_request_created',
          created_at: new Date().toISOString()
        });
      }

      Alert.alert('Success', 'Stock request submitted successfully');
      setSelectedItemId('');
      setQuantity('');
      setReason('');
      setRef('');
      onSuccess();
      onClose();
    } catch (error: any) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <View style={styles.header}>
            <Text style={styles.title}>Request Stock</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
              <Text style={styles.closeText}>X</Text>
            </TouchableOpacity>
          </View>
          
          <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
            <Text style={styles.label}>Select Item *</Text>
            {rawMaterialItems.length === 0 ? (
              <Text style={styles.noItems}>No raw material items available</Text>
            ) : (
              <ScrollView style={styles.itemList} nestedScrollEnabled>
                {rawMaterialItems.map(item => (
                  <TouchableOpacity
                    key={item.id}
                    style={[styles.itemOption, selectedItemId === item.id && styles.itemOptionSelected]}
                    onPress={() => setSelectedItemId(item.id)}
                  >
                    <Text style={[styles.itemText, selectedItemId === item.id && styles.itemTextSelected]}>
                      {item.item_name} (Stock: {item.quantity} {item.unit})
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            )}

            <Text style={styles.label}>Quantity *</Text>
            <TextInput style={styles.input} value={quantity} onChangeText={setQuantity} keyboardType="numeric" placeholder="Enter quantity" />
            
            <Text style={styles.label}>Reason (Optional)</Text>
            <TextInput style={styles.textArea} value={reason} onChangeText={setReason} multiline numberOfLines={3} placeholder="Why do you need this item?" />

            <Text style={styles.label}>Ref (Optional)</Text>
            <TextInput style={styles.input} value={ref} onChangeText={setRef} placeholder="Reference number or code" />
          </ScrollView>

          <View style={styles.buttons}>
            <TouchableOpacity style={styles.cancelBtn} onPress={onClose}><Text style={styles.cancelText}>Cancel</Text></TouchableOpacity>
            <TouchableOpacity style={[styles.submitBtn, loading && styles.submitBtnDisabled]} onPress={handleSubmit} disabled={loading}>
              <Text style={styles.submitText}>{loading ? 'Submitting...' : 'Submit Request'}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  modal: { backgroundColor: '#fff', borderRadius: 12, width: '100%', maxWidth: 500, maxHeight: '90%' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, borderBottomWidth: 1, borderBottomColor: '#e0e0e0' },
  title: { fontSize: 20, fontWeight: 'bold' },
  closeBtn: { padding: 4 },
  closeText: { fontSize: 24, color: '#666' },
  content: { padding: 20, maxHeight: 400 },
  label: { fontSize: 14, fontWeight: '600', marginTop: 12, marginBottom: 8, color: '#333' },
  noItems: { padding: 20, textAlign: 'center', color: '#999', fontSize: 14 },
  itemList: { maxHeight: 150, borderWidth: 1, borderColor: '#ddd', borderRadius: 8, marginBottom: 12 },
  itemOption: { padding: 12, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  itemOptionSelected: { backgroundColor: '#007AFF' },
  itemText: { fontSize: 16, color: '#333' },
  itemTextSelected: { color: '#fff', fontWeight: '600' },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, fontSize: 16, backgroundColor: '#fff' },
  textArea: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, fontSize: 16, minHeight: 80, textAlignVertical: 'top', backgroundColor: '#fff' },
  buttons: { flexDirection: 'row', gap: 10, padding: 20, borderTopWidth: 1, borderTopColor: '#e0e0e0' },
  cancelBtn: { flex: 1, padding: 14, borderRadius: 8, borderWidth: 1, borderColor: '#ddd', backgroundColor: '#fff' },
  cancelText: { textAlign: 'center', fontSize: 16, color: '#333', fontWeight: '600' },
  submitBtn: { flex: 1, padding: 14, borderRadius: 8, backgroundColor: '#007AFF' },
  submitBtnDisabled: { backgroundColor: '#ccc' },
  submitText: { textAlign: 'center', fontSize: 16, color: '#fff', fontWeight: '600' }
});
