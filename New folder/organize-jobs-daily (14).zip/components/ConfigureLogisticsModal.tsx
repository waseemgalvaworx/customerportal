import React, { useState, useEffect } from 'react';
import { View, Text, Modal, ScrollView, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { supabase } from '../app/lib/supabase';
import AddVehicleModal from './AddVehicleModal';
import AddDriverModal from './AddDriverModal';
import VehicleDetailsModal from './VehicleDetailsModal';
import DriverDetailsModal from './DriverDetailsModal';

interface ConfigureLogisticsModalProps {
  visible: boolean;
  onClose: () => void;
}

export default function ConfigureLogisticsModal({ visible, onClose }: ConfigureLogisticsModalProps) {
  const [activeSection, setActiveSection] = useState('vehicles');
  const [vehicles, setVehicles] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [loading, setLoading] = useState(false);
  
  const [showVehicleModal, setShowVehicleModal] = useState(false);
  const [showDriverModal, setShowDriverModal] = useState(false);
  const [showVehicleDetails, setShowVehicleDetails] = useState(false);
  const [showDriverDetails, setShowDriverDetails] = useState(false);
  const [selectedVehicleId, setSelectedVehicleId] = useState(null);
  const [selectedDriverId, setSelectedDriverId] = useState(null);

  useEffect(() => {
    if (visible) loadData();
  }, [visible, activeSection]);

  const loadData = async () => {
    setLoading(true);
    try {
      if (activeSection === 'vehicles') {
        const { data } = await supabase.from('vehicles').select('*').order('created_at', { ascending: false });
        setVehicles(data || []);
      } else {
        const { data } = await supabase.from('drivers').select('*').order('created_at', { ascending: false });
        setDrivers(data || []);
      }
    } catch (error) {
      Alert.alert('Error', error.message);
    }
    setLoading(false);
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <Text style={styles.title}>Configure Logistics</Text>
          
          <View style={styles.tabs}>
            <TouchableOpacity style={[styles.tab, activeSection === 'vehicles' && styles.activeTab]} onPress={() => setActiveSection('vehicles')}>
              <Text style={styles.tabText}>Vehicles</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.tab, activeSection === 'drivers' && styles.activeTab]} onPress={() => setActiveSection('drivers')}>
              <Text style={styles.tabText}>Drivers</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.content}>
            {activeSection === 'vehicles' && (
              <View>
                <TouchableOpacity style={styles.addButton} onPress={() => setShowVehicleModal(true)}>
                  <Text style={styles.addButtonText}>+ Add Vehicle</Text>
                </TouchableOpacity>
                {vehicles.map(v => (
                  <TouchableOpacity key={v.id} style={styles.card} onPress={() => { setSelectedVehicleId(v.id); setShowVehicleDetails(true); }}>
                    <Text style={styles.cardTitle}>{v.vehicle_number}</Text>
                    <Text>{v.make} {v.model}</Text>
                    <Text>License: {v.license_plate}</Text>
                    <Text>Status: {v.status}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}

            {activeSection === 'drivers' && (
              <View>
                <TouchableOpacity style={styles.addButton} onPress={() => setShowDriverModal(true)}>
                  <Text style={styles.addButtonText}>+ Add Driver</Text>
                </TouchableOpacity>
                {drivers.map(d => (
                  <TouchableOpacity key={d.id} style={styles.card} onPress={() => { setSelectedDriverId(d.id); setShowDriverDetails(true); }}>
                    <Text style={styles.cardTitle}>{d.full_name}</Text>
                    <Text>License: {d.license_number}</Text>
                    <Text>Phone: {d.phone}</Text>
                    <Text>Status: {d.status}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </ScrollView>

          <TouchableOpacity style={styles.closeButton} onPress={onClose}>
            <Text style={styles.closeText}>Close</Text>
          </TouchableOpacity>

          <AddVehicleModal visible={showVehicleModal} onClose={() => setShowVehicleModal(false)} onSuccess={loadData} />
          <AddDriverModal visible={showDriverModal} onClose={() => setShowDriverModal(false)} onSuccess={loadData} />
          <VehicleDetailsModal visible={showVehicleDetails} onClose={() => setShowVehicleDetails(false)} vehicleId={selectedVehicleId} onSuccess={loadData} />
          <DriverDetailsModal visible={showDriverDetails} onClose={() => setShowDriverDetails(false)} driverId={selectedDriverId} onSuccess={loadData} />
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: 'white', borderRadius: 12, padding: 20, maxHeight: '90%' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 15 },
  tabs: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: '#e5e7eb', marginBottom: 15 },
  tab: { flex: 1, padding: 12, alignItems: 'center' },
  activeTab: { borderBottomWidth: 2, borderBottomColor: '#2563eb' },
  tabText: { fontSize: 14, fontWeight: '600' },
  content: { flex: 1, marginBottom: 15 },
  addButton: { backgroundColor: '#2563eb', padding: 15, borderRadius: 8, marginBottom: 15 },
  addButtonText: { color: 'white', textAlign: 'center', fontWeight: '600' },
  card: { backgroundColor: '#f9fafb', padding: 15, borderRadius: 8, marginBottom: 10, borderWidth: 1, borderColor: '#e5e7eb' },
  cardTitle: { fontSize: 16, fontWeight: 'bold', marginBottom: 5 },
  closeButton: { backgroundColor: '#6b7280', padding: 15, borderRadius: 8 },
  closeText: { color: 'white', textAlign: 'center', fontWeight: '600' }
});
