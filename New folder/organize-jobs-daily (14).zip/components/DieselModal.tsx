import React, { useState, useEffect } from 'react';
import { View, Text, Modal, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../app/lib/supabase';
import { DieselInventoryCard } from './DieselInventoryCard';
import DieselRefillModal from './DieselRefillModal';
import DieselReadingModal from './DieselReadingModal';
import DieselAnalyticsModal from './DieselAnalyticsModal';
import DieselRefillRecordsModal from './DieselRefillRecordsModal';


interface DieselModalProps {
  visible: boolean;
  onClose: () => void;
  onRefresh?: () => void;
}

export default function DieselModal({ visible, onClose, onRefresh }: DieselModalProps) {
  const [dieselItem, setDieselItem] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [refillModalVisible, setRefillModalVisible] = useState(false);
  const [readingModalVisible, setReadingModalVisible] = useState(false);
  const [analyticsModalVisible, setAnalyticsModalVisible] = useState(false);
  const [refillRecordsModalVisible, setRefillRecordsModalVisible] = useState(false);


  useEffect(() => {
    if (visible) fetchDieselItem();
  }, [visible]);

  const fetchDieselItem = async () => {
    try {
      const { data, error } = await supabase.from('inventory_items').select('*').ilike('item_name', 'diesel').single();
      if (error) throw error;
      setDieselItem(data);
    } catch (err) {
      console.error('Error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => { 
    await fetchDieselItem(); 
    onRefresh?.(); 
  };


  return (
    <>
      <Modal visible={visible} animationType="slide" transparent>
        <View style={styles.overlay}>
          <View style={styles.modal}>
            <View style={styles.header}>
              <Text style={styles.title}>Diesel Management</Text>
              <TouchableOpacity onPress={onClose}><Ionicons name="close" size={28} color="#333" /></TouchableOpacity>
            </View>
            <ScrollView style={styles.content}>
              {loading ? <Text>Loading...</Text> : dieselItem ? (
                <>
                  <DieselInventoryCard height={dieselItem.quantity} lastUpdated={dieselItem.updated_at} lowStockThreshold={dieselItem.reorder_level || 500} />
                  <View style={styles.buttonGrid}>
                    <TouchableOpacity style={[styles.actionButton, {backgroundColor: '#28a745'}]} onPress={() => setRefillModalVisible(true)}>
                      <Ionicons name="add-circle" size={24} color="#fff" />
                      <Text style={styles.actionButtonText}>Record Refill</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.actionButton, {backgroundColor: '#17a2b8'}]} onPress={() => setRefillRecordsModalVisible(true)}>
                      <Ionicons name="list" size={24} color="#fff" />
                      <Text style={styles.actionButtonText}>Refill Records</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.actionButton, {backgroundColor: '#007AFF'}]} onPress={() => setReadingModalVisible(true)}>
                      <Ionicons name="clipboard" size={24} color="#fff" />
                      <Text style={styles.actionButtonText}>Log Reading</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.actionButton, {backgroundColor: '#ff6b6b'}]} onPress={() => setAnalyticsModalVisible(true)}>
                      <Ionicons name="stats-chart" size={24} color="#fff" />
                      <Text style={styles.actionButtonText}>View Analytics</Text>
                    </TouchableOpacity>

                  </View>
                </>
              ) : <Text>No diesel item found</Text>}
            </ScrollView>
          </View>
        </View>
      </Modal>
      <DieselRefillModal visible={refillModalVisible} onClose={() => setRefillModalVisible(false)} onSuccess={() => { handleRefresh(); }} />
      <DieselReadingModal visible={readingModalVisible} onClose={() => setReadingModalVisible(false)} onSuccess={handleRefresh} />
      <DieselAnalyticsModal visible={analyticsModalVisible} onClose={() => setAnalyticsModalVisible(false)} />
      <DieselRefillRecordsModal visible={refillRecordsModalVisible} onClose={() => setRefillRecordsModalVisible(false)} />


    </>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modal: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, maxHeight: '80%' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, borderBottomWidth: 1, borderBottomColor: '#ddd' },
  title: { fontSize: 20, fontWeight: 'bold' },
  content: { padding: 20 },
  buttonGrid: { marginTop: 20, gap: 12 },
  actionButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: 16, borderRadius: 12, gap: 8 },
  actionButtonText: { color: '#fff', fontSize: 16, fontWeight: '700' }
});
