import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

interface StatusHistoryTimelineProps {
  history: any[];
}

export default function StatusHistoryTimeline({ history }: StatusHistoryTimelineProps) {
  if (!history || history.length === 0) {
    return <Text style={styles.empty}>No history available</Text>;
  }

  return (
    <View style={styles.container}>
      {history.map((item, index) => (
        <View key={item.id || index} style={styles.item}>
          <View style={styles.dot} />
          <View style={styles.content}>
            <Text style={styles.time}>{new Date(item.created_at).toLocaleString()}</Text>
            <Text style={styles.user}>{item.username}</Text>
            <Text style={styles.desc}>{item.action_description}</Text>
          </View>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginTop: 8 },
  item: { flexDirection: 'row', marginBottom: 12 },
  dot: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#3B82F6', marginRight: 12, marginTop: 4 },
  content: { flex: 1, backgroundColor: '#F9FAFB', padding: 10, borderRadius: 8 },
  time: { fontSize: 11, color: '#6B7280', marginBottom: 2 },
  user: { fontSize: 12, fontWeight: '600', color: '#3B82F6', marginBottom: 2 },
  desc: { fontSize: 13, color: '#1F2937' },
  empty: { fontSize: 14, color: '#9CA3AF', textAlign: 'center', marginTop: 20 }
});
