import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, Alert, Modal, TextInput, Switch } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useJobs } from '../contexts/JobContext';
import { FinishingPreview } from './ArchiveModalPreview';
import { CompletedItemsPreview } from './CompletedItemsPreview';
import { DeliveredPreview } from './DeliveredPreview';
import UnarchiveFinishingModal from './UnarchiveFinishingModal';
import SelectEmailRecipientsModal from './SelectEmailRecipientsModal';
import { supabase } from '@/app/lib/supabase';

interface MainContentProps {
  selectedReportType: 'completed' | 'finishing' | 'delivered' | null;
  dates: string[];
  dataByDate: { [key: string]: any };
  selectedDate: string | null;
  setSelectedDate: (date: string) => void;
  dropdownOpen: boolean;
  setDropdownOpen: (open: boolean) => void;
  handleSelectReportType: (type: 'completed' | 'finishing' | 'delivered') => void;
  selectedData: any;
  reportDate: string;
  onViewPDF: (includeTime: boolean) => void;
  onEmailReport: (recipients: string[], includeTime: boolean) => void;
  emailingReport: boolean;
  onBack?: () => void;
  onRefresh?: () => void;
}

export const ArchiveModalMainContent: React.FC<MainContentProps> = ({
  selectedReportType, dates, dataByDate, selectedDate, setSelectedDate, dropdownOpen, setDropdownOpen,
  handleSelectReportType, selectedData, reportDate, onViewPDF, onEmailReport, emailingReport, onBack, onRefresh
}) => {
  const [showUnarchiveModal, setShowUnarchiveModal] = useState(false);
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [password, setPassword] = useState('');
  const [includeTime, setIncludeTime] = useState(true);

  const handleUnarchiveClick = () => {
    if (!selectedData || (Array.isArray(selectedData) && selectedData.length === 0)) {
      Alert.alert('Error', 'No items to unarchive'); return;
    }
    setShowPasswordPrompt(true);
  };

  const handlePasswordSubmit = () => {
    if (password !== '4321') { Alert.alert('Error', 'Incorrect password'); return; }
    setPassword(''); setShowPasswordPrompt(false);
    if (selectedReportType === 'delivered') handleUnarchiveDelivered();
    else handleUnarchiveCompleted();
  };

  const handleUnarchiveCompleted = async () => {
    Alert.alert('Unarchive Items', `Unarchive ${selectedData.length} item(s)?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Unarchive', style: 'destructive', onPress: async () => {
        for (const item of selectedData) {
          await supabase.from('item_stage_tracking').update({ ready_date: null }).eq('job_id', item.job_id).eq('item_id', item.item_id);
        }
        Alert.alert('Success', `${selectedData.length} item(s) unarchived`);
        onRefresh?.(); onBack?.();
      }}
    ]);
  };

  const handleUnarchiveDelivered = async () => {
    Alert.alert('Unarchive Deliveries', `Unarchive ${selectedData.length} item(s)?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Unarchive', style: 'destructive', onPress: async () => {
        await supabase.from('archived_deliveries').delete().in('id', selectedData.map((i: any) => i.id));
        Alert.alert('Success', `${selectedData.length} item(s) unarchived`);
        onRefresh?.(); onBack?.();
      }}
    ]);
  };

  if (dates.length === 0 && selectedReportType) {
    return <View style={s.empty}><Ionicons name="archive-outline" size={64} color="#ccc" /><Text style={s.emptyText}>No archived {selectedReportType} items</Text></View>;
  }

  const todayStr = new Date().toLocaleDateString('en-GB');
  const todayCount = selectedReportType === 'finishing' ? (dataByDate[todayStr] ? 1 : 0) : (dataByDate[todayStr]?.length || 0);
  const totalRecords = selectedReportType === 'finishing' ? dates.length : Object.values(dataByDate).reduce((sum: number, arr: any) => sum + (Array.isArray(arr) ? arr.length : 1), 0);
  const dateRange = dates.length > 0 ? `${dates[dates.length - 1]} - ${dates[0]}` : 'No data';

  if (!selectedReportType) {
    return (
      <View style={s.cat}>
        <Text style={s.catTitle}>Select Report Type</Text>
        <TouchableOpacity style={s.card} onPress={() => handleSelectReportType('completed')}><Ionicons name="checkmark-done-circle" size={48} color="#007AFF" /><Text style={s.cardTitle}>Completed Items</Text></TouchableOpacity>
        <TouchableOpacity style={s.card} onPress={() => handleSelectReportType('finishing')}><Ionicons name="color-wand" size={48} color="#4CAF50" /><Text style={s.cardTitle}>Finishing Report</Text></TouchableOpacity>
        <TouchableOpacity style={s.card} onPress={() => handleSelectReportType('delivered')}><Ionicons name="car" size={48} color="#8B5CF6" /><Text style={s.cardTitle}>Delivered Items</Text></TouchableOpacity>
      </View>
    );
  }

  return (
    <>
      <View style={s.statsBar}>
        <View style={s.statItem}><Text style={s.statLabel}>Total</Text><Text style={s.statValue}>{totalRecords}</Text></View>
        <View style={s.statItem}><Text style={s.statLabel}>Today</Text><Text style={s.statValue}>{todayCount}</Text></View>
        <View style={s.statItem}><Text style={s.statLabel}>Range</Text><Text style={s.statValueSmall}>{dateRange}</Text></View>
        {dates.includes(todayStr) && <TouchableOpacity style={s.todayBtn} onPress={() => setSelectedDate(todayStr)}><Text style={s.todayBtnText}>Today</Text></TouchableOpacity>}
      </View>
      <View style={s.dd}>
        <TouchableOpacity style={s.ddBtn} onPress={() => setDropdownOpen(!dropdownOpen)}>
          <View><Text style={s.ddLabel}>Date</Text><Text style={s.ddVal}>{selectedDate}</Text></View>
          <Ionicons name={dropdownOpen ? "chevron-up" : "chevron-down"} size={24} color="#007AFF" />
        </TouchableOpacity>
        {dropdownOpen && <ScrollView style={s.ddMenu}>{dates.map(d => <TouchableOpacity key={d} style={[s.ddItem, d === selectedDate && s.ddActive]} onPress={() => { setSelectedDate(d); setDropdownOpen(false); }}><Text style={[s.ddText, d === selectedDate && s.ddTextActive]}>{d}</Text></TouchableOpacity>)}</ScrollView>}
      </View>
      <View style={s.timeToggle}><Text style={s.timeLabel}>Include time</Text><Switch value={includeTime} onValueChange={setIncludeTime} /></View>
      <View style={s.preview}>
        {selectedReportType === 'completed' && <CompletedItemsPreview items={selectedData} reportDate={reportDate} />}
        {selectedReportType === 'finishing' && <FinishingPreview finishingReport={selectedData} reportDate={reportDate} />}
        {selectedReportType === 'delivered' && <DeliveredPreview deliveries={selectedData} reportDate={reportDate} />}
      </View>
      <View style={s.actions}>
        <TouchableOpacity style={[s.btn, s.unBtn]} onPress={handleUnarchiveClick}><Ionicons name="arrow-undo" size={20} color="#fff" /><Text style={s.btnText}>Unarchive</Text></TouchableOpacity>
        <TouchableOpacity style={s.btn} onPress={() => onViewPDF(includeTime)}><Text style={s.btnText}>View PDF</Text></TouchableOpacity>
        <TouchableOpacity style={[s.btn, s.emailBtn]} onPress={() => setShowEmailModal(true)}><Text style={s.btnText}>Email</Text></TouchableOpacity>
      </View>
      <SelectEmailRecipientsModal visible={showEmailModal} onClose={() => setShowEmailModal(false)} onSend={(r) => { setShowEmailModal(false); onEmailReport(r, includeTime); }} sending={emailingReport} />
      <Modal visible={showPasswordPrompt} transparent><View style={s.overlay}><View style={s.modal}><Text style={s.modalTitle}>Enter Password</Text><TextInput style={s.input} secureTextEntry value={password} onChangeText={setPassword} placeholder="Password" /><View style={s.modalBtns}><TouchableOpacity style={s.cancelBtn} onPress={() => setShowPasswordPrompt(false)}><Text style={s.modalBtnText}>Cancel</Text></TouchableOpacity><TouchableOpacity style={s.confirmBtn} onPress={handlePasswordSubmit}><Text style={s.modalBtnText}>OK</Text></TouchableOpacity></View></View></View></Modal>
      {selectedReportType === 'finishing' && <UnarchiveFinishingModal visible={showUnarchiveModal} onClose={() => setShowUnarchiveModal(false)} reportDate={selectedDate || ''} archivedReport={selectedData} onSuccess={() => onRefresh?.()} />}
    </>
  );
};

const s = StyleSheet.create({
  empty: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyText: { fontSize: 16, color: '#999', marginTop: 20 },
  cat: { flex: 1, padding: 16 },
  catTitle: { fontSize: 20, fontWeight: '600', marginBottom: 20, textAlign: 'center' },
  card: { backgroundColor: '#f8f9fa', borderRadius: 16, padding: 20, marginBottom: 12, alignItems: 'center' },
  cardTitle: { fontSize: 18, fontWeight: 'bold', marginTop: 8 },
  statsBar: { flexDirection: 'row', backgroundColor: '#EEF2FF', padding: 12, alignItems: 'center', borderBottomWidth: 1, borderBottomColor: '#ddd' },
  statItem: { flex: 1, alignItems: 'center' },
  statLabel: { fontSize: 10, color: '#666' },
  statValue: { fontSize: 16, fontWeight: 'bold', color: '#007AFF' },
  statValueSmall: { fontSize: 10, fontWeight: '600', color: '#007AFF' },
  todayBtn: { backgroundColor: '#007AFF', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 },
  todayBtnText: { color: '#fff', fontSize: 12, fontWeight: '600' },
  dd: { backgroundColor: '#f8f9fa', borderBottomWidth: 1, borderBottomColor: '#ddd' },
  ddBtn: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16 },
  ddLabel: { fontSize: 12, color: '#666' },
  ddVal: { fontSize: 16, fontWeight: '600' },
  ddMenu: { maxHeight: 200, backgroundColor: '#fff' },
  ddItem: { padding: 14, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  ddActive: { backgroundColor: '#007AFF' },
  ddText: { fontSize: 14 },
  ddTextActive: { color: '#fff', fontWeight: 'bold' },
  timeToggle: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 12, backgroundColor: '#fff' },
  timeLabel: { fontSize: 14 },
  preview: { flex: 1, backgroundColor: '#f5f5f5' },
  actions: { padding: 16, backgroundColor: '#fff', flexDirection: 'row', gap: 8 },
  btn: { flex: 1, alignItems: 'center', backgroundColor: '#007AFF', padding: 14, borderRadius: 10 },
  unBtn: { backgroundColor: '#F59E0B' },
  emailBtn: { backgroundColor: '#4CAF50' },
  btnText: { color: '#fff', fontSize: 14, fontWeight: 'bold' },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modal: { backgroundColor: 'white', borderRadius: 12, padding: 24, width: '85%' },
  modalTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 16, textAlign: 'center' },
  input: { borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, padding: 12, marginBottom: 16 },
  modalBtns: { flexDirection: 'row', gap: 12 },
  cancelBtn: { flex: 1, backgroundColor: '#6B7280', padding: 12, borderRadius: 8, alignItems: 'center' },
  confirmBtn: { flex: 1, backgroundColor: '#F59E0B', padding: 12, borderRadius: 8, alignItems: 'center' },
  modalBtnText: { color: 'white', fontWeight: '600' }
});
