import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Modal, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ItemStatus } from '../contexts/JobContext';

interface StatusFilterModalProps {
  visible: boolean;
  onClose: () => void;
  statusFilter: ItemStatus | 'all';
  onSelectStatus: (status: ItemStatus | 'all') => void;
  statusStats: Record<ItemStatus, number>;
  total: number;
  statusColors: Record<ItemStatus, string>;
  activeFilter: 'all' | 'galvaxpress' | 'high';
  onSelectActiveFilter: (filter: 'all' | 'galvaxpress' | 'high') => void;
  galvXpressCount: number;
  highPriorityCount: number;
}

export default function StatusFilterModal({
  visible,
  onClose,
  statusFilter,
  onSelectStatus,
  statusStats,
  total,
  statusColors,
  activeFilter,
  onSelectActiveFilter,
  galvXpressCount,
  highPriorityCount
}: StatusFilterModalProps) {
  const statuses: ItemStatus[] = ['Pending', 'Workshop', 'Acid', 'Galva', 'Finishing', 'Ready'];

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={visible}
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <View style={styles.header}>
            <Text style={styles.title}>Filter Jobs</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
              <Ionicons name="close" size={24} color="#6B7280" />
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Priority & GalvXpress Filters */}
            <Text style={styles.sectionTitle}>Priority & Express</Text>
            <View style={styles.grid}>
              <TouchableOpacity
                style={[
                  styles.filterCard,
                  activeFilter === 'all' && styles.filterCardActive
                ]}
                onPress={() => onSelectActiveFilter('all')}
              >
                <View style={styles.filterCardContent}>
                  <Ionicons 
                    name="apps-outline" 
                    size={28} 
                    color={activeFilter === 'all' ? '#3B82F6' : '#6B7280'} 
                  />
                  <Text style={[
                    styles.filterName,
                    activeFilter === 'all' && styles.filterNameActive
                  ]}>All Jobs</Text>
                  <Text style={styles.filterCount}>{total}</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                style={[
                  styles.filterCard,
                  activeFilter === 'galvaxpress' && styles.filterCardActive,
                  { borderColor: '#DC2626' }
                ]}
                onPress={() => {
                  // Toggle: if already selected, unselect (go to 'all')
                  if (activeFilter === 'galvaxpress') {
                    onSelectActiveFilter('all');
                  } else {
                    onSelectActiveFilter('galvaxpress');
                  }
                }}

              >
                <View style={styles.filterCardContent}>
                  <Ionicons 
                    name="flash" 
                    size={28} 
                    color={activeFilter === 'galvaxpress' ? '#DC2626' : '#6B7280'} 
                  />
                  <Text style={[
                    styles.filterName,
                    activeFilter === 'galvaxpress' && styles.filterNameActive
                  ]}>GalvXpress</Text>
                  <Text style={styles.filterCount}>{galvXpressCount}</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                style={[
                  styles.filterCard,
                  activeFilter === 'high' && styles.filterCardActive,
                  { borderColor: '#EF4444' }
                ]}
                onPress={() => {
                  // Toggle: if already selected, unselect (go to 'all')
                  if (activeFilter === 'high') {
                    onSelectActiveFilter('all');
                  } else {
                    onSelectActiveFilter('high');
                  }
                }}

              >
                <View style={styles.filterCardContent}>
                  <Ionicons 
                    name="alert-circle" 
                    size={28} 
                    color={activeFilter === 'high' ? '#EF4444' : '#6B7280'} 
                  />
                  <Text style={[
                    styles.filterName,
                    activeFilter === 'high' && styles.filterNameActive
                  ]}>High Priority</Text>
                  <Text style={styles.filterCount}>{highPriorityCount}</Text>
                </View>
              </TouchableOpacity>
            </View>

            {/* Status Filters */}
            <Text style={styles.sectionTitle}>Item Status</Text>
            <View style={styles.grid}>
              <TouchableOpacity
                style={[
                  styles.filterCard,
                  statusFilter === 'all' && styles.filterCardActive
                ]}
                onPress={() => onSelectStatus('all')}
              >
                <View style={styles.filterCardContent}>
                  <Ionicons 
                    name="list-outline" 
                    size={28} 
                    color={statusFilter === 'all' ? '#3B82F6' : '#6B7280'} 
                  />
                  <Text style={[
                    styles.filterName,
                    statusFilter === 'all' && styles.filterNameActive
                  ]}>All Statuses</Text>
                  <Text style={styles.filterCount}>{total}</Text>
                </View>
              </TouchableOpacity>

              {statuses.map(status => (
                <TouchableOpacity
                  key={status}
                  style={[
                    styles.filterCard,
                    statusFilter === status && styles.filterCardActive,
                    { borderColor: statusColors[status] }
                  ]}
                  onPress={() => {
                    // Toggle: if already selected, unselect (go to 'all')
                    if (statusFilter === status) {
                      onSelectStatus('all');
                    } else {
                      onSelectStatus(status);
                    }
                  }}
                >
                  <View style={styles.filterCardContent}>
                    <View style={[styles.statusDot, { backgroundColor: statusColors[status] }]} />
                    <Text style={[
                      styles.filterName,
                      statusFilter === status && styles.filterNameActive
                    ]}>{status}</Text>
                    <Text style={styles.filterCount}>{statusStats[status]}</Text>
                  </View>
                </TouchableOpacity>

              ))}
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modal: { backgroundColor: 'white', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: '85%' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  title: { fontSize: 20, fontWeight: 'bold', color: '#1F2937' },
  closeBtn: { padding: 4 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#374151', marginTop: 16, marginBottom: 12 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  filterCard: { width: '47%', backgroundColor: '#F9FAFB', borderRadius: 12, padding: 16, borderWidth: 2, borderColor: 'transparent' },
  filterCardActive: { backgroundColor: '#EFF6FF', borderColor: '#3B82F6' },
  filterCardContent: { alignItems: 'center', gap: 8 },
  statusDot: { width: 24, height: 24, borderRadius: 12 },
  filterName: { fontSize: 13, fontWeight: '600', color: '#6B7280', textAlign: 'center' },
  filterNameActive: { color: '#1E40AF' },
  filterCount: { fontSize: 20, fontWeight: 'bold', color: '#1F2937' }
});
