import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface EmptyStateDeliveryProps {
  message?: string;
}

export default function EmptyStateDelivery({ message = 'No deliveries found' }: EmptyStateDeliveryProps) {
  return (
    <View style={styles.container}>
      <View style={styles.iconContainer}>
        <Ionicons name="cube-outline" size={64} color="#d1d5db" />
      </View>
      <Text style={styles.title}>{message}</Text>
      <Text style={styles.subtitle}>Try adjusting your filters or add a new delivery</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingVertical: 60 },
  iconContainer: { width: 120, height: 120, borderRadius: 60, backgroundColor: '#f3f4f6', alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  title: { fontSize: 18, fontWeight: '600', color: '#6b7280', marginBottom: 8 },
  subtitle: { fontSize: 14, color: '#9ca3af', textAlign: 'center', paddingHorizontal: 40 }
});
