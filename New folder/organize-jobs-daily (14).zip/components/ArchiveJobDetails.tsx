import React from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Job } from '../contexts/JobContext';

interface Props {
  job: Job;
  onBack: () => void;
  onRestore: (jobId: string) => void;
}

export const ArchiveJobDetails: React.FC<Props> = ({ job, onBack, onRestore }) => {
  const totalWeight = job.items.reduce((sum, item) => sum + (parseFloat(item.weightKg) || 0), 0);

  const handleRestore = () => {
    Alert.alert('Restore Job', `Restore ${job.jobNumber} to Completed?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Restore', onPress: () => onRestore(job.id) }
    ]);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color="#007AFF" />
        </TouchableOpacity>
        <Text style={styles.title}>Job Details</Text>
        <TouchableOpacity onPress={handleRestore} style={styles.restoreBtn}>
          <Ionicons name="refresh" size={24} color="#10B981" />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content}>
        <View style={styles.card}>
          <Text style={styles.jobNumber}>{job.jobNumber}</Text>
          <Text style={styles.customer}>{job.customerName}</Text>
          <Text style={styles.date}>Archived: {job.archivedDate ? new Date(job.archivedDate).toLocaleDateString('en-GB') : 'Unknown'}</Text>
          {job.deliveredAt && (
            <Text style={styles.deliveredDate}>
              Delivered: {new Date(job.deliveredAt).toLocaleString('en-GB', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}
            </Text>
          )}
        </View>


        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Items ({job.items.length})</Text>
          {job.items.map(item => (
            <View key={item.id} style={styles.itemRow}>
              <Text style={styles.itemDesc}>{item.descriptionOfWorks}</Text>
              <Text style={styles.itemWeight}>{item.weightKg} kg</Text>
            </View>
          ))}
          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>Total Weight:</Text>
            <Text style={styles.totalValue}>{totalWeight.toFixed(2)} kg</Text>
          </View>
        </View>

      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 20, borderBottomWidth: 1, borderBottomColor: '#eee' },
  backBtn: { padding: 5 },
  restoreBtn: { padding: 5 },
  title: { fontSize: 20, fontWeight: 'bold' },
  content: { flex: 1, padding: 20 },
  card: { backgroundColor: '#fff', padding: 15, borderRadius: 10, marginBottom: 15, borderWidth: 1, borderColor: '#ddd' },
  jobNumber: { fontSize: 22, fontWeight: 'bold', marginBottom: 5 },
  customer: { fontSize: 16, color: '#666', marginBottom: 5 },
  date: { fontSize: 14, color: '#999' },
  deliveredDate: { fontSize: 14, color: '#10B981', marginTop: 4, fontWeight: '600' },

  sectionTitle: { fontSize: 16, fontWeight: 'bold', marginBottom: 10 },
  itemRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderTopWidth: 1, borderTopColor: '#eee' },
  itemDesc: { flex: 1, fontSize: 14 },
  itemWeight: { fontSize: 14, fontWeight: '600', color: '#666' },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 10, paddingTop: 10, borderTopWidth: 2, borderTopColor: '#007AFF' },
  totalLabel: { fontSize: 16, fontWeight: 'bold' },
  totalValue: { fontSize: 16, fontWeight: 'bold', color: '#007AFF' }
});
