import React from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface Props {
  searchQuery: string;
  onSearchChange: (text: string) => void;
  startDate: Date | null;
  endDate: Date | null;
  onStartDatePress: () => void;
  onEndDatePress: () => void;
  onClearDates: () => void;
  customers: string[];
  selectedCustomer: string;
  onCustomerChange: (customer: string) => void;
}

export default function DeliveryArchiveFilters({
  searchQuery, onSearchChange, startDate, endDate, onStartDatePress, onEndDatePress,
  onClearDates, customers, selectedCustomer, onCustomerChange
}: Props) {
  return (
    <View style={styles.container}>
      <View style={styles.searchRow}>
        <View style={styles.searchBox}>
          <Ionicons name="search-outline" size={18} color="#9ca3af" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search deliveries..."
            placeholderTextColor="#9ca3af"
            value={searchQuery}
            onChangeText={onSearchChange}
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => onSearchChange('')}>
              <Ionicons name="close-circle" size={18} color="#9ca3af" />
            </TouchableOpacity>
          )}
        </View>
      </View>

      <View style={styles.dateRow}>
        <TouchableOpacity style={styles.dateBtn} onPress={onStartDatePress}>
          <Ionicons name="calendar-outline" size={16} color="#2563eb" />
          <Text style={styles.dateBtnText}>{startDate ? startDate.toLocaleDateString() : 'Start Date'}</Text>
        </TouchableOpacity>
        <Text style={styles.dateSep}>to</Text>
        <TouchableOpacity style={styles.dateBtn} onPress={onEndDatePress}>
          <Ionicons name="calendar-outline" size={16} color="#2563eb" />
          <Text style={styles.dateBtnText}>{endDate ? endDate.toLocaleDateString() : 'End Date'}</Text>
        </TouchableOpacity>
        {(startDate || endDate) && (
          <TouchableOpacity style={styles.clearBtn} onPress={onClearDates}>
            <Ionicons name="close" size={16} color="#ef4444" />
          </TouchableOpacity>
        )}
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.customerRow}>
        <TouchableOpacity
          style={[styles.customerChip, selectedCustomer === '' && styles.customerChipActive]}
          onPress={() => onCustomerChange('')}
        >
          <Text style={[styles.customerText, selectedCustomer === '' && styles.customerTextActive]}>All</Text>
        </TouchableOpacity>
        {customers.map(c => (
          <TouchableOpacity
            key={c}
            style={[styles.customerChip, selectedCustomer === c && styles.customerChipActive]}
            onPress={() => onCustomerChange(c)}
          >
            <Text style={[styles.customerText, selectedCustomer === c && styles.customerTextActive]} numberOfLines={1}>{c}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: '#f9fafb', padding: 12, borderBottomWidth: 1, borderBottomColor: '#e5e7eb' },
  searchRow: { marginBottom: 10 },
  searchBox: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'white', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8, borderWidth: 1, borderColor: '#e5e7eb' },
  searchInput: { flex: 1, marginLeft: 8, fontSize: 14, color: '#1f2937' },
  dateRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 10, gap: 8 },
  dateBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'white', padding: 10, borderRadius: 8, borderWidth: 1, borderColor: '#e5e7eb' },
  dateBtnText: { fontSize: 13, color: '#374151' },
  dateSep: { fontSize: 12, color: '#9ca3af' },
  clearBtn: { padding: 8, backgroundColor: '#fee2e2', borderRadius: 6 },
  customerRow: { flexDirection: 'row' },
  customerChip: { paddingHorizontal: 12, paddingVertical: 6, backgroundColor: 'white', borderRadius: 16, marginRight: 8, borderWidth: 1, borderColor: '#e5e7eb' },
  customerChipActive: { backgroundColor: '#2563eb', borderColor: '#2563eb' },
  customerText: { fontSize: 12, color: '#6b7280' },
  customerTextActive: { color: 'white' }
});
