import React from 'react';
import { View, Text, Modal, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface Props {
  visible: boolean;
  onClose: () => void;
  onAddDelivery: () => void;
  onRequestDelivery: () => void;
}

export default function DeliveryActionChoiceModal({ visible, onClose, onAddDelivery, onRequestDelivery }: Props) {
  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <Text style={styles.title}>Choose Action</Text>
          
          <TouchableOpacity style={styles.option} onPress={() => { onClose(); onAddDelivery(); }}>
            <Ionicons name="add-circle" size={32} color="#2563eb" />
            <View style={styles.optionText}>
              <Text style={styles.optionTitle}>Add Delivery</Text>
              <Text style={styles.optionDesc}>Create a new delivery directly</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity style={styles.option} onPress={() => { onClose(); onRequestDelivery(); }}>
            <Ionicons name="paper-plane" size={32} color="#10b981" />
            <View style={styles.optionText}>
              <Text style={styles.optionTitle}>Request Delivery</Text>
              <Text style={styles.optionDesc}>Submit a delivery request</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity style={styles.cancelBtn} onPress={onClose}>
            <Text style={styles.cancelText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: 'white', borderRadius: 12, padding: 20 },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' },
  option: { flexDirection: 'row', alignItems: 'center', padding: 16, backgroundColor: '#f9fafb', borderRadius: 8, marginBottom: 12, gap: 12 },
  optionText: { flex: 1 },
  optionTitle: { fontSize: 16, fontWeight: '600', marginBottom: 4 },
  optionDesc: { fontSize: 13, color: '#6b7280' },
  cancelBtn: { padding: 14, alignItems: 'center', marginTop: 8 },
  cancelText: { fontSize: 15, color: '#6b7280', fontWeight: '600' }
});
