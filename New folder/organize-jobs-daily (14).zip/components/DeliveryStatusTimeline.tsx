import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Modal, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../app/lib/supabase';

interface DeliveryStatusTimelineProps {
  deliveryId: string;
  visible: boolean;
  onClose: () => void;
}

export default function DeliveryStatusTimeline({ deliveryId, visible, onClose }: DeliveryStatusTimelineProps) {
  const [history, setHistory] = useState([]);
  const [delivery, setDelivery] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (visible && deliveryId) {
      loadData();
    }
  }, [visible, deliveryId]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [deliveryRes, historyRes] = await Promise.all([
        supabase.from('logistics_deliveries').select('*').eq('id', deliveryId).single(),
        supabase.from('delivery_status_history').select('*').eq('delivery_id', deliveryId).order('created_at', { ascending: false })
      ]);
      
      if (deliveryRes.data) setDelivery(deliveryRes.data);
      if (historyRes.data) setHistory(historyRes.data);
    } catch (err) {
      console.error('Error loading delivery data:', err);
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async () => {
    if (!newStatus) return;
    
    try {
      await supabase.from('delivery_status_history').insert({
        delivery_id: deliveryId,
        status: newStatus,
        notes: notes.trim() || null,
        changed_by: 'current_user'
      });
      
      await supabase.from('logistics_deliveries').update({ status: newStatus }).eq('id', deliveryId);
      
      Alert.alert('Success', 'Status updated');
      setShowUpdateModal(false);
      setNotes('');
      loadData();
    } catch (err) {
      Alert.alert('Error', 'Failed to update status');
    }
  };

  const getStatusColor = (status: string) => {
    const colors = {
      scheduled: '#3B82F6',
      'in-transit': '#F59E0B',
      delivered: '#10B981',
      completed: '#059669'
    };
    return colors[status] || '#6B7280';
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <View style={styles.header}>
            <Text style={styles.title}>Delivery Timeline</Text>
            <TouchableOpacity onPress={onClose}>
              <Ionicons name="close" size={24} color="#6B7280" />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.content}>
            {delivery && (
              <View style={styles.deliveryInfo}>
                <Text style={styles.deliveryNumber}>{delivery.delivery_number}</Text>
                <View style={[styles.statusBadge, { backgroundColor: getStatusColor(delivery.status) }]}>
                  <Text style={styles.statusText}>{delivery.status}</Text>
                </View>
              </View>
            )}

            <TouchableOpacity style={styles.updateButton} onPress={() => setShowUpdateModal(true)}>
              <Ionicons name="create-outline" size={20} color="white" />
              <Text style={styles.updateButtonText}>Update Status</Text>
            </TouchableOpacity>

            <View style={styles.timeline}>
              {history.map((item, index) => (
                <View key={item.id} style={styles.timelineItem}>
                  <View style={styles.timelineLeft}>
                    <View style={[styles.dot, { backgroundColor: getStatusColor(item.status) }]} />
                    {index < history.length - 1 && <View style={styles.line} />}
                  </View>
                  <View style={styles.timelineRight}>
                    <Text style={styles.timelineStatus}>{item.status}</Text>
                    <Text style={styles.timelineTime}>{new Date(item.created_at).toLocaleString()}</Text>
                    {item.notes && <Text style={styles.timelineNotes}>{item.notes}</Text>}
                  </View>
                </View>
              ))}
            </View>
          </ScrollView>

          {showUpdateModal && (
            <View style={styles.updateModal}>
              <Text style={styles.updateTitle}>Update Status</Text>
              <View style={styles.statusButtons}>
                {['scheduled', 'in-transit', 'delivered', 'completed'].map(s => (
                  <TouchableOpacity key={s} style={[styles.statusButton, newStatus === s && styles.statusButtonActive]} onPress={() => setNewStatus(s)}>
                    <Text style={[styles.statusButtonText, newStatus === s && styles.statusButtonTextActive]}>{s}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              <TextInput style={styles.notesInput} placeholder="Add notes (optional)" value={notes} onChangeText={setNotes} multiline />
              <View style={styles.modalButtons}>
                <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowUpdateModal(false)}>
                  <Text style={styles.cancelBtnText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.saveBtn} onPress={updateStatus}>
                  <Text style={styles.saveBtnText}>Save</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modal: { backgroundColor: 'white', borderTopLeftRadius: 20, borderTopRightRadius: 20, maxHeight: '90%' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  title: { fontSize: 20, fontWeight: 'bold', color: '#1F2937' },
  content: { padding: 20 },
  deliveryInfo: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  deliveryNumber: { fontSize: 18, fontWeight: '600', color: '#1F2937' },
  statusBadge: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12 },
  statusText: { color: 'white', fontSize: 12, fontWeight: '600', textTransform: 'uppercase' },
  updateButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#3B82F6', padding: 12, borderRadius: 8, marginBottom: 20, gap: 8 },
  updateButtonText: { color: 'white', fontSize: 16, fontWeight: '600' },
  timeline: { marginTop: 10 },
  timelineItem: { flexDirection: 'row', marginBottom: 20 },
  timelineLeft: { width: 30, alignItems: 'center', marginRight: 12 },
  dot: { width: 14, height: 14, borderRadius: 7, borderWidth: 3, borderColor: '#E5E7EB' },
  line: { width: 2, flex: 1, backgroundColor: '#E5E7EB', marginTop: 4 },
  timelineRight: { flex: 1, backgroundColor: '#F9FAFB', padding: 12, borderRadius: 8 },
  timelineStatus: { fontSize: 16, fontWeight: '600', color: '#1F2937', marginBottom: 4, textTransform: 'capitalize' },
  timelineTime: { fontSize: 12, color: '#6B7280', marginBottom: 4 },
  timelineNotes: { fontSize: 14, color: '#374151', marginTop: 4 },
  updateModal: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: 'white', padding: 20, borderTopWidth: 1, borderTopColor: '#E5E7EB' },
  updateTitle: { fontSize: 18, fontWeight: '600', marginBottom: 12 },
  statusButtons: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  statusButton: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, borderWidth: 1, borderColor: '#D1D5DB' },
  statusButtonActive: { backgroundColor: '#3B82F6', borderColor: '#3B82F6' },
  statusButtonText: { fontSize: 14, color: '#6B7280' },
  statusButtonTextActive: { color: 'white', fontWeight: '600' },
  notesInput: { borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, padding: 12, marginBottom: 12, minHeight: 60, textAlignVertical: 'top' },
  modalButtons: { flexDirection: 'row', gap: 10 },
  cancelBtn: { flex: 1, padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#D1D5DB' },
  cancelBtnText: { textAlign: 'center', color: '#6B7280', fontWeight: '600' },
  saveBtn: { flex: 1, padding: 12, borderRadius: 8, backgroundColor: '#3B82F6' },
  saveBtnText: { textAlign: 'center', color: 'white', fontWeight: '600' }
});
