import React from 'react';
import { View, Text, Modal, TouchableOpacity, ScrollView, StyleSheet, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { DraftPreview } from '../types/drafts';

interface Props {
  visible: boolean;
  onClose: () => void;
  drafts: DraftPreview[];
  onSelectDraft: (id: string) => void;
  onCreateNew: () => void;
}

export default function DraftPickerModal({ visible, onClose, drafts, onSelectDraft, onCreateNew }: Props) {
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.overlay}>
        <Pressable style={styles.backdrop} onPress={onClose} />
        <View style={styles.content}>
          <View style={styles.header}>
            <Text style={styles.title}>Your Drafts ({drafts.length})</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeBtn} hitSlop={{top:10,bottom:10,left:10,right:10}}>
              <Ionicons name="close" size={24} color="#6B7280" />
            </TouchableOpacity>
          </View>

          <TouchableOpacity style={styles.newBtn} onPress={onCreateNew} activeOpacity={0.8}>
            <Ionicons name="add-circle" size={24} color="#fff" />
            <Text style={styles.newBtnText}>Create New Draft</Text>
          </TouchableOpacity>

          <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
            {drafts.length === 0 ? (
              <View style={styles.empty}>
                <Ionicons name="document-outline" size={48} color="#D1D5DB" />
                <Text style={styles.emptyText}>No drafts saved</Text>
              </View>
            ) : (
              drafts.map((item) => (
                <TouchableOpacity 
                  key={item.id} 
                  style={styles.draftCard}
                  onPress={() => onSelectDraft(item.id)}
                  activeOpacity={0.7}
                >
                  <View style={styles.draftInfo}>
                    <Text style={styles.draftTitle}>{item.jobNumber || 'Untitled Draft'}</Text>
                    <Text style={styles.draftCustomer}>{item.customerName || 'No customer'}</Text>
                    <Text style={styles.draftMeta}>{item.itemCount} items • {formatDate(item.updatedAt)}</Text>
                  </View>
                  <View style={styles.arrowContainer}>
                    <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
                  </View>
                </TouchableOpacity>
              ))
            )}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  backdrop: { flex: 1 },
  content: { backgroundColor: '#fff', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: '80%' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  title: { fontSize: 20, fontWeight: 'bold', color: '#111827' },
  closeBtn: { padding: 8 },
  newBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#2563EB', padding: 14, borderRadius: 12, marginBottom: 16 },
  newBtnText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  scrollView: { maxHeight: 400 },
  draftCard: { flexDirection: 'row', backgroundColor: '#F9FAFB', borderRadius: 12, marginBottom: 12, borderWidth: 1, borderColor: '#E5E7EB', overflow: 'hidden' },
  draftInfo: { flex: 1, padding: 16 },
  draftTitle: { fontSize: 16, fontWeight: '600', color: '#111827' },
  draftCustomer: { fontSize: 14, color: '#6B7280', marginTop: 4 },
  draftMeta: { fontSize: 12, color: '#9CA3AF', marginTop: 6 },
  arrowContainer: { justifyContent: 'center', alignItems: 'center', paddingRight: 16 },
  empty: { alignItems: 'center', paddingVertical: 40 },
  emptyText: { fontSize: 14, color: '#9CA3AF', marginTop: 8 },
});
