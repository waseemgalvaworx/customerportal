import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import ItemOptionsDisplay from './ItemOptionsDisplay';
import { useRouter } from 'expo-router';

export default function PlanningJobCard({ job, isSelected, onToggleSelect, onRevert, onChangeDeliveryDate, calculateTotalWeight, getStatusColor }: any) {
  const router = useRouter();
  
  return (

    <View style={styles.jobCard}>
      <View style={styles.topRow}>
        <TouchableOpacity onPress={onToggleSelect} style={styles.checkbox}>
          <Ionicons name={isSelected ? "checkbox" : "square-outline"} size={24} color="#3B82F6" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.jobContent} onPress={() => router.push(`/job/${job.id}?source=planning` as any)}>
          <View style={styles.jobHeader}>
            <Text style={styles.jobNumber}>{job.jobNumber}</Text>
          </View>

          <Text style={styles.customerName}>👤 {job.customerName}</Text>
          <Text style={styles.jobWeight}>⚖️ {calculateTotalWeight(job.items).toFixed(1)} kg</Text>
          {job.deliveryDate && (
            <Text style={styles.deliveryDate}>🚚 {new Date(job.deliveryDate).toLocaleString()}</Text>
          )}
          {job.notes && (
            <View style={styles.notesInfo}>
              <Ionicons name="document-text-outline" size={12} color="#92400E" />
              <Text style={styles.notesText}>{job.notes}</Text>
            </View>
          )}
          <View style={styles.itemStatusSection}>
            {job.items.map((item: any) => (
              <View key={item.id} style={styles.itemStatusRow}>
                <View style={styles.itemInfo}>
                  {item.itemCount && (
                    <Text style={styles.itemCount}>Qty: {item.itemCount}</Text>
                  )}
                  <Text style={styles.itemDesc}>{item.descriptionOfWorks}</Text>
                  <Text style={styles.itemWeight}>{item.weightKg} kg</Text>
                  <ItemOptionsDisplay 
                    paintVarnish={item.paintVarnish}
                    galva={item.galva}
                    lightGalva={item.lightGalva}
                    lightPaint={item.lightPaint}
                    rusty={item.rusty}
                    doubleDip={item.doubleDip}
                    multipleDip={item.multipleDip}
                  />
                </View>
                <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) }]}>
                  <Text style={styles.statusBadgeText}>{item.status}</Text>
                </View>
              </View>
            ))}

          </View>
        </TouchableOpacity>

        <TouchableOpacity onPress={onRevert} style={styles.removeBtn}>
          <Ionicons name="arrow-undo" size={24} color="#3B82F6" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  jobCard: { backgroundColor: 'white', borderRadius: 12, padding: 12, marginBottom: 12 },
  topRow: { flexDirection: 'row', alignItems: 'flex-start' },
  checkbox: { marginRight: 8 },
  jobContent: { flex: 1 },
  jobHeader: { marginBottom: 6 },
  jobNumber: { fontSize: 18, fontWeight: 'bold', color: '#111827' },
  customerName: { fontSize: 14, color: '#2563eb', marginBottom: 4 },
  jobWeight: { fontSize: 12, color: '#8b5cf6', marginBottom: 2 },
  deliveryDate: { fontSize: 11, color: '#059669', marginBottom: 6 },
  notesInfo: { flexDirection: 'row', alignItems: 'flex-start', gap: 4, marginBottom: 6, paddingVertical: 4, paddingHorizontal: 6, backgroundColor: '#FEF3C7', borderRadius: 4 },
  notesText: { flex: 1, fontSize: 10, color: '#92400E', lineHeight: 14 },
  itemStatusSection: { marginTop: 8 },
  itemStatusRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6, gap: 8 },
  itemInfo: { flex: 1 },
  itemCount: { fontSize: 10, color: '#3B82F6', fontWeight: '600', marginBottom: 2 },
  itemDesc: { fontSize: 11, color: '#6B7280', marginBottom: 2 },
  itemWeight: { fontSize: 10, color: '#9CA3AF', marginBottom: 2 },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  statusBadgeText: { fontSize: 10, fontWeight: '600', color: 'white' },
  removeBtn: { marginLeft: 8 }
});

