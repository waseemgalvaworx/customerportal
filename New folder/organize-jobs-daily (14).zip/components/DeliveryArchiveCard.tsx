import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface DeliveryArchiveCardProps {
  delivery: any;
  onRestore: (id: string) => void;
  onDelete: (id: string) => void;
  selected: boolean;
  onSelect: (id: string) => void;
}

export default function DeliveryArchiveCard({ delivery, onRestore, onDelete, selected, onSelect }: DeliveryArchiveCardProps) {
  const d = delivery;
  return (
    <View style={[styles.card, selected && styles.cardSelected]}>
      <TouchableOpacity style={styles.checkbox} onPress={() => onSelect(d.id)}>
        <Ionicons name={selected ? 'checkbox' : 'square-outline'} size={22} color={selected ? '#2563eb' : '#9ca3af'} />
      </TouchableOpacity>
      <View style={styles.content}>
        <View style={styles.row}>
          <Text style={styles.title}>{d.delivery_number}</Text>
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{d.delivery_type || 'N/A'}</Text>
          </View>
        </View>
        <Text style={styles.address} numberOfLines={1}>{d.delivery_address}</Text>
        <Text style={styles.meta}>
          <Ionicons name="calendar-outline" size={12} color="#9ca3af" /> Scheduled: {d.scheduled_date || 'N/A'}
        </Text>
        {d.archived_at && (
          <Text style={styles.meta}>
            <Ionicons name="archive-outline" size={12} color="#9ca3af" /> Archived: {new Date(d.archived_at).toLocaleDateString()}
          </Text>
        )}
        {d.job?.customerName && (
          <Text style={styles.customer}>
            <Ionicons name="person-outline" size={12} color="#6b7280" /> {d.job.customerName}
          </Text>
        )}
      </View>
      <View style={styles.actions}>
        <TouchableOpacity style={styles.restoreBtn} onPress={() => onRestore(d.id)}>
          <Ionicons name="refresh-outline" size={18} color="#16a34a" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.deleteBtn} onPress={() => onDelete(d.id)}>
          <Ionicons name="trash-outline" size={18} color="#ef4444" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { flexDirection: 'row', backgroundColor: 'white', padding: 12, borderRadius: 8, marginBottom: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.1, shadowRadius: 2, elevation: 2, alignItems: 'center' },
  cardSelected: { backgroundColor: '#eff6ff', borderWidth: 1, borderColor: '#2563eb' },
  checkbox: { marginRight: 10 },
  content: { flex: 1 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  title: { fontSize: 15, fontWeight: 'bold', color: '#1f2937' },
  badge: { backgroundColor: '#f3f4f6', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 10 },
  badgeText: { fontSize: 10, color: '#6b7280', textTransform: 'capitalize' },
  address: { fontSize: 13, color: '#6b7280', marginBottom: 2 },
  meta: { fontSize: 11, color: '#9ca3af', marginBottom: 1 },
  customer: { fontSize: 12, color: '#6b7280', marginTop: 2 },
  actions: { flexDirection: 'column', gap: 8 },
  restoreBtn: { padding: 8, backgroundColor: '#dcfce7', borderRadius: 6 },
  deleteBtn: { padding: 8, backgroundColor: '#fee2e2', borderRadius: 6 }
});
