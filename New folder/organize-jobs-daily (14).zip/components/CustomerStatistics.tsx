import React, { useState, useMemo, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Job } from '../contexts/JobContext';
import { supabase } from '../app/lib/supabase';

interface CustomerStatisticsProps {
  jobs: Job[];
  finishingRecords: any[];
}

interface CustomerMetrics {
  name: string;
  totalWeight: number;
  jobCount: number;
  avgProcessingDays: number;
  trends: {
    daily: number;
    weekly: number;
    monthly: number;
    yearly: number;
  };
}

type PeriodType = 'daily' | 'weekly' | 'monthly' | 'yearly';

export default function CustomerStatistics({ jobs, finishingRecords }: CustomerStatisticsProps) {
  const [selectedPeriod, setSelectedPeriod] = useState<PeriodType>('monthly');
  const [completedJobs, setCompletedJobs] = useState<Job[]>([]);
  const [expandedCustomer, setExpandedCustomer] = useState<string | null>(null);

  useEffect(() => {
    fetchCompletedJobs();
  }, []);

  const fetchCompletedJobs = async () => {
    const { data, error } = await supabase
      .from('jobs')
      .select('*')
      .eq('status', 'archived')
      .order('archivedDate', { ascending: false });
    
    if (!error && data) {
      const formatted = data.map((job: any) => ({
        ...job,
        dateOfEntry: new Date(job.dateOfEntry),
        completedDate: job.completedDate ? new Date(job.completedDate) : undefined,
        archivedDate: job.archivedDate ? new Date(job.archivedDate) : undefined,
      }));
      setCompletedJobs(formatted);
    }
  };

  const customerMetrics = useMemo(() => {
    const metricsMap = new Map<string, CustomerMetrics>();
    const allJobs = [...jobs, ...completedJobs];

    // Calculate total weight and job count from jobs only (not finishing records)
    allJobs.forEach(job => {
      const customerName = job.customerName;
      if (!metricsMap.has(customerName)) {
        metricsMap.set(customerName, {
          name: customerName,
          totalWeight: 0,
          jobCount: 0,
          avgProcessingDays: 0,
          trends: { daily: 0, weekly: 0, monthly: 0, yearly: 0 }
        });
      }

      const metrics = metricsMap.get(customerName)!;
      metrics.jobCount++;
      
      job.items.forEach(item => {
        metrics.totalWeight += parseFloat(item.weightKg || '0');
      });
    });

    // Calculate average processing days
    completedJobs.forEach(job => {
      if (job.completedDate && job.dateOfEntry) {
        const metrics = metricsMap.get(job.customerName);
        if (metrics) {
          const days = Math.floor((job.completedDate.getTime() - job.dateOfEntry.getTime()) / (1000 * 60 * 60 * 24));
          metrics.avgProcessingDays = (metrics.avgProcessingDays * (metrics.jobCount - 1) + days) / metrics.jobCount;
        }
      }
    });

    // Calculate trends based on dateOfEntry (when job was created)
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const todayEnd = new Date(todayStart.getTime() + 24 * 60 * 60 * 1000);
    
    // Get start of current week (Sunday)
    const currentWeekStart = new Date(now);
    currentWeekStart.setDate(now.getDate() - now.getDay());
    currentWeekStart.setHours(0, 0, 0, 0);
    
    // Get start of current month
    const currentMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    
    // Get start of current year
    const currentYearStart = new Date(now.getFullYear(), 0, 1);

    allJobs.forEach(job => {
      const metrics = metricsMap.get(job.customerName);
      if (!metrics) return;

      const jobDate = job.dateOfEntry;
      const weight = job.items.reduce((sum, item) => sum + parseFloat(item.weightKg || '0'), 0);

      // Daily: weight received today
      if (jobDate >= todayStart && jobDate < todayEnd) {
        metrics.trends.daily += weight;
      }
      
      // Weekly: weight received during ongoing week
      if (jobDate >= currentWeekStart) {
        metrics.trends.weekly += weight;
      }
      
      // Monthly: weight received during ongoing month
      if (jobDate >= currentMonthStart) {
        metrics.trends.monthly += weight;
      }
      
      // Yearly: weight received during ongoing year
      if (jobDate >= currentYearStart) {
        metrics.trends.yearly += weight;
      }
    });

    return Array.from(metricsMap.values()).sort((a, b) => b.totalWeight - a.totalWeight);
  }, [jobs, completedJobs, finishingRecords]);


  return (
    <View style={styles.container}>
      <View style={styles.periodSelector}>
        {(['daily', 'weekly', 'monthly', 'yearly'] as PeriodType[]).map(period => (
          <TouchableOpacity
            key={period}
            style={[styles.periodBtn, selectedPeriod === period && styles.periodBtnActive]}
            onPress={() => setSelectedPeriod(period)}
          >
            <Text style={[styles.periodText, selectedPeriod === period && styles.periodTextActive]}>
              {period.charAt(0).toUpperCase() + period.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.list}>
        {customerMetrics.map((customer, index) => (
          <View key={customer.name} style={styles.customerCard}>
            <TouchableOpacity
              style={styles.customerHeader}
              onPress={() => setExpandedCustomer(expandedCustomer === customer.name ? null : customer.name)}
            >
              <View style={styles.rankBadge}>
                <Text style={styles.rankText}>#{index + 1}</Text>
              </View>
              <View style={styles.customerInfo}>
                <Text style={styles.customerName}>{customer.name}</Text>
                <Text style={styles.totalWeight}>{customer.totalWeight.toFixed(2)} kg total</Text>
              </View>
              <Ionicons
                name={expandedCustomer === customer.name ? "chevron-up" : "chevron-down"}
                size={20}
                color="#6B7280"
              />
            </TouchableOpacity>

            {expandedCustomer === customer.name && (
              <View style={styles.detailsContainer}>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Jobs Completed:</Text>
                  <Text style={styles.detailValue}>{customer.jobCount}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Avg Processing Time:</Text>
                  <Text style={styles.detailValue}>
                    {customer.avgProcessingDays > 0 ? `${customer.avgProcessingDays.toFixed(1)} days` : 'N/A'}
                  </Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>{selectedPeriod.charAt(0).toUpperCase() + selectedPeriod.slice(1)} Trend:</Text>
                  <Text style={styles.detailValue}>{customer.trends[selectedPeriod].toFixed(2)} kg</Text>
                </View>
              </View>
            )}
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  periodSelector: { flexDirection: 'row', padding: 12, gap: 8, backgroundColor: '#F9FAFB' },
  periodBtn: { flex: 1, padding: 10, borderRadius: 8, backgroundColor: 'white', alignItems: 'center', borderWidth: 1, borderColor: '#E5E7EB' },
  periodBtnActive: { backgroundColor: '#3B82F6', borderColor: '#3B82F6' },
  periodText: { fontSize: 12, fontWeight: '600', color: '#6B7280' },
  periodTextActive: { color: 'white' },
  list: { flex: 1 },
  customerCard: { backgroundColor: 'white', marginHorizontal: 12, marginVertical: 6, borderRadius: 8, overflow: 'hidden', borderWidth: 1, borderColor: '#E5E7EB' },
  customerHeader: { flexDirection: 'row', alignItems: 'center', padding: 12, gap: 12 },
  rankBadge: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#3B82F6', justifyContent: 'center', alignItems: 'center' },
  rankText: { color: 'white', fontWeight: 'bold', fontSize: 14 },
  customerInfo: { flex: 1 },
  customerName: { fontSize: 15, fontWeight: 'bold', color: '#1F2937', marginBottom: 2 },
  totalWeight: { fontSize: 13, color: '#6B7280' },
  detailsContainer: { borderTopWidth: 1, borderTopColor: '#E5E7EB', padding: 12, backgroundColor: '#F9FAFB' },
  detailRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6 },
  detailLabel: { fontSize: 13, color: '#6B7280' },
  detailValue: { fontSize: 13, fontWeight: '600', color: '#1F2937' }
});
