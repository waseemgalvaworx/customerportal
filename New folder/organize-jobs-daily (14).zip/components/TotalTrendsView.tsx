import React, { useMemo, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import DateRangePicker from './DateRangePicker';

interface Job {
  dateOfEntry: Date | string;
  completedDate?: Date | string;
  archivedDate?: Date | string;
  status: string;
  items: Array<{ weightKg: string }>;
}

interface TotalTrendsViewProps {
  jobs: Job[];
}

export default function TotalTrendsView({ jobs }: TotalTrendsViewProps) {
  const [expanded, setExpanded] = useState(true);
  const [startDate, setStartDate] = useState(new Date(new Date().setDate(new Date().getDate() - 30)));
  const [endDate, setEndDate] = useState(new Date());

  const stats = useMemo(() => {
    const filteredJobs = jobs.filter(job => {
      let date;
      if (job.status === 'pending' || job.status === 'planning') {
        date = job.dateOfEntry;
      } else {
        date = job.completedDate || job.archivedDate;
      }
      if (!date) return false;
      const jobDate = new Date(date);
      return jobDate >= startDate && jobDate <= endDate;
    });

    const totalWeight = filteredJobs.reduce((sum, job) => 
      sum + job.items.reduce((s: number, item: any) => s + parseFloat(item.weightKg || '0'), 0), 0
    );

    const completedJobs = filteredJobs.filter(j => j.completedDate);
    const turnaroundTimes = completedJobs.map(job => {
      const start = new Date(job.dateOfEntry).getTime();
      const end = new Date(job.completedDate!).getTime();
      return (end - start) / (1000 * 60 * 60 * 24);
    });
    const avgTurnaround = turnaroundTimes.length > 0
      ? turnaroundTimes.reduce((a, b) => a + b, 0) / turnaroundTimes.length
      : 0;

    return {
      totalJobs: filteredJobs.length,
      totalWeight,
      avgTurnaround,
    };
  }, [jobs, startDate, endDate]);

  const daysDiff = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));

  return (
    <View style={styles.container}>
      <TouchableOpacity 
        style={styles.header} 
        onPress={() => setExpanded(!expanded)}
        activeOpacity={0.7}
      >
        <Text style={styles.title}>Total Overview</Text>
        <Ionicons 
          name={expanded ? "chevron-up" : "chevron-down"} 
          size={24} 
          color="#6B7280" 
        />
      </TouchableOpacity>

      {expanded && (
        <>
          <DateRangePicker
            startDate={startDate}
            endDate={endDate}
            onStartDateChange={setStartDate}
            onEndDateChange={setEndDate}
            label={`Period: ${daysDiff} days`}
          />

          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Ionicons name="briefcase-outline" size={24} color="#3B82F6" />
              <Text style={styles.statValue}>{stats.totalJobs}</Text>
              <Text style={styles.statLabel}>Total Jobs</Text>
            </View>
            <View style={styles.statCard}>
              <Ionicons name="scale-outline" size={24} color="#10B981" />
              <Text style={styles.statValue}>{stats.totalWeight.toFixed(1)}</Text>
              <Text style={styles.statLabel}>Total Weight (kg)</Text>
            </View>
            <View style={styles.statCard}>
              <Ionicons name="time-outline" size={24} color="#F59E0B" />
              <Text style={styles.statValue}>{stats.avgTurnaround.toFixed(1)}</Text>
              <Text style={styles.statLabel}>Avg Days</Text>
            </View>
          </View>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  title: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  statsGrid: { flexDirection: 'row', gap: 12, marginTop: 16 },
  statCard: { flex: 1, backgroundColor: '#F9FAFB', borderRadius: 8, padding: 12, alignItems: 'center', borderWidth: 1, borderColor: '#E5E7EB' },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#1F2937', marginTop: 8 },
  statLabel: { fontSize: 11, color: '#6B7280', marginTop: 4, textAlign: 'center' },
});
