import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TextInput, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../app/lib/supabase';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import DateTimePicker from './DateTimePicker';
import { notifyManagersNewRequest } from '../utils/notificationHelper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ALLOWED_TASK_USERS } from '../contexts/TaskContext';

interface RequestDeliveryModalProps {
  visible: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const TIME_SLOTS = ['06:00','07:00','08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00'];
const DELIVERY_TYPES = [
  { value: 'delivery', label: 'Delivery' },
  { value: 'pickup', label: 'Pick Up' },
  { value: 'other', label: 'Other' }
];

const DRAFT_KEY = 'request_delivery_draft';

interface DraftData {
  clientName: string;
  requestedDate: string;
  requestedTime: string;
  deliveryAddress: string;
  contactPhone: string;
  notes: string;
  deliveryType: string;
  description: string;
  savedAt: number;
}

export default function RequestDeliveryModal({ visible, onClose, onSuccess }: RequestDeliveryModalProps) {
  const { user } = usePasswordAuth();
  const [clientName, setClientName] = useState('');
  const [requestedDate, setRequestedDate] = useState(new Date());
  const [requestedTime, setRequestedTime] = useState('08:00');
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [deliveryType, setDeliveryType] = useState('delivery');
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);
  const [showDraftIndicator, setShowDraftIndicator] = useState(false);
  const [hasDraft, setHasDraft] = useState(false);

  // Check if user is allowed to use draft feature
  const canUseDrafts = ALLOWED_TASK_USERS.includes(user?.username || '');

  // Load draft on mount
  useEffect(() => {
    if (visible && canUseDrafts) {
      loadDraft();
    }
  }, [visible, canUseDrafts]);

  // Auto-save draft when form changes
  useEffect(() => {
    if (visible && canUseDrafts && hasFormData()) {
      const timeout = setTimeout(() => {
        saveDraft();
      }, 1000); // Debounce 1 second
      return () => clearTimeout(timeout);
    }
  }, [clientName, deliveryAddress, contactPhone, notes, deliveryType, description, requestedTime, visible]);

  const hasFormData = () => {
    return clientName.trim() || deliveryAddress.trim() || contactPhone.trim() || notes.trim() || description.trim();
  };

  const loadDraft = async () => {
    try {
      const draftStr = await AsyncStorage.getItem(DRAFT_KEY);
      if (draftStr) {
        const draft: DraftData = JSON.parse(draftStr);
        // Only load if draft is less than 24 hours old
        if (Date.now() - draft.savedAt < 24 * 60 * 60 * 1000) {
          setClientName(draft.clientName || '');
          setDeliveryAddress(draft.deliveryAddress || '');
          setContactPhone(draft.contactPhone || '');
          setNotes(draft.notes || '');
          setDeliveryType(draft.deliveryType || 'delivery');
          setDescription(draft.description || '');
          setRequestedTime(draft.requestedTime || '08:00');
          if (draft.requestedDate) {
            setRequestedDate(new Date(draft.requestedDate));
          }
          setHasDraft(true);
        } else {
          // Clear old draft
          await AsyncStorage.removeItem(DRAFT_KEY);
        }
      }
    } catch (error) {
      console.error('Error loading draft:', error);
    }
  };

  const saveDraft = async () => {
    try {
      const draft: DraftData = {
        clientName,
        requestedDate: requestedDate.toISOString(),
        requestedTime,
        deliveryAddress,
        contactPhone,
        notes,
        deliveryType,
        description,
        savedAt: Date.now()
      };
      await AsyncStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
      setShowDraftIndicator(true);
      setHasDraft(true);
      setTimeout(() => setShowDraftIndicator(false), 2000);
    } catch (error) {
      console.error('Error saving draft:', error);
    }
  };

  const clearDraft = async () => {
    try {
      await AsyncStorage.removeItem(DRAFT_KEY);
      setHasDraft(false);
    } catch (error) {
      console.error('Error clearing draft:', error);
    }
  };

  const handleSubmit = async () => {
    if (!clientName.trim() || !deliveryAddress.trim()) {
      Alert.alert('Error', 'Client name and delivery address are required');
      return;
    }

    setSaving(true);
    try {
      const today = new Date();
      const day = String(today.getDate()).padStart(2, '0');
      const month = String(today.getMonth() + 1).padStart(2, '0');
      const year = String(today.getFullYear()).slice(-2);
      const datePrefix = `${day}${month}${year}`;
      
      const { data: existingDeliveries, error: queryError } = await supabase
        .from('logistics_deliveries')
        .select('delivery_number')
        .like('delivery_number', `GAL-${datePrefix}%`)
        .order('created_at', { ascending: false })
        .limit(1);
      
      if (queryError) throw queryError;
      
      let sequenceNumber = 1;
      if (existingDeliveries && existingDeliveries.length > 0) {
        const lastNumber = existingDeliveries[0].delivery_number;
        const lastSequence = parseInt(lastNumber.split(datePrefix)[1] || '0');
        sequenceNumber = lastSequence + 1;
      }
      
      const deliveryNumber = `GAL-${datePrefix}${String(sequenceNumber).padStart(2, '0')}`;
      const dateStr = requestedDate.toISOString().split('T')[0];
      const scheduledDateTime = `${dateStr} ${requestedTime}`;

      const { data, error } = await supabase.from('logistics_deliveries').insert({
        delivery_number: deliveryNumber,
        client_name: clientName.trim(),
        delivery_address: deliveryAddress.trim(),
        scheduled_date: scheduledDateTime,
        contact_phone: contactPhone.trim(),
        notes: notes.trim(),
        delivery_type: deliveryType,
        description: description.trim(),
        status: 'requested',
        requested_by: user?.username || 'Unknown',
        original_scheduled_date: scheduledDateTime
      }).select();

      console.log('Insert result:', { data, error });

      if (error) {
        console.error('Insert error:', error);
        Alert.alert('Error', `Failed to submit request: ${error.message}`);
      } else {
        console.log('Successfully inserted:', data);
        
        // Notify managers about the new request
        await notifyManagersNewRequest({
          deliveryNumber,
          requestedBy: user?.username || 'Unknown',
          deliveryType,
          address: deliveryAddress.trim()
        });
        
        // Clear draft on successful submit
        await clearDraft();
        
        resetForm();
        onSuccess();
        onClose();
        setTimeout(() => {
          Alert.alert('Success', 'Delivery request submitted successfully');
        }, 300);
      }
    } catch (err) {
      console.error('Unexpected error:', err);
      Alert.alert('Error', 'An unexpected error occurred.');
    } finally {
      setSaving(false);
    }
  };

  const resetForm = () => {
    setClientName('');
    setRequestedDate(new Date());
    setRequestedTime('08:00');
    setDeliveryAddress('');
    setContactPhone('');
    setNotes('');
    setDeliveryType('delivery');
    setDescription('');
    setShowDatePicker(false);
    setShowTimePicker(false);
    setHasDraft(false);
  };

  const handleCancel = () => {
    // Don't clear draft on cancel - keep it for later
    resetForm();
    onClose();
  };

  const handleClearDraft = () => {
    Alert.alert(
      'Clear Draft',
      'Are you sure you want to clear the saved draft?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Clear', 
          style: 'destructive',
          onPress: async () => {
            await clearDraft();
            resetForm();
          }
        }
      ]
    );
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <ScrollView>
            <View style={styles.headerRow}>
              <Text style={styles.title}>Request Delivery / Pick Up</Text>
              {canUseDrafts && showDraftIndicator && (
                <View style={styles.draftIndicator}>
                  <Ionicons name="cloud-done" size={14} color="#10B981" />
                  <Text style={styles.draftIndicatorText}>Draft saved</Text>
                </View>
              )}
            </View>
            
            {canUseDrafts && hasDraft && (
              <TouchableOpacity style={styles.draftBanner} onPress={handleClearDraft}>
                <Ionicons name="document-text-outline" size={16} color="#3B82F6" />
                <Text style={styles.draftBannerText}>Draft restored from previous session</Text>
                <Ionicons name="close-circle" size={18} color="#6B7280" />
              </TouchableOpacity>
            )}
            
            <Text style={styles.label}>Type *</Text>
            <View style={styles.typeRow}>
              {DELIVERY_TYPES.map(type => (
                <TouchableOpacity 
                  key={type.value} 
                  style={[styles.typeBtn, deliveryType === type.value && styles.typeBtnActive]}
                  onPress={() => setDeliveryType(type.value)}
                >
                  <Text style={[styles.typeBtnText, deliveryType === type.value && styles.typeBtnTextActive]}>{type.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
            
            <Text style={styles.label}>Client Name *</Text>
            <TextInput style={styles.input} value={clientName} onChangeText={setClientName} placeholder="Enter client name" />
            
            <Text style={styles.label}>Requested Date *</Text>
            <TouchableOpacity style={styles.input} onPress={() => setShowDatePicker(!showDatePicker)}>
              <Text>{formatDate(requestedDate)}</Text>
            </TouchableOpacity>
            {showDatePicker && (
              <View style={styles.pickerContainer}>
                <DateTimePicker value={requestedDate} onChange={(date) => { setRequestedDate(date); setShowDatePicker(false); }} mode="date" />
              </View>
            )}
            
            <Text style={styles.label}>Requested Time</Text>
            <TouchableOpacity style={styles.input} onPress={() => setShowTimePicker(!showTimePicker)}>
              <Text>{requestedTime}</Text>
            </TouchableOpacity>
            {showTimePicker && (
              <View style={styles.timeList}>
                <ScrollView style={styles.timeScroll}>
                  {TIME_SLOTS.map(t => (
                    <TouchableOpacity key={t} style={styles.timeItem} onPress={() => { setRequestedTime(t); setShowTimePicker(false); }}>
                      <Text style={styles.timeText}>{t}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </View>
            )}
            
            <Text style={styles.label}>{deliveryType === 'pickup' ? 'Pick Up Address *' : 'Delivery Address *'}</Text>
            <TextInput style={[styles.input, styles.textArea]} value={deliveryAddress} onChangeText={setDeliveryAddress} multiline numberOfLines={3} placeholder={deliveryType === 'pickup' ? 'Enter pick up address' : 'Enter delivery address'} />
            
            <Text style={styles.label}>Description</Text>
            <TextInput style={[styles.input, styles.textArea]} value={description} onChangeText={setDescription} multiline numberOfLines={2} placeholder="What needs to be delivered/picked up?" />
            
            <Text style={styles.label}>Contact Phone</Text>
            <TextInput style={styles.input} value={contactPhone} onChangeText={setContactPhone} keyboardType="phone-pad" placeholder="Enter contact phone" />
            
            <Text style={styles.label}>Notes</Text>
            <TextInput style={[styles.input, styles.textArea]} value={notes} onChangeText={setNotes} multiline numberOfLines={2} placeholder="Additional notes" />

            <View style={styles.buttons}>
              <TouchableOpacity style={styles.cancelButton} onPress={handleCancel}>
                <Text style={styles.cancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveButton} onPress={handleSubmit} disabled={saving}>
                <Text style={styles.saveText}>{saving ? 'Submitting...' : 'Submit Request'}</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: 'white', borderRadius: 12, padding: 20, maxHeight: '85%' },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
  title: { fontSize: 20, fontWeight: 'bold' },
  draftIndicator: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#ECFDF5', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  draftIndicatorText: { fontSize: 11, color: '#059669', fontWeight: '500' },
  draftBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#EFF6FF', padding: 10, borderRadius: 8, marginBottom: 15 },
  draftBannerText: { flex: 1, fontSize: 12, color: '#3B82F6', fontWeight: '500' },
  label: { fontSize: 14, fontWeight: '600', marginBottom: 5, color: '#374151' },
  input: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, padding: 12, marginBottom: 15, fontSize: 16, justifyContent: 'center' },
  textArea: { height: 70, textAlignVertical: 'top' },
  pickerContainer: { marginBottom: 15 },
  timeList: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, marginBottom: 15, maxHeight: 150 },
  timeScroll: { maxHeight: 140 },
  timeItem: { padding: 12, borderBottomWidth: 1, borderBottomColor: '#f3f4f6' },
  timeText: { fontSize: 16 },
  typeRow: { flexDirection: 'row', gap: 8, marginBottom: 15 },
  typeBtn: { flex: 1, padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#d1d5db', alignItems: 'center' },
  typeBtnActive: { backgroundColor: '#2563eb', borderColor: '#2563eb' },
  typeBtnText: { fontSize: 14, fontWeight: '600', color: '#6b7280' },
  typeBtnTextActive: { color: 'white' },
  buttons: { flexDirection: 'row', gap: 10, marginTop: 10 },
  cancelButton: { flex: 1, padding: 15, borderRadius: 8, borderWidth: 1, borderColor: '#d1d5db' },
  cancelText: { textAlign: 'center', fontSize: 16, color: '#6b7280' },
  saveButton: { flex: 1, padding: 15, borderRadius: 8, backgroundColor: '#2563eb' },
  saveText: { textAlign: 'center', fontSize: 16, color: 'white', fontWeight: '600' }
});
