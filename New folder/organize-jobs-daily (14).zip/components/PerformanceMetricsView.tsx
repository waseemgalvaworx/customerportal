import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, ActivityIndicator } from 'react-native';
import { supabase } from '@/app/lib/supabase';

interface StageMetrics {
  stage: string;
  avgDuration: number;
  count: number;
  totalDuration: number;
}

export default function PerformanceMetricsView() {
  const [metrics, setMetrics] = useState<StageMetrics[]>([]);
  const [loading, setLoading] = useState(true);
  const [avgCompletionTime, setAvgCompletionTime] = useState(0);

  useEffect(() => {
    loadMetrics();
  }, []);

  const loadMetrics = async () => {
    setLoading(true);
    
    // Get completed jobs with completion times
    const { data: jobs } = await supabase
      .from('jobs')
      .select('dateOfEntry, completedDate')
      .eq('status', 'done')
      .not('completedDate', 'is', null);

    if (jobs) {
      const durations = jobs.map(j => {
        const start = new Date(j.dateOfEntry).getTime();
        const end = new Date(j.completedDate).getTime();
        return (end - start) / (1000 * 60 * 60 * 24); // days
      });
      const avg = durations.reduce((a, b) => a + b, 0) / durations.length;
      setAvgCompletionTime(avg || 0);
    }

    // Get stage metrics from performance_metrics table
    const { data: perfData } = await supabase
      .from('performance_metrics')
      .select('stage, duration_minutes');

    if (perfData) {
      const grouped = perfData.reduce((acc: any, curr) => {
        if (!acc[curr.stage]) {
          acc[curr.stage] = { stage: curr.stage, totalDuration: 0, count: 0 };
        }
        acc[curr.stage].totalDuration += curr.duration_minutes || 0;
        acc[curr.stage].count += 1;
        return acc;
      }, {});

      const metricsArray = Object.values(grouped).map((g: any) => ({
        ...g,
        avgDuration: g.totalDuration / g.count
      })) as StageMetrics[];

      setMetrics(metricsArray.sort((a, b) => b.avgDuration - a.avgDuration));
    }

    setLoading(false);
  };

  if (loading) {
    return <View style={{ padding: 20, alignItems: 'center' }}><ActivityIndicator size="large" /></View>;
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: 'white', padding: 20 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20 }}>Performance Metrics</Text>
      
      <View style={{ backgroundColor: '#f0f9ff', padding: 20, borderRadius: 12, marginBottom: 20 }}>
        <Text style={{ fontSize: 16, color: '#666', marginBottom: 5 }}>Average Completion Time</Text>
        <Text style={{ fontSize: 32, fontWeight: 'bold', color: '#007AFF' }}>
          {avgCompletionTime.toFixed(1)} days
        </Text>
      </View>

      <Text style={{ fontSize: 18, fontWeight: '600', marginBottom: 15 }}>Stage Bottlenecks</Text>
      {metrics.map((m, i) => (
        <View key={i} style={{ backgroundColor: '#f5f5f5', padding: 15, borderRadius: 10, marginBottom: 10 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text style={{ fontSize: 16, fontWeight: '600' }}>{m.stage}</Text>
            <Text style={{ fontSize: 14, color: '#666' }}>{m.count} jobs</Text>
          </View>
          <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#FF9500', marginTop: 5 }}>
            {m.avgDuration.toFixed(0)} min avg
          </Text>
          <View style={{ height: 8, backgroundColor: '#e0e0e0', borderRadius: 4, marginTop: 10, overflow: 'hidden' }}>
            <View style={{ height: '100%', backgroundColor: '#FF9500', width: `${Math.min(100, (m.avgDuration / Math.max(...metrics.map(x => x.avgDuration))) * 100)}%` }} />
          </View>
        </View>
      ))}
    </ScrollView>
  );
}
