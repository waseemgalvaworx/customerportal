import React, { useState, useEffect, useRef } from 'react';
import { Modal, View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '@/app/lib/supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { exportQualityControlPDF } from '@/utils/qualityControlPdfExport';
import { ALLOWED_TASK_USERS } from '@/contexts/TaskContext';
import { usePasswordAuth } from '@/contexts/PasswordAuthContext';

interface QCModalProps {
  visible: boolean;
  onClose: () => void;
  jobId: string;
  itemName: string;
  jobNumber: string;
}

interface DraftData {
  qcData: any;
  jobId: string;
  itemName: string;
  savedAt: number;
}

const getDraftKey = (jobId: string, itemName: string) => `qc_form_draft_${jobId}_${itemName.replace(/\s+/g, '_')}`;

export default function QualityControlModal({ visible, onClose, jobId, itemName, jobNumber }: QCModalProps) {
  const { user } = usePasswordAuth();
  const [currentUser, setCurrentUser] = useState('');
  const [qcData, setQcData] = useState<any>({});
  const [loading, setLoading] = useState(true);
  
  // Draft-related state
  const [showDraftIndicator, setShowDraftIndicator] = useState(false);
  const [hasDraft, setHasDraft] = useState(false);
  const [draftRestoredBanner, setDraftRestoredBanner] = useState(false);
  const initialLoadDone = useRef(false);
  const originalData = useRef<any>(null);

  // Check if user is allowed to use draft feature
  const canUseDrafts = ALLOWED_TASK_USERS.includes(user?.username || '');

  useEffect(() => {
    if (visible) {
      initialLoadDone.current = false;
      loadData();
    }
  }, [visible]);

  // Auto-save draft when form changes
  useEffect(() => {
    if (visible && canUseDrafts && initialLoadDone.current && hasFormChanges()) {
      const timeout = setTimeout(() => {
        saveDraft();
      }, 1000); // Debounce 1 second
      return () => clearTimeout(timeout);
    }
  }, [qcData, visible]);

  const hasFormChanges = () => {
    if (!originalData.current) return false;
    return JSON.stringify(qcData) !== JSON.stringify(originalData.current);
  };

  const loadDraft = async () => {
    try {
      const draftStr = await AsyncStorage.getItem(getDraftKey(jobId, itemName));
      if (draftStr) {
        const draft: DraftData = JSON.parse(draftStr);
        // Only load if draft is less than 24 hours old and matches this job/item
        if (Date.now() - draft.savedAt < 24 * 60 * 60 * 1000 && 
            draft.jobId === jobId && draft.itemName === itemName) {
          return draft.qcData;
        } else {
          await AsyncStorage.removeItem(getDraftKey(jobId, itemName));
        }
      }
    } catch (error) {
      console.error('Error loading QC draft:', error);
    }
    return null;
  };

  const saveDraft = async () => {
    try {
      const draft: DraftData = {
        qcData,
        jobId,
        itemName,
        savedAt: Date.now()
      };
      await AsyncStorage.setItem(getDraftKey(jobId, itemName), JSON.stringify(draft));
      setShowDraftIndicator(true);
      setHasDraft(true);
      setTimeout(() => setShowDraftIndicator(false), 2000);
    } catch (error) {
      console.error('Error saving QC draft:', error);
    }
  };

  const clearDraft = async () => {
    try {
      await AsyncStorage.removeItem(getDraftKey(jobId, itemName));
      setHasDraft(false);
      setDraftRestoredBanner(false);
    } catch (error) {
      console.error('Error clearing QC draft:', error);
    }
  };

  const handleClearDraft = () => {
    Alert.alert(
      'Discard Draft',
      'Are you sure you want to discard your unsaved changes?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Discard', 
          style: 'destructive',
          onPress: async () => {
            await clearDraft();
            // Reset to original data
            if (originalData.current) {
              setQcData(originalData.current);
            }
          }
        }
      ]
    );
  };

  const loadData = async () => {
    const storedUser = await AsyncStorage.getItem('currentUser');
    setCurrentUser(storedUser || '');
    
    const { data } = await supabase
      .from('quality_control')
      .select('*')
      .eq('job_id', jobId)
      .eq('item_name', itemName)
      .maybeSingle();

    const serverData = data || {};
    originalData.current = serverData;

    // Check for draft if user is allowed
    if (canUseDrafts) {
      const draftData = await loadDraft();
      if (draftData && JSON.stringify(draftData) !== JSON.stringify(serverData)) {
        setQcData(draftData);
        setHasDraft(true);
        setDraftRestoredBanner(true);
      } else {
        setQcData(serverData);
      }
    } else {
      setQcData(serverData);
    }

    setLoading(false);
    initialLoadDone.current = true;
  };


  const toggleArray = (field: string, value: string) => {
    const arr = qcData[field] || [];
    setQcData({
      ...qcData,
      [field]: arr.includes(value) ? arr.filter((v: string) => v !== value) : [...arr, value]
    });
  };

  const updateField = (field: string, value: any) => {
    setQcData({ ...qcData, [field]: value });
  };

  const saveData = async () => {
    try {
      console.log('Save button pressed - starting save...');
      setLoading(true);
      
      const payload = {
        job_id: jobId,
        job_number: jobNumber,
        item_name: itemName,
        workshop_surface_condition: qcData.workshop_surface_condition || [],
        workshop_drilling_done: qcData.workshop_drilling_done || false,
        workshop_welding_quality: qcData.workshop_welding_quality || null,
        workshop_racking: qcData.workshop_racking || null,
        acid_forward_good_condition: qcData.acid_forward_good_condition || false,
        acid_surface_condition: qcData.acid_surface_condition || [],
        zinc_forward_good_condition: qcData.zinc_forward_good_condition || false,
        zinc_surface_condition: qcData.zinc_surface_condition || [],
        zinc_immersion_time: qcData.zinc_immersion_time || null,
        zinc_coating_condition: qcData.zinc_coating_condition || null,
        finishing_surface_condition: qcData.finishing_surface_condition || [],
        finishing_remedial_action: qcData.finishing_remedial_action || false,
        finishing_remedial_explanation: qcData.finishing_remedial_explanation || null,
        finishing_coating_thickness_microns: qcData.finishing_coating_thickness_microns || null,
        updated_by: currentUser,
        updated_at: new Date().toISOString()
      };

      console.log('Payload prepared:', payload);

      if (qcData.id) {
        console.log('Updating existing record with ID:', qcData.id);
        const { data, error } = await supabase
          .from('quality_control')
          .update(payload)
          .eq('id', qcData.id)
          .select();
        
        if (error) {
          console.error('Update error:', error);
          throw error;
        }
        console.log('Update successful:', data);
        
        // Clear draft on successful save
        await clearDraft();
        originalData.current = data?.[0] || payload;
        
        Alert.alert('Success', 'Quality control data updated in QC Archive');
      } else {
        console.log('Inserting new record...');
        const insertPayload = {
          ...payload,
          created_by: currentUser,
          created_at: new Date().toISOString()
        };
        const { data, error } = await supabase
          .from('quality_control')
          .insert(insertPayload)
          .select();
        
        if (error) {
          console.error('Insert error:', error);
          throw error;
        }
        console.log('Insert successful:', data);
        if (data && data.length > 0) {
          setQcData(data[0]);
          originalData.current = data[0];
        }
        
        // Clear draft on successful save
        await clearDraft();
        
        Alert.alert('Success', 'Quality control data saved to QC Archive');
      }
      setLoading(false);
    } catch (error: any) {
      setLoading(false);
      console.error('Save error:', error);
      Alert.alert('Error', `Failed to save: ${error.message || 'Unknown error'}`);
    }
  };


  const exportPDF = async () => {
    await exportQualityControlPDF(qcData, jobNumber, itemName);
  };

  const handleClose = () => {
    // Don't clear draft on close - keep it for later
    setDraftRestoredBanner(false);
    onClose();
  };


  return (
    <Modal visible={visible} animationType="slide">
      <View style={s.container}>
        <View style={s.header}>
          <Text style={s.title}>Quality Checklist</Text>
          <View style={s.headerRight}>
            {canUseDrafts && showDraftIndicator && (
              <View style={s.draftIndicator}>
                <Ionicons name="cloud-done" size={14} color="#10B981" />
                <Text style={s.draftIndicatorText}>Saved</Text>
              </View>
            )}
            <TouchableOpacity onPress={handleClose}><Text style={s.close}>✕</Text></TouchableOpacity>
          </View>
        </View>
        <Text style={s.sub}>Job: {jobNumber} | Item: {itemName}</Text>
        
        {canUseDrafts && draftRestoredBanner && (
          <TouchableOpacity style={s.draftBanner} onPress={handleClearDraft}>
            <Ionicons name="document-text-outline" size={16} color="#F59E0B" />
            <Text style={s.draftBannerText}>Unsaved changes restored - tap to discard</Text>
            <Ionicons name="close-circle" size={18} color="#6B7280" />
          </TouchableOpacity>
        )}
        
        <ScrollView style={s.scroll}>
          {/* WORKSHOP */}
          <Text style={s.section}>WORKSHOP</Text>
          <Text style={s.label}>Surface Condition:</Text>
          <View style={s.row}>
            {['Galv', 'Grease/oil', 'Paint', 'Poor', 'Good', 'Excellent'].map(v => (
              <TouchableOpacity key={v} onPress={() => toggleArray('workshop_surface_condition', v)} 
                style={[s.chip, (qcData.workshop_surface_condition || []).includes(v) && s.chipActive]}>
                <Text>{v}</Text>
              </TouchableOpacity>
            ))}

          </View>

          <Text style={s.label}>Drilling:</Text>
          <View style={s.row}>
            <TouchableOpacity onPress={() => updateField('workshop_drilling_done', true)} 
              style={[s.chip, qcData.workshop_drilling_done === true && s.chipActive]}>
              <Text>Yes</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => updateField('workshop_drilling_done', false)} 
              style={[s.chip, qcData.workshop_drilling_done === false && s.chipActive]}>
              <Text>No</Text>
            </TouchableOpacity>
          </View>


          <Text style={s.label}>Welding Quality:</Text>
          <View style={s.row}>
            {['Poor', 'Good', 'Excellent'].map(v => (
              <TouchableOpacity key={v} onPress={() => updateField('workshop_welding_quality', v)} 
                style={[s.chip, qcData.workshop_welding_quality === v && s.chipActive]}>
                <Text>{v}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={s.label}>Racking:</Text>
          <View style={s.row}>
            {['Individual', 'Jig'].map(v => (
              <TouchableOpacity key={v} onPress={() => updateField('workshop_racking', v)} 
                style={[s.chip, qcData.workshop_racking === v && s.chipActive]}>
                <Text>{v}</Text>
              </TouchableOpacity>
            ))}
          </View>


          {/* ACID DEPARTMENT */}
          <Text style={s.section}>ACID DEPARTMENT</Text>
          <Text style={s.label}>Forward to Acid in good condition:</Text>
          <View style={s.row}>
            <TouchableOpacity onPress={() => updateField('acid_forward_good_condition', true)} 
              style={[s.chip, qcData.acid_forward_good_condition === true && s.chipActive]}>
              <Text>Yes</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => updateField('acid_forward_good_condition', false)} 
              style={[s.chip, qcData.acid_forward_good_condition === false && s.chipActive]}>
              <Text>No</Text>
            </TouchableOpacity>
          </View>

          <Text style={s.label}>Surface Condition:</Text>
          <View style={s.row}>
            {['Galv', 'Grease/oil', 'Paint'].map(v => (
              <TouchableOpacity key={v} onPress={() => toggleArray('acid_surface_condition', v)} 
                style={[s.chip, (qcData.acid_surface_condition || []).includes(v) && s.chipActive]}>
                <Text>{v}</Text>
              </TouchableOpacity>
            ))}
          </View>




          {/* ZINC DEPARTMENT */}
          <Text style={s.section}>ZINC DEPARTMENT</Text>
          <Text style={s.label}>Forward to Zinc in good condition:</Text>
          <View style={s.row}>
            <TouchableOpacity onPress={() => updateField('zinc_forward_good_condition', true)} 
              style={[s.chip, qcData.zinc_forward_good_condition === true && s.chipActive]}>
              <Text>Yes</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => updateField('zinc_forward_good_condition', false)} 
              style={[s.chip, qcData.zinc_forward_good_condition === false && s.chipActive]}>
              <Text>No</Text>
            </TouchableOpacity>
          </View>


          {/* FINISHING */}
          <Text style={s.section}>FINISHING & DELIVERY</Text>
          <Text style={s.label}>Surface Condition:</Text>
          <View style={s.row}>
            {['Rough', 'Smooth', 'Black spots', 'Ungalvanised'].map(v => (
              <TouchableOpacity key={v} onPress={() => toggleArray('finishing_surface_condition', v)} 
                style={[s.chip, (qcData.finishing_surface_condition || []).includes(v) && s.chipActive]}>
                <Text>{v}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={s.label}>Re-Galv:</Text>
          <View style={s.row}>
            <TouchableOpacity onPress={() => updateField('finishing_regalv', true)} 
              style={[s.chip, qcData.finishing_regalv === true && s.chipActive]}>
              <Text>Yes</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => updateField('finishing_regalv', false)} 
              style={[s.chip, qcData.finishing_regalv === false && s.chipActive]}>
              <Text>No</Text>
            </TouchableOpacity>
          </View>

          <Text style={s.label}>Remedial Action:</Text>
          <View style={s.row}>
            <TouchableOpacity onPress={() => updateField('finishing_remedial_action', true)} 
              style={[s.chip, qcData.finishing_remedial_action === true && s.chipActive]}>
              <Text>Yes</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => updateField('finishing_remedial_action', false)} 
              style={[s.chip, qcData.finishing_remedial_action === false && s.chipActive]}>
              <Text>No</Text>
            </TouchableOpacity>
          </View>


          {qcData.finishing_remedial_action === true && (
            <TextInput style={s.input} placeholder="Explain remedial action taken..." 
              value={qcData.finishing_remedial_explanation || ''} 
              onChangeText={t => updateField('finishing_remedial_explanation', t)} 
              multiline />
          )}






          <View style={s.btnRow}>
            <TouchableOpacity 
              style={[s.btn, loading && s.btnDisabled]} 
              onPress={saveData}
              disabled={loading}
            >
              <Text style={s.btnText}>{loading ? 'Saving...' : 'Save to QC Archive'}</Text>
            </TouchableOpacity>
          </View>



        </ScrollView>
      </View>
    </Modal>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, borderBottomWidth: 1, borderBottomColor: '#ddd' },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  title: { fontSize: 24, fontWeight: 'bold' },
  close: { fontSize: 24 },
  draftIndicator: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#ECFDF5', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  draftIndicatorText: { fontSize: 11, color: '#059669', fontWeight: '500' },
  draftBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#FEF3C7', padding: 12, marginHorizontal: 12, marginTop: 8, borderRadius: 8, borderWidth: 1, borderColor: '#FCD34D' },
  draftBannerText: { flex: 1, fontSize: 12, color: '#92400E', fontWeight: '500' },
  sub: { padding: 10, backgroundColor: '#f5f5f5', fontWeight: '600' },
  scroll: { flex: 1, padding: 20 },
  section: { fontSize: 20, fontWeight: 'bold', marginTop: 20, marginBottom: 10, textDecorationLine: 'underline' },
  label: { fontSize: 16, fontWeight: '600', marginTop: 10, marginBottom: 5 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 10 },
  chip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, borderWidth: 1, borderColor: '#ddd', backgroundColor: '#f5f5f5' },
  chipActive: { backgroundColor: '#4CAF50', borderColor: '#4CAF50' },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 10, marginBottom: 10, backgroundColor: '#fff' },
  btnRow: { flexDirection: 'row', gap: 10, marginTop: 20, marginBottom: 40 },
  btn: { flex: 1, backgroundColor: '#2196F3', padding: 15, borderRadius: 8, alignItems: 'center' },
  btnDisabled: { backgroundColor: '#ccc' },
  btnText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});
