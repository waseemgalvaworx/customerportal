import React from 'react';
import { View, Text, ScrollView } from 'react-native';

interface DataItem {
  date: string;
  target: number;
  completed: number;
}

interface Props {
  data: DataItem[];
}

export default function TargetVsCompletedChart({ data }: Props) {
  const maxValue = Math.max(...data.map(d => Math.max(d.target, d.completed)), 1);
  
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
  };

  const getPercentage = (completed: number, target: number) => {
    if (target === 0) return completed > 0 ? 100 : 0;
    return Math.round((completed / target) * 100);
  };

  const totals = data.reduce((acc, d) => ({
    target: acc.target + d.target,
    completed: acc.completed + d.completed
  }), { target: 0, completed: 0 });

  const overallPercentage = getPercentage(totals.completed, totals.target);

  return (
    <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 20, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 }}>
      <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#1f2937', marginBottom: 4 }}>Target vs Completed</Text>
      <Text style={{ fontSize: 13, color: '#6b7280', marginBottom: 16 }}>Daily production comparison (previous days)</Text>
      
      {/* Summary Card */}
      <View style={{ backgroundColor: overallPercentage >= 100 ? '#ECFDF5' : overallPercentage >= 80 ? '#FEF3C7' : '#FEF2F2', borderRadius: 10, padding: 14, marginBottom: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View>
          <Text style={{ fontSize: 13, color: '#6b7280' }}>Overall Achievement</Text>
          <Text style={{ fontSize: 24, fontWeight: 'bold', color: overallPercentage >= 100 ? '#059669' : overallPercentage >= 80 ? '#D97706' : '#DC2626' }}>{overallPercentage}%</Text>
        </View>
        <View style={{ alignItems: 'flex-end' }}>
          <Text style={{ fontSize: 12, color: '#6b7280' }}>Target: {totals.target.toFixed(0)} kg</Text>
          <Text style={{ fontSize: 12, color: '#6b7280' }}>Completed: {totals.completed.toFixed(0)} kg</Text>
        </View>
      </View>

      {/* Legend */}
      <View style={{ flexDirection: 'row', marginBottom: 12, gap: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <View style={{ width: 12, height: 12, backgroundColor: '#E5E7EB', borderRadius: 2, marginRight: 6 }} />
          <Text style={{ fontSize: 12, color: '#6b7280' }}>Target</Text>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <View style={{ width: 12, height: 12, backgroundColor: '#007AFF', borderRadius: 2, marginRight: 6 }} />
          <Text style={{ fontSize: 12, color: '#6b7280' }}>Completed</Text>
        </View>
      </View>

      <ScrollView style={{ maxHeight: 300 }} showsVerticalScrollIndicator={false}>
        {data.slice(-14).map((item, index) => {
          const pct = getPercentage(item.completed, item.target);
          const targetWidth = (item.target / maxValue) * 100;
          const completedWidth = (item.completed / maxValue) * 100;
          
          return (
            <View key={index} style={{ marginBottom: 12 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
                <Text style={{ fontSize: 12, fontWeight: '600', color: '#374151' }}>{formatDate(item.date)}</Text>
                <Text style={{ fontSize: 12, fontWeight: '600', color: pct >= 100 ? '#059669' : pct >= 80 ? '#D97706' : '#DC2626' }}>{pct}%</Text>
              </View>
              <View style={{ height: 8, backgroundColor: '#F3F4F6', borderRadius: 4, overflow: 'hidden' }}>
                <View style={{ position: 'absolute', height: '100%', width: `${targetWidth}%`, backgroundColor: '#E5E7EB', borderRadius: 4 }} />
                <View style={{ position: 'absolute', height: '100%', width: `${completedWidth}%`, backgroundColor: pct >= 100 ? '#10B981' : '#007AFF', borderRadius: 4 }} />
              </View>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 2 }}>
                <Text style={{ fontSize: 10, color: '#9CA3AF' }}>{item.completed.toFixed(0)} kg</Text>
                <Text style={{ fontSize: 10, color: '#9CA3AF' }}>/ {item.target.toFixed(0)} kg</Text>
              </View>
            </View>
          );
        })}
      </ScrollView>
      
      {data.length > 14 && (
        <Text style={{ fontSize: 11, color: '#9CA3AF', textAlign: 'center', marginTop: 8 }}>Showing last 14 days</Text>
      )}
    </View>
  );
}
