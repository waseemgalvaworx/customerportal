import React, { useState } from 'react';
import { View, Text, StyleSheet, Modal, TouchableOpacity, TextInput, Alert, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../app/lib/supabase';

interface UnarchiveFinishingModalProps {
  visible: boolean;
  onClose: () => void;
  reportDate: string;
  archivedReport: any;
  onSuccess: () => void;
}

export default function UnarchiveFinishingModal({ 
  visible, 
  onClose, 
  reportDate, 
  archivedReport,
  onSuccess 
}: UnarchiveFinishingModalProps) {
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(true);
  const [selectedRecords, setSelectedRecords] = useState<Set<number>>(new Set());

  const toggleRecord = (index: number) => {
    setSelectedRecords(prev => {
      const newSet = new Set(prev);
      if (newSet.has(index)) newSet.delete(index);
      else newSet.add(index);
      return newSet;
    });
  };

  const handlePasswordSubmit = () => {
    if (password !== '4321') {
      Alert.alert('Error', 'Incorrect password');
      return;
    }
    setShowPasswordPrompt(false);
  };

  const handleUnarchive = async () => {
    if (selectedRecords.size === 0) {
      Alert.alert('No Records Selected', 'Please select at least one record to unarchive');
      return;
    }

    setLoading(true);
    try {
      const recordsToRestore = archivedReport.records
        .filter((_: any, idx: number) => selectedRecords.has(idx))
        .map((rec: any) => {
          const { id, created_at, ...rest } = rec;
          return rest;
        });

      // DEDUPLICATION CHECK: Get all item_ids that already exist in finishing_records
      const itemIdsToRestore = recordsToRestore.map((r: any) => r.item_id).filter(Boolean);
      
      if (itemIdsToRestore.length > 0) {
        const { data: existingRecords, error: checkError } = await supabase
          .from('finishing_records')
          .select('item_id')
          .in('item_id', itemIdsToRestore);

        if (checkError) {
          console.error('Error checking existing records:', checkError);
        }

        // Filter out records that already exist in finishing_records
        const existingItemIds = new Set(existingRecords?.map(r => r.item_id) || []);
        const filteredRecords = recordsToRestore.filter((r: any) => !existingItemIds.has(r.item_id));
        
        const skippedCount = recordsToRestore.length - filteredRecords.length;
        
        if (filteredRecords.length === 0) {
          Alert.alert(
            'Already Exists', 
            `All ${skippedCount} selected record(s) already exist in finishing records. No records were restored.`
          );
          setLoading(false);
          return;
        }

        // Insert only non-duplicate records
        const { error: insertError } = await supabase
          .from('finishing_records')
          .insert(filteredRecords);

        if (insertError) {
          // Handle unique constraint violation gracefully
          if (insertError.code === '23505') {
            Alert.alert('Duplicate Error', 'Some records already exist in finishing records. Please try again.');
          } else {
            Alert.alert('Error', 'Failed to restore records: ' + insertError.message);
          }
          setLoading(false);
          return;
        }

        // If all records were unarchived, delete the archive entry
        if (selectedRecords.size === archivedReport.records.length) {
          await supabase
            .from('archived_finishing_reports')
            .delete()
            .eq('report_date', archivedReport.report_date);
        }

        const successMessage = skippedCount > 0 
          ? `${filteredRecords.length} record(s) restored!\n${skippedCount} duplicate(s) were skipped.`
          : `${filteredRecords.length} record(s) restored!`;
        
        Alert.alert('Success', successMessage);
      } else {
        // No item_ids to check, proceed with insert
        const { error: insertError } = await supabase
          .from('finishing_records')
          .insert(recordsToRestore);

        if (insertError) {
          Alert.alert('Error', 'Failed to restore records: ' + insertError.message);
          setLoading(false);
          return;
        }

        // If all records were unarchived, delete the archive entry
        if (selectedRecords.size === archivedReport.records.length) {
          await supabase
            .from('archived_finishing_reports')
            .delete()
            .eq('report_date', archivedReport.report_date);
        }

        Alert.alert('Success', `${selectedRecords.size} record(s) restored!`);
      }

      setPassword('');
      setShowPasswordPrompt(true);
      setSelectedRecords(new Set());
      onSuccess();
      onClose();
    } catch (error: any) {
      Alert.alert('Error', 'Failed to unarchive: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setPassword('');
    setShowPasswordPrompt(true);
    setSelectedRecords(new Set());
    onClose();
  };

  if (showPasswordPrompt) {
    return (
      <Modal visible={visible} transparent animationType="fade">
        <View style={styles.overlay}>
          <View style={styles.modal}>
            <View style={styles.header}>
              <Ionicons name="lock-closed" size={32} color="#F59E0B" />
              <Text style={styles.title}>Enter Password</Text>
            </View>
            <Text style={styles.message}>Enter password to unarchive finishing records</Text>
            <TextInput
              style={styles.input}
              secureTextEntry
              value={password}
              onChangeText={setPassword}
              placeholder="Enter password"
              keyboardType="number-pad"
            />
            <View style={styles.buttons}>
              <TouchableOpacity style={styles.cancelBtn} onPress={handleCancel}>
                <Text style={styles.btnText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.unarchiveBtn} onPress={handlePasswordSubmit}>
                <Text style={styles.btnText}>Continue</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  }

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.overlay}>
        <View style={styles.modalLarge}>
          <Text style={styles.title}>Select Records to Unarchive</Text>
          <Text style={styles.subtitle}>{reportDate}</Text>
          <ScrollView style={styles.recordList}>
            {archivedReport.records?.map((record: any, idx: number) => (
              <TouchableOpacity key={idx} style={styles.recordRow} onPress={() => toggleRecord(idx)}>
                <View style={[styles.checkbox, selectedRecords.has(idx) && styles.checkboxActive]}>
                  {selectedRecords.has(idx) && <Ionicons name="checkmark" size={18} color="#fff" />}
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.recordText}>{record.job_number} - {record.customer_name}</Text>
                  <Text style={styles.recordDesc}>{record.description}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
          <View style={styles.buttons}>
            <TouchableOpacity style={styles.cancelBtn} onPress={handleCancel}>
              <Text style={styles.btnText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[styles.unarchiveBtn, loading && styles.disabledBtn]} 
              onPress={handleUnarchive}
              disabled={loading}
            >
              <Text style={styles.btnText}>
                {loading ? 'Restoring...' : `Unarchive (${selectedRecords.size})`}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modal: { backgroundColor: 'white', borderRadius: 12, padding: 24, width: '85%', maxWidth: 400 },
  modalLarge: { backgroundColor: 'white', borderRadius: 12, padding: 20, width: '90%', maxHeight: '80%' },
  header: { flexDirection: 'row', alignItems: 'center', marginBottom: 16, gap: 12 },
  title: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', textAlign: 'center', marginBottom: 8 },
  subtitle: { fontSize: 14, color: '#6B7280', textAlign: 'center', marginBottom: 16 },
  message: { fontSize: 14, color: '#374151', marginBottom: 12, lineHeight: 20 },
  input: { borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, padding: 12, fontSize: 16, marginBottom: 16 },
  recordList: { maxHeight: 400, marginBottom: 16 },
  recordRow: { flexDirection: 'row', alignItems: 'center', padding: 12, backgroundColor: '#F9FAFB', borderRadius: 8, marginBottom: 8 },
  checkbox: { width: 24, height: 24, borderRadius: 6, borderWidth: 2, borderColor: '#D1D5DB', marginRight: 12, justifyContent: 'center', alignItems: 'center' },
  checkboxActive: { backgroundColor: '#3B82F6', borderColor: '#3B82F6' },
  recordText: { fontSize: 14, color: '#374151', fontWeight: '500' },
  recordDesc: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  buttons: { flexDirection: 'row', gap: 12 },
  cancelBtn: { flex: 1, backgroundColor: '#6B7280', padding: 12, borderRadius: 8, alignItems: 'center' },
  unarchiveBtn: { flex: 1, backgroundColor: '#F59E0B', padding: 12, borderRadius: 8, alignItems: 'center' },
  disabledBtn: { opacity: 0.5 },
  btnText: { color: 'white', fontWeight: '600', fontSize: 14 }
});
