import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TouchableOpacity, ScrollView, StyleSheet, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../app/lib/supabase';
import StatusHistoryTimeline from './StatusHistoryTimelineSimple';



interface JobDetailsViewModalProps {
  visible: boolean;
  onClose: () => void;
  jobId: string | null;
}

export default function JobDetailsViewModal({ visible, onClose, jobId }: JobDetailsViewModalProps) {
  const [job, setJob] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [statusHistory, setStatusHistory] = useState<any[]>([]);
  const [stageHistory, setStageHistory] = useState<any[]>([]);


  useEffect(() => {
    if (visible && jobId) {
      fetchJobDetails();
      fetchStatusHistory();
      fetchStageHistory();
    }
  }, [visible, jobId]);


  const fetchJobDetails = async () => {
    if (!jobId) return;
    setLoading(true);
    try {
      const { data, error } = await supabase.from('jobs').select('*').eq('id', jobId).single();
      if (error) throw error;
      setJob(data);
    } catch (error) {
      console.error('Error fetching job:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchStatusHistory = async () => {
    if (!jobId) return;
    try {
      const { data, error } = await supabase
        .from('activity_logs')
        .select('*')
        .eq('entity_id', jobId)
        .in('action_type', ['JOB_CREATED', 'JOB_STATUS_CHANGED', 'JOB_UPDATED'])
        .order('created_at', { ascending: true });
      if (error) throw error;
      setStatusHistory(data || []);
    } catch (error) {
      console.error('Error fetching history:', error);
    }
  };

  const fetchStageHistory = async () => {
    if (!jobId) return;
    try {
      const { data, error } = await supabase
        .from('item_stage_tracking')
        .select('*')
        .eq('job_id', jobId)
        .order('created_at', { ascending: true });
      if (error) throw error;
      setStageHistory(data || []);
    } catch (error) {
      console.error('Error fetching stage history:', error);
    }
  };

  const getStageColor = (stage: string) => {
    const colors: any = {
      pending: '#F59E0B',
      workshop: '#3B82F6',
      acid: '#EF4444',
      galva: '#8B5CF6',
      finishing: '#10B981',
      ready: '#059669'
    };
    return colors[stage] || '#9CA3AF';
  };

  const getStatusColor = (status: string) => {
    const colors: any = {
      pending: '#F59E0B', planning: '#6366F1', galva: '#8B5CF6',
      wip: '#3B82F6', done: '#10B981', archived: '#6B7280'
    };
    return colors[status] || '#9CA3AF';
  };

  if (!job && !loading) return null;

  return (
    <Modal visible={visible} animationType="slide" transparent={false}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Job Details</Text>
          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <Ionicons name="close" size={28} color="#1F2937" />
          </TouchableOpacity>
        </View>

        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#6366F1" />
          </View>
        ) : job ? (
          <ScrollView style={styles.content}>
            <View style={styles.section}>
              <Text style={styles.jobNumber}>Job #{job.jobNumber}</Text>
              <Text style={styles.customer}>{job.customerName}</Text>
              <View style={[styles.statusBadge, { backgroundColor: getStatusColor(job.status || 'pending') }]}>
                <Text style={styles.statusText}>{(job.status || 'pending').toUpperCase()}</Text>
              </View>

            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Job Information</Text>
              <View style={styles.infoRow}>
                <Text style={styles.label}>Entry Date:</Text>
                <Text style={styles.value}>{new Date(job.dateOfEntry || job.createdAt).toLocaleDateString()}</Text>
              </View>
              {job.priority && (
                <View style={styles.infoRow}>
                  <Text style={styles.label}>Priority:</Text>
                  <Text style={styles.value}>{job.priority.toUpperCase()}</Text>
                </View>
              )}
              {job.deliveryDate && (
                <View style={styles.infoRow}>
                  <Text style={styles.label}>Delivery Date:</Text>
                  <Text style={styles.value}>{new Date(job.deliveryDate).toLocaleString()}</Text>
                </View>
              )}
              {job.notes && (
                <View style={styles.infoRow}>
                  <Text style={styles.label}>Notes:</Text>
                  <Text style={styles.valueMulti}>{job.notes}</Text>
                </View>
              )}
            </View>

            {job.items && job.items.length > 0 && (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Items ({job.items.length})</Text>
                {job.items.map((item: any, idx: number) => (
                  <View key={idx} style={styles.itemCard}>
                    {item.itemCount && <Text style={styles.itemCount}>Qty: {item.itemCount}</Text>}
                    <Text style={styles.itemDesc}>{item.descriptionOfWorks}</Text>
                    <Text style={styles.itemWeight}>{item.weightKg} kg</Text>
                    {item.status && <Text style={styles.itemStatus}>Status: {item.status}</Text>}
                  </View>
                ))}
              </View>
            )}

            {statusHistory.length > 0 && (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Status History</Text>
                <StatusHistoryTimeline history={statusHistory} />
              </View>
            )}

            {stageHistory.length > 0 && (job.status === 'done' || job.status === 'archived') && (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Production Stage History</Text>
                <Text style={styles.stageSubtitle}>Track item progression through production stages</Text>
                {stageHistory.filter(stage => stage && stage.current_stage).map((stage, idx) => (
                  <View key={idx} style={styles.stageCard}>
                    <View style={styles.stageHeader}>
                      <View style={[styles.stageBadge, { backgroundColor: getStageColor((stage.current_stage || 'pending').toLowerCase()) }]}>
                        <Text style={styles.stageText}>{(stage.current_stage || 'unknown').toUpperCase()}</Text>
                      </View>
                      <Text style={styles.stageTime}>
                        {stage.entry_time ? new Date(stage.entry_time).toLocaleString() : stage.created_at ? new Date(stage.created_at).toLocaleString() : 'N/A'}
                      </Text>
                    </View>
                    <Text style={styles.stageItem}>Item ID: {stage.item_id || 'N/A'}</Text>
                    {stage.ready_date && <Text style={styles.stageNotes}>Ready: {new Date(stage.ready_date).toLocaleString()}</Text>}
                  </View>
                ))}

              </View>
            )}

          </ScrollView>
        ) : null}
      </View>
    </Modal>
  );
}


const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6', paddingTop: 50 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  title: { fontSize: 22, fontWeight: 'bold', color: '#1F2937' },
  closeButton: { padding: 4 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  content: { flex: 1 },
  section: { backgroundColor: '#fff', padding: 16, marginTop: 8 },
  jobNumber: { fontSize: 24, fontWeight: 'bold', color: '#1F2937', marginBottom: 4 },
  customer: { fontSize: 18, color: '#374151', marginBottom: 8 },
  statusBadge: { alignSelf: 'flex-start', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12 },
  statusText: { fontSize: 12, fontWeight: '600', color: '#fff', textTransform: 'uppercase' },
  sectionTitle: { fontSize: 18, fontWeight: '600', color: '#1F2937', marginBottom: 12 },
  infoRow: { marginBottom: 12 },
  label: { fontSize: 14, fontWeight: '600', color: '#6B7280', marginBottom: 4 },
  value: { fontSize: 16, color: '#1F2937' },
  valueMulti: { fontSize: 15, color: '#374151', lineHeight: 22 },
  itemCard: { backgroundColor: '#F9FAFB', padding: 12, borderRadius: 8, marginBottom: 8 },
  itemCount: { fontSize: 13, color: '#3B82F6', fontWeight: '600', marginBottom: 2 },
  itemDesc: { fontSize: 15, color: '#1F2937', marginBottom: 4 },
  itemWeight: { fontSize: 14, color: '#6B7280' },
  itemStatus: { fontSize: 13, color: '#8B5CF6', marginTop: 4, fontStyle: 'italic' },
  stageSubtitle: { fontSize: 14, color: '#6B7280', marginBottom: 12, fontStyle: 'italic' },
  stageCard: { backgroundColor: '#F9FAFB', padding: 12, borderRadius: 8, marginBottom: 10, borderLeftWidth: 3, borderLeftColor: '#6366F1' },
  stageHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  stageBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  stageText: { fontSize: 11, fontWeight: '600', color: '#fff' },
  stageTime: { fontSize: 12, color: '#6B7280' },
  stageItem: { fontSize: 13, color: '#374151', marginBottom: 4 },
  stageNotes: { fontSize: 12, color: '#6B7280', fontStyle: 'italic', marginTop: 4 }
});

