import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, Modal, StyleSheet, ScrollView, Alert } from 'react-native';
import { supabase } from '@/app/lib/supabase';
import { Ionicons } from '@expo/vector-icons';
import NotificationPermissionsModal from './NotificationPermissionsModal';

interface User {
  id: string;
  username: string;
  full_name: string;
  role: string;
  is_active: boolean;
}

interface EditUserModalProps {
  visible: boolean;
  user: User | null;
  onClose: () => void;
  onUserUpdated: () => void;
}

const ROLES = [
  { value: 'admin', label: 'Admin' },
  { value: 'manager', label: 'Manager' },
  { value: 'operator', label: 'Operator' },
  { value: 'viewer', label: 'Viewer' },
  { value: 'data_entry_officer', label: 'Data Entry Officer' }
];

export default function EditUserModal({ visible, user, onClose, onUserUpdated }: EditUserModalProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState('operator');
  const [isActive, setIsActive] = useState(true);
  const [loading, setLoading] = useState(false);
  const [showNotificationPermissions, setShowNotificationPermissions] = useState(false);


  useEffect(() => {
    if (user) {
      setUsername(user.username);
      setFullName(user.full_name);
      setRole(user.role);
      setIsActive(user.is_active);
      setPassword('');
    }
  }, [user]);

  const handleSubmit = async () => {
    if (!username || !fullName) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }
    setLoading(true);
    try {
      // Update user profile in profiles table
      const updateData: any = { 
        username, 
        full_name: fullName, 
        role, 
        is_active: isActive 
      };

      const { error: profileError } = await supabase
        .from('profiles')
        .update(updateData)
        .eq('id', user?.id);

      if (profileError) throw profileError;

      // If password is provided, update it via edge function
      if (password) {
        const { error: passwordError } = await supabase.functions.invoke('update-user', { 
          body: { user_id: user?.id, password } 
        });
        if (passwordError) {
          console.warn('Password update failed:', passwordError);
          Alert.alert('Partial Success', 'User updated but password change failed');
        }
      }

      Alert.alert('Success', 'User updated successfully');
      onUserUpdated();
      onClose();
    } catch (error: any) {
      Alert.alert('Error', error.message || 'Failed to update user');
    } finally {
      setLoading(false);
    }
  };


  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <Text style={styles.title}>Edit User</Text>
          <ScrollView>
            <TextInput style={styles.input} placeholder="Username" value={username} onChangeText={setUsername} autoCapitalize="none" />
            <TextInput style={styles.input} placeholder="New Password (leave blank to keep current)" value={password} onChangeText={setPassword} secureTextEntry />
            <TextInput style={styles.input} placeholder="Full Name" value={fullName} onChangeText={setFullName} />
            <Text style={styles.label}>Role</Text>
            {ROLES.map(r => (
              <TouchableOpacity key={r.value} style={[styles.roleOption, role === r.value && styles.roleSelected]} onPress={() => setRole(r.value)}>
                <Text style={[styles.roleText, role === r.value && styles.roleTextSelected]}>{r.label}</Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={styles.activeToggle} onPress={() => setIsActive(!isActive)}>
              <Text style={styles.activeText}>{isActive ? '✓ Active' : '✗ Inactive'}</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.notificationButton} onPress={() => setShowNotificationPermissions(true)}>
              <Ionicons name="notifications-outline" size={20} color="#007AFF" />
              <Text style={styles.notificationButtonText}>Notification Permissions</Text>
              <Ionicons name="chevron-forward" size={20} color="#007AFF" />
            </TouchableOpacity>

          </ScrollView>
          <View style={styles.buttons}>
            <TouchableOpacity style={[styles.button, styles.cancelButton]} onPress={onClose}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.button, styles.submitButton]} onPress={handleSubmit} disabled={loading}>
              <Text style={styles.submitText}>{loading ? 'Updating...' : 'Update User'}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>


      {user && (
        <NotificationPermissionsModal
          visible={showNotificationPermissions}
          userId={user.id}
          username={user.username}
          onClose={() => setShowNotificationPermissions(false)}
        />
      )}
    </Modal>
  );
}


const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: '#fff', borderRadius: 12, padding: 20, maxHeight: '80%' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 20 },
  input: { backgroundColor: '#f5f5f5', padding: 12, borderRadius: 8, marginBottom: 12, borderWidth: 1, borderColor: '#ddd' },
  label: { fontSize: 14, fontWeight: '600', marginBottom: 8, marginTop: 8 },
  roleOption: { padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#ddd', marginBottom: 8 },
  roleSelected: { backgroundColor: '#007AFF', borderColor: '#007AFF' },
  roleText: { fontSize: 14, color: '#333' },
  roleTextSelected: { color: '#fff', fontWeight: '600' },
  activeToggle: { padding: 12, backgroundColor: '#f5f5f5', borderRadius: 8, marginTop: 12 },
  activeText: { fontSize: 14, fontWeight: '600', textAlign: 'center' },
  notificationButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 12, backgroundColor: '#E3F2FD', borderRadius: 8, marginTop: 12, borderWidth: 1, borderColor: '#007AFF' },
  notificationButtonText: { flex: 1, fontSize: 14, fontWeight: '600', color: '#007AFF', marginLeft: 8 },
  buttons: { flexDirection: 'row', gap: 10, marginTop: 20 },
  button: { flex: 1, padding: 12, borderRadius: 8, alignItems: 'center' },
  cancelButton: { backgroundColor: '#f5f5f5' },
  submitButton: { backgroundColor: '#007AFF' },
  cancelText: { color: '#333', fontWeight: '600' },
  submitText: { color: '#fff', fontWeight: '600' }
});

