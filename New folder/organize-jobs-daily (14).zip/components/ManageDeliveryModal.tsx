import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TextInput, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';
import { supabase } from '../app/lib/supabase';

interface ManageDeliveryModalProps {
  visible: boolean;
  onClose: () => void;
  deliveryId: string | null;
  onSuccess: () => void;
}

export default function ManageDeliveryModal({ visible, onClose, deliveryId, onSuccess }: ManageDeliveryModalProps) {
  const [delivery, setDelivery] = useState<any>(null);
  const [vehicles, setVehicles] = useState<any[]>([]);
  const [drivers, setDrivers] = useState<any[]>([]);
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [selectedDriver, setSelectedDriver] = useState<string | null>(null);
  const [customerName, setCustomerName] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (visible && deliveryId) {
      loadDelivery();
      loadVehiclesAndDrivers();
    }
  }, [visible, deliveryId]);

  useEffect(() => {
    if (!visible) {
      setDelivery(null);
      setSelectedVehicle(null);
      setSelectedDriver(null);
      setCustomerName('');
      setNotes('');
    }
  }, [visible]);

  const loadDelivery = async () => {
    const { data } = await supabase.from('logistics_deliveries').select('*').eq('id', deliveryId).single();
    if (data) {
      setDelivery(data);
      setNotes(data.notes || '');
      setSelectedVehicle(data.vehicle_id || null);
      setSelectedDriver(data.driver_id || null);
      setCustomerName(data.customer_name || '');
    }
  };

  const loadVehiclesAndDrivers = async () => {
    const { data: v } = await supabase.from('vehicles').select('*').eq('status', 'active');
    const { data: d } = await supabase.from('drivers').select('*').eq('status', 'active');
    setVehicles(v || []);
    setDrivers(d || []);
  };

  const handleSave = async () => {
    setSaving(true);
    const updateData: any = {
      delivery_address: delivery.delivery_address,
      vehicle_id: selectedVehicle,
      driver_id: selectedDriver,
      notes: notes.trim()
    };
    
    if (delivery.delivery_type === 'pickup' || delivery.delivery_type === 'delivery') {
      updateData.customer_name = customerName.trim();
    }

    const { error } = await supabase.from('logistics_deliveries').update(updateData).eq('id', deliveryId);

    setSaving(false);
    if (error) {
      Alert.alert('Error', error.message);
    } else {
      Alert.alert('Success', 'Delivery updated successfully');
      onSuccess();
      onClose();
    }
  };

  const showCustomerField = delivery && (delivery.delivery_type === 'pickup' || delivery.delivery_type === 'delivery');

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <ScrollView showsVerticalScrollIndicator={false}>
            <Text style={styles.title}>Manage Delivery</Text>
            
            {delivery && (
              <>
                <Text style={styles.label}>Delivery Number</Text>
                <Text style={styles.info}>{delivery.delivery_number}</Text>
                
                <Text style={styles.label}>Type</Text>
                <Text style={styles.info}>{delivery.delivery_type?.toUpperCase() || 'N/A'}</Text>

                {showCustomerField && (
                  <>
                    <Text style={styles.label}>Customer Name</Text>
                    <TextInput 
                      style={styles.input} 
                      value={customerName} 
                      onChangeText={setCustomerName}
                      placeholder="Enter customer name"
                    />
                  </>
                )}
                
                <Text style={styles.label}>Address</Text>
                <TextInput style={styles.input} value={delivery.delivery_address} onChangeText={(text) => setDelivery({...delivery, delivery_address: text})} />
                
                <Text style={styles.label}>Assign Vehicle</Text>
                <ScrollView horizontal style={styles.selectList} showsHorizontalScrollIndicator={false}>
                  <TouchableOpacity style={[styles.selectItem, !selectedVehicle && styles.selected]} onPress={() => setSelectedVehicle(null)}>
                    <Text style={!selectedVehicle ? styles.selectedText : undefined}>None</Text>
                  </TouchableOpacity>
                  {vehicles.map(v => (
                    <TouchableOpacity key={v.id} style={[styles.selectItem, selectedVehicle === v.id && styles.selected]} onPress={() => setSelectedVehicle(v.id)}>
                      <Text style={selectedVehicle === v.id ? styles.selectedText : undefined}>{v.vehicle_number}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
                
                <Text style={styles.label}>Assign Driver</Text>
                <ScrollView horizontal style={styles.selectList} showsHorizontalScrollIndicator={false}>
                  <TouchableOpacity style={[styles.selectItem, !selectedDriver && styles.selected]} onPress={() => setSelectedDriver(null)}>
                    <Text style={!selectedDriver ? styles.selectedText : undefined}>None</Text>
                  </TouchableOpacity>
                  {drivers.map(d => (
                    <TouchableOpacity key={d.id} style={[styles.selectItem, selectedDriver === d.id && styles.selected]} onPress={() => setSelectedDriver(d.id)}>
                      <Text style={selectedDriver === d.id ? styles.selectedText : undefined}>{d.full_name}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
                
                <Text style={styles.label}>Notes</Text>
                <TextInput style={[styles.input, styles.textArea]} value={notes} onChangeText={setNotes} multiline numberOfLines={3} placeholder="Add notes..." />
              </>
            )}

            <View style={styles.buttons}>
              <TouchableOpacity style={styles.cancelButton} onPress={onClose}>
                <Text style={styles.cancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveButton} onPress={handleSave} disabled={saving}>
                <Text style={styles.saveText}>{saving ? 'Saving...' : 'Save'}</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: 'white', borderRadius: 12, padding: 20, maxHeight: '85%' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 20 },
  label: { fontSize: 14, fontWeight: '600', marginTop: 10, marginBottom: 5, color: '#374151' },
  info: { fontSize: 16, marginBottom: 10, color: '#6b7280' },
  input: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, padding: 12, marginBottom: 15, fontSize: 16 },
  textArea: { height: 80, textAlignVertical: 'top' },
  selectList: { marginBottom: 15 },
  selectItem: { padding: 10, borderRadius: 8, borderWidth: 1, borderColor: '#d1d5db', marginRight: 10 },
  selected: { backgroundColor: '#2563eb', borderColor: '#2563eb' },
  selectedText: { color: 'white' },
  buttons: { flexDirection: 'row', gap: 8, marginTop: 10 },
  cancelButton: { flex: 1, padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#d1d5db' },
  cancelText: { textAlign: 'center', fontSize: 14, color: '#6b7280' },
  saveButton: { flex: 1, padding: 12, borderRadius: 8, backgroundColor: '#2563eb' },
  saveText: { textAlign: 'center', fontSize: 14, color: 'white', fontWeight: '600' }
});
