import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface DeliveryStatsCardsProps {
  totalDeliveries: number;
  inTransit: number;
  completedToday: number;
}

export default function DeliveryStatsCards({ totalDeliveries, inTransit, completedToday }: DeliveryStatsCardsProps) {
  return (
    <View style={styles.container}>
      <View style={[styles.card, { backgroundColor: '#3b82f6' }]}>
        <Ionicons name="cube-outline" size={28} color="white" />
        <Text style={styles.value}>{totalDeliveries}</Text>
        <Text style={styles.label}>Total Deliveries</Text>
      </View>

      <View style={[styles.card, { backgroundColor: '#f59e0b' }]}>
        <Ionicons name="car-outline" size={28} color="white" />
        <Text style={styles.value}>{inTransit}</Text>
        <Text style={styles.label}>In Transit</Text>
      </View>

      <View style={[styles.card, { backgroundColor: '#10b981' }]}>
        <Ionicons name="checkmark-circle-outline" size={28} color="white" />
        <Text style={styles.value}>{completedToday}</Text>
        <Text style={styles.label}>Completed Today</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flexDirection: 'row', gap: 10, marginBottom: 15 },
  card: { flex: 1, padding: 15, borderRadius: 12, alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  value: { fontSize: 24, fontWeight: 'bold', color: 'white', marginTop: 8 },
  label: { fontSize: 11, color: 'rgba(255,255,255,0.9)', marginTop: 4, textAlign: 'center' }
});
