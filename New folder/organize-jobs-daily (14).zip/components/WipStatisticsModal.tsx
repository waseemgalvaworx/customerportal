import React, { useMemo, useState, useEffect } from 'react';
import { View, Text, StyleSheet, Modal, TouchableOpacity, ScrollView, Alert, TextInput } from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import { Job, ItemStatus } from '../contexts/JobContext';
import { supabase } from '../app/lib/supabase';
import FinishingPreviewModal from './FinishingPreviewModal';
import { saveFinishingRecordPDF } from '../utils/finishingRecordExport';
import { useSettings } from '../contexts/SettingsContext';
import WipJobCard from './WipJobCard';




interface WipStatisticsModalProps {

  visible: boolean;
  onClose: () => void;
  jobs: Job[];
}


interface FinishingRecord {
  id: string;
  job_number: string;
  customer_name: string;
  item_description: string;
  weight_kg: string;
  recorded_date: string;
  item_id?: string;
}

export default function WipStatisticsModal({ visible, onClose, jobs }: WipStatisticsModalProps) {
  const [expandedStatus, setExpandedStatus] = useState<ItemStatus | null>(null);
  const [finishingRecords, setFinishingRecords] = useState<FinishingRecord[]>([]);
  const [showPreview, setShowPreview] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showArchiveConfirmModal, setShowArchiveConfirmModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showArchivePasswordModal, setShowArchivePasswordModal] = useState(false);
  const [password, setPassword] = useState('');
  const [archivePassword, setArchivePassword] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'galvaxpress' | 'high' | 'urgent'>('all');
  const [finishingWeight, setFinishingWeight] = useState(0);
  const [targetWeight, setTargetWeight] = useState(0);

  const { settings } = useSettings();

  // Fetch and refresh data when modal opens or jobs change
  useEffect(() => {
    if (visible) {
      fetchFinishingRecords();
      calculateProductionProgress();
    }
  }, [visible, jobs]);

  // Calculate production progress based on new logic
  const calculateProductionProgress = () => {
    const todayDate = new Date();
    todayDate.setHours(0, 0, 0, 0);

    let targetTotal = 0;
    let finishingTotal = 0;

    jobs.forEach(job => {
      if (!job.deliveryDate) return;

      const deliveryDate = new Date(job.deliveryDate);
      deliveryDate.setHours(0, 0, 0, 0);

      // Include jobs with delivery date today or earlier that are still in production
      if (deliveryDate <= todayDate) {
        job.items.forEach(item => {
          const weight = Number(item.weightKg) || 0;
          
          // All items with delivery date <= today count toward target (except those already finished)
          if (item.status !== 'Finishing') {
            targetTotal += weight;
          }
          
          // Items in Finishing status count as completed
          if (item.status === 'Finishing') {
            finishingTotal += weight;
            targetTotal += weight; // Also add to target since they were part of today's goal
          }
        });
      }
    });

    setTargetWeight(targetTotal);
    setFinishingWeight(finishingTotal);
  };

  // Real-time subscription to job updates and finishing_records
  useEffect(() => {
    if (!visible) return;

    const channel = supabase
      .channel('wip-statistics-realtime')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'jobs' },
        () => {
          fetchFinishingRecords();
          calculateProductionProgress();
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'archived_finishing_reports' },
        () => {
          calculateProductionProgress();
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'finishing_records' },
        () => {
          fetchFinishingRecords();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [visible]);

  // Simple fetch - no auto-add logic. Records are added via JobContext when status changes.
  const fetchFinishingRecords = async () => {
    const today = new Date().toISOString().split('T')[0];
    const { data, error } = await supabase.from('finishing_records').select('*').eq('recorded_date', today);
    if (!error && data) {
      // Remove duplicates based on item_id (keep the most recent one)
      const uniqueRecords = Array.from(
        data.reduce((map, item) => {
          const existing = map.get(item.item_id);
          if (!existing || new Date(item.created_at || 0) > new Date(existing.created_at || 0)) {
            map.set(item.item_id, item);
          }
          return map;
        }, new Map()).values()
      );
      setFinishingRecords(uniqueRecords);
    }
  };


  const handleClearFinishing = () => {
    setShowConfirmModal(true);
  };



  const handleConfirmYes = () => {
    setShowConfirmModal(false);
    setShowPasswordModal(true);
  };


  const handlePasswordSubmit = async () => {
    if (password === '4321') {
      setShowPasswordModal(false);
      setPassword('');
      const today = new Date().toISOString().split('T')[0];
      const { error } = await supabase.from('finishing_records').delete().eq('recorded_date', today);
      if (!error) {
        setFinishingRecords([]);
        Alert.alert('Success', 'Data cleared');
      } else {
        Alert.alert('Error', 'Failed to clear');
      }
    } else {
      Alert.alert('Error', 'Incorrect password');
    }
  };

  const handleArchiveFinishing = () => {
    setShowArchiveConfirmModal(true);
  };

  const handleArchiveConfirmYes = () => {
    setShowArchiveConfirmModal(false);
    setShowArchivePasswordModal(true);
  };

  const handleArchivePasswordSubmit = async () => {
    if (archivePassword === '4321') {
      setShowArchivePasswordModal(false);
      setArchivePassword('');
      const today = new Date().toISOString().split('T')[0];
      
      console.log('=== STARTING ARCHIVE PROCESS ===');
      console.log('Today date:', today);
      console.log('Finishing records to archive:', finishingRecords.length);
      
      if (finishingRecords.length === 0) {
        Alert.alert('Info', 'No finishing records to archive');
        return;
      }
      
      // Fetch all existing archived reports to check for duplicates
      console.log('Fetching existing archived reports to check for duplicates...');
      const { data: existingReports, error: fetchError } = await supabase
        .from('archived_finishing_reports')
        .select('records');
      
      if (fetchError) {
        console.error('Error fetching existing reports:', fetchError);
        Alert.alert('Error', 'Failed to check for duplicates: ' + fetchError.message);
        return;
      }
      
      // Extract all item_ids that have already been archived
      const archivedItemIds = new Set<string>();
      if (existingReports) {
        existingReports.forEach(report => {
          if (report.records && Array.isArray(report.records)) {
            report.records.forEach((record: any) => {
              if (record.item_id) {
                archivedItemIds.add(record.item_id);
              }
            });
          }
        });
      }
      
      console.log('Found', archivedItemIds.size, 'already archived item_ids');
      
      // Filter out records that have already been archived
      const newRecordsToArchive = finishingRecords.filter(record => !archivedItemIds.has(record.item_id));
      
      console.log('Records after filtering duplicates:', newRecordsToArchive.length);
      
      if (newRecordsToArchive.length === 0) {
        Alert.alert('Info', 'All finishing records have already been archived previously. No new records to archive.');
        return;
      }
      
      // Calculate totals for new records only
      const totalItems = newRecordsToArchive.length;
      const totalWeight = newRecordsToArchive.reduce((sum, rec) => sum + parseFloat(rec.weight_kg || '0'), 0);
      
      console.log('Total new items to archive:', totalItems);
      console.log('Total weight:', totalWeight);
      
      // Prepare archive record with only new finishing records as JSONB
      const archiveRecord = {
        report_date: today,
        archived_at: new Date().toISOString(),
        records: newRecordsToArchive, // Store only new records as JSONB
        total_items: totalItems,
        total_weight: totalWeight,
        created_by: null // Can be set to current user ID if auth is available
      };

      console.log('Archive record prepared:', JSON.stringify(archiveRecord, null, 2));
      console.log('Attempting to insert into archived_finishing_reports table...');

      const { data: insertData, error: archiveError } = await supabase
        .from('archived_finishing_reports')
        .insert([archiveRecord])
        .select();

      if (archiveError) {
        console.error('❌ ARCHIVE ERROR:', archiveError);
        console.error('Error code:', archiveError.code);
        console.error('Error message:', archiveError.message);
        console.error('Error details:', JSON.stringify(archiveError, null, 2));
        Alert.alert(
          'Archive Failed', 
          `Could not archive data:\n\n${archiveError.message}\n\nPlease ensure:\n1. The archived_finishing_reports table exists\n2. RLS policies allow INSERT\n3. Check FINISHING_TABLES_SETUP.md for setup instructions`
        );
        return;
      }

      console.log('✅ ARCHIVE SUCCESSFUL!');
      console.log('Inserted data:', JSON.stringify(insertData, null, 2));

      // Then delete from main table (delete ALL records for today, not just new ones)
      console.log('Deleting records from finishing_records table...');
      const { error: deleteError } = await supabase
        .from('finishing_records')
        .delete()
        .eq('recorded_date', today);

      if (deleteError) {
        console.error('❌ DELETE ERROR:', deleteError);
        Alert.alert('Warning', 'Data archived but failed to delete from finishing_records: ' + deleteError.message);
        return;
      }

      console.log('✅ DELETE SUCCESSFUL!');
      console.log('=== ARCHIVE PROCESS COMPLETE ===');
      setFinishingRecords([]);
      
      const skippedCount = finishingRecords.length - newRecordsToArchive.length;
      const message = skippedCount > 0 
        ? `Data archived successfully!\n\n${totalItems} new items (${totalWeight.toFixed(2)} kg) moved to archive.\n${skippedCount} duplicate items were skipped.\n\nYou can view this in the Archive screen under "Finishing Report".`
        : `Data archived successfully!\n\n${totalItems} items (${totalWeight.toFixed(2)} kg) moved to archive.\n\nYou can view this in the Archive screen under "Finishing Report".`;
      
      Alert.alert('Success', message);
    } else {
      Alert.alert('Error', 'Incorrect password');
    }
  };






  const handleExport = async () => {
    try {
      await saveFinishingRecordPDF(finishingRecords, settings?.saveLocation || 'downloads');
      setShowPreview(false);
      Alert.alert('Success', 'PDF exported');
    } catch (error) {
      Alert.alert('Error', 'Export failed');
    }
  };


  // Filter and sort jobs
  const filteredAndSortedJobs = useMemo(() => {
    let filtered = jobs;
    
    // Apply filter
    if (activeFilter === 'galvaxpress') {
      filtered = jobs.filter(j => j.galvaXpress);
    } else if (activeFilter === 'high') {
      filtered = jobs.filter(j => j.priority === 'high');
    } else if (activeFilter === 'urgent') {
      const now = new Date();
      filtered = jobs.filter(j => {
        if (!j.deliveryDate) return false;
        const diffHours = (new Date(j.deliveryDate).getTime() - now.getTime()) / (1000 * 60 * 60);
        return diffHours > 0 && diffHours < 48;
      });
    }
    
    // Sort by priority and delivery date
    return filtered.sort((a, b) => {
      // GalvXpress first
      if (a.galvaXpress && !b.galvaXpress) return -1;
      if (!a.galvaXpress && b.galvaXpress) return 1;
      
      // Then by priority
      const priorityOrder = { high: 0, medium: 1, low: 2 };
      const aPriority = priorityOrder[a.priority || 'low'];
      const bPriority = priorityOrder[b.priority || 'low'];
      if (aPriority !== bPriority) return aPriority - bPriority;
      
      // Then by delivery date
      if (a.deliveryDate && b.deliveryDate) {
        return new Date(a.deliveryDate).getTime() - new Date(b.deliveryDate).getTime();
      }
      if (a.deliveryDate) return -1;
      if (b.deliveryDate) return 1;
      
      return 0;
    });
  }, [jobs, activeFilter]);

  const statistics = useMemo(() => {
    const stats = {
      Workshop: { count: 0, weight: 0, jobs: [] as Job[] },
      Acid: { count: 0, weight: 0, jobs: [] as Job[] },
      Galva: { count: 0, weight: 0, jobs: [] as Job[] },
      Finishing: { count: finishingRecords.length, weight: finishingRecords.reduce((s, r) => s + parseFloat(r.weight_kg || '0'), 0), jobs: [] as Job[] }
    };
    const jobsByStatus: Record<string, Job[]> = { Workshop: [], Acid: [], Galva: [], Finishing: [] };
    filteredAndSortedJobs.forEach(job => {
      const statusCounts: Record<string, number> = {};
      job.items.forEach(item => {
        const status = item.status as ItemStatus;
        if (status !== 'Finishing' && stats[status]) {
          statusCounts[status] = (statusCounts[status] || 0) + 1;
          stats[status].count++;
          stats[status].weight += parseFloat(item.weightKg || '0');
        }
      });
      Object.keys(statusCounts).forEach(status => {
        if (!jobsByStatus[status].find(j => j.id === job.id)) jobsByStatus[status].push(job);
      });
    });
    stats.Workshop.jobs = jobsByStatus.Workshop;
    stats.Acid.jobs = jobsByStatus.Acid;
    stats.Galva.jobs = jobsByStatus.Galva;
    return stats;
  }, [filteredAndSortedJobs, finishingRecords]);

  const statusColors = { Workshop: '#3B82F6', Acid: '#F59E0B', Galva: '#8B5CF6', Finishing: '#EC4899' };

  // Calculate progress percentage
  const progressPercentage = useMemo(() => {
    if (targetWeight === 0) return 0;
    return Math.min((finishingWeight / targetWeight) * 100, 100);
  }, [finishingWeight, targetWeight]);




  return (<>
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <View style={styles.container}>
         <View style={styles.header}>
          <Text style={styles.title}>WIP Statistics</Text>
          <TouchableOpacity onPress={onClose}>
            <Ionicons name="close" size={28} color="#374151" />
          </TouchableOpacity>
        </View>


        <ScrollView style={styles.content}>

          {(Object.keys(statistics) as ItemStatus[]).map(status => (
            <View key={status} style={styles.statusSection}>
              <TouchableOpacity style={[styles.statusHeader, { backgroundColor: statusColors[status] }]} onPress={() => setExpandedStatus(expandedStatus === status ? null : status)}>
                <View style={styles.statusLeft}>
                  <Text style={styles.statusTitle}>{status}</Text>
                  <View style={styles.statusStats}>
                    <Text style={styles.statusCount}>{statistics[status].count} items</Text>
                    <Text style={styles.statusWeight}>{statistics[status].weight.toFixed(2)} kg</Text>
                  </View>
                </View>
                <Ionicons name={expandedStatus === status ? "chevron-up" : "chevron-down"} size={24} color="white" />
              </TouchableOpacity>
              {status === 'Finishing' && expandedStatus === status && (<View style={styles.finishingContent}>
                {finishingRecords.length === 0 ? <Text style={styles.noData}>No records for today. Items are automatically recorded when moved to Finishing status.</Text> : finishingRecords.map(rec => (
                  <View key={rec.id} style={styles.finishingCard}>
                    <Text style={styles.jobNumber}>Job #{rec.job_number}</Text>
                    <Text style={styles.customerName}>{rec.customer_name}</Text>
                    <Text style={styles.itemDesc}>{rec.item_description}</Text>
                    <Text style={styles.itemWeight}>{parseFloat(rec.weight_kg || '0').toFixed(2)} kg</Text>
                  </View>
                ))}
                
                {finishingRecords.length > 0 && (<View style={styles.finishingActions}>
                  <TouchableOpacity style={styles.previewBtn} onPress={() => setShowPreview(true)}>
                    <Ionicons name="document-text" size={18} color="white" /><Text style={styles.btnText}>Preview</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={styles.archiveBtn} 
                    onPress={handleArchiveFinishing}
                    activeOpacity={0.7}
                  >
                    <Ionicons name="archive" size={18} color="white" />
                    <Text style={styles.btnText}>Archive</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={styles.clearBtn} 
                    onPress={handleClearFinishing}
                    activeOpacity={0.7}
                  >
                    <Ionicons name="trash" size={18} color="white" />
                    <Text style={styles.btnText}>Clear</Text>
                  </TouchableOpacity>
                </View>)}

              </View>)}




              {status !== 'Finishing' && expandedStatus === status && statistics[status].jobs.map(job => (
                <WipJobCard key={job.id} job={job} status={status} />
              ))}

            </View>
          ))}


          {/* Production Progress Display */}
          <View style={styles.progressContainer}>
            <View style={styles.progressHeader}>
              <Ionicons name="trending-up" size={22} color="#1F2937" />
              <Text style={styles.progressTitle}>Production Progress</Text>
            </View>
            
            <View style={styles.progressContent}>
              <View style={styles.targetRow}>
                <Ionicons name="scale-outline" size={18} color="#3B82F6" />
                <Text style={styles.targetLabel}>Target Weight:</Text>
                <Text style={styles.targetValue}>{targetWeight.toFixed(2)} kg</Text>
              </View>
              
              <View style={styles.progressStats}>
                <View style={styles.statItem}>
                  <Ionicons name="checkmark-circle" size={16} color="#059669" />
                  <Text style={styles.statLabel}>Finishing:</Text>
                  <Text style={styles.statValue}>{finishingWeight.toFixed(2)} kg</Text>
                </View>
                <Text style={styles.percentageValue}>{progressPercentage.toFixed(1)}%</Text>
              </View>
              
              <View style={styles.progressBarContainer}>
                <View style={[styles.progressBarFill, { width: `${progressPercentage}%` }]} />
              </View>
              
              <Text style={styles.remainingValue}>
                Remaining: {Math.max(0, targetWeight - finishingWeight).toFixed(2)} kg
              </Text>
            </View>
          </View>




        </ScrollView>




      </View>
    </Modal>

    <Modal visible={showConfirmModal} transparent animationType="fade">
      <View style={styles.passwordOverlay}>
        <View style={styles.passwordModal}>
          <Text style={styles.passwordTitle}>Clear Finishing Data</Text>
          <Text style={styles.confirmText}>Are you sure you want to clear all finishing records for today?</Text>
          <View style={styles.passwordButtons}>
            <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowConfirmModal(false)}>
              <Text style={styles.btnText}>No</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.okBtn} onPress={handleConfirmYes}>
              <Text style={styles.btnText}>Yes</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
    <Modal visible={showPasswordModal} transparent animationType="fade">
      <View style={styles.passwordOverlay}>
        <View style={styles.passwordModal}>
          <Text style={styles.passwordTitle}>Enter Password</Text>
          <TextInput style={styles.passwordInput} secureTextEntry value={password} onChangeText={setPassword} placeholder="Password" keyboardType="number-pad" />
          <View style={styles.passwordButtons}>
            <TouchableOpacity style={styles.cancelBtn} onPress={() => { setShowPasswordModal(false); setPassword(''); }}>
              <Text style={styles.btnText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.okBtn} onPress={handlePasswordSubmit}>
              <Text style={styles.btnText}>OK</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
    <Modal visible={showArchiveConfirmModal} transparent animationType="fade">
      <View style={styles.passwordOverlay}>
        <View style={styles.passwordModal}>
          <Text style={styles.passwordTitle}>Archive Finishing Data</Text>
          <Text style={styles.confirmText}>Are you sure you want to archive all finishing records for today? This will move them to the archive table.</Text>
          <View style={styles.passwordButtons}>
            <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowArchiveConfirmModal(false)}>
              <Text style={styles.btnText}>No</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.okBtn} onPress={handleArchiveConfirmYes}>
              <Text style={styles.btnText}>Yes</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
    <Modal visible={showArchivePasswordModal} transparent animationType="fade">
      <View style={styles.passwordOverlay}>
        <View style={styles.passwordModal}>
          <Text style={styles.passwordTitle}>Enter Password</Text>
          <TextInput style={styles.passwordInput} secureTextEntry value={archivePassword} onChangeText={setArchivePassword} placeholder="Password" keyboardType="number-pad" />
          <View style={styles.passwordButtons}>
            <TouchableOpacity style={styles.cancelBtn} onPress={() => { setShowArchivePasswordModal(false); setArchivePassword(''); }}>
              <Text style={styles.btnText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.okBtn} onPress={handleArchivePasswordSubmit}>
              <Text style={styles.btnText}>OK</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
    <FinishingPreviewModal visible={showPreview} onClose={() => setShowPreview(false)} records={finishingRecords} onExport={handleExport} />




  </>);



}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  title: { fontSize: 20, fontWeight: 'bold', color: '#1F2937' },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  iconButton: { padding: 4 },
  filterTabs: { flexDirection: 'row', backgroundColor: 'white', paddingHorizontal: 12, paddingVertical: 8, gap: 8, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  filterTab: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, backgroundColor: '#F3F4F6', gap: 4 },
  filterTabActive: { backgroundColor: '#3B82F6' },
  filterTabText: { fontSize: 12, fontWeight: '600', color: '#6B7280' },
  filterTabTextActive: { color: 'white' },
  content: { flex: 1, padding: 16 },
  statusSection: { marginBottom: 16, backgroundColor: 'white', borderRadius: 12, overflow: 'hidden', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  statusHeader: { padding: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  statusLeft: { flex: 1 },
  statusTitle: { fontSize: 18, fontWeight: 'bold', color: 'white', marginBottom: 8 },
  statusStats: { flexDirection: 'row', gap: 16 },
  statusCount: { fontSize: 14, color: 'white', fontWeight: '600' },
  statusWeight: { fontSize: 14, color: 'white', fontWeight: 'bold' },
  jobCard: { borderTopWidth: 1, borderTopColor: '#E5E7EB', padding: 12, backgroundColor: '#FAFAFA' },
  jobHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  jobNumber: { fontSize: 12, fontWeight: 'bold', color: '#1F2937' },
  customerName: { fontSize: 12, fontWeight: '600', color: '#6B7280' },
  itemRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4, paddingLeft: 12 },
  itemDesc: { flex: 1, fontSize: 13, color: '#374151' },
  itemWeight: { fontSize: 13, fontWeight: 'bold', color: '#1F2937', marginLeft: 8 },
  finishingContent: { padding: 12, backgroundColor: '#F9FAFB' },
  finishingCard: { backgroundColor: 'white', padding: 12, borderRadius: 8, marginBottom: 8, borderLeftWidth: 3, borderLeftColor: '#EC4899' },
  noData: { textAlign: 'center', color: '#6B7280', padding: 20, fontSize: 14 },
  finishingActions: { flexDirection: 'row', gap: 8, marginTop: 12 },
  previewBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#EC4899', padding: 12, borderRadius: 8, gap: 8 },
  archiveBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#F59E0B', padding: 12, borderRadius: 8, gap: 8 },
  clearBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#EF4444', padding: 12, borderRadius: 8, gap: 8 },
  btnText: { color: 'white', fontWeight: '600', fontSize: 14 },
  passwordOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  passwordModal: { backgroundColor: 'white', borderRadius: 12, padding: 24, width: '80%', maxWidth: 400 },
  passwordTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 16, textAlign: 'center' },
  confirmText: { fontSize: 14, color: '#6B7280', marginBottom: 20, textAlign: 'center', lineHeight: 20 },
  passwordInput: { borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, padding: 12, fontSize: 16, marginBottom: 16 },
  passwordButtons: { flexDirection: 'row', gap: 12 },
  cancelBtn: { flex: 1, backgroundColor: '#6B7280', padding: 12, borderRadius: 8, alignItems: 'center' },
  okBtn: { flex: 1, backgroundColor: '#EC4899', padding: 12, borderRadius: 8, alignItems: 'center' },

  
  // Production Progress Styles
  progressContainer: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginTop: 8,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  progressHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  progressTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
  },

  progressContent: {
    gap: 12,
  },
  targetRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: '#EFF6FF',
    borderRadius: 8,
  },
  targetLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1E40AF',
  },
  targetValue: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#3B82F6',
    marginLeft: 'auto',
  },
  progressStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: '#059669',
  },
  statValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#059669',
  },
  percentageValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1E40AF',
  },
  progressBarContainer: {
    height: 12,
    backgroundColor: '#DBEAFE',
    borderRadius: 6,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: '#3B82F6',
    borderRadius: 6,
  },
  remainingValue: {
    fontSize: 12,
    fontWeight: '500',
    color: '#6B7280',
    textAlign: 'center',
  },
});
