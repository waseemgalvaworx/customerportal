import React, { useMemo, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import DateTimePicker from './DateTimePicker';

interface Job {
  completedDate?: Date | string;
  status: string;
  items: Array<{ weightKg: string }>;
}

interface DailyCompletedKgsViewProps {
  jobs: Job[];
}

export default function DailyCompletedKgsView({ jobs }: DailyCompletedKgsViewProps) {
  const [expanded, setExpanded] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [showDatePicker, setShowDatePicker] = useState(false);

  const dailyData = useMemo(() => {
    const dataMap = new Map<string, number>();
    
    const completedJobs = jobs.filter(job => 
      (job.status === 'done' || job.status === 'archived') && job.completedDate
    );
    
    completedJobs.forEach(job => {
      const date = new Date(job.completedDate!);
      
      // Exclude Sundays (day 0)
      if (date.getDay() === 0) return;
      
      const dateKey = date.toISOString().split('T')[0];
      
      const jobWeight = job.items.reduce((sum, item) => 
        sum + parseFloat(item.weightKg || '0'), 0
      );
      
      dataMap.set(dateKey, (dataMap.get(dateKey) || 0) + jobWeight);
    });
    
    return Array.from(dataMap.entries())
      .map(([date, weight]) => ({ date, weight }))
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [jobs]);


  const filteredData = selectedDate 
    ? dailyData.filter(d => d.date === selectedDate.toISOString().split('T')[0])
    : dailyData.slice(0, 30);

  return (
    <View style={styles.container}>
      <TouchableOpacity 
        style={styles.header} 
        onPress={() => setExpanded(!expanded)}
        activeOpacity={0.7}
      >
        <Text style={styles.title}>Daily Completed Kgs</Text>
        <Ionicons 
          name={expanded ? "chevron-up" : "chevron-down"} 
          size={24} 
          color="#6B7280" 
        />
      </TouchableOpacity>

      {expanded && (
        <>
          <TouchableOpacity 
            style={styles.dateButton}
            onPress={() => setShowDatePicker(true)}
          >
            <Ionicons name="calendar-outline" size={20} color="#3B82F6" />
            <Text style={styles.dateButtonText}>
              {selectedDate 
                ? selectedDate.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
                : 'Select Date (Last 30 days)'
              }
            </Text>
            {selectedDate && (
              <TouchableOpacity onPress={() => setSelectedDate(null)}>
                <Ionicons name="close-circle" size={20} color="#EF4444" />
              </TouchableOpacity>
            )}
          </TouchableOpacity>

          <ScrollView style={styles.list}>
            {filteredData.map((day) => (
              <View key={day.date} style={styles.dayCard}>
                <Text style={styles.dayDate}>
                  {new Date(day.date).toLocaleDateString('en-GB', { 
                    weekday: 'short', day: 'numeric', month: 'short', year: 'numeric'
                  })}
                </Text>
                <Text style={styles.dayWeight}>{day.weight.toFixed(1)} kg</Text>
              </View>
            ))}
            {filteredData.length === 0 && (
              <Text style={styles.emptyText}>No completed jobs</Text>
            )}
          </ScrollView>
        </>
      )}

      {showDatePicker && (
        <DateTimePicker
          value={selectedDate || new Date()}
          onChange={(date) => {
            setSelectedDate(date);
            setShowDatePicker(false);
          }}
          onClose={() => setShowDatePicker(false)}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  dateButton: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 12, padding: 12, backgroundColor: '#F9FAFB', borderRadius: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  dateButtonText: { flex: 1, fontSize: 14, color: '#374151', fontWeight: '500' },
  list: { maxHeight: 400, marginTop: 12 },
  dayCard: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  dayDate: { fontSize: 14, color: '#374151', fontWeight: '500' },
  dayWeight: { fontSize: 16, fontWeight: 'bold', color: '#3B82F6' },
  emptyText: { textAlign: 'center', color: '#9CA3AF', marginTop: 20, fontSize: 14 },
});
