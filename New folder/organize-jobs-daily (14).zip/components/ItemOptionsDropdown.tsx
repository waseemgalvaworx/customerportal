import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface ItemOptionsDropdownProps {
  paintVarnish: boolean;
  galva: boolean;
  lightGalva: boolean;
  lightPaint: boolean;
  rusty: boolean;
  doubleDip: boolean;
  multipleDip: boolean;
  onToggle: (option: string) => void;
}

export default function ItemOptionsDropdown({ 
  paintVarnish, galva, lightGalva, lightPaint, rusty, doubleDip, multipleDip, onToggle 
}: ItemOptionsDropdownProps) {
  const [expanded, setExpanded] = useState(false);

  return (
    <View style={styles.container}>
      <TouchableOpacity 
        style={styles.toggleBtn} 
        onPress={() => setExpanded(!expanded)}
      >
        <Text style={styles.toggleText}>Options</Text>
        <Ionicons 
          name={expanded ? "chevron-up" : "chevron-down"} 
          size={16} 
          color="#6B7280" 
        />
      </TouchableOpacity>
      
      {expanded && (
        <View style={styles.optionsGrid}>
          <TouchableOpacity 
            style={styles.option} 
            onPress={() => onToggle('paintVarnish')}
          >
            <Ionicons 
              name={paintVarnish ? "checkbox" : "square-outline"} 
              size={16} 
              color="#8B5CF6" 
            />
            <Text style={styles.optionText}>Paint/Varnish</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.option} 
            onPress={() => onToggle('galva')}
          >
            <Ionicons 
              name={galva ? "checkbox" : "square-outline"} 
              size={16} 
              color="#3B82F6" 
            />
            <Text style={styles.optionText}>Galva</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.option} 
            onPress={() => onToggle('lightGalva')}
          >
            <Ionicons 
              name={lightGalva ? "checkbox" : "square-outline"} 
              size={16} 
              color="#06B6D4" 
            />
            <Text style={styles.optionText}>Light Galva</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.option} 
            onPress={() => onToggle('lightPaint')}
          >
            <Ionicons 
              name={lightPaint ? "checkbox" : "square-outline"} 
              size={16} 
              color="#10B981" 
            />
            <Text style={styles.optionText}>Light Paint</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.option} 
            onPress={() => onToggle('rusty')}
          >
            <Ionicons 
              name={rusty ? "checkbox" : "square-outline"} 
              size={16} 
              color="#F59E0B" 
            />
            <Text style={styles.optionText}>Rusty</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.option} 
            onPress={() => onToggle('doubleDip')}
          >
            <Ionicons 
              name={doubleDip ? "checkbox" : "square-outline"} 
              size={16} 
              color="#EC4899" 
            />
            <Text style={styles.optionText}>Double Dip</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.option} 
            onPress={() => onToggle('multipleDip')}
          >
            <Ionicons 
              name={multipleDip ? "checkbox" : "square-outline"} 
              size={16} 
              color="#A855F7" 
            />
            <Text style={styles.optionText}>Multiple Dip</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}


const styles = StyleSheet.create({
  container: { marginTop: 8 },
  toggleBtn: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    gap: 4, 
    paddingVertical: 6,
    paddingHorizontal: 8,
    backgroundColor: '#F3F4F6',
    borderRadius: 6,
    alignSelf: 'flex-start'
  },
  toggleText: { fontSize: 13, color: '#6B7280', fontWeight: '500' },
  optionsGrid: { 
    marginTop: 8, 
    gap: 6,
    paddingLeft: 8
  },
  option: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    gap: 6,
    paddingVertical: 4
  },
  optionText: { fontSize: 12, color: '#374151' }
});
