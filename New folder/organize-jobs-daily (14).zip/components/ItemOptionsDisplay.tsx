import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

interface ItemOptionsDisplayProps {
  paintVarnish?: boolean;
  galva?: boolean;
  lightGalva?: boolean;
  lightPaint?: boolean;
  rusty?: boolean;
  doubleDip?: boolean;
  multipleDip?: boolean;
}

export default function ItemOptionsDisplay({ 
  paintVarnish, galva, lightGalva, lightPaint, rusty, doubleDip, multipleDip 
}: ItemOptionsDisplayProps) {
  const options = [];
  if (paintVarnish) options.push({ label: 'Paint/Varnish', color: '#8B5CF6' });
  if (galva) options.push({ label: 'Galva', color: '#3B82F6' });
  if (lightGalva) options.push({ label: 'Light Galva', color: '#06B6D4' });
  if (lightPaint) options.push({ label: 'Light Paint', color: '#10B981' });
  if (rusty) options.push({ label: 'Rusty', color: '#F59E0B' });
  if (doubleDip) options.push({ label: 'Double Dip', color: '#EC4899' });
  if (multipleDip) options.push({ label: 'Multiple Dip', color: '#EF4444' });

  if (options.length === 0) return null;

  return (
    <View style={styles.container}>
      {options.map((option, index) => (
        <View key={index} style={[styles.badge, { backgroundColor: option.color + '20' }]}>
          <Text style={[styles.badgeText, { color: option.color }]}>{option.label}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flexDirection: 'row', flexWrap: 'wrap', gap: 4 },
  badge: { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
  badgeText: { fontSize: 9, fontWeight: '600' }
});

