import React, { useState, useEffect } from 'react';
import { Modal, View, Text, TextInput, ScrollView, TouchableOpacity, StyleSheet, Alert, SafeAreaView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '@/app/lib/supabase';
import { usePasswordAuth } from '@/contexts/PasswordAuthContext';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ALLOWED_TASK_USERS } from '@/contexts/TaskContext';

interface QCArchiveModalProps {
  visible: boolean;
  onClose: () => void;
}

interface DraftData {
  searchQuery: string;
  selectedQCId?: string;
  newThickness?: string;
  savedAt: number;
}

const DRAFT_KEY = 'qc_archive_draft';

export default function QCArchiveModal({ visible, onClose }: QCArchiveModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [jobs, setJobs] = useState<any[]>([]);
  const [selectedQC, setSelectedQC] = useState<any>(null);
  const [searching, setSearching] = useState(false);
  const [editingThickness, setEditingThickness] = useState(false);
  const [newThickness, setNewThickness] = useState('');
  const [saving, setSaving] = useState(false);
  const { user } = usePasswordAuth();

  // Draft-related state
  const [showDraftIndicator, setShowDraftIndicator] = useState(false);
  const [hasDraft, setHasDraft] = useState(false);

  // Check if user is allowed to use draft feature
  const canUseDrafts = ALLOWED_TASK_USERS.includes(user?.username || '');

  // Load draft when modal opens
  useEffect(() => {
    if (visible && canUseDrafts) {
      loadDraft();
    }
  }, [visible, canUseDrafts]);

  // Auto-save draft when form changes
  useEffect(() => {
    if (visible && canUseDrafts && (searchQuery.trim() || newThickness.trim())) {
      const timeout = setTimeout(() => {
        saveDraft();
      }, 1000); // Debounce 1 second
      return () => clearTimeout(timeout);
    }
  }, [searchQuery, newThickness, selectedQC?.id, visible]);

  const loadDraft = async () => {
    try {
      const draftStr = await AsyncStorage.getItem(DRAFT_KEY);
      if (draftStr) {
        const draft: DraftData = JSON.parse(draftStr);
        // Only load if draft is less than 24 hours old
        if (Date.now() - draft.savedAt < 24 * 60 * 60 * 1000) {
          if (draft.searchQuery) {
            setSearchQuery(draft.searchQuery);
            // Auto-search if there was a query
            setTimeout(() => searchJobsWithQuery(draft.searchQuery), 500);
          }
          if (draft.newThickness) {
            setNewThickness(draft.newThickness);
          }
          setHasDraft(true);
        } else {
          await AsyncStorage.removeItem(DRAFT_KEY);
        }
      }
    } catch (error) {
      console.error('Error loading QC archive draft:', error);
    }
  };

  const saveDraft = async () => {
    try {
      const draft: DraftData = {
        searchQuery,
        selectedQCId: selectedQC?.id,
        newThickness: editingThickness ? newThickness : undefined,
        savedAt: Date.now()
      };
      await AsyncStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
      setShowDraftIndicator(true);
      setHasDraft(true);
      setTimeout(() => setShowDraftIndicator(false), 2000);
    } catch (error) {
      console.error('Error saving QC archive draft:', error);
    }
  };

  const clearDraft = async () => {
    try {
      await AsyncStorage.removeItem(DRAFT_KEY);
      setHasDraft(false);
    } catch (error) {
      console.error('Error clearing QC archive draft:', error);
    }
  };

  const handleClearDraft = () => {
    Alert.alert(
      'Clear Draft',
      'Are you sure you want to clear the saved search?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Clear', 
          style: 'destructive',
          onPress: async () => {
            await clearDraft();
            setSearchQuery('');
            setJobs([]);
            setSelectedQC(null);
            setNewThickness('');
          }
        }
      ]
    );
  };

  const searchJobsWithQuery = async (query: string) => {
    if (!query.trim()) return;
    setSearching(true);
    try {
      const { data, error } = await supabase
        .from('quality_control')
        .select('*')
        .ilike('job_number', `%${query}%`)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setJobs(data || []);
    } catch (err) {
      Alert.alert('Error', 'Failed to search');
    } finally {
      setSearching(false);
    }
  };

  const searchJobs = async () => {
    if (!searchQuery.trim()) {
      Alert.alert('Search Required', 'Please enter a job number');
      return;
    }
    await searchJobsWithQuery(searchQuery);
  };

  const handleClose = () => {
    // Don't clear draft on close - keep it for later
    setJobs([]);
    setSelectedQC(null);
    setEditingThickness(false);
    onClose();
  };

  const startEditThickness = () => {
    setNewThickness(selectedQC.finishing_coating_thickness_microns?.toString() || '');
    setEditingThickness(true);
  };

  const saveThickness = async () => {
    const thickness = parseFloat(newThickness);
    if (isNaN(thickness) || thickness < 0) {
      Alert.alert('Invalid Input', 'Please enter a valid thickness value');
      return;
    }

    setSaving(true);
    try {
      const oldThickness = selectedQC.finishing_coating_thickness_microns;
      
      // Update the quality_control record
      const { error: updateError } = await supabase
        .from('quality_control')
        .update({ finishing_coating_thickness_microns: thickness })
        .eq('id', selectedQC.id);

      if (updateError) throw updateError;

      // Log the edit
      const { error: logError } = await supabase
        .from('qc_thickness_edit_logs')
        .insert({
          qc_record_id: selectedQC.id,
          job_number: selectedQC.job_number,
          item_name: selectedQC.item_name,
          old_thickness: oldThickness,
          new_thickness: thickness,
          edited_by_username: user?.username || 'Unknown'
        });

      if (logError) throw logError;

      // Clear draft on successful save
      await clearDraft();

      // Update local state
      setSelectedQC({ ...selectedQC, finishing_coating_thickness_microns: thickness });
      setEditingThickness(false);
      Alert.alert('Success', 'Thickness updated successfully');
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Failed to save thickness');
    } finally {
      setSaving(false);
    }
  };

  if (selectedQC) {
    return (
      <Modal visible={visible} animationType="slide">
        <SafeAreaView style={s.safeArea}>
          <View style={s.container}>
            <View style={s.header}>
              <TouchableOpacity onPress={() => { setSelectedQC(null); setEditingThickness(false); }} style={s.headerBtn}>
                <Ionicons name="arrow-back" size={24} color="#2196F3" />
              </TouchableOpacity>
              <Text style={s.title}>QC Details</Text>
              <View style={s.headerRight}>
                {canUseDrafts && showDraftIndicator && (
                  <View style={s.draftIndicator}>
                    <Ionicons name="cloud-done" size={14} color="#10B981" />
                    <Text style={s.draftIndicatorText}>Saved</Text>
                  </View>
                )}
                <TouchableOpacity onPress={handleClose} style={s.headerBtn}>
                  <Ionicons name="close" size={28} color="#333" />
                </TouchableOpacity>
              </View>
            </View>
            <ScrollView style={s.scroll} contentContainerStyle={s.scrollContent}>
              <Text style={s.jobInfo}>Job: {selectedQC.job_number} | {selectedQC.item_name}</Text>
              <Text style={s.section}>WORKSHOP</Text>
              <Text style={s.detail}>Surface: {(selectedQC.workshop_surface_condition || []).join(', ') || 'N/A'}</Text>
              <Text style={s.detail}>Drilling: {selectedQC.workshop_drilling_done ? 'Yes' : 'No'}</Text>
              <Text style={s.section}>ACID</Text>
              <Text style={s.detail}>Good Condition: {selectedQC.acid_forward_good_condition ? 'Yes' : 'No'}</Text>
              <Text style={s.section}>ZINC</Text>
              <Text style={s.detail}>Coating: {selectedQC.zinc_coating_condition || 'N/A'}</Text>
              <Text style={s.section}>FINISHING</Text>
              {editingThickness ? (
                <View style={s.editBox}>
                  <Text style={s.label}>Thickness (microns):</Text>
                  <TextInput
                    style={s.thicknessInput}
                    value={newThickness}
                    onChangeText={setNewThickness}
                    keyboardType="numeric"
                    placeholder="Enter thickness"
                  />
                  <View style={s.editBtns}>
                    <TouchableOpacity style={s.cancelBtn} onPress={() => setEditingThickness(false)}>
                      <Text style={s.cancelBtnText}>Cancel</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={s.saveBtn} onPress={saveThickness} disabled={saving}>
                      <Text style={s.saveBtnText}>{saving ? 'Saving...' : 'Save'}</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ) : (
                <View style={s.thicknessRow}>
                  <Text style={s.detail}>Thickness: {selectedQC.finishing_coating_thickness_microns || 'N/A'} microns</Text>
                  <TouchableOpacity style={s.editIconBtn} onPress={startEditThickness}>
                    <Ionicons name="pencil" size={18} color="#2196F3" />
                  </TouchableOpacity>
                </View>
              )}
            </ScrollView>
          </View>
        </SafeAreaView>
      </Modal>
    );
  }

  return (
    <Modal visible={visible} animationType="slide">
      <SafeAreaView style={s.safeArea}>
        <View style={s.container}>
          <View style={s.header}>
            <Text style={s.title}>QC Archive</Text>
            <View style={s.headerRight}>
              {canUseDrafts && showDraftIndicator && (
                <View style={s.draftIndicator}>
                  <Ionicons name="cloud-done" size={14} color="#10B981" />
                  <Text style={s.draftIndicatorText}>Saved</Text>
                </View>
              )}
              <TouchableOpacity onPress={handleClose} style={s.headerBtn}>
                <Ionicons name="close" size={28} color="#333" />
              </TouchableOpacity>
            </View>
          </View>
          
          {canUseDrafts && hasDraft && searchQuery.trim() && (
            <TouchableOpacity style={s.draftBanner} onPress={handleClearDraft}>
              <Ionicons name="document-text-outline" size={16} color="#3B82F6" />
              <Text style={s.draftBannerText}>Search restored from previous session</Text>
              <Ionicons name="close-circle" size={18} color="#6B7280" />
            </TouchableOpacity>
          )}
          
          <View style={s.searchBox}>
            <TextInput style={s.input} placeholder="Search job number..." value={searchQuery} onChangeText={setSearchQuery} onSubmitEditing={searchJobs} />
            <TouchableOpacity style={s.searchBtn} onPress={searchJobs} disabled={searching}>
              <Ionicons name="search" size={20} color="#fff" />
            </TouchableOpacity>
          </View>
          <ScrollView style={s.scroll} contentContainerStyle={s.scrollContent}>
            {jobs.length === 0 && <View style={s.empty}><Ionicons name="search-outline" size={64} color="#ccc" /><Text style={s.emptyText}>Search for QC records</Text></View>}
            {jobs.map((job) => (
              <TouchableOpacity key={job.id} style={s.card} onPress={() => setSelectedQC(job)}>
                <Text style={s.jobNum}>Job: {job.job_number}</Text>
                <Text style={s.item}>{job.item_name}</Text>
                <Text style={s.date}>{new Date(job.created_at).toLocaleString()}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      </SafeAreaView>
    </Modal>
  );
}

const s = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#fff' },
  container: { flex: 1, backgroundColor: '#fff' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderBottomColor: '#ddd' },
  headerBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  title: { fontSize: 22, fontWeight: 'bold', flex: 1, textAlign: 'center' },
  draftIndicator: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#ECFDF5', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  draftIndicatorText: { fontSize: 11, color: '#059669', fontWeight: '500' },
  draftBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#EFF6FF', padding: 12, marginHorizontal: 12, marginTop: 8, borderRadius: 8 },
  draftBannerText: { flex: 1, fontSize: 12, color: '#3B82F6', fontWeight: '500' },
  searchBox: { flexDirection: 'row', padding: 12, gap: 8, backgroundColor: '#f9f9f9' },
  input: { flex: 1, borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, backgroundColor: '#fff' },
  searchBtn: { backgroundColor: '#2196F3', padding: 12, borderRadius: 8, justifyContent: 'center', width: 48 },
  scroll: { flex: 1 },
  scrollContent: { padding: 12, paddingBottom: 24 },
  empty: { alignItems: 'center', paddingTop: 100 },
  emptyText: { fontSize: 16, color: '#999', marginTop: 16 },
  card: { backgroundColor: '#f9f9f9', padding: 16, borderRadius: 8, marginBottom: 12, borderWidth: 1, borderColor: '#e0e0e0' },
  jobNum: { fontSize: 16, fontWeight: 'bold', color: '#333' },
  item: { fontSize: 14, color: '#666', marginTop: 4 },
  date: { fontSize: 12, color: '#999', marginTop: 4 },
  jobInfo: { fontSize: 16, fontWeight: 'bold', padding: 12, backgroundColor: '#f5f5f5', borderRadius: 8, marginBottom: 12 },
  section: { fontSize: 18, fontWeight: 'bold', marginTop: 16, marginBottom: 8, color: '#2196F3' },
  detail: { fontSize: 14, color: '#555', marginBottom: 6, paddingLeft: 8 },
  thicknessRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  editIconBtn: { padding: 8, backgroundColor: '#E3F2FD', borderRadius: 6 },
  editBox: { backgroundColor: '#f9f9f9', padding: 12, borderRadius: 8, marginTop: 8 },
  label: { fontSize: 14, fontWeight: '600', marginBottom: 8, color: '#333' },
  thicknessInput: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, backgroundColor: '#fff', fontSize: 16 },
  editBtns: { flexDirection: 'row', gap: 8, marginTop: 12 },
  cancelBtn: { flex: 1, padding: 12, backgroundColor: '#f5f5f5', borderRadius: 8, alignItems: 'center' },
  cancelBtnText: { fontSize: 16, color: '#666', fontWeight: '600' },
  saveBtn: { flex: 1, padding: 12, backgroundColor: '#4CAF50', borderRadius: 8, alignItems: 'center' },
  saveBtnText: { fontSize: 16, color: '#fff', fontWeight: '600' },
});
