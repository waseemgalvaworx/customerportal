import React, { useState, useEffect, useRef } from 'react';
import { Modal, View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '@/app/lib/supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ItemStatus } from '@/contexts/JobContext';
import { ALLOWED_TASK_USERS } from '@/contexts/TaskContext';
import { usePasswordAuth } from '@/contexts/PasswordAuthContext';

interface Props {
  visible: boolean;
  onClose: () => void;
  onConfirm: (qcData: any) => void;
  targetStatus: ItemStatus;
  jobId: string;
  itemId: string;
  itemName: string;
  jobNumber: string;
}

interface DraftData {
  qcData: any;
  jobId: string;
  itemId: string;
  targetStatus: string;
  savedAt: number;
}

const getDraftKey = (jobId: string, itemId: string, targetStatus: string) => 
  `status_qc_draft_${jobId}_${itemId}_${targetStatus}`;

export default function StatusQCModal({ visible, onClose, onConfirm, targetStatus, jobId, itemId, itemName, jobNumber }: Props) {
  const { user } = usePasswordAuth();
  const [qcData, setQcData] = useState<any>({});
  const [currentUser, setCurrentUser] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  // Draft-related state
  const [showDraftIndicator, setShowDraftIndicator] = useState(false);
  const [hasDraft, setHasDraft] = useState(false);
  const [draftRestoredBanner, setDraftRestoredBanner] = useState(false);
  const initialLoadDone = useRef(false);
  const originalData = useRef<any>(null);

  // Check if user is allowed to use draft feature
  const canUseDrafts = ALLOWED_TASK_USERS.includes(user?.username || '');

  useEffect(() => {
    if (visible) {
      setQcData({}); // Reset QC data when modal opens
      setIsSaving(false); // Reset saving state when modal opens
      initialLoadDone.current = false;
      setDraftRestoredBanner(false);
      loadData();
    }
  }, [visible, jobId, itemId]);

  // Auto-save draft when form changes
  useEffect(() => {
    if (visible && canUseDrafts && initialLoadDone.current && hasFormChanges()) {
      const timeout = setTimeout(() => {
        saveDraft();
      }, 1000); // Debounce 1 second
      return () => clearTimeout(timeout);
    }
  }, [qcData, visible]);

  const hasFormChanges = () => {
    if (!originalData.current) return false;
    return JSON.stringify(qcData) !== JSON.stringify(originalData.current);
  };

  const loadDraft = async () => {
    try {
      const draftStr = await AsyncStorage.getItem(getDraftKey(jobId, itemId, targetStatus));
      if (draftStr) {
        const draft: DraftData = JSON.parse(draftStr);
        // Only load if draft is less than 24 hours old and matches this context
        if (Date.now() - draft.savedAt < 24 * 60 * 60 * 1000 && 
            draft.jobId === jobId && draft.itemId === itemId && draft.targetStatus === targetStatus) {
          return draft.qcData;
        } else {
          await AsyncStorage.removeItem(getDraftKey(jobId, itemId, targetStatus));
        }
      }
    } catch (error) {
      console.error('Error loading Status QC draft:', error);
    }
    return null;
  };

  const saveDraft = async () => {
    try {
      const draft: DraftData = {
        qcData,
        jobId,
        itemId,
        targetStatus,
        savedAt: Date.now()
      };
      await AsyncStorage.setItem(getDraftKey(jobId, itemId, targetStatus), JSON.stringify(draft));
      setShowDraftIndicator(true);
      setHasDraft(true);
      setTimeout(() => setShowDraftIndicator(false), 2000);
    } catch (error) {
      console.error('Error saving Status QC draft:', error);
    }
  };

  const clearDraft = async () => {
    try {
      await AsyncStorage.removeItem(getDraftKey(jobId, itemId, targetStatus));
      setHasDraft(false);
      setDraftRestoredBanner(false);
    } catch (error) {
      console.error('Error clearing Status QC draft:', error);
    }
  };

  const handleClearDraft = () => {
    clearDraft();
    // Reset to original data
    if (originalData.current) {
      setQcData(originalData.current);
    }
  };


  const loadData = async () => {
    setIsLoading(true);
    console.time('QC_MODAL_LOAD');
    
    try {
      // Load user from cache (fast)
      const storedUser = await AsyncStorage.getItem('currentUser');
      setCurrentUser(storedUser || '');
      
      // Load QC data with timeout to prevent blocking
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('QC load timeout')), 3000)
      );
      
      const queryPromise = supabase
        .from('quality_control')
        .select('*')
        .eq('job_id', jobId)
        .eq('item_name', itemName)
        .maybeSingle();
      
      const { data, error } = await Promise.race([queryPromise, timeoutPromise]) as any;
      
      let serverData = {};
      if (error) {
        console.error('QC load error:', error);
      } else if (data) {
        serverData = data;
      }
      
      originalData.current = serverData;

      // Check for draft if user is allowed
      if (canUseDrafts) {
        const draftData = await loadDraft();
        if (draftData && JSON.stringify(draftData) !== JSON.stringify(serverData)) {
          setQcData(draftData);
          setHasDraft(true);
          setDraftRestoredBanner(true);
        } else {
          setQcData(serverData);
        }
      } else {
        setQcData(serverData);
      }
    } catch (err: any) {
      console.error('QC load error:', err.message);
      // Continue without QC data - don't block the user
    } finally {
      console.timeEnd('QC_MODAL_LOAD');
      setIsLoading(false);
      initialLoadDone.current = true;
    }
  };

  const toggleArray = (field: string, value: string) => {
    const arr = qcData[field] || [];
    setQcData({
      ...qcData,
      [field]: arr.includes(value) ? arr.filter((v: string) => v !== value) : [...arr, value]
    });
  };

  const updateField = (field: string, value: any) => {
    setQcData({ ...qcData, [field]: value });
  };

  const handleConfirm = async () => {
    // Prevent double-clicks
    if (isSaving) return;
    
    setIsSaving(true);
    console.time('QC_STATUS_UPDATE');
    
    // Save QC data in background (fire-and-forget) - don't await
    const payload = {
      job_id: jobId,
      job_number: jobNumber,
      item_name: itemName,
      ...qcData,
      updated_by: currentUser,
      updated_at: new Date().toISOString()
    };

    if (qcData.id) {
      supabase.from('quality_control').update(payload).eq('id', qcData.id)
        .then(() => console.log('QC updated'))
        .catch(err => console.error('QC update error:', err));
    } else {
      const insertPayload = { ...payload, created_by: currentUser, created_at: new Date().toISOString() };
      supabase.from('quality_control').insert(insertPayload)
        .then(() => console.log('QC inserted'))
        .catch(err => console.error('QC insert error:', err));
    }
    
    // Clear draft on successful confirm
    await clearDraft();
    
    console.timeEnd('QC_STATUS_UPDATE');
    
    // Call onConfirm AFTER starting the background save
    // The parent will handle closing the modal
    onConfirm(qcData);
    
    // Reset saving state after a short delay (in case modal stays open due to error)
    setTimeout(() => setIsSaving(false), 500);
  };

  const handleClose = () => {
    // Don't clear draft on close - keep it for later
    setDraftRestoredBanner(false);
    onClose();
  };



  const renderWorkshop = () => (
    <>
      <Text style={s.label}>Surface Condition:</Text>
      <View style={s.row}>
        {['Galv', 'Grease', 'Paint', 'Oil', 'Poor', 'Good', 'Excellent'].map(v => (
          <TouchableOpacity key={v} onPress={() => toggleArray('workshop_surface_condition', v)} 
            style={[s.chip, (qcData.workshop_surface_condition || []).includes(v) && s.chipActive]}>
            <Text>{v}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <Text style={s.label}>Drilling Done:</Text>
      <View style={s.row}>
        <TouchableOpacity onPress={() => updateField('workshop_drilling_done', true)} 
          style={[s.chip, qcData.workshop_drilling_done === true && s.chipActive]}><Text>Yes</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => updateField('workshop_drilling_done', false)} 
          style={[s.chip, qcData.workshop_drilling_done === false && s.chipActive]}><Text>No</Text></TouchableOpacity>
      </View>
      <Text style={s.label}>Welding Quality:</Text>
      <View style={s.row}>
        {['Poor', 'Good', 'Excellent'].map(v => (
          <TouchableOpacity key={v} onPress={() => updateField('workshop_welding_quality', v)} 
            style={[s.chip, qcData.workshop_welding_quality === v && s.chipActive]}><Text>{v}</Text></TouchableOpacity>
        ))}
      </View>
      <Text style={s.label}>Racking:</Text>
      <View style={s.row}>
        {['Individual', 'Jig'].map(v => (
          <TouchableOpacity key={v} onPress={() => updateField('workshop_racking', v)} 
            style={[s.chip, qcData.workshop_racking === v && s.chipActive]}><Text>{v}</Text></TouchableOpacity>
        ))}
      </View>
    </>
  );

  const renderAcid = () => (
    <>
      <Text style={s.label}>Forward to Acid in good condition:</Text>
      <View style={s.row}>
        <TouchableOpacity onPress={() => updateField('acid_forward_good_condition', true)} 
          style={[s.chip, qcData.acid_forward_good_condition === true && s.chipActive]}><Text>Yes</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => updateField('acid_forward_good_condition', false)} 
          style={[s.chip, qcData.acid_forward_good_condition === false && s.chipActive]}><Text>No</Text></TouchableOpacity>
      </View>
      <Text style={s.label}>Surface Condition:</Text>
      <View style={s.row}>
        {['Galv', 'Grease', 'Paint', 'Oil'].map(v => (
          <TouchableOpacity key={v} onPress={() => toggleArray('acid_surface_condition', v)} 
            style={[s.chip, (qcData.acid_surface_condition || []).includes(v) && s.chipActive]}><Text>{v}</Text></TouchableOpacity>
        ))}
      </View>
    </>
  );

  const renderReady = () => (
    <>
      <Text style={s.label}>Coating Thickness:</Text>
      <TextInput style={s.input} placeholder="Microns" 
        value={qcData.finishing_coating_thickness_microns || ''} 
        onChangeText={t => updateField('finishing_coating_thickness_microns', t)} keyboardType="numeric" />
    </>
  );

  const renderFinishing = () => (
    <>
      <Text style={s.label}>Surface Condition:</Text>
      <View style={s.row}>
        {['Rough', 'Smooth', 'Black spots', 'Ungalvanise'].map(v => (
          <TouchableOpacity key={v} onPress={() => toggleArray('finishing_surface_condition', v)} 
            style={[s.chip, (qcData.finishing_surface_condition || []).includes(v) && s.chipActive]}><Text>{v}</Text></TouchableOpacity>
        ))}
      </View>
      <Text style={s.label}>Remedial Action Required:</Text>
      <View style={s.row}>
        <TouchableOpacity onPress={() => updateField('finishing_remedial_action', true)} 
          style={[s.chip, qcData.finishing_remedial_action === true && s.chipActive]}><Text>Yes</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => updateField('finishing_remedial_action', false)} 
          style={[s.chip, qcData.finishing_remedial_action === false && s.chipActive]}><Text>No</Text></TouchableOpacity>
      </View>
      {qcData.finishing_remedial_action && (
        <TextInput style={s.input} placeholder="Explain remedial action..." 
          value={qcData.finishing_remedial_explanation || ''} 
          onChangeText={t => updateField('finishing_remedial_explanation', t)} multiline />
      )}
    </>
  );

  const getTitle = () => {
    const titles: Record<string, string> = {
      Workshop: 'Workshop QC Check', Acid: 'Acid Department QC Check',
      Galva: 'No QC Required', Finishing: 'Finishing QC Check', Ready: 'Ready QC Check'
    };
    return titles[targetStatus] || 'Quality Control';
  };

  const renderContent = () => {
    switch (targetStatus) {
      case 'Workshop': return renderWorkshop();
      case 'Acid': return renderAcid();
      case 'Finishing': return renderFinishing();
      case 'Ready': return renderReady();
      default: return null;
    }
  };

  if (targetStatus === 'Pending' || targetStatus === 'Galva') return null;

  return (
    <Modal visible={visible} animationType="slide">
      <View style={s.container}>
        <View style={s.header}>
          <Text style={s.title}>{getTitle()}</Text>
          <View style={s.headerRight}>
            {canUseDrafts && showDraftIndicator && (
              <View style={s.draftIndicator}>
                <Ionicons name="cloud-done" size={14} color="#10B981" />
                <Text style={s.draftIndicatorText}>Saved</Text>
              </View>
            )}
            <TouchableOpacity onPress={handleClose}><Text style={s.close}>X</Text></TouchableOpacity>
          </View>
        </View>
        <Text style={s.sub}>Job: {jobNumber} | Item: {itemName}</Text>
        
        {canUseDrafts && draftRestoredBanner && (
          <TouchableOpacity style={s.draftBanner} onPress={handleClearDraft}>
            <Ionicons name="document-text-outline" size={16} color="#F59E0B" />
            <Text style={s.draftBannerText}>Unsaved changes restored - tap to discard</Text>
            <Ionicons name="close-circle" size={18} color="#6B7280" />
          </TouchableOpacity>
        )}
        
        <ScrollView style={s.scroll}>
          {renderContent()}
          <View style={s.btnRow}>
            <TouchableOpacity style={[s.btn, s.btnSecondary]} onPress={handleClose} disabled={isSaving}>
              <Text style={s.btnTextSecondary}>Skip QC</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[s.btn, isSaving && s.btnDisabled]} 
              onPress={handleConfirm}
              disabled={isSaving}
            >
              <Text style={s.btnText}>{isSaving ? 'Saving...' : 'Save & Update Status'}</Text>
            </TouchableOpacity>
          </View>

        </ScrollView>
      </View>
    </Modal>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, borderBottomWidth: 1, borderBottomColor: '#ddd' },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  title: { fontSize: 24, fontWeight: 'bold' },
  close: { fontSize: 24, fontWeight: 'bold' },
  draftIndicator: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#ECFDF5', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  draftIndicatorText: { fontSize: 11, color: '#059669', fontWeight: '500' },
  draftBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#FEF3C7', padding: 12, marginHorizontal: 12, marginTop: 8, borderRadius: 8, borderWidth: 1, borderColor: '#FCD34D' },
  draftBannerText: { flex: 1, fontSize: 12, color: '#92400E', fontWeight: '500' },
  sub: { padding: 10, backgroundColor: '#f5f5f5', fontWeight: '600' },
  scroll: { flex: 1, padding: 20 },
  label: { fontSize: 16, fontWeight: '600', marginTop: 10, marginBottom: 5 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 10 },
  chip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, borderWidth: 1, borderColor: '#ddd', backgroundColor: '#f5f5f5' },
  chipActive: { backgroundColor: '#4CAF50', borderColor: '#4CAF50' },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 10, marginBottom: 10, backgroundColor: '#fff' },
  btnRow: { flexDirection: 'row', gap: 10, marginTop: 20, marginBottom: 40 },
  btn: { flex: 1, backgroundColor: '#2196F3', padding: 15, borderRadius: 8, alignItems: 'center' },
  btnSecondary: { backgroundColor: '#6B7280' },
  btnDisabled: { backgroundColor: '#9CA3AF' },
  btnText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  btnTextSecondary: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});

