import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Animated } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTasks } from '../contexts/TaskContext';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import ActiveTasksModal from './ActiveTasksModal';

export const ActiveTasksButton: React.FC = () => {
  const { activeTasks, isUserAllowed } = useTasks();
  const { user } = usePasswordAuth();
  const [modalVisible, setModalVisible] = useState(false);
  const pulseAnimation = useRef(new Animated.Value(1)).current;
  const prevCountRef = useRef(activeTasks.length);

  // Check if current user is allowed to access Active Tasks
  const hasAccess = isUserAllowed(user?.username);

  // Count tasks with unsaved changes
  const unsavedCount = activeTasks.filter(t => t.hasUnsavedChanges).length;

  // Animate when new task is added
  useEffect(() => {
    if (activeTasks.length > prevCountRef.current && hasAccess) {
      Animated.sequence([
        Animated.timing(pulseAnimation, { toValue: 1.3, duration: 150, useNativeDriver: true }),
        Animated.timing(pulseAnimation, { toValue: 1, duration: 150, useNativeDriver: true }),
      ]).start();
    }
    prevCountRef.current = activeTasks.length;
  }, [activeTasks.length, hasAccess]);

  // Don't show if user doesn't have access or no active tasks
  if (!hasAccess || activeTasks.length === 0) {
    return null;
  }

  return (
    <>
      <TouchableOpacity 
        style={styles.container} 
        onPress={() => setModalVisible(true)}
        activeOpacity={0.7}
      >
        <Animated.View style={{ transform: [{ scale: pulseAnimation }] }}>
          <Ionicons 
            name="layers" 
            size={22} 
            color={unsavedCount > 0 ? "#F59E0B" : "#3B82F6"} 
          />
          <View style={[
            styles.badge,
            unsavedCount > 0 && styles.badgeUnsaved
          ]}>
            <Text style={styles.badgeText}>
              {activeTasks.length}
            </Text>
          </View>
        </Animated.View>
      </TouchableOpacity>

      <ActiveTasksModal 
        visible={modalVisible} 
        onClose={() => setModalVisible(false)} 
      />
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    marginRight: 12,
    padding: 5,
  },
  badge: {
    position: 'absolute',
    top: -6,
    right: -8,
    backgroundColor: '#3B82F6',
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
    borderWidth: 2,
    borderColor: 'white',
  },
  badgeUnsaved: {
    backgroundColor: '#F59E0B',
  },
  badgeText: {
    color: 'white',
    fontSize: 10,
    fontWeight: 'bold',
  },
});

export default ActiveTasksButton;
