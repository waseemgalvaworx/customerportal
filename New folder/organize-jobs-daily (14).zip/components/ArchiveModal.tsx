import React, { useState, useMemo, useEffect } from 'react';
import { Modal, View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Job } from '../contexts/JobContext';
import { handleViewPDF, handleEmailReport } from './ArchiveModalHandlers';
import { ArchiveModalMainContent } from './ArchiveModalMain';

interface ArchiveModalProps {
  visible: boolean;
  onClose: () => void;
  archivedJobs: Job[];
}

type ReportType = 'completed' | 'finishing' | null;

const formatDateForReport = (date: Date) => {
  const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
  const months = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'];
  return `${days[date.getDay()]} ${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`;
};

export const ArchiveModal: React.FC<ArchiveModalProps> = ({ visible, onClose, archivedJobs }) => {
  const [selectedReportType, setSelectedReportType] = useState<ReportType>(null);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [emailingReport, setEmailingReport] = useState(false);

  const jobsByDate = useMemo(() => {
    const grouped: { [key: string]: Job[] } = {};
    archivedJobs.forEach(job => {
      if (job.archivedDate) {
        const date = new Date(job.archivedDate).toLocaleDateString('en-GB');
        if (!grouped[date]) grouped[date] = [];
        grouped[date].push(job);
      }
    });
    return grouped;
  }, [archivedJobs]);

  const dates = Object.keys(jobsByDate).sort((a, b) => {
    const [dayA, monthA, yearA] = a.split('/');
    const [dayB, monthB, yearB] = b.split('/');
    return new Date(`${yearB}-${monthB}-${dayB}`).getTime() - new Date(`${yearA}-${monthA}-${dayA}`).getTime();
  });

  const selectedJobs = selectedDate ? jobsByDate[selectedDate] || [] : [];
  
  const reportDate = selectedDate 
    ? (() => {
        const [day, month, year] = selectedDate.split('/');
        return formatDateForReport(new Date(parseInt(year), parseInt(month) - 1, parseInt(day)));
      })()
    : formatDateForReport(new Date());

  useEffect(() => {
    if (visible) {
      setSelectedReportType(null);
      setSelectedDate(null);
      setDropdownOpen(false);
      setEmailingReport(false);
    }
  }, [visible]);

  const handleSelectReportType = (type: ReportType) => {
    setSelectedReportType(type);
    if (dates.length > 0 && !selectedDate) {
      setSelectedDate(dates[0]);
    }
  };

  const handleBack = () => {
    setSelectedReportType(null);
    setSelectedDate(null);
    setDropdownOpen(false);
  };

  const handleClose = () => {
    setSelectedReportType(null);
    setSelectedDate(null);
    setDropdownOpen(false);
    setEmailingReport(false);
    onClose();
  };

  const onViewPDFHandler = (includeTime: boolean) => {
    handleViewPDF(selectedReportType, selectedJobs, selectedDate, includeTime);
  };

  const onEmailReportHandler = (recipients: string[], includeTime: boolean) => {
    handleEmailReport(selectedReportType, selectedJobs, selectedDate, recipients, setEmailingReport, includeTime);
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <View style={styles.header}>
            {selectedReportType && (
              <TouchableOpacity onPress={handleBack} style={styles.backButton}>
                <Ionicons name="arrow-back" size={24} color="#007AFF" />
              </TouchableOpacity>
            )}
            <Text style={styles.title}>
              {selectedReportType === 'finishing' ? 'Finishing Report' : 
               selectedReportType === 'completed' ? 'Completed Jobs Report' : 
               'Archive'}
            </Text>
            <TouchableOpacity onPress={handleClose}>
              <Ionicons name="close" size={28} color="#333" />
            </TouchableOpacity>
          </View>
          <ArchiveModalMainContent
            selectedReportType={selectedReportType}
            dates={dates}
            dataByDate={jobsByDate}
            selectedDate={selectedDate}
            setSelectedDate={setSelectedDate}
            dropdownOpen={dropdownOpen}
            setDropdownOpen={setDropdownOpen}
            handleSelectReportType={handleSelectReportType}
            selectedData={selectedJobs}
            reportDate={reportDate}
            onViewPDF={onViewPDFHandler}
            onEmailReport={onEmailReportHandler}
            emailingReport={emailingReport}
            onBack={handleBack}
          />
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modal: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, height: '90%' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, borderBottomWidth: 1, borderBottomColor: '#eee' },
  backButton: { marginRight: 12 },
  title: { fontSize: 24, fontWeight: 'bold', flex: 1 },
});
