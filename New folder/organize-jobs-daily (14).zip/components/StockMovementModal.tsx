import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TouchableOpacity, TextInput, ScrollView, StyleSheet, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '@/app/lib/supabase';
import { isDieselItem, dieselHeightToVolume } from '../utils/dieselConversion';
import { usePasswordAuth } from '@/contexts/PasswordAuthContext';
import { logInventoryAction } from '@/utils/inventoryLogger';
import { notifyAllUsers } from '@/utils/notificationHelper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ALLOWED_TASK_USERS } from '../contexts/TaskContext';

interface StockMovementModalProps {
  visible: boolean;
  onClose: () => void;
  item: any;
  onSuccess: () => void;
  prefilledData?: {
    movementType?: 'in' | 'out';
    quantity?: string;
    notes?: string;
  };
}

const DRAFT_KEY_PREFIX = 'stock_movement_draft_';

interface DraftData {
  movementType: 'in' | 'out';
  quantity: string;
  reason: string;
  notes: string;
  savedAt: number;
}

export default function StockMovementModal({ visible, onClose, item, onSuccess, prefilledData }: StockMovementModalProps) {
  const { user } = usePasswordAuth();
  const [movementType, setMovementType] = useState<'in' | 'out'>('in');
  const [quantity, setQuantity] = useState('');
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [showDraftIndicator, setShowDraftIndicator] = useState(false);
  const [hasDraft, setHasDraft] = useState(false);
  
  const isDiesel = item && isDieselItem(item.item_name);
  const draftKey = item ? `${DRAFT_KEY_PREFIX}${item.id}` : '';
  
  // Check if user is allowed to use draft feature
  const canUseDrafts = ALLOWED_TASK_USERS.includes(user?.username || '');

  // Handle prefilled data
  useEffect(() => {
    if (prefilledData) {
      if (prefilledData.movementType) setMovementType(prefilledData.movementType);
      if (prefilledData.quantity) setQuantity(prefilledData.quantity);
      if (prefilledData.notes) setNotes(prefilledData.notes);
    }
  }, [prefilledData]);

  // Load draft on mount
  useEffect(() => {
    if (visible && canUseDrafts && item && !prefilledData) {
      loadDraft();
    }
  }, [visible, canUseDrafts, item]);

  // Auto-save draft when form changes
  useEffect(() => {
    if (visible && canUseDrafts && item && hasFormData()) {
      const timeout = setTimeout(() => {
        saveDraft();
      }, 1000); // Debounce 1 second
      return () => clearTimeout(timeout);
    }
  }, [movementType, quantity, reason, notes, visible]);

  const hasFormData = () => {
    return quantity.trim() || reason.trim() || notes.trim();
  };

  const loadDraft = async () => {
    try {
      const draftStr = await AsyncStorage.getItem(draftKey);
      if (draftStr) {
        const draft: DraftData = JSON.parse(draftStr);
        // Only load if draft is less than 24 hours old
        if (Date.now() - draft.savedAt < 24 * 60 * 60 * 1000) {
          setMovementType(draft.movementType || 'in');
          setQuantity(draft.quantity || '');
          setReason(draft.reason || '');
          setNotes(draft.notes || '');
          setHasDraft(true);
        } else {
          // Clear old draft
          await AsyncStorage.removeItem(draftKey);
        }
      }
    } catch (error) {
      console.error('Error loading draft:', error);
    }
  };

  const saveDraft = async () => {
    try {
      const draft: DraftData = {
        movementType,
        quantity,
        reason,
        notes,
        savedAt: Date.now()
      };
      await AsyncStorage.setItem(draftKey, JSON.stringify(draft));
      setShowDraftIndicator(true);
      setHasDraft(true);
      setTimeout(() => setShowDraftIndicator(false), 2000);
    } catch (error) {
      console.error('Error saving draft:', error);
    }
  };

  const clearDraft = async () => {
    try {
      await AsyncStorage.removeItem(draftKey);
      setHasDraft(false);
    } catch (error) {
      console.error('Error clearing draft:', error);
    }
  };

  const handleSave = async () => {
    console.log('🔴 [STOCK MOVEMENT] handleSave CALLED');
    if (!quantity || parseFloat(quantity) <= 0) {
      Alert.alert('Invalid', 'Enter valid height/quantity');
      return;
    }

    setSaving(true);
    
    const qty = parseFloat(quantity);

    // CRITICAL FIX: Fetch fresh current quantity from database to avoid stale data
    const { data: freshItem, error: fetchError } = await supabase
      .from('inventory_items')
      .select('quantity')
      .eq('id', item.id)
      .single();

    if (fetchError) {
      console.error('Failed to fetch fresh item data:', fetchError);
      setSaving(false);
      Alert.alert('Error', 'Failed to fetch current stock level');
      return;
    }

    const currentStock = freshItem?.quantity || 0;
    console.log('📊 Current stock from DB:', currentStock, 'Movement:', movementType, qty);
    
    const newQty = isDiesel ? qty : (movementType === 'in' ? currentStock + qty : currentStock - qty);

    
    if (newQty < 0) {
      setSaving(false);
      Alert.alert('Error', 'Insufficient stock');
      return;
    }

    if (isDiesel && (newQty < 1 || newQty > 80)) {
      setSaving(false);
      Alert.alert('Error', 'Height must be between 1 and 80 cm');
      return;
    }

    console.log('📤 [STOCK MOVEMENT] Processing:', { isDiesel, quantity: qty, currentStock, newQty });
    
    try {
      const { error: updateError } = await supabase
        .from('inventory_items')
        .update({ quantity: newQty })
        .eq('id', item.id);
      
      if (updateError) throw updateError;

      const { error: transError } = await supabase
        .from('inventory_transactions')
        .insert({
          item_id: item.id,
          transaction_type: isDiesel ? 'adjustment' : movementType,
          quantity: qty,
          reason: reason || null,
          notes: notes || null
        });
      
      if (transError) throw transError;

      // Log the action
      const categoryDisplay = item.category === 'raw_materials' ? 'Raw Materials'
                            : item.category === 'finished_goods' ? 'Direct Sale'
                            : 'By Products';
      
      await logInventoryAction({
        action: movementType === 'in' ? 'stock_in' : 'stock_out',
        item_id: item.id,
        item_name: item.item_name,
        category: categoryDisplay,
        quantity_change: movementType === 'in' ? qty : -qty,
        old_quantity: currentStock,
        new_quantity: newQty,
        notes: reason || notes || `Stock ${movementType}`,
        performed_by: user?.username || 'Unknown'
      });


      // Send notification to all users about stock movement
      const movementText = movementType === 'in' ? 'added to' : 'removed from';
      await notifyAllUsers({
        title: `Stock ${movementType === 'in' ? 'In' : 'Out'}: ${item.item_name}`,
        message: `${qty} ${item.unit} ${movementText} ${item.item_name} by ${user?.username || 'Unknown'}. New stock: ${newQty} ${item.unit}`,
        type: 'inventory',
        priority: 'normal'
      });

      // Check for low stock alert (only for stock out)
      if (movementType === 'out' && item.reorder_level && newQty <= item.reorder_level) {
        await notifyAllUsers({
          title: 'Low Stock Alert',
          message: `${item.item_name} is running low! Current: ${newQty} ${item.unit}, Reorder level: ${item.reorder_level} ${item.unit}`,
          type: 'inventory',
          priority: 'high'
        });
      }

      // Clear draft on successful save
      await clearDraft();

      setSaving(false);
      console.log('✅ [STOCK MOVEMENT] Success');
      Alert.alert('Success', isDiesel ? 'Diesel level updated' : 'Stock updated');
      setQuantity(''); setReason(''); setNotes('');
      onSuccess();
      onClose();

    } catch (err: any) {
      console.error('💥 [STOCK MOVEMENT] Exception:', err);
      setSaving(false);
      Alert.alert('Error', err.message || 'Failed to update');
    }
  };

  const handleClearDraft = () => {
    Alert.alert(
      'Clear Draft',
      'Are you sure you want to clear the saved draft?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Clear', 
          style: 'destructive',
          onPress: async () => {
            await clearDraft();
            setQuantity('');
            setReason('');
            setNotes('');
            setMovementType('in');
          }
        }
      ]
    );
  };

  if (!visible || !item) return null;

  const currentStock = item.current_stock || item.quantity || 0;

  return (
    <Modal visible={true} animationType="slide" onRequestClose={onClose}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>
            {isDiesel ? 'Update Diesel Level' : `Stock Movement - ${item.item_name}`}
          </Text>
          <View style={styles.headerRight}>
            {canUseDrafts && showDraftIndicator && (
              <View style={styles.draftIndicator}>
                <Ionicons name="cloud-done" size={14} color="#10B981" />
                <Text style={styles.draftIndicatorText}>Saved</Text>
              </View>
            )}
            <TouchableOpacity onPress={onClose}>
              <Text style={styles.closeText}>✕</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        <ScrollView contentContainerStyle={styles.form} keyboardShouldPersistTaps="handled">
          {canUseDrafts && hasDraft && (
            <TouchableOpacity style={styles.draftBanner} onPress={handleClearDraft}>
              <Ionicons name="document-text-outline" size={16} color="#3B82F6" />
              <Text style={styles.draftBannerText}>Draft restored</Text>
              <Ionicons name="close-circle" size={18} color="#6B7280" />
            </TouchableOpacity>
          )}
          
          {isDiesel ? (
            <>
              <Text style={styles.info}>Current Height: {currentStock} cm</Text>
              <Text style={styles.info}>Current Volume: {dieselHeightToVolume(currentStock).toLocaleString()} L</Text>
              <Text style={styles.label}>New Height (cm) *</Text>
              <TextInput 
                style={styles.input} 
                value={quantity} 
                onChangeText={(val) => {
                  setQuantity(val);
                  const height = parseFloat(val);
                  if (height > 0 && height <= 80) {
                    setNotes(`Volume: ${dieselHeightToVolume(height).toLocaleString()} L`);
                  }
                }}
                keyboardType="decimal-pad" 
                placeholder="Enter tank height (1-80 cm)"
              />
              {quantity && parseFloat(quantity) > 0 && (
                <Text style={styles.volumePreview}>
                  Volume: {dieselHeightToVolume(parseFloat(quantity)).toLocaleString()} L
                </Text>
              )}
            </>
          ) : (
            <>
              <Text style={styles.info}>Current: {currentStock} {item.unit}</Text>
            </>
          )}


          {!isDiesel && (
            <>
              <View style={styles.toggleContainer}>
                <TouchableOpacity 
                  onPress={() => setMovementType('in')}
                  style={[styles.toggleButton, movementType === 'in' && styles.toggleActive]}
                >
                  <Text style={[styles.toggleText, movementType === 'in' && styles.toggleTextActive]}>Stock In</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  onPress={() => setMovementType('out')}
                  style={[styles.toggleButton, movementType === 'out' && styles.toggleActive]}
                >
                  <Text style={[styles.toggleText, movementType === 'out' && styles.toggleTextActive]}>Stock Out</Text>
                </TouchableOpacity>
              </View>
              
              <Text style={styles.label}>Quantity *</Text>
              <TextInput style={styles.input} value={quantity} onChangeText={setQuantity} keyboardType="decimal-pad" />
            </>
          )}
          
          <Text style={styles.label}>Reason</Text>
          <TextInput style={styles.input} value={reason} onChangeText={setReason} />
          
          <Text style={styles.label}>Notes</Text>
          <TextInput style={[styles.input, styles.textArea]} value={notes} onChangeText={setNotes} multiline numberOfLines={3} />

          <View style={{ height: 100 }} />
        </ScrollView>
        
        <View style={styles.footer} pointerEvents="box-none">
          <TouchableOpacity 
            onPress={handleSave}
            style={[styles.saveButton, saving && styles.disabled]} 
            disabled={saving}
          >
            <Text style={styles.saveButtonText}>{saving ? 'Saving...' : 'Save Movement'}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#ddd' },
  title: { fontSize: 18, fontWeight: 'bold', flex: 1 },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  closeText: { fontSize: 24, color: '#666', padding: 8 },
  draftIndicator: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#ECFDF5', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  draftIndicatorText: { fontSize: 11, color: '#059669', fontWeight: '500' },
  draftBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#EFF6FF', padding: 10, borderRadius: 8, marginBottom: 15 },
  draftBannerText: { flex: 1, fontSize: 12, color: '#3B82F6', fontWeight: '500' },
  form: { padding: 16, paddingBottom: 120 },
  info: { fontSize: 16, fontWeight: '600', marginBottom: 8, color: '#007AFF' },
  volumePreview: { fontSize: 18, fontWeight: 'bold', color: '#10b981', marginTop: 8, backgroundColor: '#f0fdf4', padding: 12, borderRadius: 8 },
  toggleContainer: { flexDirection: 'row', marginBottom: 16 },
  toggleButton: { flex: 1, padding: 12, backgroundColor: '#e0e0e0', alignItems: 'center', marginHorizontal: 4, borderRadius: 8 },
  toggleActive: { backgroundColor: '#007AFF' },
  toggleText: { color: '#666', fontWeight: '600' },
  toggleTextActive: { color: '#fff' },
  label: { fontSize: 14, fontWeight: '600', marginBottom: 8, marginTop: 12, color: '#333' },
  input: { backgroundColor: '#fff', padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#ddd', fontSize: 16 },
  textArea: { height: 80, textAlignVertical: 'top' },
  footer: { 
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#fff', 
    padding: 16, 
    borderTopWidth: 1, 
    borderTopColor: '#ddd',
    zIndex: 1000
  },
  saveButton: { 
    backgroundColor: '#007AFF', 
    padding: 16, 
    borderRadius: 8,
    alignItems: 'center'
  },
  disabled: { backgroundColor: '#999' },
  saveButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 }
});
