import React from 'react';
import { TouchableOpacity, Text, StyleSheet, Alert, Platform, ActionSheetIOS } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Job } from '../contexts/JobContext';
import { shareBatchPDF, emailBatchPDF } from '../utils/batchPdfExport';

interface BatchExportButtonProps {
  jobs: Job[];
  label?: string;
}

export default function BatchExportButton({ jobs, label = 'Export All as PDF' }: BatchExportButtonProps) {
  const handleBatchExport = async () => {
    console.log('BatchExportButton: handleBatchExport called, jobs.length:', jobs.length);
    
    if (jobs.length === 0) {
      Alert.alert('No Jobs', 'There are no jobs to export');
      return;
    }

    if (Platform.OS === 'ios') {
      ActionSheetIOS.showActionSheetWithOptions(
        {
          options: ['Cancel', 'Share PDF', 'Email PDF'],
          cancelButtonIndex: 0,
        },
        async (buttonIndex) => {
          console.log('BatchExportButton: iOS ActionSheet button index:', buttonIndex);
          try {
            if (buttonIndex === 1) {
              console.log('BatchExportButton: Attempting to share PDF...');
              await shareBatchPDF(jobs);
              console.log('BatchExportButton: PDF shared successfully');
              Alert.alert('Success', `Exported ${jobs.length} jobs to PDF`);
            } else if (buttonIndex === 2) {
              console.log('BatchExportButton: Attempting to email PDF...');
              await emailBatchPDF(jobs);
              console.log('BatchExportButton: PDF emailed successfully');
            }
          } catch (error) {
            console.error('BatchExportButton: Error exporting PDF:', error);
            Alert.alert('Error', `Failed to export PDF: ${error.message || 'Unknown error'}`);
          }
        }
      );
    } else {
      Alert.alert(
        'Export PDF',
        `Export ${jobs.length} jobs as PDF?`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Share PDF',
            onPress: async () => {
              try {
                console.log('BatchExportButton: Attempting to share PDF (Android)...');
                await shareBatchPDF(jobs);
                console.log('BatchExportButton: PDF shared successfully');
                Alert.alert('Success', `Exported ${jobs.length} jobs to PDF`);
              } catch (error) {
                console.error('BatchExportButton: Error sharing PDF:', error);
                Alert.alert('Error', `Failed to export PDF: ${error.message || 'Unknown error'}`);
              }
            }
          },
          {
            text: 'Email PDF',
            onPress: async () => {
              try {
                console.log('BatchExportButton: Attempting to email PDF (Android)...');
                await emailBatchPDF(jobs);
                console.log('BatchExportButton: PDF emailed successfully');
              } catch (error) {
                console.error('BatchExportButton: Error emailing PDF:', error);
                Alert.alert('Error', `Failed to send email: ${error.message || 'Unknown error'}`);
              }
            }
          }
        ]
      );
    }
  };


  return (
    <TouchableOpacity style={styles.button} onPress={handleBatchExport}>
      <Ionicons name="documents" size={18} color="white" />
      <Text style={styles.buttonText}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#8B5CF6',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
    gap: 6,
  },
  buttonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
});
