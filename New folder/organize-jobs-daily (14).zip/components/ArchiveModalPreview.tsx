import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Job } from '../contexts/JobContext';
import { supabase } from '@/app/lib/supabase';

export const CompletedJobsPreview: React.FC<{ jobs: Job[]; reportDate: string }> = ({ jobs, reportDate }) => {
  const [deliveredStatus, setDeliveredStatus] = useState<{ [jobId: string]: boolean }>({});
  const [deliveryDates, setDeliveryDates] = useState<{ [jobId: string]: string }>({});
  const [sortBy, setSortBy] = useState<'jobNumber' | 'deliveryDate'>('jobNumber');
  const [filterDelivered, setFilterDelivered] = useState<'all' | 'delivered' | 'pending'>('all');

  useEffect(() => {
    loadDeliveredStatus();
  }, [jobs]);

  const loadDeliveredStatus = async () => {
    const jobIds = jobs.map(j => j.id);
    if (jobIds.length === 0) return;

    const { data, error } = await supabase
      .from('completed_jobs')
      .select('job_id, delivered, delivery_date')
      .in('job_id', jobIds);

    if (!error && data) {
      const statusMap: { [jobId: string]: boolean } = {};
      const datesMap: { [jobId: string]: string } = {};
      data.forEach(item => {
        statusMap[item.job_id] = item.delivered || false;
        datesMap[item.job_id] = item.delivery_date || '';
      });
      setDeliveredStatus(statusMap);
      setDeliveryDates(datesMap);
    }
  };

  const toggleDelivered = async (jobId: string) => {
    const newStatus = !deliveredStatus[jobId];
    const newDeliveryDate = newStatus ? new Date().toISOString() : null;
    
    setDeliveredStatus(prev => ({ ...prev, [jobId]: newStatus }));
    setDeliveryDates(prev => ({ ...prev, [jobId]: newDeliveryDate || '' }));

    const { error } = await supabase
      .from('completed_jobs')
      .update({ 
        delivered: newStatus,
        delivery_date: newDeliveryDate
      })
      .eq('job_id', jobId);

    if (error) {
      console.error('Error updating delivered status:', error);
      setDeliveredStatus(prev => ({ ...prev, [jobId]: !newStatus }));
      setDeliveryDates(prev => ({ ...prev, [jobId]: newStatus ? '' : (newDeliveryDate || '') }));
    }
  };

  // Filter and sort jobs
  const getFilteredAndSortedJobs = () => {
    let filtered = [...jobs];
    
    // Apply filter
    if (filterDelivered === 'delivered') {
      filtered = filtered.filter(job => deliveredStatus[job.id]);
    } else if (filterDelivered === 'pending') {
      filtered = filtered.filter(job => !deliveredStatus[job.id]);
    }
    
    // Apply sort
    if (sortBy === 'deliveryDate') {
      filtered.sort((a, b) => {
        const dateA = deliveryDates[a.id] || '';
        const dateB = deliveryDates[b.id] || '';
        if (!dateA && !dateB) return 0;
        if (!dateA) return 1;
        if (!dateB) return -1;
        return new Date(dateB).getTime() - new Date(dateA).getTime();
      });
    } else {
      filtered.sort((a, b) => a.jobNumber.localeCompare(b.jobNumber));
    }
    
    return filtered;
  };

  const displayJobs = getFilteredAndSortedJobs();
  const totalWeight = displayJobs.reduce((total, job) => {
    const jobWeight = job.items.reduce((sum, item) => sum + parseFloat(item.weightKg || '0'), 0);
    return total + jobWeight;
  }, 0);

  return (
    <ScrollView style={styles.previewScroll}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Production Sheet</Text>
        <Text style={styles.headerDate}>{reportDate}</Text>
      </View>
      
      {/* Filter and Sort Controls */}
      <View style={styles.controlsRow}>
        <View style={styles.controlGroup}>
          <Text style={styles.controlLabel}>Filter:</Text>
          <TouchableOpacity 
            style={[styles.filterBtn, filterDelivered === 'all' && styles.filterBtnActive]}
            onPress={() => setFilterDelivered('all')}
          >
            <Text style={[styles.filterBtnText, filterDelivered === 'all' && styles.filterBtnTextActive]}>All</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.filterBtn, filterDelivered === 'delivered' && styles.filterBtnActive]}
            onPress={() => setFilterDelivered('delivered')}
          >
            <Text style={[styles.filterBtnText, filterDelivered === 'delivered' && styles.filterBtnTextActive]}>Delivered</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.filterBtn, filterDelivered === 'pending' && styles.filterBtnActive]}
            onPress={() => setFilterDelivered('pending')}
          >
            <Text style={[styles.filterBtnText, filterDelivered === 'pending' && styles.filterBtnTextActive]}>Pending</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.controlGroup}>
          <Text style={styles.controlLabel}>Sort:</Text>
          <TouchableOpacity 
            style={[styles.filterBtn, sortBy === 'jobNumber' && styles.filterBtnActive]}
            onPress={() => setSortBy('jobNumber')}
          >
            <Text style={[styles.filterBtnText, sortBy === 'jobNumber' && styles.filterBtnTextActive]}>Job #</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.filterBtn, sortBy === 'deliveryDate' && styles.filterBtnActive]}
            onPress={() => setSortBy('deliveryDate')}
          >
            <Text style={[styles.filterBtnText, sortBy === 'deliveryDate' && styles.filterBtnTextActive]}>Delivery Date</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.table}>
        <View style={styles.tableHeader}>
          <Text style={[styles.headerCell, styles.deliveredCol]}>✓</Text>
          <Text style={[styles.headerCell, styles.jobNoCol]}>JOB</Text>
          <Text style={[styles.headerCell, styles.dateCol]}>ENTRY</Text>
          <Text style={[styles.headerCell, styles.deliveryDateCol]}>DELIVERED</Text>
          <Text style={[styles.headerCell, styles.customerCol]}>CUSTOMER</Text>
          <Text style={[styles.headerCell, styles.detailsCol]}>DETAILS</Text>
          <Text style={[styles.headerCell, styles.weightCol]}>WEIGHT</Text>
        </View>

        {displayJobs.map((job) => (
          <View key={job.id} style={styles.tableRow}>
            <TouchableOpacity 
              style={[styles.cell, styles.deliveredCol, styles.checkboxCell]}
              onPress={() => toggleDelivered(job.id)}
            >
              <Ionicons 
                name={deliveredStatus[job.id] ? "checkmark-circle" : "ellipse-outline"} 
                size={20} 
                color={deliveredStatus[job.id] ? "#4CAF50" : "#999"} 
              />
            </TouchableOpacity>
            <Text style={[styles.cell, styles.jobNoCol, styles.centerAlign]}>{job.jobNumber}</Text>
            <Text style={[styles.cell, styles.dateCol, styles.centerAlign]}>
              {new Date(job.dateOfEntry).toLocaleDateString('en-GB')}
            </Text>
            <Text style={[styles.cell, styles.deliveryDateCol, styles.centerAlign, deliveredStatus[job.id] && styles.deliveredText]}>
              {deliveryDates[job.id] ? new Date(deliveryDates[job.id]).toLocaleDateString('en-GB') : '-'}
            </Text>
            <Text style={[styles.cell, styles.customerCol]}>{job.customerName}</Text>
            <View style={[styles.cell, styles.detailsCol]}>
              {job.items.map((item, i) => {
                const opts = [];
                if (item.paintVarnish) opts.push('Paint/Varnish');
                if (item.galva) opts.push('Galva');
                if (item.lightGalva) opts.push('Light Galva');
                if (item.lightPaint) opts.push('Light Paint');
                if (item.rusty) opts.push('Rusty');
                return (
                  <Text key={i} style={styles.itemText}>
                    • {item.descriptionOfWorks}{opts.length > 0 ? ` - ${opts.join(', ')}` : ''}
                  </Text>
                );
              })}
            </View>
            <View style={[styles.cell, styles.weightCol]}>
              {job.items.map((item, i) => (
                <Text key={i} style={[styles.itemText, styles.rightAlign]}>
                  {parseFloat(item.weightKg || '0') > 0 ? parseFloat(item.weightKg).toFixed(2) : ''}
                </Text>
              ))}
            </View>
          </View>
        ))}

        
        <View style={[styles.tableRow, styles.totalRow]}>
          <View style={[styles.cell, styles.totalLabelCell]}>
            <Text style={styles.totalLabel}>TOTAL:</Text>
          </View>
          <Text style={[styles.cell, styles.weightCol, styles.rightAlign, styles.totalText]}>
            {totalWeight.toFixed(2)}
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

export const FinishingPreview: React.FC<{ finishingReport: any; reportDate: string }> = ({ finishingReport, reportDate }) => {
  if (!finishingReport || !finishingReport.records) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No finishing records available</Text>
      </View>
    );
  }

  const records = finishingReport.records;
  const totalWeight = finishingReport.total_weight || records.reduce((sum: number, rec: any) => sum + parseFloat(rec.weight_kg || '0'), 0);

  const groupedByJob = records.reduce((acc: any, rec: any) => {
    if (!acc[rec.job_number]) {
      acc[rec.job_number] = { customer_name: rec.customer_name, items: [] };
    }
    acc[rec.job_number].items.push(rec);
    return acc;
  }, {});

  return (
    <ScrollView style={styles.previewScroll}>
      <View style={[styles.header, styles.finishingHeader]}>
        <Text style={[styles.headerTitle, styles.finishingTitle]}>FINISHING - Work Shift Report</Text>
        <Text style={styles.headerDate}>{reportDate}</Text>
      </View>
      
      <View style={styles.table}>
        <View style={[styles.tableHeader, styles.finishingTableHeader]}>
          <Text style={[styles.headerCell, styles.finishingHeaderCell, styles.jobCol]}>JOB NO</Text>
          <Text style={[styles.headerCell, styles.finishingHeaderCell, styles.customerCol]}>CUSTOMER</Text>
          <Text style={[styles.headerCell, styles.finishingHeaderCell, styles.descCol]}>ITEM DESCRIPTION</Text>
          <Text style={[styles.headerCell, styles.finishingHeaderCell, styles.weightCol]}>WEIGHT (KG)</Text>
        </View>

        {Object.entries(groupedByJob).map(([jobNum, data]: [string, any]) => (
          data.items.map((rec: any, idx: number) => (
            <View key={rec.id} style={styles.tableRow}>
              <Text style={[styles.cell, styles.jobCol, styles.centerAlign]}>
                {idx === 0 ? jobNum : ''}
              </Text>
              <Text style={[styles.cell, styles.customerCol]}>
                {idx === 0 ? data.customer_name : ''}
              </Text>
              <Text style={[styles.cell, styles.descCol]}>{rec.item_description}</Text>
              <Text style={[styles.cell, styles.weightCol, styles.rightAlign]}>
                {parseFloat(rec.weight_kg || '0').toFixed(2)}
              </Text>
            </View>
          ))
        ))}
        
        <View style={[styles.tableRow, styles.finishingTotalRow]}>
          <View style={[styles.cell, styles.finishingTotalLabelCell]}>
            <Text style={[styles.totalLabel, styles.finishingTotalLabel]}>SHIFT TOTAL:</Text>
          </View>
          <Text style={[styles.cell, styles.weightCol, styles.rightAlign, styles.totalText, styles.finishingTotalText]}>
            {totalWeight.toFixed(2)}
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  previewScroll: { flex: 1, backgroundColor: '#fff', padding: 12 },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  emptyText: { fontSize: 16, color: '#999', textAlign: 'center' },
  header: { marginBottom: 8, paddingBottom: 8, borderBottomWidth: 1, borderBottomColor: '#e5e7eb' },
  finishingHeader: { borderBottomWidth: 2, borderBottomColor: '#10B981' },
  headerTitle: { fontSize: 14, fontWeight: 'bold', textAlign: 'center', marginBottom: 4 },
  finishingTitle: { color: '#10B981' },
  headerDate: { fontSize: 10, textAlign: 'center', color: '#666' },
  controlsRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8, gap: 8 },
  controlGroup: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  controlLabel: { fontSize: 10, fontWeight: '600', color: '#374151', marginRight: 4 },
  filterBtn: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 4, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#D1D5DB' },
  filterBtnActive: { backgroundColor: '#3B82F6', borderColor: '#3B82F6' },
  filterBtnText: { fontSize: 9, color: '#6B7280' },
  filterBtnTextActive: { color: '#fff', fontWeight: '600' },
  table: { borderWidth: 1, borderColor: '#000' },
  tableHeader: { flexDirection: 'row', backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#000' },
  finishingTableHeader: { backgroundColor: '#10B981' },
  headerCell: { fontSize: 9, fontWeight: 'bold', padding: 4, borderRightWidth: 1, borderRightColor: '#000', textAlign: 'center' },
  finishingHeaderCell: { color: 'white' },
  tableRow: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: '#000' },
  cell: { fontSize: 8, padding: 3, borderRightWidth: 1, borderRightColor: '#000' },
  checkboxCell: { justifyContent: 'center', alignItems: 'center' },
  itemText: { fontSize: 8, lineHeight: 12, marginBottom: 1 },
  rightAlign: { textAlign: 'right' },
  centerAlign: { textAlign: 'center' },
  deliveredText: { color: '#10B981', fontWeight: '600' },
  deliveredCol: { width: '6%' },
  jobNoCol: { width: '8%' },
  dateCol: { width: '9%' },
  deliveryDateCol: { width: '9%' },
  customerCol: { width: '16%' },
  detailsCol: { width: '40%' },
  weightCol: { width: '12%' },
  jobCol: { width: '12%' },
  descCol: { width: '56%' },
  totalRow: { backgroundColor: '#f3f4f6' },
  finishingTotalRow: { backgroundColor: '#10B981' },
  totalLabelCell: { width: '88%', justifyContent: 'center', alignItems: 'flex-end', paddingRight: 5 },
  finishingTotalLabelCell: { width: '88%', justifyContent: 'center', alignItems: 'flex-end', paddingRight: 5 },
  totalLabel: { fontSize: 9, fontWeight: 'bold' },
  finishingTotalLabel: { color: 'white' },
  totalText: { fontSize: 9, fontWeight: 'bold' },
  finishingTotalText: { color: 'white' },
});

