import React from 'react';
import { View, Text, Modal, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface Props {
  visible: boolean;
  onClose: () => void;
  onEdit: () => void;
  onArchive: () => void;
  onViewHistory: () => void;
  deliveryNumber: string;
}

export default function DeliveryCardActionMenu({ visible, onClose, onEdit, onArchive, onViewHistory, deliveryNumber }: Props) {
  return (
    <Modal visible={visible} transparent animationType="fade">
      <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={onClose}>
        <View style={styles.modal}>
          <Text style={styles.title}>{deliveryNumber}</Text>
          
          <TouchableOpacity style={styles.menuItem} onPress={() => { onClose(); onEdit(); }}>
            <Ionicons name="create-outline" size={22} color="#2563eb" />
            <Text style={styles.menuText}>Edit Details</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.menuItem} onPress={() => { onClose(); onArchive(); }}>
            <Ionicons name="archive-outline" size={22} color="#f59e0b" />
            <Text style={styles.menuText}>Archive</Text>
          </TouchableOpacity>

          <View style={styles.divider} />

          <TouchableOpacity style={styles.cancelItem} onPress={onClose}>
            <Text style={styles.cancelText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modal: { backgroundColor: 'white', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, paddingBottom: 40 },
  title: { fontSize: 18, fontWeight: 'bold', marginBottom: 16, textAlign: 'center' },
  menuItem: { flexDirection: 'row', alignItems: 'center', padding: 16, gap: 12 },
  menuText: { fontSize: 16, color: '#1f2937' },
  divider: { height: 1, backgroundColor: '#e5e7eb', marginVertical: 8 },
  cancelItem: { padding: 16, alignItems: 'center' },
  cancelText: { fontSize: 16, color: '#6b7280', fontWeight: '600' }
});
