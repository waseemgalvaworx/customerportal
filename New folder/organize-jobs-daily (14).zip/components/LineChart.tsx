import React from 'react';
import { View, Text, Dimensions } from 'react-native';

interface DataPoint {
  date: string;
  value: number;
}

interface Props {
  data: DataPoint[];
  color?: string;
  label?: string;
  height?: number;
  showForecast?: boolean;
}

export default function LineChart({ data, color = '#007AFF', label, height = 200, showForecast = false }: Props) {
  if (data.length === 0) return null;

  const maxValue = Math.max(...data.map(d => d.value));
  const minValue = Math.min(...data.map(d => d.value));
  const range = maxValue - minValue || 1;
  const width = Dimensions.get('window').width - 80;
  const pointWidth = width / (data.length - 1 || 1);

  return (
    <View style={{ marginBottom: 30 }}>
      {label && <Text style={{ fontSize: 16, fontWeight: '600', marginBottom: 10, color: '#333' }}>{label}</Text>}
      
      <View style={{ height, backgroundColor: '#f9fafb', borderRadius: 12, padding: 15, position: 'relative' }}>
        {/* Y-axis labels */}
        <View style={{ position: 'absolute', left: 0, top: 15, bottom: 35 }}>
          <Text style={{ fontSize: 10, color: '#666' }}>{maxValue.toFixed(0)}</Text>
          <View style={{ flex: 1 }} />
          <Text style={{ fontSize: 10, color: '#666' }}>{((maxValue + minValue) / 2).toFixed(0)}</Text>
          <View style={{ flex: 1 }} />
          <Text style={{ fontSize: 10, color: '#666' }}>{minValue.toFixed(0)}</Text>
        </View>

        {/* Chart area */}
        <View style={{ marginLeft: 40, height: height - 50, flexDirection: 'row', alignItems: 'flex-end' }}>
          {data.map((point, i) => {
            const barHeight = ((point.value - minValue) / range) * (height - 50);
            const isForecast = showForecast && i >= data.length - 7;
            
            return (
              <View key={i} style={{ width: pointWidth, alignItems: 'center' }}>
                <View style={{ 
                  width: 4, 
                  height: barHeight || 2, 
                  backgroundColor: isForecast ? '#FFA500' : color,
                  borderRadius: 2,
                  opacity: isForecast ? 0.6 : 1
                }} />
              </View>
            );
          })}
        </View>

        {/* X-axis labels */}
        <View style={{ marginLeft: 40, flexDirection: 'row', marginTop: 8 }}>
          {data.filter((_, i) => i % Math.ceil(data.length / 5) === 0).map((point, i) => (
            <Text key={i} style={{ fontSize: 9, color: '#666', flex: 1 }}>
              {point.date.split('-').slice(1).join('/')}
            </Text>
          ))}
        </View>
      </View>
    </View>
  );
}
