import React, { useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Animated } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNotifications } from '../contexts/NotificationContext';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import { useRouter } from 'expo-router';

// Users who should not see the notification bell
const HIDDEN_NOTIFICATION_USERS = ['JS'];

export const NotificationBell: React.FC = () => {
  const { unreadCount, hasNewNotification, clearNewNotificationFlag } = useNotifications();
  const { user } = usePasswordAuth();
  const router = useRouter();
  const shakeAnimation = useRef(new Animated.Value(0)).current;
  const pulseAnimation = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (hasNewNotification) {
      // Shake animation
      Animated.sequence([
        Animated.timing(shakeAnimation, { toValue: 10, duration: 50, useNativeDriver: true }),
        Animated.timing(shakeAnimation, { toValue: -10, duration: 50, useNativeDriver: true }),
        Animated.timing(shakeAnimation, { toValue: 10, duration: 50, useNativeDriver: true }),
        Animated.timing(shakeAnimation, { toValue: 0, duration: 50, useNativeDriver: true }),
      ]).start();

      // Pulse animation
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnimation, { toValue: 1.2, duration: 500, useNativeDriver: true }),
          Animated.timing(pulseAnimation, { toValue: 1, duration: 500, useNativeDriver: true }),
        ]),
        { iterations: 3 }
      ).start(() => {
        clearNewNotificationFlag();
      });
    }
  }, [hasNewNotification]);

  // Hide notification bell for JS user
  if (user && HIDDEN_NOTIFICATION_USERS.includes(user.username)) {
    return null;
  }

  const handlePress = () => {
    clearNewNotificationFlag();
    router.push('/notifications');
  };

  return (
    <TouchableOpacity style={styles.container} onPress={handlePress}>
      <Animated.View style={{ transform: [{ translateX: shakeAnimation }, { scale: pulseAnimation }] }}>
        <Ionicons name={unreadCount > 0 ? "notifications" : "notifications-outline"} size={24} color="#333" />
        {unreadCount > 0 && (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>
              {unreadCount > 99 ? '99+' : unreadCount}
            </Text>
          </View>
        )}
      </Animated.View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: { position: 'relative', marginRight: 15, padding: 5 },
  badge: { position: 'absolute', top: -5, right: -5, backgroundColor: '#ef4444', borderRadius: 10, minWidth: 18, height: 18, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 4 },
  badgeText: { color: 'white', fontSize: 10, fontWeight: 'bold' },
});
