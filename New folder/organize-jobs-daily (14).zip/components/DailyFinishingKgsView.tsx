import React, { useMemo, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import DateTimePicker from './DateTimePicker';
import { supabase } from '../app/lib/supabase';

interface DailyFinishingKgsViewProps {
  jobs: any[];
}

export default function DailyFinishingKgsView({ jobs }: DailyFinishingKgsViewProps) {
  const [expanded, setExpanded] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [finishingRecords, setFinishingRecords] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  React.useEffect(() => {
    const fetchFinishingRecords = async () => {
      setLoading(true);
      setError(null);
      try {
        // Fetch active finishing records
        const { data: activeRecords, error: activeError } = await supabase
          .from('finishing_records')
          .select('*');

        if (activeError) throw activeError;

        // Fetch archived finishing reports
        const { data: archivedReports, error: archivedError } = await supabase
          .from('archived_finishing_reports')
          .select('*');

        if (archivedError) throw archivedError;

        console.log('Active finishing records:', activeRecords?.length || 0);
        console.log('Archived finishing reports:', archivedReports?.length || 0);

        // Use a Map to deduplicate by item_id, keeping the record with the most recent date
        const recordsByItemId = new Map<string, any>();

        // Process active records first
        (activeRecords || []).forEach(record => {
          const itemId = record.item_id;
          if (itemId) {
            const existing = recordsByItemId.get(itemId);
            const recordDate = new Date(record.created_at || record.recorded_date || 0);
            if (!existing || recordDate > new Date(existing.created_at || 0)) {
              recordsByItemId.set(itemId, {
                ...record,
                created_at: record.created_at || record.recorded_date,
                weight_kg: record.weight_kg,
                source: 'active'
              });
            }
          } else {
            // For records without item_id, use a unique key based on other fields
            const uniqueKey = `${record.job_number}-${record.item_description}-${record.recorded_date}`;
            if (!recordsByItemId.has(uniqueKey)) {
              recordsByItemId.set(uniqueKey, {
                ...record,
                created_at: record.created_at || record.recorded_date,
                weight_kg: record.weight_kg,
                source: 'active'
              });
            }
          }
        });

        // Process archived records - only add if item_id doesn't already exist
        if (archivedReports && archivedReports.length > 0) {
          archivedReports.forEach(report => {
            if (report.records && Array.isArray(report.records)) {
              report.records.forEach((record: any) => {
                const itemId = record.item_id;
                if (itemId) {
                  // Only add archived record if this item_id is NOT already in active records
                  if (!recordsByItemId.has(itemId)) {
                    recordsByItemId.set(itemId, {
                      ...record,
                      created_at: report.report_date,
                      weight_kg: record.weight_kg || record.weightKg,
                      source: 'archived'
                    });
                  }
                  // If item_id exists in active, skip the archived version (active is more recent)
                } else {
                  // For records without item_id, use unique key
                  const uniqueKey = `${record.job_number}-${record.item_description}-${report.report_date}`;
                  if (!recordsByItemId.has(uniqueKey)) {
                    recordsByItemId.set(uniqueKey, {
                      ...record,
                      created_at: report.report_date,
                      weight_kg: record.weight_kg || record.weightKg,
                      source: 'archived'
                    });
                  }
                }
              });
            }
          });
        }

        const allRecords = Array.from(recordsByItemId.values());
        console.log('Total deduplicated finishing records:', allRecords.length);
        
        // Log breakdown by source for debugging
        const activeCount = allRecords.filter(r => r.source === 'active').length;
        const archivedCount = allRecords.filter(r => r.source === 'archived').length;
        console.log(`Breakdown: ${activeCount} from active, ${archivedCount} from archived`);

        setFinishingRecords(allRecords);
      } catch (err: any) {
        console.error('Error fetching finishing records:', err);
        setError(err.message || 'Failed to fetch finishing records');
      } finally {
        setLoading(false);
      }
    };
    fetchFinishingRecords();
  }, []);

  const dailyData = useMemo(() => {
    try {
      const dataMap = new Map<string, number>();
      
      finishingRecords.forEach(record => {
        const date = new Date(record.created_at);
        
        // Exclude Sundays (day 0)
        if (date.getDay() === 0) return;
        
        // Validate date
        if (isNaN(date.getTime())) return;
        
        const dateKey = date.toISOString().split('T')[0];
        const weight = parseFloat(record.weight_kg || '0');
        
        // Skip invalid weights
        if (isNaN(weight) || weight <= 0) return;
        
        dataMap.set(dateKey, (dataMap.get(dateKey) || 0) + weight);
      });
      
      return Array.from(dataMap.entries())
        .map(([date, weight]) => ({ date, weight }))
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    } catch (err) {
      console.error('Error calculating daily data:', err);
      return [];
    }
  }, [finishingRecords]);


  const filteredData = selectedDate 
    ? dailyData.filter(d => d.date === selectedDate.toISOString().split('T')[0])
    : dailyData.slice(0, 30);

  return (
    <View style={styles.container}>
      <TouchableOpacity 
        style={styles.header} 
        onPress={() => setExpanded(!expanded)}
        activeOpacity={0.7}
      >
        <Text style={styles.title}>Daily Finishing Kgs</Text>
        <Ionicons 
          name={expanded ? "chevron-up" : "chevron-down"} 
          size={24} 
          color="#6B7280" 
        />
      </TouchableOpacity>

      {expanded && (
        <>
          <TouchableOpacity 
            style={styles.dateButton}
            onPress={() => setShowDatePicker(true)}
          >
            <Ionicons name="calendar-outline" size={20} color="#3B82F6" />
            <Text style={styles.dateButtonText}>
              {selectedDate 
                ? selectedDate.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
                : 'Select Date (Last 30 days)'
              }
            </Text>
            {selectedDate && (
              <TouchableOpacity onPress={() => setSelectedDate(null)}>
                <Ionicons name="close-circle" size={20} color="#EF4444" />
              </TouchableOpacity>
            )}
          </TouchableOpacity>

          {loading && (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#3B82F6" />
              <Text style={styles.loadingText}>Loading finishing data...</Text>
            </View>
          )}

          {error && (
            <View style={styles.errorContainer}>
              <Ionicons name="alert-circle" size={24} color="#EF4444" />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          )}

          {!loading && !error && (
            <ScrollView style={styles.list}>
              {filteredData.map((day) => (
                <View key={day.date} style={styles.dayCard}>
                  <Text style={styles.dayDate}>
                    {new Date(day.date).toLocaleDateString('en-GB', { 
                      weekday: 'short', day: 'numeric', month: 'short', year: 'numeric'
                    })}
                  </Text>
                  <Text style={styles.dayWeight}>{day.weight.toFixed(1)} kg</Text>
                </View>
              ))}
              {filteredData.length === 0 && (
                <Text style={styles.emptyText}>No finishing records</Text>
              )}
            </ScrollView>
          )}
        </>
      )}

      {showDatePicker && (
        <DateTimePicker
          value={selectedDate || new Date()}
          onChange={(date) => {
            setSelectedDate(date);
            setShowDatePicker(false);
          }}
          onClose={() => setShowDatePicker(false)}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  dateButton: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 12, padding: 12, backgroundColor: '#F9FAFB', borderRadius: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  dateButtonText: { flex: 1, fontSize: 14, color: '#374151', fontWeight: '500' },
  list: { maxHeight: 400, marginTop: 12 },
  dayCard: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  dayDate: { fontSize: 14, color: '#374151', fontWeight: '500' },
  dayWeight: { fontSize: 16, fontWeight: 'bold', color: '#F59E0B' },
  emptyText: { textAlign: 'center', color: '#9CA3AF', marginTop: 20, fontSize: 14 },
  loadingContainer: { alignItems: 'center', padding: 20 },
  loadingText: { marginTop: 8, color: '#6B7280', fontSize: 14 },
  errorContainer: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 12, backgroundColor: '#FEE2E2', borderRadius: 8, marginTop: 12 },
  errorText: { flex: 1, color: '#DC2626', fontSize: 14 },
});
