import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ItemStatus } from '../contexts/JobContext';

interface FilterChipsProps {
  activeFilter: 'all' | 'galvaxpress' | 'high';
  statusFilter: ItemStatus | 'all';
  onRemoveActiveFilter: () => void;
  onRemoveStatusFilter: () => void;
}

export default function FilterChips({
  activeFilter,
  statusFilter,
  onRemoveActiveFilter,
  onRemoveStatusFilter
}: FilterChipsProps) {
  const hasActiveFilters = activeFilter !== 'all' || statusFilter !== 'all';

  if (!hasActiveFilters) {
    return null;
  }

  return (
    <View style={styles.container}>
      {activeFilter === 'galvaxpress' && (
        <View style={styles.chip}>
          <Text style={styles.chipText}>GalvXpress</Text>
          <TouchableOpacity onPress={onRemoveActiveFilter} style={styles.removeButton}>
            <Ionicons name="close" size={16} color="#374151" />
          </TouchableOpacity>
        </View>
      )}
      
      {activeFilter === 'high' && (
        <View style={styles.chip}>
          <Text style={styles.chipText}>High Priority</Text>
          <TouchableOpacity onPress={onRemoveActiveFilter} style={styles.removeButton}>
            <Ionicons name="close" size={16} color="#374151" />
          </TouchableOpacity>
        </View>
      )}
      
      {statusFilter !== 'all' && (
        <View style={styles.chip}>
          <Text style={styles.chipText}>{statusFilter}</Text>
          <TouchableOpacity onPress={onRemoveStatusFilter} style={styles.removeButton}>
            <Ionicons name="close" size={16} color="#374151" />
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    paddingHorizontal: 16,
    paddingBottom: 12,
    backgroundColor: 'white'
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#E0F2FE',
    borderRadius: 16,
    paddingLeft: 12,
    paddingRight: 6,
    paddingVertical: 6,
    gap: 6
  },
  chipText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#0369A1'
  },
  removeButton: {
    padding: 2
  }
});
