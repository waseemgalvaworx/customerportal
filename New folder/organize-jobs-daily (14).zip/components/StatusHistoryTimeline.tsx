import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, TextInput, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../app/lib/supabase';

interface StatusLog {
  id: string;
  created_at: string;
  username: string;
  action_description: string;
  entity_id?: string;
}

export default function StatusHistoryTimeline() {
  const [logs, setLogs] = useState<StatusLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [jobFilter, setJobFilter] = useState('');

  useEffect(() => {
    fetchStatusHistory();
  }, [jobFilter]);

  const fetchStatusHistory = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('activity_logs')
        .select('*')
        .or('action_type.eq.JOB_UPDATED,action_type.eq.STATUS_CHANGED,action_description.ilike.%status%')
        .order('created_at', { ascending: false })
        .limit(200);

      if (jobFilter.trim()) {
        query = query.ilike('action_description', `%${jobFilter}%`);
      }

      const { data, error } = await query;
      if (error) throw error;
      setLogs(data || []);
    } catch (err) {
      console.error('Error fetching status history:', err);
    } finally {
      setLoading(false);
    }
  };

  const renderTimelineItem = ({ item, index }: { item: StatusLog; index: number }) => (
    <View style={styles.timelineItem}>
      <View style={styles.timelineLeft}>
        <View style={styles.timelineDot} />
        {index < logs.length - 1 && <View style={styles.timelineLine} />}
      </View>
      <View style={styles.timelineContent}>
        <Text style={styles.timelineTime}>{new Date(item.created_at).toLocaleString()}</Text>
        <Text style={styles.timelineUser}>{item.username}</Text>
        <Text style={styles.timelineDesc}>{item.action_description}</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Ionicons name="git-branch" size={24} color="#3B82F6" />
        <Text style={styles.title}>Status History Timeline</Text>
      </View>
      
      <TextInput
        style={styles.searchInput}
        placeholder="Filter by job number..."
        value={jobFilter}
        onChangeText={setJobFilter}
      />

      {loading ? (
        <ActivityIndicator size="large" color="#3B82F6" style={styles.loader} />
      ) : logs.length === 0 ? (
        <Text style={styles.emptyText}>No status changes found</Text>
      ) : (
        <FlatList
          data={logs}
          renderItem={renderTimelineItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.list}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { flexDirection: 'row', alignItems: 'center', padding: 16, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#E5E7EB', gap: 8 },
  title: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  searchInput: { margin: 16, padding: 12, backgroundColor: 'white', borderRadius: 8, borderWidth: 1, borderColor: '#D1D5DB', fontSize: 14 },
  list: { padding: 16 },
  timelineItem: { flexDirection: 'row', marginBottom: 16 },
  timelineLeft: { width: 40, alignItems: 'center' },
  timelineDot: { width: 12, height: 12, borderRadius: 6, backgroundColor: '#3B82F6', borderWidth: 3, borderColor: '#DBEAFE' },
  timelineLine: { width: 2, flex: 1, backgroundColor: '#D1D5DB', marginTop: 4 },
  timelineContent: { flex: 1, backgroundColor: 'white', padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  timelineTime: { fontSize: 11, color: '#6B7280', marginBottom: 4 },
  timelineUser: { fontSize: 13, fontWeight: '600', color: '#3B82F6', marginBottom: 4 },
  timelineDesc: { fontSize: 13, color: '#1F2937' },
  loader: { marginTop: 40 },
  emptyText: { textAlign: 'center', color: '#6B7280', fontSize: 14, marginTop: 40, paddingHorizontal: 16 }
});
