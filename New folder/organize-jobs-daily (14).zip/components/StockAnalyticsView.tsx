import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ActivityIndicator, ScrollView } from 'react-native';
import { supabase } from '@/app/lib/supabase';
import StockReportTable from './StockReportTable';
import DateTimePicker from './DateTimePicker';

export default function StockAnalyticsView({ refreshKey }: { refreshKey: number }) {
  const [loading, setLoading] = useState(true);
  const [startDate, setStartDate] = useState(new Date(Date.now() - 30*24*60*60*1000));
  const [endDate, setEndDate] = useState(new Date());
  const [showStartPicker, setShowStartPicker] = useState(false);
  const [showEndPicker, setShowEndPicker] = useState(false);

  useEffect(() => {
    setLoading(false);
  }, [refreshKey]);

  const adjustDate = (days: number) => {
    setStartDate(new Date(Date.now() + days*24*60*60*1000));
    setEndDate(new Date());
  };

  if (loading) return <ActivityIndicator size="large" style={{ marginTop: 50 }} />;

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Transaction History Report</Text>
      
      <Text style={styles.label}>Quick Select:</Text>
      <View style={styles.dateButtons}>
        <TouchableOpacity style={styles.dateBtn} onPress={() => adjustDate(-7)}>
          <Text style={styles.dateBtnText}>7 Days</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.dateBtn} onPress={() => adjustDate(-30)}>
          <Text style={styles.dateBtnText}>30 Days</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.dateBtn} onPress={() => adjustDate(-90)}>
          <Text style={styles.dateBtnText}>90 Days</Text>
        </TouchableOpacity>
      </View>
      
      <Text style={styles.label}>Custom Date Range:</Text>
      <View style={styles.customDateRow}>
        <View style={styles.datePickerContainer}>
          <Text style={styles.dateLabel}>From:</Text>
          <TouchableOpacity style={styles.dateInput} onPress={() => setShowStartPicker(true)}>
            <Text>{startDate.toLocaleDateString()}</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.datePickerContainer}>
          <Text style={styles.dateLabel}>To:</Text>
          <TouchableOpacity style={styles.dateInput} onPress={() => setShowEndPicker(true)}>
            <Text>{endDate.toLocaleDateString()}</Text>
          </TouchableOpacity>
        </View>
      </View>

      <StockReportTable startDate={startDate} endDate={endDate} />

      {showStartPicker && (
        <DateTimePicker
          value={startDate}
          onChange={(date) => {
            setStartDate(date);
            setShowStartPicker(false);
          }}
          onClose={() => setShowStartPicker(false)}
        />
      )}

      {showEndPicker && (
        <DateTimePicker
          value={endDate}
          onChange={(date) => {
            setEndDate(date);
            setShowEndPicker(false);
          }}
          onClose={() => setShowEndPicker(false)}
        />
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16 },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 16 },
  label: { fontSize: 14, fontWeight: 'bold', marginBottom: 8, marginTop: 12 },
  dateButtons: { flexDirection: 'row', gap: 8, marginBottom: 12 },
  dateBtn: { backgroundColor: '#007AFF', paddingHorizontal: 16, paddingVertical: 10, borderRadius: 8 },
  dateBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 14 },
  customDateRow: { flexDirection: 'row', gap: 12, marginBottom: 16 },
  datePickerContainer: { flex: 1 },
  dateLabel: { fontSize: 12, color: '#666', marginBottom: 4 },
  dateInput: { backgroundColor: '#fff', padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#ddd' }
});
