import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../app/lib/supabase';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import { createNotification } from '../utils/notificationHelper';
import { getUserIdFromUsername } from '../utils/userMapping';
import DateTimePicker from './DateTimePicker';

const TIME_SLOTS = ['06:00','07:00','08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00'];

interface Props {
  visible: boolean;
  onClose: () => void;
  onSuccess: () => void;
  delivery: any;
}

export default function ApproveDeliveryRequestModal({ visible, onClose, onSuccess, delivery }: Props) {
  const { user } = usePasswordAuth();
  const [newDate, setNewDate] = useState(new Date());
  const [newTime, setNewTime] = useState('08:00');
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (delivery?.scheduled_date) {
      const parts = delivery.scheduled_date.split(' ');
      if (parts[0]) setNewDate(new Date(parts[0]));
      if (parts[1]) setNewTime(parts[1]);
    }
  }, [delivery]);

  const formatDate = (date: Date) => date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });

  const sendNotificationToRequester = async (action: string, hasChanges: boolean, originalDate: string, newDateTime: string) => {
    if (!delivery?.requested_by) return;
    const requesterId = getUserIdFromUsername(delivery.requested_by);
    if (!requesterId) return;

    let title = '', message = '';
    if (action === 'approved') {
      if (hasChanges) {
        title = 'Delivery Request Modified & Approved';
        message = `Your ${delivery.delivery_type || 'delivery'} request (${delivery.delivery_number}) has been approved with changes.\n\nOriginal: ${originalDate}\nNew: ${newDateTime}\n\nApproved by: ${user?.username}`;
      } else {
        title = 'Delivery Request Approved';
        message = `Your ${delivery.delivery_type || 'delivery'} request (${delivery.delivery_number}) has been approved as requested.\n\nScheduled: ${newDateTime}\n\nApproved by: ${user?.username}`;
      }
    } else if (action === 'rejected') {
      title = 'Delivery Request Rejected';
      message = `Your ${delivery.delivery_type || 'delivery'} request (${delivery.delivery_number}) has been rejected.\n\nRejected by: ${user?.username}`;
    }

    await createNotification({ userId: requesterId, title, message, type: 'logistics', priority: 'high' });
  };

  const handleApprove = async () => {
    setSaving(true);
    try {
      const dateStr = newDate.toISOString().split('T')[0];
      const newDateTime = `${dateStr} ${newTime}`;
      const originalDate = delivery?.original_scheduled_date || delivery?.scheduled_date || '';
      const hasChanges = newDateTime !== originalDate;

      const { error } = await supabase.from('logistics_deliveries').update({
        scheduled_date: newDateTime,
        status: 'scheduled',
        approved_by: user?.username || 'Unknown'
      }).eq('id', delivery.id);

      if (error) throw error;
      await sendNotificationToRequester('approved', hasChanges, originalDate, newDateTime);
      Alert.alert('Success', 'Request approved successfully');
      onSuccess();
      onClose();
    } catch (err: any) {
      Alert.alert('Error', err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleReject = async () => {
    Alert.alert('Reject Request', 'Are you sure you want to reject this request?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Reject', style: 'destructive', onPress: async () => {
        setSaving(true);
        try {
          const { error } = await supabase.from('logistics_deliveries').update({ status: 'cancelled', approved_by: user?.username }).eq('id', delivery.id);
          if (error) throw error;
          await sendNotificationToRequester('rejected', false, '', '');
          Alert.alert('Success', 'Request rejected');
          onSuccess();
          onClose();
        } catch (err: any) {
          Alert.alert('Error', err.message);
        } finally {
          setSaving(false);
        }
      }}
    ]);
  };

  if (!delivery) return null;

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <ScrollView>
            <Text style={styles.title}>Review Request</Text>
            <View style={styles.infoBox}>
              <Text style={styles.infoLabel}>Request #</Text>
              <Text style={styles.infoValue}>{delivery.delivery_number}</Text>
            </View>
            <View style={styles.infoBox}>
              <Text style={styles.infoLabel}>Type</Text>
              <Text style={styles.infoValue}>{delivery.delivery_type || 'Delivery'}</Text>
            </View>
            <View style={styles.infoBox}>
              <Text style={styles.infoLabel}>Requested By</Text>
              <Text style={styles.infoValue}>{delivery.requested_by || 'Unknown'}</Text>
            </View>
            <View style={styles.infoBox}>
              <Text style={styles.infoLabel}>Client</Text>
              <Text style={styles.infoValue}>{delivery.client_name || 'N/A'}</Text>
            </View>
            <View style={styles.infoBox}>
              <Text style={styles.infoLabel}>Address</Text>
              <Text style={styles.infoValue}>{delivery.delivery_address}</Text>
            </View>
            {delivery.description && (
              <View style={styles.infoBox}>
                <Text style={styles.infoLabel}>Description</Text>
                <Text style={styles.infoValue}>{delivery.description}</Text>
              </View>
            )}
            <View style={styles.infoBox}>
              <Text style={styles.infoLabel}>Original Request</Text>
              <Text style={styles.infoValue}>{delivery.original_scheduled_date || delivery.scheduled_date}</Text>
            </View>

            <Text style={styles.sectionTitle}>Modify Date/Time (if needed)</Text>
            <TouchableOpacity style={styles.dateBtn} onPress={() => setShowDatePicker(!showDatePicker)}>
              <Ionicons name="calendar-outline" size={20} color="#2563eb" />
              <Text style={styles.dateBtnText}>{formatDate(newDate)}</Text>
            </TouchableOpacity>
            {showDatePicker && <DateTimePicker value={newDate} onChange={(d) => { setNewDate(d); setShowDatePicker(false); }} mode="date" />}

            <TouchableOpacity style={styles.dateBtn} onPress={() => setShowTimePicker(!showTimePicker)}>
              <Ionicons name="time-outline" size={20} color="#2563eb" />
              <Text style={styles.dateBtnText}>{newTime}</Text>
            </TouchableOpacity>
            {showTimePicker && (
              <View style={styles.timeList}>
                <ScrollView style={{ maxHeight: 140 }}>
                  {TIME_SLOTS.map(t => (
                    <TouchableOpacity key={t} style={styles.timeItem} onPress={() => { setNewTime(t); setShowTimePicker(false); }}>
                      <Text>{t}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </View>
            )}

            <View style={styles.buttons}>
              <TouchableOpacity style={styles.rejectBtn} onPress={handleReject} disabled={saving}>
                <Text style={styles.rejectText}>Reject</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.approveBtn} onPress={handleApprove} disabled={saving}>
                <Text style={styles.approveText}>{saving ? 'Saving...' : 'Approve'}</Text>
              </TouchableOpacity>
            </View>
            <TouchableOpacity style={styles.cancelBtn} onPress={onClose}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: 'white', borderRadius: 12, padding: 20, maxHeight: '90%' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 16, textAlign: 'center' },
  infoBox: { marginBottom: 10 },
  infoLabel: { fontSize: 12, color: '#6b7280', marginBottom: 2 },
  infoValue: { fontSize: 15, color: '#1f2937', fontWeight: '500' },
  sectionTitle: { fontSize: 16, fontWeight: '700', marginTop: 16, marginBottom: 10, color: '#2563eb' },
  dateBtn: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 14, backgroundColor: '#eff6ff', borderRadius: 8, marginBottom: 10 },
  dateBtnText: { fontSize: 16, color: '#1f2937' },
  timeList: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, marginBottom: 10, maxHeight: 150 },
  timeItem: { padding: 12, borderBottomWidth: 1, borderBottomColor: '#f3f4f6' },
  buttons: { flexDirection: 'row', gap: 10, marginTop: 20 },
  rejectBtn: { flex: 1, padding: 14, borderRadius: 8, backgroundColor: '#fee2e2', alignItems: 'center' },
  rejectText: { fontSize: 16, fontWeight: '600', color: '#dc2626' },
  approveBtn: { flex: 1, padding: 14, borderRadius: 8, backgroundColor: '#16a34a', alignItems: 'center' },
  approveText: { fontSize: 16, fontWeight: '600', color: 'white' },
  cancelBtn: { marginTop: 10, padding: 14, alignItems: 'center' },
  cancelText: { fontSize: 15, color: '#6b7280' }
});
