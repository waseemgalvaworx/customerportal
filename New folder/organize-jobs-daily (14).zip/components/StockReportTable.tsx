import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, ActivityIndicator, TouchableOpacity, Alert, Modal } from 'react-native';
import { supabase } from '@/app/lib/supabase';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';

interface StockReportTableProps {
  startDate: Date;
  endDate: Date;
}


export default function StockReportTable({ startDate, endDate }: StockReportTableProps) {
  const [allItems, setAllItems] = useState<any[]>([]);
  const [selectedItemId, setSelectedItemId] = useState<string>('all');
  const [selectedItemName, setSelectedItemName] = useState<string>('All Items');
  const [reportData, setReportData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showPicker, setShowPicker] = useState(false);

  useEffect(() => {
    fetchItems();
  }, []);

  useEffect(() => {
    if (allItems.length > 0) {
      fetchReportData();
    }
  }, [startDate, endDate, selectedItemId, allItems]);

  const fetchItems = async () => {
    const { data } = await supabase.from('inventory_items').select('*').order('item_name');
    // Only set items that actually exist (not deleted)
    setAllItems(data || []);
    setLoading(false);
  };


  const fetchReportData = async () => {
    setLoading(true);
    const itemsToProcess = selectedItemId === 'all' 
      ? allItems 
      : allItems.filter(i => i.id === selectedItemId);

    const enriched = await Promise.all(itemsToProcess.map(async (item) => {
      const { data: trans } = await supabase
        .from('inventory_transactions')
        .select('*')
        .eq('item_id', item.id)
        .gte('transaction_date', startDate.toISOString())
        .lte('transaction_date', endDate.toISOString());
      
      // Exclude opening balance transactions from stock movements
      const actualTransactions = trans?.filter(t => 
        t.notes !== 'Opening Balance' && 
        t.reference !== 'OPENING_BALANCE'
      ) || [];
      
      const totalIn = actualTransactions.filter(t => t.transaction_type === 'in').reduce((s, t) => s + t.quantity, 0);
      const totalOut = actualTransactions.filter(t => t.transaction_type === 'out').reduce((s, t) => s + t.quantity, 0);
      
      return { ...item, totalIn, totalOut, netChange: totalIn - totalOut };

    }));
    
    setReportData(enriched);
    setLoading(false);
  };

  const exportReport = async () => {
    const html = `
      <html><body>
        <h2>Stock Report (${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()})</h2>
        <table border="1" cellpadding="5" style="border-collapse:collapse;width:100%">
          <tr><th>Item</th><th>Category</th><th>Stock</th><th>Unit</th><th>In</th><th>Out</th><th>Net</th></tr>
          ${reportData.map(i => `<tr><td>${i.item_name}</td><td>${i.category}</td><td>${i.quantity}</td><td>${i.unit}</td><td>${i.totalIn}</td><td>${i.totalOut}</td><td>${i.netChange}</td></tr>`).join('')}
        </table>
      </body></html>
    `;
    const { uri } = await Print.printToFileAsync({ html });
    await Sharing.shareAsync(uri);
    Alert.alert('Success', 'PDF exported successfully');
  };


  const selectItem = (id: string, name: string) => {
    setSelectedItemId(id);
    setSelectedItemName(name);
    setShowPicker(false);
  };

  if (loading) return <ActivityIndicator size="large" style={{ marginTop: 20 }} />;

  return (
    <View style={styles.container}>
      <View style={styles.controls}>
        <View style={styles.pickerContainer}>
          <Text style={styles.label}>Select Item:</Text>
          <TouchableOpacity onPress={() => setShowPicker(true)} style={styles.pickerButton}>
            <Text>{selectedItemName}</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity onPress={exportReport} style={styles.exportButton}>
          <Text style={styles.exportButtonText}>Export PDF</Text>

        </TouchableOpacity>
      </View>

      <ScrollView horizontal>
        <View>
          <View style={styles.headerRow}>
            <Text style={[styles.cell, styles.headerCell, {width: 150}]}>Item</Text>
            <Text style={[styles.cell, styles.headerCell, {width: 100}]}>Category</Text>
            <Text style={[styles.cell, styles.headerCell, {width: 100}]}>Current Stock</Text>
            <Text style={[styles.cell, styles.headerCell, {width: 80}]}>In</Text>
            <Text style={[styles.cell, styles.headerCell, {width: 80}]}>Out</Text>
            <Text style={[styles.cell, styles.headerCell, {width: 80}]}>Net</Text>
          </View>
          {reportData.map(item => (
            <View key={item.id} style={styles.row}>
              <Text style={[styles.cell, {width: 150}]}>{item.item_name}</Text>
              <Text style={[styles.cell, {width: 100}]}>{item.category}</Text>
              <Text style={[styles.cell, {width: 100}]}>{item.quantity} {item.unit}</Text>
              <Text style={[styles.cell, {width: 80, color: '#10B981'}]}>+{item.totalIn}</Text>
              <Text style={[styles.cell, {width: 80, color: '#EF4444'}]}>-{item.totalOut}</Text>
              <Text style={[styles.cell, {width: 80, fontWeight: 'bold'}]}>{item.netChange > 0 ? '+' : ''}{item.netChange}</Text>
            </View>
          ))}
        </View>
      </ScrollView>

      <Modal visible={showPicker} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Select Item</Text>
            <ScrollView style={styles.itemList}>
              <TouchableOpacity onPress={() => selectItem('all', 'All Items')} style={styles.itemOption}>
                <Text style={styles.itemOptionText}>All Items</Text>
              </TouchableOpacity>
              {allItems.map(item => (
                <TouchableOpacity key={item.id} onPress={() => selectItem(item.id, item.item_name)} style={styles.itemOption}>
                  <Text style={styles.itemOptionText}>{item.item_name}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <TouchableOpacity onPress={() => setShowPicker(false)} style={styles.closeBtn}>
              <Text style={styles.closeBtnText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  controls: { flexDirection: 'row', padding: 12, gap: 12, alignItems: 'flex-end' },
  pickerContainer: { flex: 1 },
  label: { fontSize: 12, fontWeight: 'bold', marginBottom: 4, color: '#374151' },
  pickerButton: { backgroundColor: '#fff', padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#ddd' },
  exportButton: { backgroundColor: '#10B981', padding: 12, borderRadius: 8 },
  exportButtonText: { color: '#fff', fontWeight: 'bold' },
  headerRow: { flexDirection: 'row', backgroundColor: '#F3F4F6' },
  row: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  cell: { padding: 12, fontSize: 13 },
  headerCell: { fontWeight: 'bold', color: '#374151' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, maxHeight: '70%' },
  modalTitle: { fontSize: 18, fontWeight: 'bold', padding: 16, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  itemList: { maxHeight: 400 },
  itemOption: { padding: 16, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  itemOptionText: { fontSize: 16 },
  closeBtn: { padding: 16, backgroundColor: '#F3F4F6', margin: 12, borderRadius: 8 },
  closeBtnText: { textAlign: 'center', fontWeight: 'bold', color: '#374151' }
});
