import React, { useState, useEffect } from 'react';
import { View, Text, Modal, TextInput, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';
import { supabase } from '../app/lib/supabase';

interface VehicleDetailsModalProps {
  visible: boolean;
  onClose: () => void;
  vehicleId: string | null;
  onSuccess: () => void;
}

export default function VehicleDetailsModal({ visible, onClose, vehicleId, onSuccess }: VehicleDetailsModalProps) {
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [make, setMake] = useState('');
  const [model, setModel] = useState('');
  const [licensePlate, setLicensePlate] = useState('');
  const [status, setStatus] = useState('active');
  const [capacity, setCapacity] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (visible && vehicleId) {
      loadVehicle();
    } else if (!visible) {
      // Reset form when modal closes
      resetForm();
    }
  }, [visible, vehicleId]);

  const resetForm = () => {
    setVehicleNumber('');
    setMake('');
    setModel('');
    setLicensePlate('');
    setStatus('active');
    setCapacity('');
    setNotes('');
  };

  const loadVehicle = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('vehicles')
        .select('*')
        .eq('id', vehicleId)
        .single();
      
      if (error) throw error;
      
      if (data) {
        setVehicleNumber(data.vehicle_number || '');
        setMake(data.make || '');
        setModel(data.model || '');
        setLicensePlate(data.license_plate || '');
        // Ensure status is valid, default to 'active' if not
        const validStatuses = ['active', 'maintenance', 'inactive'];
        setStatus(validStatuses.includes(data.status) ? data.status : 'active');
        setCapacity(data.capacity_kg?.toString() || '');
        setNotes(data.notes || '');
      }
    } catch (error) {
      console.error('Error loading vehicle:', error);
      Alert.alert('Error', 'Failed to load vehicle details');
    } finally {
      setLoading(false);
    }
  };


  const handleSave = async () => {
    if (!vehicleNumber.trim() || !licensePlate.trim()) {
      Alert.alert('Error', 'Vehicle number and license plate are required');
      return;
    }

    // Ensure status is valid
    const validStatuses = ['active', 'maintenance', 'inactive'];
    const finalStatus = validStatuses.includes(status) ? status : 'active';

    setSaving(true);
    try {
      const updateData = {
        vehicle_number: vehicleNumber.trim(),
        make: make.trim(),
        model: model.trim(),
        license_plate: licensePlate.trim(),
        status: finalStatus,
        capacity_kg: capacity ? parseFloat(capacity) : null,
        notes: notes.trim(),
        updated_at: new Date().toISOString()
      };

      console.log('Updating vehicle:', vehicleId, updateData);


      const { data, error } = await supabase
        .from('vehicles')
        .update(updateData)
        .eq('id', vehicleId)
        .select();

      if (error) throw error;

      console.log('Update result:', data);

      // Call onSuccess first to refresh data
      await onSuccess();
      
      // Close modal
      onClose();
      
      // Show success message
      setTimeout(() => {
        Alert.alert('Success', 'Vehicle updated successfully');
      }, 300);
    } catch (error) {
      console.error('Error saving vehicle:', error);
      Alert.alert('Error', 'Failed to save: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <ScrollView>
            <Text style={styles.title}>Vehicle Details</Text>
            
            {loading ? (
              <Text style={styles.loadingText}>Loading...</Text>
            ) : (
              <>
                <Text style={styles.label}>Vehicle Number *</Text>
                <TextInput 
                  style={styles.input} 
                  value={vehicleNumber} 
                  onChangeText={setVehicleNumber}
                  editable={!saving}
                />
                
                <Text style={styles.label}>Make</Text>
                <TextInput 
                  style={styles.input} 
                  value={make} 
                  onChangeText={setMake}
                  editable={!saving}
                />
                
                <Text style={styles.label}>Model</Text>
                <TextInput 
                  style={styles.input} 
                  value={model} 
                  onChangeText={setModel}
                  editable={!saving}
                />
                
                <Text style={styles.label}>License Plate *</Text>
                <TextInput 
                  style={styles.input} 
                  value={licensePlate} 
                  onChangeText={setLicensePlate}
                  editable={!saving}
                />
                
                <Text style={styles.label}>Capacity (tons)</Text>
                <TextInput 
                  style={styles.input} 
                  value={capacity} 
                  onChangeText={setCapacity} 
                  keyboardType="numeric"
                  editable={!saving}
                />
                
                <Text style={styles.label}>Status</Text>
                <View style={styles.statusRow}>
                  <TouchableOpacity 
                    style={[styles.statusBtn, status === 'active' && styles.statusActive]} 
                    onPress={() => setStatus('active')}
                    disabled={saving}
                  >
                    <Text style={[styles.statusText, status === 'active' && styles.statusTextActive]}>Active</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={[styles.statusBtn, status === 'maintenance' && styles.statusActive]} 
                    onPress={() => setStatus('maintenance')}
                    disabled={saving}
                  >
                    <Text style={[styles.statusText, status === 'maintenance' && styles.statusTextActive]}>Maintenance</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={[styles.statusBtn, status === 'inactive' && styles.statusActive]} 
                    onPress={() => setStatus('inactive')}
                    disabled={saving}
                  >
                    <Text style={[styles.statusText, status === 'inactive' && styles.statusTextActive]}>Inactive</Text>
                  </TouchableOpacity>
                </View>
                
                <Text style={styles.label}>Notes</Text>
                <TextInput 
                  style={[styles.input, styles.textArea]} 
                  value={notes} 
                  onChangeText={setNotes} 
                  multiline 
                  numberOfLines={3}
                  editable={!saving}
                />

                <View style={styles.buttons}>
                  <TouchableOpacity 
                    style={styles.cancelButton} 
                    onPress={onClose}
                    disabled={saving}
                  >
                    <Text style={styles.cancelText}>Cancel</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={[styles.saveButton, saving && styles.saveButtonDisabled]} 
                    onPress={handleSave} 
                    disabled={saving}
                  >
                    <Text style={styles.saveText}>{saving ? 'Saving...' : 'Save Changes'}</Text>
                  </TouchableOpacity>
                </View>
              </>
            )}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modal: { backgroundColor: 'white', borderRadius: 12, padding: 20, maxHeight: '80%' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 20 },
  loadingText: { textAlign: 'center', padding: 20, color: '#6b7280' },
  label: { fontSize: 14, fontWeight: '600', marginBottom: 5, color: '#374151' },
  input: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, padding: 12, marginBottom: 15, fontSize: 16 },
  textArea: { height: 80, textAlignVertical: 'top' },
  statusRow: { flexDirection: 'row', gap: 10, marginBottom: 15 },
  statusBtn: { flex: 1, padding: 10, borderRadius: 8, borderWidth: 1, borderColor: '#d1d5db', alignItems: 'center' },
  statusActive: { backgroundColor: '#2563eb', borderColor: '#2563eb' },
  statusText: { fontSize: 14, color: '#374151' },
  statusTextActive: { color: 'white', fontWeight: '600' },
  buttons: { flexDirection: 'row', gap: 10, marginTop: 10 },
  cancelButton: { flex: 1, padding: 15, borderRadius: 8, borderWidth: 1, borderColor: '#d1d5db' },
  cancelText: { textAlign: 'center', fontSize: 16, color: '#6b7280' },
  saveButton: { flex: 1, padding: 15, borderRadius: 8, backgroundColor: '#2563eb' },
  saveButtonDisabled: { backgroundColor: '#93c5fd' },
  saveText: { textAlign: 'center', fontSize: 16, color: 'white', fontWeight: '600' }
});
