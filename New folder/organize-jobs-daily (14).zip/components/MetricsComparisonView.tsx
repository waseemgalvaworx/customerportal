import React, { useMemo, useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../app/lib/supabase';

type ViewPeriod = 'daily' | 'weekly' | 'monthly' | 'yearly';

interface MetricsComparisonViewProps {
  jobs: any[];
}

export default function MetricsComparisonView({ jobs }: MetricsComparisonViewProps) {
  const [expandedReceived, setExpandedReceived] = useState(false);
  const [expandedFinishing, setExpandedFinishing] = useState(false);
  const [expandedCompleted, setExpandedCompleted] = useState(false);
  
  const [viewPeriod, setViewPeriod] = useState<ViewPeriod>('daily');
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [finishingRecords, setFinishingRecords] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchFinishingRecords = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Fetch from both finishing_records and archived_finishing_reports
        const [activeResult, archivedResult] = await Promise.all([
          supabase.from('finishing_records').select('*'),
          supabase.from('archived_finishing_reports').select('*')
        ]);

        if (activeResult.error) {
          console.error('Error fetching active finishing records:', activeResult.error);
        }
        if (archivedResult.error) {
          console.error('Error fetching archived finishing records:', archivedResult.error);
        }

        // Use a Map to deduplicate by item_id
        const recordsByItemId = new Map<string, any>();

        // Process active records first (they take priority)
        (activeResult.data || []).forEach(record => {
          const itemId = record.item_id;
          if (itemId) {
            const existing = recordsByItemId.get(itemId);
            const recordDate = new Date(record.created_at || record.recorded_date || 0);
            if (!existing || recordDate > new Date(existing.created_at || 0)) {
              recordsByItemId.set(itemId, {
                created_at: record.created_at || record.recorded_date,
                weight_kg: record.weight_kg,
                item_id: itemId,
                source: 'active'
              });
            }
          } else {
            // For records without item_id, use unique key
            const uniqueKey = `active-${record.job_number}-${record.item_description}-${record.recorded_date}`;
            if (!recordsByItemId.has(uniqueKey)) {
              recordsByItemId.set(uniqueKey, {
                created_at: record.created_at || record.recorded_date,
                weight_kg: record.weight_kg,
                source: 'active'
              });
            }
          }
        });

        // Process archived records - only add if item_id doesn't already exist
        (archivedResult.data || []).forEach(archive => {
          const reportDate = archive.report_date;
          const records = archive.records || [];
          
          if (Array.isArray(records)) {
            records.forEach((record: any) => {
              const itemId = record.item_id;
              if (itemId) {
                // Only add if this item_id is NOT already in active records
                if (!recordsByItemId.has(itemId)) {
                  recordsByItemId.set(itemId, {
                    created_at: reportDate,
                    weight_kg: record.weight_kg || record.weightKg || '0',
                    item_id: itemId,
                    source: 'archived'
                  });
                }
              } else {
                // For records without item_id, use unique key
                const uniqueKey = `archived-${record.job_number}-${record.item_description}-${reportDate}`;
                if (!recordsByItemId.has(uniqueKey)) {
                  recordsByItemId.set(uniqueKey, {
                    created_at: reportDate,
                    weight_kg: record.weight_kg || record.weightKg || '0',
                    source: 'archived'
                  });
                }
              }
            });
          }
        });

        const combinedData = Array.from(recordsByItemId.values());

        console.log('Fetched finishing records (deduplicated):', {
          active: combinedData.filter(r => r.source === 'active').length,
          archived: combinedData.filter(r => r.source === 'archived').length,
          total: combinedData.length
        });

        setFinishingRecords(combinedData);
      } catch (err) {
        console.error('Error in fetchFinishingRecords:', err);
        setError('Failed to load finishing records');
      } finally {
        setLoading(false);
      }
    };
    fetchFinishingRecords();
  }, []);


  const receivedData = useMemo(() => {
    try {
      const dataMap = new Map<string, number>();
      jobs.forEach(job => {
        const date = new Date(job.dateOfEntry);
        if (isNaN(date.getTime())) return;
        const key = getPeriodKey(date, viewPeriod);
        const weight = job.items.reduce((sum: number, item: any) => 
          sum + parseFloat(item.weightKg || '0'), 0
        );
        dataMap.set(key, (dataMap.get(key) || 0) + weight);
      });
      return formatData(dataMap, viewPeriod, selectedDate);
    } catch (err) {
      console.error('Error calculating receivedData:', err);
      return [];
    }
  }, [jobs, viewPeriod, selectedDate]);

  const finishingData = useMemo(() => {
    try {
      const dataMap = new Map<string, number>();
      finishingRecords.forEach(record => {
        const date = new Date(record.created_at);
        if (isNaN(date.getTime())) return;
        const key = getPeriodKey(date, viewPeriod);
        const weight = parseFloat(record.weight_kg || '0');
        if (isNaN(weight) || weight <= 0) return;
        dataMap.set(key, (dataMap.get(key) || 0) + weight);
      });
      return formatData(dataMap, viewPeriod, selectedDate);
    } catch (err) {
      console.error('Error calculating finishingData:', err);
      return [];
    }
  }, [finishingRecords, viewPeriod, selectedDate]);

  const completedData = useMemo(() => {
    try {
      const dataMap = new Map<string, number>();
      const completedJobs = jobs.filter(j => 
        (j.status === 'done' || j.status === 'archived') && j.completedDate
      );
      completedJobs.forEach(job => {
        const date = new Date(job.completedDate);
        if (isNaN(date.getTime())) return;
        const key = getPeriodKey(date, viewPeriod);
        const weight = job.items.reduce((sum: number, item: any) => 
          sum + parseFloat(item.weightKg || '0'), 0
        );
        dataMap.set(key, (dataMap.get(key) || 0) + weight);
      });
      return formatData(dataMap, viewPeriod, selectedDate);
    } catch (err) {
      console.error('Error calculating completedData:', err);
      return [];
    }
  }, [jobs, viewPeriod, selectedDate]);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#3B82F6" />
        <Text style={styles.loadingText}>Loading comparison data...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Ionicons name="alert-circle" size={48} color="#EF4444" />
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }

  return (
    <View>
      <View style={styles.periodSelector}>
        <TouchableOpacity
          style={[styles.periodButton, viewPeriod === 'daily' && styles.periodButtonActive]}
          onPress={() => setViewPeriod('daily')}
        >
          <Text style={[styles.periodText, viewPeriod === 'daily' && styles.periodTextActive]}>Daily</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.periodButton, viewPeriod === 'weekly' && styles.periodButtonActive]}
          onPress={() => setViewPeriod('weekly')}
        >
          <Text style={[styles.periodText, viewPeriod === 'weekly' && styles.periodTextActive]}>Weekly</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.periodButton, viewPeriod === 'monthly' && styles.periodButtonActive]}
          onPress={() => setViewPeriod('monthly')}
        >
          <Text style={[styles.periodText, viewPeriod === 'monthly' && styles.periodTextActive]}>Monthly</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.periodButton, viewPeriod === 'yearly' && styles.periodButtonActive]}
          onPress={() => setViewPeriod('yearly')}
        >
          <Text style={[styles.periodText, viewPeriod === 'yearly' && styles.periodTextActive]}>Yearly</Text>
        </TouchableOpacity>
      </View>

      <MetricSection
        title="Daily Kgs Received"
        data={receivedData}
        expanded={expandedReceived}
        onToggle={() => setExpandedReceived(!expandedReceived)}
        color="#10B981"
      />

      <MetricSection
        title="Finishing Kgs"
        data={finishingData}
        expanded={expandedFinishing}
        onToggle={() => setExpandedFinishing(!expandedFinishing)}
        color="#F59E0B"
      />

      <MetricSection
        title="Completed Kgs"
        data={completedData}
        expanded={expandedCompleted}
        onToggle={() => setExpandedCompleted(!expandedCompleted)}
        color="#3B82F6"
      />
    </View>
  );
}

function MetricSection({ title, data, expanded, onToggle, color }: any) {
  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.header} onPress={onToggle} activeOpacity={0.7}>
        <Text style={styles.title}>{title}</Text>
        <Ionicons name={expanded ? "chevron-up" : "chevron-down"} size={24} color="#6B7280" />
      </TouchableOpacity>

      {expanded && (
        <ScrollView style={styles.list}>
          {data.map((item: any, idx: number) => (
            <View key={idx} style={styles.dayCard}>
              <Text style={styles.dayDate}>{item.label}</Text>
              <Text style={[styles.dayWeight, { color }]}>{item.weight.toFixed(1)} kg</Text>
            </View>
          ))}
          {data.length === 0 && (
            <Text style={styles.emptyText}>No data available</Text>
          )}
        </ScrollView>
      )}
    </View>
  );
}

function getPeriodKey(date: Date, period: ViewPeriod): string {
  if (period === 'daily') {
    return date.toISOString().split('T')[0];
  } else if (period === 'weekly') {
    const week = getISOWeek(date);
    const year = date.getFullYear();
    return `${year}-W${week}`;
  } else if (period === 'monthly') {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
  } else {
    return String(date.getFullYear());
  }
}

function formatData(dataMap: Map<string, number>, period: ViewPeriod, selectedDate: Date | null) {
  let data = Array.from(dataMap.entries())
    .map(([key, weight]) => ({ 
      label: formatLabel(key, period), 
      weight,
      sortKey: key 
    }))
    .sort((a, b) => b.sortKey.localeCompare(a.sortKey));

  if (selectedDate && period === 'daily') {
    const dateKey = selectedDate.toISOString().split('T')[0];
    data = data.filter(d => d.sortKey === dateKey);
  } else {
    data = data.slice(0, 30);
  }

  return data;
}

function formatLabel(key: string, period: ViewPeriod): string {
  if (period === 'daily') {
    return new Date(key).toLocaleDateString('en-GB', { 
      weekday: 'short', day: 'numeric', month: 'short', year: 'numeric'
    });
  } else if (period === 'weekly') {
    return key;
  } else if (period === 'monthly') {
    const [year, month] = key.split('-');
    return new Date(parseInt(year), parseInt(month) - 1).toLocaleDateString('en-GB', { 
      month: 'short', year: 'numeric'
    });
  } else {
    return key;
  }
}

function getISOWeek(date: Date): number {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() + 4 - (d.getDay() || 7));
  const yearStart = new Date(d.getFullYear(), 0, 1);
  return Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
}

const styles = StyleSheet.create({
  loadingContainer: { padding: 40, alignItems: 'center', backgroundColor: 'white', borderRadius: 12, marginBottom: 16 },
  loadingText: { marginTop: 12, fontSize: 14, color: '#6B7280' },
  errorContainer: { padding: 40, alignItems: 'center', backgroundColor: 'white', borderRadius: 12, marginBottom: 16 },
  errorText: { marginTop: 12, fontSize: 14, color: '#EF4444', textAlign: 'center' },
  periodSelector: { flexDirection: 'row', marginBottom: 16, backgroundColor: 'white', borderRadius: 8, padding: 4 },
  periodButton: { flex: 1, paddingVertical: 8, paddingHorizontal: 8, borderRadius: 6, alignItems: 'center' },
  periodButtonActive: { backgroundColor: '#3B82F6' },
  periodText: { fontSize: 13, fontWeight: '600', color: '#6B7280' },
  periodTextActive: { color: 'white' },
  container: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title: { fontSize: 18, fontWeight: 'bold', color: '#1F2937' },
  list: { maxHeight: 400, marginTop: 12 },
  dayCard: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  dayDate: { fontSize: 14, color: '#374151', fontWeight: '500' },
  dayWeight: { fontSize: 16, fontWeight: 'bold' },
  emptyText: { textAlign: 'center', color: '#9CA3AF', marginTop: 20, fontSize: 14 },
});
