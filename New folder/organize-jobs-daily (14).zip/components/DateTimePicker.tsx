import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Modal } from 'react-native';

type DateTimePickerProps = {
  value?: Date;
  onChange?: (date: Date) => void;
  onClose?: () => void;
  mode?: 'date' | 'datetime';
} | {
  selectedDay: number;
  selectedMonth: number;
  selectedYear: number;
  selectedHour: number;
  selectedMinute: number;
  onDayChange: (day: number) => void;
  onMonthChange: (month: number) => void;
  onYearChange: (year: number) => void;
  onHourChange: (hour: number) => void;
  onMinuteChange: (minute: number) => void;
};

export default function DateTimePicker(props: DateTimePickerProps) {
  // Check if using new interface
  const isNewInterface = 'value' in props && props.value !== undefined;
  
  const initialDate = isNewInterface ? props.value : new Date();
  const [selectedDay, setSelectedDay] = useState(initialDate.getDate());
  const [selectedMonth, setSelectedMonth] = useState(initialDate.getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(initialDate.getFullYear());
  const [selectedHour, setSelectedHour] = useState(initialDate.getHours());
  const [selectedMinute, setSelectedMinute] = useState(initialDate.getMinutes());

  const mode = isNewInterface && 'mode' in props ? props.mode : 'datetime';

  const days = Array.from({ length: 31 }, (_, i) => i + 1);
  const months = Array.from({ length: 12 }, (_, i) => i + 1);
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 10 }, (_, i) => currentYear - 5 + i);
  const hours = Array.from({ length: 24 }, (_, i) => i);
  const minutes = Array.from({ length: 60 }, (_, i) => i);

  const dayScrollRef = useRef<ScrollView>(null);
  const monthScrollRef = useRef<ScrollView>(null);
  const yearScrollRef = useRef<ScrollView>(null);
  const hourScrollRef = useRef<ScrollView>(null);
  const minuteScrollRef = useRef<ScrollView>(null);

  useEffect(() => {
    setTimeout(() => {
      const day = isNewInterface ? selectedDay : (props as any).selectedDay;
      const month = isNewInterface ? selectedMonth : (props as any).selectedMonth;
      const year = isNewInterface ? selectedYear : (props as any).selectedYear;
      const hour = isNewInterface ? selectedHour : (props as any).selectedHour;
      const minute = isNewInterface ? selectedMinute : (props as any).selectedMinute;

      dayScrollRef.current?.scrollTo({ y: (day - 1) * 44, animated: false });
      monthScrollRef.current?.scrollTo({ y: (month - 1) * 44, animated: false });
      yearScrollRef.current?.scrollTo({ y: years.indexOf(year) * 44, animated: false });
      hourScrollRef.current?.scrollTo({ y: hour * 44, animated: false });
      minuteScrollRef.current?.scrollTo({ y: minute * 44, animated: false });
    }, 100);
  }, []);

  const handleDayChange = (day: number) => {
    setSelectedDay(day);
    if (!isNewInterface) (props as any).onDayChange(day);
  };

  const handleMonthChange = (month: number) => {
    setSelectedMonth(month);
    if (!isNewInterface) (props as any).onMonthChange(month);
  };

  const handleYearChange = (year: number) => {
    setSelectedYear(year);
    if (!isNewInterface) (props as any).onYearChange(year);
  };

  const handleHourChange = (hour: number) => {
    setSelectedHour(hour);
    if (!isNewInterface) (props as any).onHourChange(hour);
  };

  const handleMinuteChange = (minute: number) => {
    setSelectedMinute(minute);
    if (!isNewInterface) (props as any).onMinuteChange(minute);
  };

  const handleConfirm = () => {
    if (isNewInterface && props.onChange) {
      const newDate = new Date(selectedYear, selectedMonth - 1, selectedDay, selectedHour, selectedMinute);
      props.onChange(newDate);
      if (props.onClose) {
        props.onClose();
      }
    }
  };


  const content = (
    <View style={styles.container}>
      <Text style={styles.label}>Date</Text>
      <View style={styles.dateRow}>
        <View style={styles.pickerContainer}>
          <Text style={styles.pickerLabel}>Day</Text>
          <ScrollView ref={dayScrollRef} style={styles.picker} showsVerticalScrollIndicator={false}>
            {days.map(d => (
              <TouchableOpacity key={d} onPress={() => handleDayChange(d)} style={[styles.option, selectedDay === d && styles.selectedOption]}>
                <Text style={[styles.optionText, selectedDay === d && styles.selectedText]}>{d.toString().padStart(2, '0')}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        <View style={styles.pickerContainer}>
          <Text style={styles.pickerLabel}>Month</Text>
          <ScrollView ref={monthScrollRef} style={styles.picker} showsVerticalScrollIndicator={false}>
            {months.map(m => (
              <TouchableOpacity key={m} onPress={() => handleMonthChange(m)} style={[styles.option, selectedMonth === m && styles.selectedOption]}>
                <Text style={[styles.optionText, selectedMonth === m && styles.selectedText]}>{m.toString().padStart(2, '0')}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        <View style={styles.pickerContainer}>
          <Text style={styles.pickerLabel}>Year</Text>
          <ScrollView ref={yearScrollRef} style={styles.picker} showsVerticalScrollIndicator={false}>
            {years.map(y => (
              <TouchableOpacity key={y} onPress={() => handleYearChange(y)} style={[styles.option, selectedYear === y && styles.selectedOption]}>
                <Text style={[styles.optionText, selectedYear === y && styles.selectedText]}>{y}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      </View>
      {mode === 'datetime' && (
        <>
          <Text style={styles.label}>Time</Text>
          <View style={styles.dateRow}>
            <View style={[styles.pickerContainer, { flex: 1 }]}>
              <Text style={styles.pickerLabel}>Hour</Text>
              <ScrollView ref={hourScrollRef} style={styles.picker} showsVerticalScrollIndicator={false}>
                {hours.map(h => (
                  <TouchableOpacity key={h} onPress={() => handleHourChange(h)} style={[styles.option, selectedHour === h && styles.selectedOption]}>
                    <Text style={[styles.optionText, selectedHour === h && styles.selectedText]}>{h.toString().padStart(2, '0')}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>
            <View style={[styles.pickerContainer, { flex: 1 }]}>
              <Text style={styles.pickerLabel}>Minute</Text>
              <ScrollView ref={minuteScrollRef} style={styles.picker} showsVerticalScrollIndicator={false}>
                {minutes.map(m => (
                  <TouchableOpacity key={m} onPress={() => handleMinuteChange(m)} style={[styles.option, selectedMinute === m && styles.selectedOption]}>
                    <Text style={[styles.optionText, selectedMinute === m && styles.selectedText]}>{m.toString().padStart(2, '0')}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>
          </View>
        </>
      )}
      {isNewInterface && (
        <View style={styles.buttonRow}>
          <TouchableOpacity style={[styles.button, styles.cancelButton]} onPress={props.onClose}>
            <Text style={styles.cancelButtonText}>Cancel</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.button, styles.confirmButton]} onPress={handleConfirm}>
            <Text style={styles.confirmButtonText}>Confirm</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );

  if (isNewInterface) {
    return (
      <Modal visible transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            {content}
          </View>
        </View>
      </Modal>
    );
  }

  return content;
}

const styles = StyleSheet.create({
  container: { marginBottom: 16 },
  label: { fontSize: 16, fontWeight: '600', color: '#374151', marginBottom: 8 },
  dateRow: { flexDirection: 'row', gap: 8, marginBottom: 16 },
  pickerContainer: { flex: 1 },
  pickerLabel: { fontSize: 12, color: '#6B7280', marginBottom: 4, textAlign: 'center' },
  picker: { maxHeight: 120, borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, backgroundColor: '#F9FAFB' },
  option: { padding: 10, alignItems: 'center' },
  selectedOption: { backgroundColor: '#3B82F6' },
  optionText: { fontSize: 16, color: '#374151' },
  selectedText: { color: 'white', fontWeight: 'bold' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: 'white', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, maxHeight: '70%' },
  buttonRow: { flexDirection: 'row', gap: 12, marginTop: 16 },
  button: { flex: 1, padding: 14, borderRadius: 8, alignItems: 'center' },
  cancelButton: { backgroundColor: '#F3F4F6' },
  confirmButton: { backgroundColor: '#3B82F6' },
  cancelButtonText: { fontSize: 16, fontWeight: '600', color: '#374151' },
  confirmButtonText: { fontSize: 16, fontWeight: '600', color: 'white' },
});
