import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Modal, ScrollView, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../app/lib/supabase';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';
import { getAllUserIds, getUsernameFromId } from '@/utils/userMapping';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ALLOWED_TASK_USERS } from '../contexts/TaskContext';

interface ComposeMessageModalProps {
  visible: boolean;
  onClose: () => void;
}

const DRAFT_KEY = 'compose_message_draft';

interface DraftData {
  recipients: string[];
  title: string;
  message: string;
  priority: 'normal' | 'high' | 'urgent';
  savedAt: number;
}

export default function ComposeMessageModal({ visible, onClose }: ComposeMessageModalProps) {
  const { user } = usePasswordAuth();
  const [recipients, setRecipients] = useState<string[]>([]);
  const [allUsers, setAllUsers] = useState<any[]>([]);
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [priority, setPriority] = useState<'normal' | 'high' | 'urgent'>('normal');
  const [sending, setSending] = useState(false);
  const [selectAll, setSelectAll] = useState(false);
  const [showDraftIndicator, setShowDraftIndicator] = useState(false);
  const [hasDraft, setHasDraft] = useState(false);

  // Check if user is allowed to use draft feature
  const canUseDrafts = ALLOWED_TASK_USERS.includes(user?.username || '');

  useEffect(() => {
    if (visible) {
      loadUsers();
      if (canUseDrafts) {
        loadDraft();
      }
    }
  }, [visible, canUseDrafts]);

  // Auto-save draft when form changes
  useEffect(() => {
    if (visible && canUseDrafts && hasFormData()) {
      const timeout = setTimeout(() => {
        saveDraft();
      }, 1000); // Debounce 1 second
      return () => clearTimeout(timeout);
    }
  }, [title, message, recipients, priority, visible]);

  const hasFormData = () => {
    return title.trim() || message.trim() || recipients.length > 0;
  };

  const loadDraft = async () => {
    try {
      const draftStr = await AsyncStorage.getItem(DRAFT_KEY);
      if (draftStr) {
        const draft: DraftData = JSON.parse(draftStr);
        // Only load if draft is less than 24 hours old
        if (Date.now() - draft.savedAt < 24 * 60 * 60 * 1000) {
          setRecipients(draft.recipients || []);
          setTitle(draft.title || '');
          setMessage(draft.message || '');
          setPriority(draft.priority || 'normal');
          setHasDraft(true);
        } else {
          // Clear old draft
          await AsyncStorage.removeItem(DRAFT_KEY);
        }
      }
    } catch (error) {
      console.error('Error loading draft:', error);
    }
  };

  const saveDraft = async () => {
    try {
      const draft: DraftData = {
        recipients,
        title,
        message,
        priority,
        savedAt: Date.now()
      };
      await AsyncStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
      setShowDraftIndicator(true);
      setHasDraft(true);
      setTimeout(() => setShowDraftIndicator(false), 2000);
    } catch (error) {
      console.error('Error saving draft:', error);
    }
  };

  const clearDraft = async () => {
    try {
      await AsyncStorage.removeItem(DRAFT_KEY);
      setHasDraft(false);
    } catch (error) {
      console.error('Error clearing draft:', error);
    }
  };

  const handleClearDraft = () => {
    Alert.alert(
      'Clear Draft',
      'Are you sure you want to clear the saved draft?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Clear', 
          style: 'destructive',
          onPress: async () => {
            await clearDraft();
            resetForm();
          }
        }
      ]
    );
  };

  const resetForm = () => {
    setTitle('');
    setMessage('');
    setRecipients([]);
    setSelectAll(false);
    setPriority('normal');
    setHasDraft(false);
  };

  const loadUsers = () => {
    // Load password auth users from userMapping
    const userIds = getAllUserIds();
    // Deduplicate user IDs (Admin and admin map to same ID)
    const uniqueUserIds = Array.from(new Set(userIds));
    const users = uniqueUserIds.map(id => ({
      id,
      username: getUsernameFromId(id),
      full_name: getUsernameFromId(id),
      role: getUsernameFromId(id)?.toLowerCase()
    }));
    setAllUsers(users);
  };



  const toggleRecipient = (userId: string) => {
    setRecipients(prev => 
      prev.includes(userId) ? prev.filter(id => id !== userId) : [...prev, userId]
    );
  };

  const toggleSelectAll = () => {
    if (selectAll) {
      setRecipients([]);
    } else {
      setRecipients(allUsers.map(u => u.id));
    }
    setSelectAll(!selectAll);
  };

  const sendMessage = async () => {
    if (!title.trim() || !message.trim()) {
      Alert.alert('Error', 'Please enter title and message');
      return;
    }
    if (recipients.length === 0) {
      Alert.alert('Error', 'Please select at least one recipient');
      return;
    }

    setSending(true);
    try {
      console.log('Sending message from user:', user?.id);
      console.log('Recipients:', recipients);
      
      // Check each recipient's notification permissions before sending
      const eligibleRecipients: string[] = [];
      const skippedRecipients: string[] = [];
      
      for (const userId of recipients) {
        try {
          const { data: profileData, error: profileError } = await supabase
            .from('profiles')
            .select('notification_permissions')
            .eq('id', userId)
            .single();
          
          if (profileError) {
            console.log(`Could not fetch permissions for ${userId}, allowing notification`);
            eligibleRecipients.push(userId);
            continue;
          }
          
          const perms = profileData?.notification_permissions;
          
          // Check if messages permission is explicitly disabled
          if (perms && perms.messages === false) {
            console.log(`User ${userId} has disabled message notifications, skipping`);
            const username = getUsernameFromId(userId);
            skippedRecipients.push(username || userId);
          } else {
            eligibleRecipients.push(userId);
          }
        } catch (err) {
          console.error(`Error checking permissions for ${userId}:`, err);
          // On error, allow the notification (fail open)
          eligibleRecipients.push(userId);
        }
      }
      
      if (eligibleRecipients.length === 0) {
        Alert.alert(
          'No Recipients', 
          `All selected recipients have disabled message notifications:\n${skippedRecipients.join(', ')}`
        );
        setSending(false);
        return;
      }
      
      const notifications = eligibleRecipients.map(userId => ({
        user_id: userId,
        sender_id: user?.id,
        title,
        message,
        type: 'message',
        priority,
        read: false
      }));

      console.log('Notifications to insert:', notifications);

      const { data, error } = await supabase.from('notifications').insert(notifications).select();
      
      if (error) {
        console.error('Insert error:', error);
        throw error;
      }

      console.log('Insert successful:', data);
      
      let successMessage = `Message sent to ${eligibleRecipients.length} user(s)`;
      if (skippedRecipients.length > 0) {
        successMessage += `\n\nSkipped ${skippedRecipients.length} user(s) who disabled messages:\n${skippedRecipients.join(', ')}`;
      }
      
      // Clear draft on successful send
      await clearDraft();
      
      Alert.alert('Success', successMessage);
      resetForm();
      onClose();
    } catch (error) {
      console.error('Error sending message:', error);
      Alert.alert('Error', 'Failed to send message');
    } finally {
      setSending(false);
    }
  };

  const handleClose = () => {
    // Don't clear draft on close - keep it for later
    onClose();
  };




  return (
    <Modal visible={visible} animationType="slide" onRequestClose={handleClose}>
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={handleClose}>
            <Ionicons name="close" size={24} color="#000" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Compose Message</Text>
          {canUseDrafts && showDraftIndicator && (
            <View style={styles.draftIndicator}>
              <Ionicons name="cloud-done" size={14} color="#10B981" />
              <Text style={styles.draftIndicatorText}>Saved</Text>
            </View>
          )}
          {!showDraftIndicator && <View style={{ width: 50 }} />}
        </View>

        {canUseDrafts && hasDraft && (
          <TouchableOpacity style={styles.draftBanner} onPress={handleClearDraft}>
            <Ionicons name="document-text-outline" size={16} color="#3B82F6" />
            <Text style={styles.draftBannerText}>Draft restored from previous session</Text>
            <Ionicons name="close-circle" size={18} color="#6B7280" />
          </TouchableOpacity>
        )}

        <ScrollView style={styles.content}>
          <View style={styles.section}>
            <Text style={styles.label}>Recipients</Text>
            <TouchableOpacity style={styles.selectAllRow} onPress={toggleSelectAll}>
              <Ionicons 
                name={selectAll ? "checkbox" : "square-outline"} 
                size={24} 
                color="#007AFF" 
              />
              <Text style={styles.selectAllText}>Select All ({allUsers.length})</Text>
            </TouchableOpacity>
            <ScrollView style={styles.userList}>
              {allUsers.map(u => (
                <TouchableOpacity 
                  key={u.id} 
                  style={styles.userRow}
                  onPress={() => toggleRecipient(u.id)}
                >
                  <Ionicons 
                    name={recipients.includes(u.id) ? "checkbox" : "square-outline"} 
                    size={24} 
                    color="#007AFF" 
                  />
                  <Text style={styles.userName}>{u.full_name || u.username}</Text>

                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          <View style={styles.section}>
            <Text style={styles.label}>Priority</Text>
            <View style={styles.priorityRow}>
              {['normal', 'high', 'urgent'].map(p => (
                <TouchableOpacity
                  key={p}
                  style={[styles.priorityBtn, priority === p && styles.priorityBtnActive]}
                  onPress={() => setPriority(p as any)}
                >
                  <Text style={[styles.priorityText, priority === p && styles.priorityTextActive]}>
                    {p.toUpperCase()}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.label}>Title</Text>
            <TextInput
              style={styles.input}
              value={title}
              onChangeText={setTitle}
              placeholder="Enter message title"
            />
          </View>

          <View style={styles.section}>
            <Text style={styles.label}>Message</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              value={message}
              onChangeText={setMessage}
              placeholder="Type your message here..."
              multiline
              numberOfLines={8}
              textAlignVertical="top"
            />
          </View>

          <View style={styles.sendButtonContainer}>
            <TouchableOpacity 
              style={[styles.sendButton, sending && styles.sendButtonDisabled]} 
              onPress={sendMessage}
              disabled={sending}
            >
              <Text style={styles.sendButtonText}>
                {sending ? 'Sending...' : 'Send'}
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>

      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderBottomColor: '#e5e7eb' },
  headerTitle: { fontSize: 18, fontWeight: '600' },
  draftIndicator: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#ECFDF5', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  draftIndicatorText: { fontSize: 11, color: '#059669', fontWeight: '500' },
  draftBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#EFF6FF', padding: 12, marginHorizontal: 16, marginTop: 12, borderRadius: 8 },
  draftBannerText: { flex: 1, fontSize: 12, color: '#3B82F6', fontWeight: '500' },
  content: { flex: 1 },
  section: { padding: 16, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  label: { fontSize: 16, fontWeight: '600', marginBottom: 8 },
  selectAllRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, marginBottom: 8 },
  selectAllText: { marginLeft: 8, fontSize: 16, fontWeight: '500' },
  userList: { maxHeight: 200 },
  userRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8 },
  userName: { marginLeft: 8, flex: 1, fontSize: 16 },
  userRole: { fontSize: 12, color: '#6b7280', textTransform: 'capitalize' },
  priorityRow: { flexDirection: 'row', gap: 8 },
  priorityBtn: { flex: 1, padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#e5e7eb', alignItems: 'center' },
  priorityBtnActive: { backgroundColor: '#007AFF', borderColor: '#007AFF' },
  priorityText: { fontSize: 14, fontWeight: '500', color: '#6b7280' },
  priorityTextActive: { color: '#fff' },
  input: { borderWidth: 1, borderColor: '#e5e7eb', borderRadius: 8, padding: 12, fontSize: 16 },
  textArea: { height: 150 },
  sendButtonContainer: { padding: 16, paddingBottom: 32 },
  sendButton: { backgroundColor: '#007AFF', padding: 16, borderRadius: 8, alignItems: 'center' },
  sendButtonDisabled: { backgroundColor: '#ccc' },
  sendButtonText: { color: '#fff', fontSize: 18, fontWeight: '600' },
});

