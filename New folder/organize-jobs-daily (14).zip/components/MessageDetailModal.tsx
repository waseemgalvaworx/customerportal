import React from 'react';
import { View, Text, Modal, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNotifications } from '../contexts/NotificationContext';

interface MessageDetailModalProps {
  visible: boolean;
  onClose: () => void;
  notification: any;
  isSentMessage?: boolean;
}


export default function MessageDetailModal({ visible, onClose, notification, isSentMessage = false }: MessageDetailModalProps) {

  const { archiveNotification, deleteNotification } = useNotifications();

  if (!notification) return null;

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return '#ef4444';
      case 'high': return '#f59e0b';
      default: return '#6b7280';
    }
  };

  const handleArchive = async () => {
    await archiveNotification(notification.id);
    onClose();
  };

  const handleDelete = async () => {
    console.log('🗑️ MessageDetailModal: Delete button clicked for notification:', notification.id);
    try {
      await deleteNotification(notification.id);
      console.log('✅ MessageDetailModal: Delete completed successfully');
      onClose();
    } catch (error) {
      console.error('❌ MessageDetailModal: Delete failed with error:', error);
    }
  };



  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={styles.container}>
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Message Details</Text>
            <TouchableOpacity onPress={onClose}>
              <Ionicons name="close" size={28} color="#000" />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.content}>
            <View style={[styles.priorityBadge, { backgroundColor: getPriorityColor(notification.priority) }]}>
              <Text style={styles.priorityText}>{notification.priority?.toUpperCase()}</Text>
            </View>

            <Text style={styles.title}>{notification.title}</Text>
            
            <Text style={styles.timestamp}>
              {new Date(notification.created_at).toLocaleString()}
            </Text>

            <View style={styles.divider} />

            <Text style={styles.message}>{notification.message}</Text>
          </ScrollView>

          <View style={styles.buttonRow}>
            {!isSentMessage && (
              <>
                <TouchableOpacity style={styles.archiveButton} onPress={handleArchive}>
                  <Ionicons name="archive-outline" size={20} color="#fff" />
                  <Text style={styles.archiveButtonText}>Archive</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.deleteButton} onPress={handleDelete}>
                  <Ionicons name="trash-outline" size={20} color="#fff" />
                  <Text style={styles.deleteButtonText}>Delete</Text>
                </TouchableOpacity>
              </>
            )}
            <TouchableOpacity style={[styles.closeButton, isSentMessage && styles.closeButtonFull]} onPress={onClose}>
              <Text style={styles.closeButtonText}>Close</Text>
            </TouchableOpacity>
          </View>

        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({

  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  container: { backgroundColor: '#fff', borderRadius: 12, maxHeight: '80%', overflow: 'hidden' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderBottomColor: '#e5e7eb' },
  headerTitle: { fontSize: 18, fontWeight: '600' },
  content: { padding: 16 },
  priorityBadge: { alignSelf: 'flex-start', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6, marginBottom: 12 },
  priorityText: { fontSize: 12, color: '#fff', fontWeight: '600' },
  title: { fontSize: 20, fontWeight: '600', marginBottom: 8, color: '#111' },
  timestamp: { fontSize: 13, color: '#9ca3af', marginBottom: 16 },
  divider: { height: 1, backgroundColor: '#e5e7eb', marginVertical: 16 },
  message: { fontSize: 16, color: '#374151', lineHeight: 24 },
  buttonRow: { flexDirection: 'row', padding: 16, gap: 12 },
  archiveButton: { flex: 1, backgroundColor: '#6b7280', padding: 16, borderRadius: 8, alignItems: 'center', flexDirection: 'row', justifyContent: 'center', gap: 8 },
  archiveButtonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  deleteButton: { flex: 1, backgroundColor: '#ef4444', padding: 16, borderRadius: 8, alignItems: 'center', flexDirection: 'row', justifyContent: 'center', gap: 8 },
  deleteButtonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  closeButton: { flex: 1, backgroundColor: '#007AFF', padding: 16, borderRadius: 8, alignItems: 'center' },
  closeButtonFull: { flex: 2 },
  closeButtonText: { color: '#fff', fontSize: 16, fontWeight: '600' },

});
