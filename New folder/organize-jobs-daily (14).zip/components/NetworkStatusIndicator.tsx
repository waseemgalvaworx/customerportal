import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { getPendingChanges, refreshOnlineStatus, clearPendingChanges } from '../utils/offlineCache';
import { syncPendingChanges } from '../utils/offlineSync';
import { supabase } from '../app/lib/supabase';

type ConnectionStatus = 'good' | 'slow' | 'offline';

const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL || 'https://obtmrrbajlrdnmnfhcas.supabase.co';
const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '';

export const NetworkStatusIndicator: React.FC = () => {
  const [status, setStatus] = useState<ConnectionStatus>('good');
  const [pendingCount, setPendingCount] = useState(0);
  const [showDetails, setShowDetails] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    checkConnection();
    const interval = setInterval(checkConnection, 10000);
    return () => clearInterval(interval);
  }, []);

  // Auto-sync when online and have pending changes
  useEffect(() => {
    if (status === 'good' && pendingCount > 0 && !isSyncing) {
      handleSync();
    }
  }, [status, pendingCount]);

  const checkConnection = async () => {
    const pending = await getPendingChanges();
    setPendingCount(pending.length);

    try {
      const start = Date.now();
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);
      
      const response = await fetch(`${SUPABASE_URL}/rest/v1/`, {
        method: 'HEAD',
        headers: { 'apikey': SUPABASE_ANON_KEY },
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      const latency = Date.now() - start;

      if (!response.ok) {
        setStatus('offline');
      } else if (latency > 2000) {
        setStatus('slow');
      } else {
        setStatus('good');
      }
    } catch (error) {
      console.log('Network check failed:', error);
      setStatus('offline');
    }
  };

  const handleSync = useCallback(async () => {
    if (isSyncing) return;
    
    setIsSyncing(true);
    console.log('🔄 Starting manual sync...');
    
    try {
      const result = await syncPendingChanges();
      console.log(`✅ Sync result: ${result.synced} synced, ${result.failed} failed`);
      
      // Refresh pending count
      const pending = await getPendingChanges();
      setPendingCount(pending.length);
      
      if (result.failed === 0 && result.synced > 0) {
        Alert.alert('Sync Complete', `${result.synced} change(s) synced successfully.`);
      } else if (result.failed > 0) {
        Alert.alert('Sync Partial', `${result.synced} synced, ${result.failed} failed. Will retry.`);
      }
    } catch (error) {
      console.error('Sync error:', error);
      Alert.alert('Sync Failed', 'Could not sync changes. Please check your connection.');
    } finally {
      setIsSyncing(false);
    }
  }, [isSyncing]);

  const handleClearPending = () => {
    Alert.alert(
      'Clear Pending Changes?',
      'This will discard all unsaved changes. This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Clear', style: 'destructive', onPress: async () => {
          await clearPendingChanges();
          setPendingCount(0);
          setShowDetails(false);
        }}
      ]
    );
  };

  const getColor = () => status === 'good' ? '#10b981' : status === 'slow' ? '#f59e0b' : '#ef4444';
  const getText = () => status === 'good' ? 'Online' : status === 'slow' ? 'Slow' : 'Offline';

  return (
    <View>
      <TouchableOpacity onPress={() => setShowDetails(!showDetails)}>
        <View style={styles.container}>
          <View style={[styles.dot, { backgroundColor: getColor() }]} />
          <Text style={styles.text}>{getText()}</Text>
          {pendingCount > 0 && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{pendingCount}</Text>
            </View>
          )}
        </View>
      </TouchableOpacity>
      
      {showDetails && (
        <View style={styles.details}>
          {pendingCount > 0 ? (
            <>
              <Text style={styles.detailsText}>
                {pendingCount} change{pendingCount !== 1 ? 's' : ''} pending
              </Text>
              {status === 'good' && (
                <TouchableOpacity style={styles.syncBtn} onPress={handleSync} disabled={isSyncing}>
                  {isSyncing ? (
                    <ActivityIndicator size="small" color="#fff" />
                  ) : (
                    <Text style={styles.syncBtnText}>Sync Now</Text>
                  )}
                </TouchableOpacity>
              )}
              <TouchableOpacity style={styles.clearBtn} onPress={handleClearPending}>
                <Text style={styles.clearBtnText}>Discard</Text>
              </TouchableOpacity>
            </>
          ) : (
            <Text style={styles.detailsText}>All changes synced</Text>
          )}
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flexDirection: 'row', alignItems: 'center', marginRight: 15 },
  dot: { width: 8, height: 8, borderRadius: 4, marginRight: 6 },
  text: { fontSize: 12, color: '#666', fontWeight: '500' },
  badge: { backgroundColor: '#ef4444', borderRadius: 10, paddingHorizontal: 6, paddingVertical: 2, marginLeft: 6 },
  badgeText: { color: '#fff', fontSize: 10, fontWeight: 'bold' },
  details: { position: 'absolute', top: 30, right: 0, backgroundColor: '#fff', padding: 12, borderRadius: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.25, shadowRadius: 3.84, elevation: 5, minWidth: 150, zIndex: 1000 },
  detailsText: { fontSize: 12, color: '#333', marginBottom: 8 },
  syncBtn: { backgroundColor: '#3B82F6', paddingVertical: 8, paddingHorizontal: 12, borderRadius: 6, alignItems: 'center', marginBottom: 6 },
  syncBtnText: { color: '#fff', fontSize: 12, fontWeight: '600' },
  clearBtn: { backgroundColor: '#F3F4F6', paddingVertical: 6, paddingHorizontal: 12, borderRadius: 6, alignItems: 'center' },
  clearBtnText: { color: '#6B7280', fontSize: 11 }
});
