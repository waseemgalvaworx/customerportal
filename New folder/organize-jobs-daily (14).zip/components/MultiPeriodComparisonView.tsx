import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

type PeriodStats = {
  label: string;
  totalJobs: number;
  totalWeight: number;
  avgTurnaround: number;
};

type MultiPeriodComparisonProps = {
  periods: PeriodStats[];
  title: string;
};

export default function MultiPeriodComparisonView({ periods, title }: MultiPeriodComparisonProps) {
  const maxJobs = Math.max(...periods.map(p => p.totalJobs), 1);
  const maxWeight = Math.max(...periods.map(p => p.totalWeight), 1);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>
      
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={true} 
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
      >
        {periods.map((period, idx) => (
          <View key={idx} style={styles.periodCard}>
            <Text style={styles.periodLabel}>{period.label}</Text>
            
            <View style={styles.statItem}>
              <Text style={styles.statLabel}>Jobs</Text>
              <Text style={styles.statValue}>{period.totalJobs}</Text>
              <View style={styles.barContainer}>
                <View style={[styles.bar, styles.jobsBar, { width: `${(period.totalJobs / maxJobs) * 100}%` }]} />
              </View>
            </View>

            <View style={styles.statItem}>
              <Text style={styles.statLabel}>Weight</Text>
              <Text style={styles.statValue}>{period.totalWeight.toFixed(1)} kg</Text>
              <View style={styles.barContainer}>
                <View style={[styles.bar, styles.weightBar, { width: `${(period.totalWeight / maxWeight) * 100}%` }]} />
              </View>
            </View>

            <View style={styles.statItem}>
              <Text style={styles.statLabel}>Turnaround</Text>
              <Text style={styles.statValue}>{period.avgTurnaround.toFixed(1)} d</Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );

}


const styles = StyleSheet.create({
  container: { marginVertical: 16 },
  title: { fontSize: 18, fontWeight: 'bold', color: '#1F2937', marginBottom: 12 },
  scroll: { marginHorizontal: -16 },
  scrollContent: { paddingHorizontal: 16 },
  periodCard: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginRight: 12, width: 180, minWidth: 180 },
  periodLabel: { fontSize: 14, fontWeight: 'bold', color: '#1F2937', marginBottom: 12, textAlign: 'center' },
  statItem: { marginBottom: 12 },
  statLabel: { fontSize: 11, color: '#6B7280', marginBottom: 2 },
  statValue: { fontSize: 16, fontWeight: 'bold', color: '#1F2937', marginBottom: 4 },
  barContainer: { height: 6, backgroundColor: '#E5E7EB', borderRadius: 3, overflow: 'hidden' },
  bar: { height: '100%', borderRadius: 3 },
  jobsBar: { backgroundColor: '#3B82F6' },
  weightBar: { backgroundColor: '#10B981' },
});

