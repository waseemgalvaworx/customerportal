# Cleanup Duplicate Finishing Records

## Problem
Duplicate finishing records were being created when items were moved to "Finishing" status multiple times on the same day.

## Solution Applied
The code has been updated to check for existing records before inserting new ones, preventing future duplicates.

## Cleanup Existing Duplicates

Run this SQL in your Supabase SQL Editor to remove existing duplicate records:

```sql
-- Remove duplicate finishing records, keeping only the first occurrence
DELETE FROM finishing_records
WHERE id IN (
  SELECT id
  FROM (
    SELECT id,
           ROW_NUMBER() OVER (
             PARTITION BY item_id, recorded_date 
             ORDER BY id
           ) AS row_num
    FROM finishing_records
  ) t
  WHERE row_num > 1
);
```

## Verify Cleanup

After running the cleanup, verify no duplicates remain:

```sql
-- Check for any remaining duplicates
SELECT item_id, recorded_date, COUNT(*) as count
FROM finishing_records
GROUP BY item_id, recorded_date
HAVING COUNT(*) > 1;
```

If this returns no rows, all duplicates have been removed.

## Optional: Add Database Constraint

To prevent duplicates at the database level, you can add a unique constraint:

```sql
-- Add unique constraint to prevent future duplicates
ALTER TABLE finishing_records 
ADD CONSTRAINT unique_item_per_day 
UNIQUE (item_id, recorded_date);
```

This ensures the database itself prevents duplicate records, even if the app logic fails.
