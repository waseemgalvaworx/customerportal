# Finishing Report Duplication Fix

## Issue Reported
The Finishing Report in Statistics was showing duplicated data with unrealistic values after recent changes.

## Root Cause Analysis

### Problem Identified
The `DailyFinishingKgsView.tsx` and `MetricsComparisonView.tsx` components were fetching data from TWO sources:
1. **`finishing_records`** table - Active/current finishing records
2. **`archived_finishing_reports`** table - Archived finishing reports

When combining these datasets, the code was NOT properly deduplicating records based on `item_id`. This caused:
- The same item to be counted TWICE if it appeared in both tables
- Inflated/unrealistic weight totals
- Historical data appearing duplicated

### Why This Happened
1. When records are archived, they are moved to `archived_finishing_reports` as JSONB
2. The archive process deletes records from `finishing_records` for TODAY only
3. However, if there were any records that weren't properly cleaned up, or if the same `item_id` appeared in multiple archived reports, the data would be duplicated when combined

## Fix Applied

### Changes to `components/DailyFinishingKgsView.tsx`
- Implemented proper deduplication using a `Map` keyed by `item_id`
- Active records take priority over archived records (if same item exists in both)
- For records without `item_id`, uses a composite key: `job_number-item_description-date`
- Added validation to skip invalid dates and weights
- Added logging to show breakdown of active vs archived records

### Changes to `components/MetricsComparisonView.tsx`
- Same deduplication logic applied
- Active records take priority over archived records
- Proper handling of records with and without `item_id`
- Added validation for dates and weights

## Deduplication Logic

```javascript
// Use a Map to deduplicate by item_id
const recordsByItemId = new Map<string, any>();

// Process active records first (they take priority)
activeRecords.forEach(record => {
  const itemId = record.item_id;
  if (itemId) {
    // Only add if not already present, or if this record is more recent
    if (!recordsByItemId.has(itemId) || recordDate > existingDate) {
      recordsByItemId.set(itemId, record);
    }
  }
});

// Process archived records - only add if item_id doesn't already exist
archivedRecords.forEach(record => {
  const itemId = record.item_id;
  if (itemId && !recordsByItemId.has(itemId)) {
    recordsByItemId.set(itemId, record);
  }
});
```

## Verification
After the fix, the console will log:
- Total active records count
- Total archived records count  
- Total deduplicated records count
- Breakdown showing how many came from each source

## Date: December 8, 2025
