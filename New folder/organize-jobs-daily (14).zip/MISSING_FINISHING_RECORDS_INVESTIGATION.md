# Missing Finishing Records Investigation

## Issue Summary
**Date Range:** 03/12/2025 - 05/12/2025

Jobs were processed and marked 'Ready' but their finishing records were never created when they moved to 'Finishing' status.

### Affected Jobs (Complete Jobs - No Finishing Records)
```
157644, 157653, 157571, 157577, 157592, 157596, 157597, 157599, 
157600, 157603, 157608, 157610, 157615, 157617, 157621, 157630, 157633
```

### Affected Jobs (Partial - Specific Items Missing)
- **157627**: 2 Supp Tube (236.50 kg) + 24 Bracings Pipe (265 kg) + 19 Bracing Tube (141.50 kg) + 8 Triangular Truss (624 kg) + 4 Mplate (20.50 kg)
- **157629**: 6 Metal Shoes (125.50 kg)

---

## Root Cause Analysis

The issue is in `contexts/JobContext.tsx` (lines 849-865 and 958-988):

```typescript
// Fire-and-forget: finishing_records operations
if (status === 'Finishing' && oldStatus !== 'Finishing') {
  const today = new Date().toISOString().split('T')[0];
  supabase.from('finishing_records').delete().eq('item_id', itemId)
    .then(() => {
      supabase.from('finishing_records').insert({...})
        .then(() => {})
        .catch(err => console.error('finishing_records insert error:', err));  // ← ERROR SWALLOWED!
    })
    .catch(err => console.error('finishing_records delete error:', err));
}
```

**The problem:** The `finishing_records` insertion is a **fire-and-forget** operation. If it fails due to:
- Network issues
- RLS policy problems
- Database constraint violations
- Race conditions

...the error is only logged to console and the record is NOT created. The job continues to 'Ready' status without the finishing record.

---

## STEP 1: Verify Jobs Exist and Get Item Details

Run this SQL in Supabase SQL Editor:

```sql
-- Get all items from the affected complete jobs
SELECT 
  j."jobNumber",
  j."customerName",
  j.status as job_status,
  item->>'id' as item_id,
  item->>'descriptionOfWorks' as item_description,
  item->>'weightKg' as weight_kg,
  item->>'status' as item_status,
  item->>'itemCount' as item_count,
  item->>'paintVarnish' as paint_varnish,
  item->>'galva' as galva,
  item->>'lightGalva' as light_galva,
  item->>'lightPaint' as light_paint,
  item->>'rusty' as rusty,
  item->>'doubleDip' as double_dip,
  item->>'multipleDip' as multiple_dip,
  j.id as job_id
FROM jobs j,
  jsonb_array_elements(j.items) as item
WHERE j."jobNumber" IN (
  '157644', '157653', '157571', '157577', '157592', '157596', '157597', '157599', 
  '157600', '157603', '157608', '157610', '157615', '157617', '157621', '157630', '157633'
)
ORDER BY j."jobNumber", item->>'descriptionOfWorks';
```

---

## STEP 2: Check If Finishing Records Exist

```sql
-- Check if any finishing records exist for these jobs
SELECT 
  fr.job_number,
  fr.item_description,
  fr.weight_kg,
  fr.recorded_date,
  fr.created_at
FROM finishing_records fr
WHERE fr.job_number IN (
  '157644', '157653', '157571', '157577', '157592', '157596', '157597', '157599', 
  '157600', '157603', '157608', '157610', '157615', '157617', '157621', '157630', '157633'
)
ORDER BY fr.job_number, fr.item_description;
```

---

## STEP 3: Check If Already Archived

```sql
-- Check if these jobs appear in archived_finishing_reports
SELECT 
  afr.report_date,
  afr.items_data
FROM archived_finishing_reports afr
WHERE afr.report_date BETWEEN '2025-12-03' AND '2025-12-05'
ORDER BY afr.report_date;

-- Or search for specific job numbers in archived data
SELECT 
  afr.report_date,
  item->>'job_number' as job_number,
  item->>'item_description' as item_description,
  item->>'weight_kg' as weight_kg
FROM archived_finishing_reports afr,
  jsonb_array_elements(afr.items_data) as item
WHERE afr.report_date BETWEEN '2025-12-03' AND '2025-12-05'
  AND item->>'job_number' IN (
    '157644', '157653', '157571', '157577', '157592', '157596', '157597', '157599', 
    '157600', '157603', '157608', '157610', '157615', '157617', '157621', '157630', '157633'
  )
ORDER BY afr.report_date, item->>'job_number';
```

---

## STEP 4: Check Activity Logs for Status Changes

```sql
-- Find when items were moved to Finishing status
SELECT 
  al.created_at,
  al.username,
  al.action_type,
  al.action_description,
  al.metadata->>'jobNumber' as job_number,
  al.metadata->>'oldStatus' as old_status,
  al.metadata->>'newStatus' as new_status,
  al.metadata->>'itemDescription' as item_description
FROM activity_logs al
WHERE al.action_type = 'ITEM_STATUS_CHANGED'
  AND al.action_description ILIKE '%to Finishing%'
  AND al.created_at BETWEEN '2025-12-03' AND '2025-12-06'
  AND (
    al.metadata->>'jobNumber' IN (
      '157644', '157653', '157571', '157577', '157592', '157596', '157597', '157599', 
      '157600', '157603', '157608', '157610', '157615', '157617', '157621', '157630', '157633',
      '157627', '157629'
    )
  )
ORDER BY al.created_at;
```

---

## STEP 5: Check Item Stage Tracking

```sql
-- Check item_stage_tracking for these jobs
SELECT 
  j."jobNumber",
  ist.item_id,
  ist.current_stage,
  ist.entry_time,
  ist.ready_date
FROM item_stage_tracking ist
JOIN jobs j ON j.id = ist.job_id
WHERE j."jobNumber" IN (
  '157644', '157653', '157571', '157577', '157592', '157596', '157597', '157599', 
  '157600', '157603', '157608', '157610', '157615', '157617', '157621', '157630', '157633',
  '157627', '157629'
)
ORDER BY j."jobNumber", ist.entry_time;
```

---

## STEP 6: RESTORE MISSING FINISHING RECORDS

### Option A: Insert with Estimated Date (Use 2025-12-04 as middle date)

```sql
-- INSERT MISSING FINISHING RECORDS FOR COMPLETE JOBS
-- Using 2025-12-04 as the recorded_date (middle of the affected period)

INSERT INTO finishing_records (
  job_id, item_id, job_number, customer_name, item_description, 
  weight_kg, recorded_date, item_options
)
SELECT 
  j.id as job_id,
  item->>'id' as item_id,
  j."jobNumber" as job_number,
  j."customerName" as customer_name,
  item->>'descriptionOfWorks' as item_description,
  (item->>'weightKg')::numeric as weight_kg,
  '2025-12-04'::date as recorded_date,
  jsonb_build_object(
    'paintVarnish', COALESCE((item->>'paintVarnish')::boolean, false),
    'galva', COALESCE((item->>'galva')::boolean, false),
    'lightGalva', COALESCE((item->>'lightGalva')::boolean, false),
    'lightPaint', COALESCE((item->>'lightPaint')::boolean, false),
    'rusty', COALESCE((item->>'rusty')::boolean, false),
    'doubleDip', COALESCE((item->>'doubleDip')::boolean, false),
    'multipleDip', COALESCE((item->>'multipleDip')::boolean, false)
  ) as item_options
FROM jobs j,
  jsonb_array_elements(j.items) as item
WHERE j."jobNumber" IN (
  '157644', '157653', '157571', '157577', '157592', '157596', '157597', '157599', 
  '157600', '157603', '157608', '157610', '157615', '157617', '157621', '157630', '157633'
)
-- Avoid duplicates
AND NOT EXISTS (
  SELECT 1 FROM finishing_records fr 
  WHERE fr.item_id = item->>'id'
);
```

### Option B: Insert Specific Missing Items for Job 157627

```sql
-- INSERT MISSING ITEMS FOR JOB 157627
INSERT INTO finishing_records (
  job_id, item_id, job_number, customer_name, item_description, 
  weight_kg, recorded_date, item_options
)
SELECT 
  j.id as job_id,
  item->>'id' as item_id,
  j."jobNumber" as job_number,
  j."customerName" as customer_name,
  item->>'descriptionOfWorks' as item_description,
  (item->>'weightKg')::numeric as weight_kg,
  '2025-12-04'::date as recorded_date,
  jsonb_build_object(
    'paintVarnish', COALESCE((item->>'paintVarnish')::boolean, false),
    'galva', COALESCE((item->>'galva')::boolean, false),
    'lightGalva', COALESCE((item->>'lightGalva')::boolean, false),
    'lightPaint', COALESCE((item->>'lightPaint')::boolean, false),
    'rusty', COALESCE((item->>'rusty')::boolean, false),
    'doubleDip', COALESCE((item->>'doubleDip')::boolean, false),
    'multipleDip', COALESCE((item->>'multipleDip')::boolean, false)
  ) as item_options
FROM jobs j,
  jsonb_array_elements(j.items) as item
WHERE j."jobNumber" = '157627'
  AND (
    item->>'descriptionOfWorks' ILIKE '%Supp Tube%'
    OR item->>'descriptionOfWorks' ILIKE '%Bracings Pipe%'
    OR item->>'descriptionOfWorks' ILIKE '%Bracing Tube%'
    OR item->>'descriptionOfWorks' ILIKE '%Triangular Truss%'
    OR item->>'descriptionOfWorks' ILIKE '%Mplate%'
  )
-- Avoid duplicates
AND NOT EXISTS (
  SELECT 1 FROM finishing_records fr 
  WHERE fr.item_id = item->>'id'
);
```

### Option C: Insert Specific Missing Items for Job 157629

```sql
-- INSERT MISSING ITEMS FOR JOB 157629
INSERT INTO finishing_records (
  job_id, item_id, job_number, customer_name, item_description, 
  weight_kg, recorded_date, item_options
)
SELECT 
  j.id as job_id,
  item->>'id' as item_id,
  j."jobNumber" as job_number,
  j."customerName" as customer_name,
  item->>'descriptionOfWorks' as item_description,
  (item->>'weightKg')::numeric as weight_kg,
  '2025-12-04'::date as recorded_date,
  jsonb_build_object(
    'paintVarnish', COALESCE((item->>'paintVarnish')::boolean, false),
    'galva', COALESCE((item->>'galva')::boolean, false),
    'lightGalva', COALESCE((item->>'lightGalva')::boolean, false),
    'lightPaint', COALESCE((item->>'lightPaint')::boolean, false),
    'rusty', COALESCE((item->>'rusty')::boolean, false),
    'doubleDip', COALESCE((item->>'doubleDip')::boolean, false),
    'multipleDip', COALESCE((item->>'multipleDip')::boolean, false)
  ) as item_options
FROM jobs j,
  jsonb_array_elements(j.items) as item
WHERE j."jobNumber" = '157629'
  AND item->>'descriptionOfWorks' ILIKE '%Metal Shoes%'
-- Avoid duplicates
AND NOT EXISTS (
  SELECT 1 FROM finishing_records fr 
  WHERE fr.item_id = item->>'id'
);
```

---

## STEP 7: Verify Restoration

```sql
-- Verify the records were created
SELECT 
  job_number,
  item_description,
  weight_kg,
  recorded_date,
  created_at
FROM finishing_records
WHERE job_number IN (
  '157644', '157653', '157571', '157577', '157592', '157596', '157597', '157599', 
  '157600', '157603', '157608', '157610', '157615', '157617', '157621', '157630', '157633',
  '157627', '157629'
)
ORDER BY job_number, item_description;

-- Count total items and weight
SELECT 
  COUNT(*) as total_items,
  SUM(weight_kg) as total_weight_kg
FROM finishing_records
WHERE job_number IN (
  '157644', '157653', '157571', '157577', '157592', '157596', '157597', '157599', 
  '157600', '157603', '157608', '157610', '157615', '157617', '157621', '157630', '157633',
  '157627', '157629'
);
```

---

## STEP 8: Archive to Correct Date (Optional)

If you want these records to appear in the Archive for 05/12/2025:

```sql
-- First, check if an archive already exists for that date
SELECT * FROM archived_finishing_reports WHERE report_date = '2025-12-05';

-- If you need to add these items to an existing archive, you'll need to:
-- 1. Fetch the existing items_data
-- 2. Append the new items
-- 3. Update the record

-- Or if creating a new archive entry:
INSERT INTO archived_finishing_reports (report_date, items_data, total_items, total_weight)
SELECT 
  '2025-12-05'::date as report_date,
  jsonb_agg(
    jsonb_build_object(
      'id', fr.id,
      'job_id', fr.job_id,
      'item_id', fr.item_id,
      'job_number', fr.job_number,
      'customer_name', fr.customer_name,
      'item_description', fr.item_description,
      'weight_kg', fr.weight_kg,
      'recorded_date', fr.recorded_date,
      'item_options', fr.item_options
    )
  ) as items_data,
  COUNT(*) as total_items,
  SUM(fr.weight_kg) as total_weight
FROM finishing_records fr
WHERE fr.job_number IN (
  '157644', '157653', '157571', '157577', '157592', '157596', '157597', '157599', 
  '157600', '157603', '157608', '157610', '157615', '157617', '157621', '157630', '157633',
  '157627', '157629'
);
```

---

## Prevention: Code Fix Recommendation

To prevent this issue in the future, the `finishing_records` operations should be awaited instead of fire-and-forget. Here's the recommended fix:

```typescript
// In contexts/JobContext.tsx, change fire-and-forget to awaited operations:

// BEFORE (fire-and-forget - errors swallowed):
if (status === 'Finishing' && oldStatus !== 'Finishing') {
  supabase.from('finishing_records').delete().eq('item_id', itemId)
    .then(() => {
      supabase.from('finishing_records').insert({...})
        .then(() => {}).catch(err => console.error('error:', err));
    });
}

// AFTER (awaited - errors will be caught):
if (status === 'Finishing' && oldStatus !== 'Finishing') {
  try {
    await supabase.from('finishing_records').delete().eq('item_id', itemId);
    const { error } = await supabase.from('finishing_records').insert({...});
    if (error) throw error;
  } catch (err) {
    console.error('finishing_records error:', err);
    // Optionally: show user alert or retry
  }
}
```

---

## Summary

1. **Root Cause**: Fire-and-forget database operations silently failed
2. **Impact**: 17 complete jobs + 2 partial jobs missing finishing records
3. **Solution**: Run the SQL INSERT statements in Step 6 to restore the records
4. **Prevention**: Consider making finishing_records operations awaited instead of fire-and-forget
