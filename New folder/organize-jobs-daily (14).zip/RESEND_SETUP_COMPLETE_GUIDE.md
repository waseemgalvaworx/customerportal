# 🚀 Complete Resend Email Setup Guide

## Current Status
✅ Database migration created (email_settings table)
✅ UI screen created (app/email-settings.tsx)
✅ Settings integration added
✅ Auto-fetch from email from database

## What You Need to Do

### Step 1: Create Resend Account (5 minutes)

1. Go to https://resend.com
2. Click "Sign Up" (free tier: 100 emails/day)
3. Verify your email address
4. Log in to dashboard

---

### Step 2: Get Your Resend API Key (2 minutes)

1. In Resend dashboard, click **API Keys** in sidebar
2. Click **Create API Key**
3. Name it: "Production App"
4. **IMPORTANT**: Copy the key (starts with `re_...`)
5. Save it somewhere safe - you won't see it again!

---

### Step 3: Add API Key to Supabase (3 minutes)

1. Go to: https://app.supabase.com/project/obtmrrbajlrdnmnfhcas
2. Click **Edge Functions** in sidebar
3. Scroll to **Secrets** section
4. Click **Add Secret**
5. Enter:
   - Name: `RESEND_API_KEY`
   - Value: (paste your Resend API key from Step 2)
6. Click **Save**

---

### Step 4: Run Database Migration (1 minute)

Run this in your Supabase SQL Editor:

```sql
-- Already created in: supabase/migrations/create_email_settings_table.sql
-- Just run: supabase db push
```

Or manually in SQL Editor:
1. Go to Supabase Dashboard → SQL Editor
2. Copy content from `supabase/migrations/create_email_settings_table.sql`
3. Click "Run"

---

### Step 5: Create Edge Function (5 minutes)

Create file: `supabase/functions/send-daily-report/index.ts`

```typescript
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { corsHeaders } from '../_shared/cors.ts'

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { recipients, subject, htmlContent, fromEmail } = await req.json()
    
    const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY')
    
    if (!RESEND_API_KEY) {
      throw new Error('RESEND_API_KEY not configured')
    }

    console.log('Sending email from:', fromEmail)
    console.log('To:', recipients)
    console.log('Subject:', subject)

    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${RESEND_API_KEY}`
      },
      body: JSON.stringify({
        from: fromEmail || 'onboarding@resend.dev',
        to: recipients,
        subject: subject,
        html: htmlContent
      })
    })
    
    const data = await res.json()
    
    if (!res.ok) {
      console.error('Resend API error:', data)
      return new Response(JSON.stringify({ 
        error: data.message || 'Failed to send email',
        details: data 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      })
    }

    console.log('Email sent successfully:', data)
    
    return new Response(JSON.stringify(data), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  } catch (error) {
    console.error('Error:', error)
    return new Response(JSON.stringify({ 
      error: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }
})
```

Create CORS helper: `supabase/functions/_shared/cors.ts`

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}
```

Deploy:
```bash
supabase functions deploy send-daily-report
```

---

### Step 6: Test with Default Email (2 minutes)

1. Open your app
2. Go to Settings (password: 1531)
3. Add email recipients
4. Go to Archive
5. Select a report
6. Click "Email Report"
7. Check your inbox!

**Note**: This uses `onboarding@resend.dev` (Resend's test email)

---

### Step 7: Verify Your Domain (Optional, for production)

#### Why verify a domain?
- Professional sender address (reports@yourcompany.com)
- Better deliverability
- No "via resend.dev" label

#### How to verify:

1. **In Resend Dashboard**:
   - Click **Domains**
   - Click **Add Domain**
   - Enter your domain (e.g., `yourcompany.com`)

2. **Add DNS Records** (in your domain registrar):
   
   Resend will show you 3 records to add:
   
   **SPF Record:**
   ```
   Type: TXT
   Name: @
   Value: v=spf1 include:amazonses.com ~all
   ```
   
   **DKIM Records (2 records):**
   ```
   Type: CNAME
   Name: resend._domainkey
   Value: (provided by Resend)
   
   Type: CNAME
   Name: resend2._domainkey
   Value: (provided by Resend)
   ```

3. **Wait for DNS Propagation** (24-48 hours)

4. **Verify in App**:
   - Open app → Settings → Domain Verification
   - Enter your email: `reports@yourcompany.com`
   - Click "Check Verification"
   - If verified ✅, you're done!

---

## Troubleshooting

### Error: "Edge Function returned non-2xx status"

**Possible causes:**
1. API key not set in Supabase
2. Domain not verified (if using custom domain)
3. Invalid email format

**Fix:**
1. Check Supabase Edge Functions → Secrets → RESEND_API_KEY exists
2. Use `onboarding@resend.dev` for testing
3. Check Supabase Edge Functions logs for detailed error

### Error: "Domain not verified"

**Fix:**
1. Wait 24-48 hours after adding DNS records
2. Check DNS propagation: https://dnschecker.org
3. Use `onboarding@resend.dev` for testing

### Error: "Rate limit exceeded"

**Fix:**
- Free tier: 100 emails/day
- Upgrade plan at resend.com

---

## Summary

✅ **What's Done:**
- Database table for email settings
- UI screen for domain verification
- Auto-fetch verified email from database
- Edge function code provided

🔧 **What You Need to Do:**
1. Create Resend account
2. Get API key
3. Add API key to Supabase secrets
4. Create edge function files
5. Deploy edge function
6. Test!

📧 **For Quick Testing:**
Use `onboarding@resend.dev` - no domain verification needed!
