# Supabase Realtime Setup Guide

## Overview
This app now uses Supabase Realtime to sync data instantly across all connected devices. When one user updates a job or customer, all other users see the changes immediately without refreshing.

## Features Implemented

### 1. Real-time Subscriptions
- **Jobs Table**: All job updates (status changes, item updates, etc.) sync instantly
- **Customers Table**: Customer additions, updates, and deletions sync in real-time

### 2. Optimistic UI Updates
- Changes appear instantly in the UI before server confirmation
- If server update fails, UI automatically reverts to previous state
- Provides smooth, responsive user experience

## Enable Realtime in Supabase Dashboard

To activate real-time functionality:

1. Go to your Supabase Dashboard
2. Navigate to **Database** → **Replication**
3. Find the **jobs** table and toggle **Enable Realtime**
4. Find the **customers** table and toggle **Enable Realtime**

Alternatively, run this SQL in the SQL Editor:

```sql
ALTER PUBLICATION supabase_realtime ADD TABLE jobs;
ALTER PUBLICATION supabase_realtime ADD TABLE customers;
```

## How It Works

### Job Updates
When a user:
- Moves a job to Planning/Done/Archive
- Updates item status
- Edits job details
- Deletes a job

All connected devices receive the update instantly via WebSocket connection.

### Customer Updates
When a user:
- Adds a new customer
- Updates customer information
- Deletes a customer

All devices see the changes immediately.

### Optimistic Updates Flow
1. User performs action (e.g., moves job to Done)
2. UI updates immediately (optimistic)
3. Request sent to Supabase
4. If successful: Realtime broadcast confirms change
5. If failed: UI reverts to previous state

## Testing Real-time Sync

1. Open the app on two devices/browsers
2. Sign in on both
3. On Device 1: Move a job to "Done"
4. On Device 2: Watch the job automatically move to Done tab
5. No refresh needed!

## Performance Notes

- Realtime uses WebSocket connections (minimal bandwidth)
- Subscriptions auto-reconnect if connection drops
- Optimistic updates ensure UI feels instant
- Server is source of truth for conflict resolution

## Troubleshooting

**Changes not syncing?**
- Verify Realtime is enabled in Supabase Dashboard
- Check browser console for connection errors
- Ensure both devices have internet connection

**UI reverting unexpectedly?**
- Check for database errors in console
- Verify RLS policies allow the operation
- Ensure user has proper permissions
