# Network Status Indicator

## Overview
A persistent network status indicator in the header that shows connection quality and pending sync changes.

## Features

### Connection Quality Monitoring
- **Good (Green)**: Online with fast connection (< 2s latency)
- **Slow (Orange)**: Online but slow connection (> 2s latency)
- **Offline (Red)**: No connection to database

### Pending Changes Warning
- Shows badge with count of pending changes waiting to sync
- Tap indicator to see details about pending changes
- Automatically updates every 10 seconds
- Real-time updates when network state changes

## Implementation

### Components
- `NetworkStatusIndicator.tsx`: Main component that monitors connection
- Uses `@react-native-community/netinfo` for network state
- Integrates with `offlineCache.ts` to get pending changes count

### Integration
- Added to header right position in `_layout.tsx`
- Visible on all screens except login
- Non-intrusive design that expands on tap

## How It Works

1. **Connection Check**: Every 10 seconds, queries database to measure latency
2. **Pending Changes**: Reads from AsyncStorage to count queued changes
3. **Visual Feedback**: Color-coded dot and text status
4. **Warning Badge**: Red badge shows pending changes count
5. **Details Panel**: Tap to see detailed information

## User Experience
- Always visible in header for constant awareness
- Color-coded for quick status recognition
- Badge alerts users to pending changes
- Tap for more details without blocking workflow
