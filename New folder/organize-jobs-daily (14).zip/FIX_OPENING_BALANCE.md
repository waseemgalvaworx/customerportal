# Fix Opening Balance Issue

## Problem
Inventory reports were showing 0 pcs for opening balance instead of the initial quantity that was input when items were created.

## Root Cause
- New items created after the opening balance feature was implemented correctly have opening balance transactions
- Existing items created before this feature don't have opening balance transactions
- The inventory report calculates opening balance from transactions before the period start date
- Without opening balance transactions, items show 0 opening balance

## Solution Implemented

### 1. Database Migration
Created `supabase/migrations/fix_inventory_opening_balances.sql` that:
- Identifies all inventory items without an "Opening Balance" transaction
- Creates opening balance transactions for these items
- Uses the current item quantity as the opening balance
- Sets transaction timestamp to 1 minute before item creation
- Only processes items with quantity > 0

### 2. How It Works
The migration:
```sql
INSERT INTO inventory_transactions (item_id, transaction_type, quantity, notes, created_at)
SELECT 
  i.id,
  'in' as transaction_type,
  i.quantity,
  'Opening Balance' as notes,
  (i.created_at - INTERVAL '1 minute') as created_at
FROM inventory_items i
WHERE i.quantity > 0
  AND NOT EXISTS (
    SELECT 1 
    FROM inventory_transactions t 
    WHERE t.item_id = i.id 
      AND t.notes = 'Opening Balance'
  );
```

### 3. Future Items
The existing code in `AddInventoryItemModal.tsx` (lines 76-95) ensures all new items automatically get opening balance transactions.

## How to Apply

Run the migration in Supabase:
1. Go to Supabase Dashboard > SQL Editor
2. Copy the contents of `supabase/migrations/fix_inventory_opening_balances.sql`
3. Execute the SQL
4. Verify the opening balances now show correctly in inventory reports

## Verification
After running the migration:
1. Open Inventory screen
2. Click "Report" button
3. Select any period (daily/weekly/monthly)
4. Opening balance should now show the correct initial quantity for all items
5. Check both "All Items" view and individual item views
