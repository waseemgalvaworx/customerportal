# Completed Jobs - Supabase Migration Guide

## Overview
SQL migrations for the `completed_jobs` table used in Archive → Completed Jobs.

---

## 1. Create Table (if not exists)

```sql
CREATE TABLE IF NOT EXISTS public.completed_jobs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  job_id UUID REFERENCES public.jobs(id) ON DELETE CASCADE,
  job_number TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  description TEXT,
  quantity INTEGER,
  item_id TEXT UNIQUE,
  item_description TEXT,
  weight_kg TEXT,
  item_options JSONB,
  completed_at TIMESTAMPTZ DEFAULT NOW(),
  archived_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  delivered BOOLEAN DEFAULT false,
  delivered_at TIMESTAMPTZ,
  delivery_date TIMESTAMPTZ,
  delivery_status TEXT DEFAULT 'undelivered',
  customer_pickup_note TEXT
);
```

---

## 2. Enable RLS & Create Policy

```sql
-- Enable Row Level Security
ALTER TABLE public.completed_jobs ENABLE ROW LEVEL SECURITY;

-- Create permissive policy for all operations
DROP POLICY IF EXISTS "completed_jobs_all_access" ON public.completed_jobs;
CREATE POLICY "completed_jobs_all_access" ON public.completed_jobs 
  FOR ALL USING (true) WITH CHECK (true);
```

---

## 3. Create Indexes

```sql
-- Primary indexes
CREATE INDEX IF NOT EXISTS idx_completed_jobs_job_id ON completed_jobs(job_id);
CREATE INDEX IF NOT EXISTS idx_completed_jobs_job_number ON completed_jobs(job_number);
CREATE INDEX IF NOT EXISTS idx_completed_jobs_item_id ON completed_jobs(item_id);
CREATE INDEX IF NOT EXISTS idx_completed_jobs_completed_at ON completed_jobs(completed_at);
CREATE INDEX IF NOT EXISTS idx_completed_jobs_archived_at ON completed_jobs(archived_at);

-- Delivery indexes
CREATE INDEX IF NOT EXISTS idx_completed_jobs_delivered ON completed_jobs(delivered);
CREATE INDEX IF NOT EXISTS idx_completed_jobs_delivered_at ON completed_jobs(delivered_at);
CREATE INDEX IF NOT EXISTS idx_completed_jobs_delivery_date ON completed_jobs(delivery_date);
CREATE INDEX IF NOT EXISTS idx_completed_jobs_delivery_status ON completed_jobs(delivery_status);

-- Composite index for archive queries
CREATE INDEX IF NOT EXISTS idx_completed_jobs_delivered_archived 
  ON completed_jobs(delivered, archived_at);
```

---

## 4. Verification Queries

```sql
-- Check table structure
SELECT column_name, data_type, column_default, is_nullable
FROM information_schema.columns 
WHERE table_name = 'completed_jobs'
ORDER BY ordinal_position;

-- Check indexes
SELECT indexname, indexdef FROM pg_indexes WHERE tablename = 'completed_jobs';

-- Check RLS status
SELECT relname, relrowsecurity FROM pg_class WHERE relname = 'completed_jobs';

-- Check policies
SELECT policyname, cmd, qual FROM pg_policies WHERE tablename = 'completed_jobs';

-- Check record count
SELECT COUNT(*) as total, 
       SUM(CASE WHEN delivered THEN 1 ELSE 0 END) as delivered_count
FROM completed_jobs;
```

---

## Current Status
- **Total Records**: 1,471
- **Delivered**: 1,327 (90%)
- **Undelivered**: 144 (10%)
- **RLS**: Enabled with permissive policy
- **All indexes**: Created
