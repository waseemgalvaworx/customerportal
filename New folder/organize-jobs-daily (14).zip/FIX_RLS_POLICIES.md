# Fix Archive Functionality - RLS Policies

## Problem
The archive function is failing due to Row Level Security (RLS) policies blocking inserts.

## Solution
Run these SQL commands in your Supabase SQL Editor:

### 1. Fix archived_finishing_reports table

```sql
-- Drop existing restrictive policies
DROP POLICY IF EXISTS "Enable read access for all users" ON public.archived_finishing_reports;
DROP POLICY IF EXISTS "Enable insert for all users" ON public.archived_finishing_reports;
DROP POLICY IF EXISTS "Enable delete for all users" ON public.archived_finishing_reports;

-- Create permissive policies
CREATE POLICY "Allow all operations" ON public.archived_finishing_reports FOR ALL USING (true) WITH CHECK (true);
```

### 2. Create completed_jobs table (if missing)

```sql
-- Create table
CREATE TABLE IF NOT EXISTS public.completed_jobs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  job_id UUID REFERENCES public.jobs(id) ON DELETE CASCADE,
  job_number TEXT,
  customer_name TEXT,
  items JSONB,
  completed_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.completed_jobs ENABLE ROW LEVEL SECURITY;

-- Create policy
CREATE POLICY "Allow all operations" ON public.completed_jobs FOR ALL USING (true) WITH CHECK (true);
```

## How to Apply

1. Go to your Supabase Dashboard
2. Navigate to SQL Editor
3. Copy and paste the SQL commands above
4. Click "Run" to execute
5. Test the archive function again

This will allow all authenticated users to insert, read, and delete from these tables.
