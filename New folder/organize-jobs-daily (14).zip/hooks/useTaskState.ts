import { useEffect, useCallback, useRef, useState } from 'react';
import { useFocusEffect } from 'expo-router';
import { useTasks, ALLOWED_TASK_USERS } from '../contexts/TaskContext';
import { usePasswordAuth } from '../contexts/PasswordAuthContext';

interface TaskConfig {
  route: string;
  title: string;
  icon: string;
  color: string;
}

interface UseTaskStateReturn<T> {
  taskId: string | null;
  savedData: T | null;
  saveTaskData: (data: T, hasUnsavedChanges?: boolean, formType?: string) => void;
  markAsSaved: () => void;
  clearTaskData: () => void;
  isEnabled: boolean;
  lastSavedAt: number | undefined;
  showDraftIndicator: boolean;
}

/**
 * Hook for screens to integrate with the Active Tasks system
 * Only enabled for allowed users (Admin, Lovena, KH)
 * 
 * Usage:
 * ```
 * const { savedData, saveTaskData, markAsSaved, isEnabled, showDraftIndicator } = useTaskState<MyFormData>({
 *   route: '/planning',
 *   title: 'Planning',
 *   icon: 'clipboard',
 *   color: '#6366F1'
 * });
 * 
 * // Restore saved data on mount
 * useEffect(() => {
 *   if (savedData && isEnabled) {
 *     setFormState(savedData);
 *   }
 * }, [savedData, isEnabled]);
 * 
 * // Save data when it changes
 * useEffect(() => {
 *   if (isEnabled) {
 *     saveTaskData({ searchQuery, selectedDate, filters }, true, 'filter');
 *   }
 * }, [searchQuery, selectedDate, filters, isEnabled]);
 * ```
 */
export function useTaskState<T extends Record<string, any>>(
  config: TaskConfig
): UseTaskStateReturn<T> {
  const { user } = usePasswordAuth();
  const { 
    addTask, 
    removeTask, 
    updateTaskData, 
    getTaskData, 
    getTaskByRoute,
    markTaskSaved,
    isUserAllowed,
    getLastSavedTime
  } = useTasks();
  
  const taskIdRef = useRef<string | null>(null);
  const isInitializedRef = useRef(false);
  const [showDraftIndicator, setShowDraftIndicator] = useState(false);

  // Check if user is allowed to use Active Tasks
  const isEnabled = isUserAllowed(user?.username);

  // Register task when screen is focused (only for allowed users)
  useFocusEffect(
    useCallback(() => {
      if (!isEnabled) return;

      // Check if task already exists for this route
      const existingTask = getTaskByRoute(config.route);
      
      if (existingTask) {
        taskIdRef.current = existingTask.id;
      } else {
        // Create new task
        const newTaskId = addTask({
          route: config.route,
          title: config.title,
          icon: config.icon,
          color: config.color,
          formData: {},
          hasUnsavedChanges: false,
        });
        taskIdRef.current = newTaskId;
      }
      
      isInitializedRef.current = true;

      // Cleanup: Don't remove task on blur - keep it active
      return () => {
        // Task persists when navigating away
      };
    }, [config.route, config.title, config.icon, config.color, isEnabled])
  );

  // Get saved data for this task
  const savedData = useCallback((): T | null => {
    if (!isEnabled) return null;
    
    if (!taskIdRef.current) {
      // Try to get from existing task by route
      const existingTask = getTaskByRoute(config.route);
      if (existingTask) {
        return existingTask.formData as T;
      }
      return null;
    }
    return getTaskData(taskIdRef.current) as T | null;
  }, [config.route, getTaskByRoute, getTaskData, isEnabled]);

  // Save task data with optional form type
  const saveTaskData = useCallback((data: T, hasUnsavedChanges: boolean = true, formType?: string) => {
    if (!isEnabled) return;
    
    if (taskIdRef.current) {
      updateTaskData(taskIdRef.current, data, hasUnsavedChanges, formType);
      
      // Show draft indicator briefly
      setShowDraftIndicator(true);
      setTimeout(() => setShowDraftIndicator(false), 2000);
    }
  }, [updateTaskData, isEnabled]);

  // Mark task as saved (no unsaved changes)
  const markAsSaved = useCallback(() => {
    if (!isEnabled) return;
    
    if (taskIdRef.current) {
      markTaskSaved(taskIdRef.current);
    }
  }, [markTaskSaved, isEnabled]);

  // Clear task data and remove task
  const clearTaskData = useCallback(() => {
    if (!isEnabled) return;
    
    if (taskIdRef.current) {
      removeTask(taskIdRef.current);
      taskIdRef.current = null;
    }
  }, [removeTask, isEnabled]);

  // Get last saved time
  const lastSavedAt = taskIdRef.current ? getLastSavedTime(taskIdRef.current) : undefined;

  return {
    taskId: taskIdRef.current,
    savedData: savedData(),
    saveTaskData,
    markAsSaved,
    clearTaskData,
    isEnabled,
    lastSavedAt,
    showDraftIndicator,
  };
}

/**
 * Simplified hook for tracking form state changes
 * Automatically detects changes and marks task as having unsaved changes
 * Only enabled for allowed users (Admin, Lovena, KH)
 */
export function useAutoSaveTask<T extends Record<string, any>>(
  config: TaskConfig,
  formData: T,
  dependencies: any[] = [],
  formType: string = 'form'
) {
  const { user } = usePasswordAuth();
  const isEnabled = ALLOWED_TASK_USERS.includes(user?.username || '');
  
  const { saveTaskData, savedData, markAsSaved, clearTaskData, showDraftIndicator, lastSavedAt } = useTaskState<T>(config);
  const initialDataRef = useRef<T | null>(null);
  const isFirstRenderRef = useRef(true);

  // Store initial data on first render
  useEffect(() => {
    if (!isEnabled) return;
    
    if (isFirstRenderRef.current) {
      initialDataRef.current = savedData || formData;
      isFirstRenderRef.current = false;
    }
  }, [isEnabled]);

  // Auto-save when form data changes
  useEffect(() => {
    if (!isEnabled) return;
    
    if (!isFirstRenderRef.current) {
      // Check if data has changed from initial
      const hasChanges = JSON.stringify(formData) !== JSON.stringify(initialDataRef.current);
      saveTaskData(formData, hasChanges, formType);
    }
  }, [formData, ...dependencies, isEnabled]);

  return {
    savedData,
    markAsSaved,
    clearTaskData,
    isEnabled,
    showDraftIndicator,
    lastSavedAt,
    resetInitialData: () => {
      if (!isEnabled) return;
      initialDataRef.current = formData;
      markAsSaved();
    }
  };
}

export default useTaskState;
