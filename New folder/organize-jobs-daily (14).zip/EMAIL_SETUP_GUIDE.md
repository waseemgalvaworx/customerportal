# 📧 Email Setup Guide with Resend

## Overview
This guide will help you set up email functionality using Resend API to send daily production reports.

## Prerequisites
- A Resend account (sign up at https://resend.com)
- A domain you own (e.g., yourdomain.com)
- Access to your domain's DNS settings

---

## Step 1: Create Resend Account

1. Go to https://resend.com
2. Sign up for a free account
3. Verify your email address

---

## Step 2: Get Your Resend API Key

1. Log in to Resend dashboard
2. Go to **API Keys** section
3. Click **Create API Key**
4. Name it (e.g., "Production App")
5. Copy the API key (starts with `re_...`)
6. **IMPORTANT**: Save this key securely - you won't see it again!

---

## Step 3: Add API Key to Supabase

1. Go to your Supabase project: https://app.supabase.com/project/obtmrrbajlrdnmnfhcas
2. Navigate to **Settings** → **Edge Functions**
3. Scroll to **Secrets**
4. Add a new secret:
   - Name: `RESEND_API_KEY`
   - Value: Your Resend API key (from Step 2)
5. Click **Save**

---

## Step 4: Verify Your Domain

### Option A: Use Resend's Domain (Quick Test)
- For testing, you can use `onboarding@resend.dev` as the sender
- Skip to Step 5

### Option B: Use Your Own Domain (Recommended for Production)

1. In Resend dashboard, go to **Domains**
2. Click **Add Domain**
3. Enter your domain (e.g., `yourdomain.com`)
4. Resend will provide DNS records to add:

   **SPF Record:**
   - Type: TXT
   - Name: @
   - Value: `v=spf1 include:amazonses.com ~all`

   **DKIM Records (2 records):**
   - Type: CNAME
   - Name: (provided by Resend)
   - Value: (provided by Resend)

5. Add these records to your domain's DNS settings
6. Wait 24-48 hours for DNS propagation
7. Click **Verify** in Resend dashboard

---

## Step 5: Configure in App

1. Open the app
2. Go to **Settings** (password: 1531)
3. Tap **Email Settings**
4. Enter your verified sender email (e.g., `reports@yourdomain.com`)
5. Tap **Check Verification Status**
6. If verified, you're ready to send emails!

---

## Step 6: Create Edge Function

Create file: `supabase/functions/send-daily-report/index.ts`

```typescript
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

serve(async (req) => {
  const { recipients, subject, htmlContent, fromEmail } = await req.json()
  
  const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY')
  
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${RESEND_API_KEY}`
    },
    body: JSON.stringify({
      from: fromEmail || 'onboarding@resend.dev',
      to: recipients,
      subject: subject,
      html: htmlContent
    })
  })
  
  const data = await res.json()
  return new Response(JSON.stringify(data), {
    headers: { 'Content-Type': 'application/json' }
  })
})
```

Deploy: `supabase functions deploy send-daily-report`

---

## Troubleshooting

### Error: "Domain not verified"
- Wait 24-48 hours after adding DNS records
- Check DNS propagation: https://dnschecker.org
- Verify records are correct in Resend dashboard

### Error: "Invalid API key"
- Ensure `RESEND_API_KEY` is set in Supabase Edge Functions secrets
- Check the key starts with `re_`

### Error: "Rate limit exceeded"
- Free tier: 100 emails/day
- Upgrade plan in Resend dashboard

---

## Testing

1. Add test recipients in Settings → Email Recipients
2. Go to Archive screen
3. Select a report
4. Tap "Email Report"
5. Check recipient inboxes (including spam folder)
