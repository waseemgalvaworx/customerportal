# 🔑 Get Your Supabase Anon Key - Step by Step

## Quick Steps (2 minutes)

### Step 1: Open Supabase Dashboard
Click this link: [Your Project API Settings](https://app.supabase.com/project/obtmrrbajlrdnmnfhcas/settings/api)

### Step 2: Sign In
- Sign in with your Supabase account
- (If you don't have access, ask the project owner to share the key)

### Step 3: Find the Anon Key
Once logged in, you'll see:
- **Project URL**: `https://obtmrrbajlrdnmnfhcas.supabase.co` ✅ (already configured)
- **Project API keys** section with two keys:
  - `anon` `public` - **THIS IS THE ONE YOU NEED** 👈
  - `service_role` `secret` - (Don't use this one)

### Step 4: Copy the Anon Key
- Click the copy icon next to the `anon public` key
- It looks like: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...` (very long string)

### Step 5: Create .env File
In your project root folder, create a file named `.env` (no extension):

```
EXPO_PUBLIC_SUPABASE_ANON_KEY=paste_your_key_here
```

### Step 6: Restart Your App
```bash
# Stop the current app (Ctrl+C)
# Then restart:
npx expo start
```

---

## ✅ Verify It Works
After restarting, check the console. You should see:
```
✅ Supabase connected successfully
```

If you see ❌ or ⚠️, double-check your .env file.

---

## 🆘 Troubleshooting

**"I don't have access to the Supabase project"**
- Ask the project owner to share the anon key with you
- Or ask them to add you as a team member

**"I created .env but it's not working"**
- Make sure the file is named exactly `.env` (not `.env.txt`)
- Make sure it's in the root folder (same level as package.json)
- Restart the Expo server completely

**"Still not working"**
- Check for typos in `EXPO_PUBLIC_SUPABASE_ANON_KEY`
- Make sure there are no spaces around the `=` sign
- Make sure the key starts with `eyJ`
