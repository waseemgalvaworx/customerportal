# Auto Performance Tracking System

## Overview
The system automatically tracks time spent in each production stage (Workshop, Acid, Galva, Finishing, Ready) without manual data entry.

## How It Works
1. **Automatic Tracking**: When items move between stages, the system records timestamps and calculates duration
2. **Database Storage**: Metrics stored in `performance_metrics` table with job_id, stage, and duration_minutes
3. **Real-Time Analysis**: View bottlenecks and average stage times in Statistics screen

## Implementation
- `utils/performanceTracker.ts`: Core tracking logic
- `contexts/JobContext.tsx`: Integrated into status change functions
- `components/PerformanceMetricsView.tsx`: Display metrics

## Benefits
- Eliminates manual time tracking
- Identifies bottleneck stages automatically
- Provides data-driven insights for process optimization
- Tracks historical performance trends
- Enables accurate delivery time predictions

## Usage
Performance tracking is automatic. View metrics in the Statistics screen to see:
- Average time per stage
- Bottleneck identification
- Overall job completion times
