# Internal Distribution Setup (No App Stores)

Your app is now configured for **internal distribution** - perfect for keeping it private within your company!

## Quick Start

### 1. Install EAS CLI (one-time setup)
```bash
npm install -g eas-cli
```

### 2. Login to Expo
```bash
eas login
```
(Create a free account at expo.dev if you don't have one)

### 3. Build for Android (Easiest - Start Here!)
```bash
eas build --profile preview --platform android
```

This creates an APK file that can be installed on any Android device. You'll get a shareable URL!

### 4. Build for iOS (Requires Apple Developer Account - $99/year)
```bash
# First, register your test devices
eas device:create

# Then build
eas build --profile preview --platform ios
```

## How It Works

- **No App Store Required**: Users install directly from a link
- **Private**: Only people with the link can access
- **Easy Updates**: Just rebuild and share the new link
- **Perfect for**: Internal business apps, beta testing, private tools

## Sharing Your App

After building, EAS gives you a URL like:
`https://expo.dev/artifacts/eas/abc123...`

Share this link with your team - they can install directly!

## Cost

- **Expo Account**: FREE
- **Android Builds**: FREE (unlimited)
- **iOS Builds**: Requires Apple Developer account ($99/year)

## Need Help?

Run `eas build --help` for more options or visit: https://docs.expo.dev/build/introduction/
