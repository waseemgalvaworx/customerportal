# Realtime Subscription Optimization

## Overview

This document describes the optimizations made to reduce database load from realtime subscriptions.

## Changes Made

### 1. Debouncing

All realtime subscriptions now use debouncing to prevent excessive database queries when multiple changes happen in quick succession.

**Implementation:**
- `utils/realtimeHelpers.ts` - Contains `createDebouncedRefresh()` function
- Default debounce delay: 300-500ms
- Batches multiple rapid updates into a single database query

### 2. Selective Subscriptions

Instead of subscribing to entire tables, subscriptions now use filters where possible:

**NotificationContext:**
- Filter: `user_id=eq.${user.id}`
- Only receives notifications for the current user

**InventoryItemsList:**
- Filter: `category=eq.${dbCategory}`
- Only receives updates for the current category view

### 3. Direct State Updates

Instead of fetching all data on every change, realtime handlers now update state directly:

**Before:**
```javascript
.on('postgres_changes', { event: '*', ... }, () => {
  fetchAllData(); // Full database query
})
```

**After:**
```javascript
.on('postgres_changes', { event: 'INSERT', ... }, (payload) => {
  setState(prev => [payload.new, ...prev]); // Direct state update
})
.on('postgres_changes', { event: 'UPDATE', ... }, (payload) => {
  setState(prev => prev.map(item => 
    item.id === payload.new.id ? payload.new : item
  ));
})
.on('postgres_changes', { event: 'DELETE', ... }, (payload) => {
  setState(prev => prev.filter(item => item.id !== payload.old.id));
})
```

### 4. Subscription Cleanup

All subscriptions properly clean up:
- Cancel pending debounced calls
- Remove channels on unmount
- Clear timeouts

## Files Modified

1. **contexts/JobContext.tsx**
   - Added debounced refresh
   - Separate handlers for INSERT/UPDATE/DELETE
   - Direct state updates

2. **contexts/CustomerContext.tsx**
   - Added debounced refresh
   - Separate handlers for INSERT/UPDATE/DELETE
   - Direct state updates

3. **contexts/NotificationContext.tsx**
   - Added debounced fetch
   - User-specific channel name
   - Direct state updates for all events

4. **components/InventoryItemsList.tsx**
   - Added debounced refresh
   - Category-specific subscription filter
   - Reduced unnecessary updates

## New Utilities

### utils/realtimeHelpers.ts

```typescript
// Create a debounced refresh function
createDebouncedRefresh(refreshFn, delayMs)

// Subscribe to specific rows
subscribeToRows(channelName, table, filterColumn, filterValue, onUpdate, events)

// Subscribe to multiple tables with one channel
subscribeToMultipleTables(channelName, tables, onUpdate)

// Subscribe with automatic debouncing
subscribeDebouncedTable(channelName, table, refreshFn, options)
```

### utils/realtimeSubscriptionManager.ts

```typescript
// Subscribe with debouncing and deduplication
subscribeToTable(config, onUpdate, options)

// Get active subscription count
getActiveSubscriptionCount()

// Clean up all subscriptions
cleanupAllSubscriptions()
```

## Performance Impact

- **Reduced WAL queries**: Fewer database queries due to debouncing
- **Lower bandwidth**: Selective subscriptions reduce data transfer
- **Better UX**: Direct state updates provide instant feedback
- **Memory efficiency**: Proper cleanup prevents memory leaks

## Best Practices

1. Always use debouncing for realtime subscriptions
2. Use filters when subscribing to tables
3. Prefer direct state updates over full refreshes
4. Clean up subscriptions on component unmount
5. Use category/user-specific channel names
