# 🏭 Galvanizing Job Tracker

A professional React Native mobile app for tracking galvanizing jobs with real-time synchronization across multiple devices.

## ✨ Key Features

- 📋 **Job Management** - Track jobs through Planning → WIP → Done → Archive stages
- 🔄 **Real-time Sync** - Instant updates across all devices using Supabase Realtime
- 👥 **Customer Management** - Store and manage customer information
- 📊 **Item Status Tracking** - Monitor each item through Workshop → Acid → Galva → Finishing → Ready
- 📄 **PDF Export** - Generate professional job reports
- ⚡ **Optimistic UI** - Instant feedback with automatic rollback on errors
- 🎯 **GalvXpress Priority** - Mark urgent jobs for special handling
- 🗄️ **Auto-Archive** - Automatically archive completed jobs

## 🚀 Quick Start

### Prerequisites
- Node.js v18+
- Expo CLI
- Supabase account

### Installation

1. **Clone and install dependencies:**
   ```bash
   npm install
   ```

2. **Configure Supabase (REQUIRED):**
   
   Copy `.env.example` to `.env` and add your credentials:
   ```bash
   cp .env.example .env
   ```
   
   Edit `.env`:
   ```
   EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
   EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
   ```
   
   Get credentials from: https://app.supabase.com/project/_/settings/api

3. **Enable Realtime in Supabase:**
   See [REALTIME_SETUP.md](./REALTIME_SETUP.md) for detailed instructions

4. **Start the app:**
   ```bash
   npx expo start
   ```

## 📖 Documentation

- [Setup Instructions](./SETUP_INSTRUCTIONS.md) - Complete setup guide
- [Realtime Setup](./REALTIME_SETUP.md) - Enable real-time synchronization
- [Troubleshooting](./TROUBLESHOOTING.md) - Common issues and solutions

## 🛠️ Tech Stack

- **React Native** with Expo
- **TypeScript** for type safety
- **Supabase** for backend and real-time database
- **Expo Router** for navigation
- **React Context** for state management

## 📱 App Structure

- **Jobs** - View and add pending jobs
- **Planning** - Jobs being planned
- **WIP** - Jobs in progress
- **Done** - Completed jobs
- **Archive** - Historical jobs
- **Customers** - Customer management

## 🔧 Troubleshooting

If the "Add Job" button doesn't work, you likely need to configure Supabase credentials. See [TROUBLESHOOTING.md](./TROUBLESHOOTING.md) for solutions.

## 📄 License

MIT
