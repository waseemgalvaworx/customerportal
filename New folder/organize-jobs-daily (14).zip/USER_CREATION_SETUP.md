# User Creation Setup Guide

## Issue: Create User Button Not Working

If the "Create User" button is not working, it's likely due to Supabase email confirmation settings.

## Solution: Disable Email Confirmation

1. Go to your Supabase dashboard: https://app.supabase.com/project/obtmrrbajlrdnmnfhcas/auth/providers

2. Scroll down to "Email Auth" section

3. **DISABLE** the following options:
   - ❌ Confirm email
   - ❌ Secure email change
   
4. Click "Save"

## Alternative: Enable Email Confirmations

If you want to keep email confirmations enabled, you'll need to:

1. Set up an email provider (SMTP) in Supabase
2. Users will receive a confirmation email
3. They must click the link to activate their account

## Testing

After disabling email confirmation:

1. Go to User Management (password: 1531)
2. Click "Add New User"
3. Fill in:
   - Username: testuser
   - Password: test123 (min 6 characters)
   - Full Name: Test User
   - Role: Operator
4. Click "Create User"
5. You should see "User created successfully"

## Troubleshooting

If you still have issues:

1. Check the console logs for detailed error messages
2. Verify your Supabase anon key is configured in .env
3. Check that the profiles table exists with correct columns
4. Ensure RLS policies allow inserting into profiles table

## Database Requirements

The profiles table should have:
- id (uuid, primary key, references auth.users)
- username (text, unique)
- full_name (text)
- role (text)
- is_active (boolean, default true)
