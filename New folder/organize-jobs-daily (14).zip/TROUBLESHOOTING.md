# Troubleshooting Guide - Job Saving Issues

## Problem: "Add Job" Button Does Nothing

If clicking the "Add Job" button does nothing, the most common cause is **missing or invalid Supabase credentials**.

### Quick Fix: Configure Supabase

**Step 1:** Check if you have a `.env` file in your project root
- If not, copy `.env.example` to `.env`

**Step 2:** Add your Supabase credentials to `.env`:
```
EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-actual-anon-key-here
```

**Step 3:** Get your credentials:
1. Go to https://app.supabase.com
2. Select your project
3. Go to Settings → API
4. Copy the "Project URL" and "anon/public" key

**Step 4:** Restart the Expo development server:
```bash
npx expo start -c
```

### Check Console for Errors

Look for these messages in your console:
- ⚠️ "SUPABASE NOT CONFIGURED" - You need to add credentials
- ❌ "Supabase connection error" - Check your credentials are correct
- ✅ "Supabase connected successfully" - Configuration is working!


### 2. Verify Database Table Structure

The `jobs` table must have these columns:
- `id` (uuid, primary key, default: gen_random_uuid())
- `jobNumber` (text)
- `dateOfEntry` (timestamp with time zone)
- `customerName` (text)
- `notes` (text)
- `items` (jsonb)
- `priority` (text, nullable)
- `status` (text)
- `completedDate` (timestamp with time zone, nullable)
- `archivedDate` (timestamp with time zone, nullable)
- `galvaXpress` (boolean, nullable)
- `deliveryDate` (timestamp with time zone, nullable)

### 3. Check Row Level Security (RLS)

Make sure RLS policies allow INSERT operations:
```sql
-- Enable RLS
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;

-- Allow all operations (for development)
CREATE POLICY "Allow all operations" ON jobs FOR ALL USING (true);
```

### 4. Test Connection

Check the console logs when adding a job:
- Open React Native debugger or use `npx expo start` with console output
- Look for "Supabase insert error:" messages
- Verify the error details

### 5. Common Issues

**Issue**: "relation 'jobs' does not exist"
- **Solution**: Create the jobs table using the SQL in SETUP_INSTRUCTIONS.md

**Issue**: "new row violates row-level security policy"
- **Solution**: Disable RLS or add proper policies (see step 3)

**Issue**: "null value in column 'id' violates not-null constraint"
- **Solution**: Ensure the `id` column has default value `gen_random_uuid()`

**Issue**: Jobs appear then disappear
- **Solution**: This was fixed - the realtime subscription now checks for duplicates

### 6. Verify the Fix

The following changes were made to fix job saving:

1. **JobContext.tsx**: 
   - Added proper date formatting (Date → ISO string)
   - Added `.select().single()` to get inserted job back
   - Fixed duplicate prevention in realtime handler
   - Added comprehensive error logging

2. **jobs.tsx**: 
   - Added async/await to handleAddJob
   - Added try/catch error handling
   - Added success/error alerts

### 7. Testing

To test if jobs are being saved:
1. Add a new job through the app
2. Check if you see "Success" alert
3. Refresh the app - job should still be there
4. Check Supabase dashboard → Table Editor → jobs table
5. Verify the job appears in the database

### 8. Still Not Working?

If jobs still aren't saving:
1. Check network connectivity
2. Verify Supabase project is not paused
3. Check Supabase API logs in dashboard
4. Try adding a job directly in Supabase Table Editor
5. Contact support with console error logs
