# EAS Update Setup Guide - Over-The-Air Updates

## What is EAS Update?
EAS Update allows you to push JavaScript, styling, and asset updates to your users instantly without going through app stores. Users will see an "App Updates" section in Settings with a button to check for and install updates.

## Setup Instructions

### 1. Install EAS CLI (if not already installed)
```bash
npm install -g eas-cli
```

### 2. Login to Expo
```bash
eas login
```

### 3. Configure EAS Update
```bash
eas update:configure
```
This will add necessary configuration to your `app.json`.

### 4. Install Required Packages
```bash
npx expo install expo-updates
```

### 5. Build Your App (First Time)
You need to create a production build first:

```bash
# For Android
eas build --platform android --profile production

# For iOS
eas build --platform ios --profile production
```

Download and install this build on your devices.

### 6. Publishing Updates
After making changes to your code, publish an update:

```bash
eas update --auto
```

Or specify a branch:
```bash
eas update --branch production --message "Bug fixes and improvements"
```

## How Users Get Updates

1. Users open the app and go to **Settings**
2. Scroll to the **App Updates** section
3. Tap **Check for Updates**
4. If an update is available, it will download automatically
5. The app will restart to apply the update

## Important Notes

- **Development Mode**: Updates only work in production builds, not in Expo Go or development mode
- **What Can Be Updated**: JavaScript code, styling, images, and other assets
- **What Cannot Be Updated**: Native code changes (requires new app store build)
- **Automatic Updates**: By default, updates are checked when the app starts
- **Manual Check**: Users can manually check via the Settings button

## Publishing Workflow

1. Make your code changes
2. Test thoroughly
3. Run: `eas update --auto`
4. Users will get the update next time they open the app or check manually

## Update Channels

You can create different update channels for testing:

```bash
# Production updates
eas update --branch production

# Staging updates
eas update --branch staging
```

Configure which branch your app uses in `app.json`:
```json
{
  "expo": {
    "updates": {
      "url": "https://u.expo.dev/[your-project-id]",
      "fallbackToCacheTimeout": 0
    },
    "runtimeVersion": {
      "policy": "sdkVersion"
    }
  }
}
```

## Troubleshooting

**Update not showing?**
- Make sure you're using a production build (not Expo Go)
- Check that you published the update to the correct branch
- Verify your app is connected to the internet

**Error checking for updates?**
- Ensure EAS Update is properly configured
- Check your Expo project ID is correct
- Verify network connectivity

## Free Tier Limits
- Expo offers a generous free tier for EAS Update
- Check current limits at: https://expo.dev/pricing

## More Information
- EAS Update Docs: https://docs.expo.dev/eas-update/introduction/
- Publishing Updates: https://docs.expo.dev/eas-update/publish/
