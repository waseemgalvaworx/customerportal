# QC Archive System Flow Documentation

## Overview
The QC Archive system allows users to save quality control checklists and search them by job number.

## Complete Flow Path

### 1. Opening QC Archive from Archive Modal

**Path:**
```
Archive Screen → Archive Modal → QC Archive Button → QCArchiveModal (separate modal)
```

**Code Flow:**
1. User taps "Archive" button on main screen
2. `ArchiveModal.tsx` opens with report type selection
3. User taps "QC Archive" card
4. `handleSelectReportType('qc')` is called in `ArchiveModal.tsx` (line 112-116)
5. Sets `showQCArchive = true`
6. Returns early (does NOT set selectedReportType)
7. `QCArchiveModal` component renders as separate modal (line 146-148)
8. Main ArchiveModal visibility controlled by `visible && !showQCArchive` (line 149)
9. Main modal is hidden while QC Archive modal is shown

**Key Fix Applied:**
- `ArchiveModalMain.tsx` now returns `null` when `selectedReportType === 'qc'` (line 44-47)
- This prevents the date dropdown from showing
- QC Archive has its own search interface

### 2. Saving QC Data from Job Details

**Path:**
```
Job Details → QC Button → Quality Control Modal → Fill Form → Save to QC Archive
```

**Code Flow:**
1. User opens job details page
2. Taps "QC" button
3. `QualityControlModal.tsx` opens with form
4. User fills in quality checklist data
5. Taps "Save to QC Archive" button
6. `saveData()` function executes (line 52-126)
7. Data saved to `quality_control` table in Supabase
8. Success alert shown

### 3. Searching QC Records

**Path:**
```
QC Archive Modal → Enter Job Number → Search → View Results → Select Record
```

**Code Flow:**
1. User opens QC Archive modal
2. Enters job number in search field
3. Taps "Search" button or presses Enter
4. `searchJobs()` function queries Supabase (line 18-39)
5. Results displayed as cards
6. User taps a card to view full details
7. Detail view shows all QC checklist data

## Database Schema

**Table:** `quality_control`

**Key Fields:**
- `id` (primary key)
- `job_id` (links to jobs table)
- `job_number` (searchable field)
- `item_name`
- Workshop fields (surface_condition, drilling, welding, racking)
- Acid department fields (forward condition, surface, immersion times)
- Zinc department fields (forward condition, surface, immersion, coating)
- Finishing fields (surface, remedial action, coating thickness)
- `created_at`, `updated_at`, `created_by`, `updated_by`

## Components Involved

1. **ArchiveModal.tsx** - Main archive modal container
2. **ArchiveModalMain.tsx** - Report type selection (excludes QC rendering)
3. **QCArchiveModal.tsx** - Separate modal for QC search and viewing
4. **QualityControlModal.tsx** - Form for filling QC checklist

## Troubleshooting

### Issue: Save button not working
**Check:**
- Console logs in `QualityControlModal.tsx` saveData function
- Supabase connection
- RLS policies on quality_control table
- Network tab for API errors

### Issue: Search not returning results
**Check:**
- Job number exists in quality_control table
- Search query formatting (uses ILIKE for case-insensitive)
- Supabase RLS policies allow SELECT

### Issue: Date dropdown showing in QC Archive
**Fixed:** ArchiveModalMain.tsx returns null when type is 'qc'

## Recent Changes

1. Removed date dropdown from QC Archive flow
2. Made QC Archive use separate modal with job search only
3. Enhanced search with loading states and empty states
4. Added comprehensive logging to save function
5. Fixed remedial action conditional display (YES shows text input)
