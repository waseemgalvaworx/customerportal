# Inventory Closing Balance Calculation Fix

## Problem
Opening balance transactions were being counted as "Stock IN" movements, causing incorrect closing balance calculations.

## Solution
Updated inventory report logic to:
1. **Include** opening balance in opening balance calculations
2. **Exclude** opening balance from stock IN/OUT movements
3. **Properly calculate** closing balance as: Opening + Stock IN - Stock OUT

## Files Modified
1. `components/InventoryReportModal.tsx` - Fixed All tab and individual item calculations
2. `components/StockReportTable.tsx` - Fixed stock report calculations

## Logic
- Opening balance transactions identified by: `notes = 'Opening Balance'` OR `reference = 'OPENING_BALANCE'`
- These transactions are filtered out when calculating period stock movements
- Closing balance = Opening Balance + (Stock IN - Stock OUT) where Stock IN/OUT exclude opening balance

## Result
Inventory reports now show accurate stock movements without double-counting opening balances.
