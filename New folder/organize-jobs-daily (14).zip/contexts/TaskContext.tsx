import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const TASKS_STORAGE_KEY = 'active_tasks';

// Users allowed to access the Active Tasks system
export const ALLOWED_TASK_USERS = ['admin', 'Lovena', 'KH'];

export interface ActiveTask {
  id: string;
  route: string;
  title: string;
  icon: string;
  color: string;
  formData: Record<string, any>;
  hasUnsavedChanges: boolean;
  timestamp: number;
  lastAccessed: number;
  lastSavedAt?: number; // Track when draft was last saved
  formType?: string; // Type of form data (e.g., 'filter', 'form', 'search')
}

interface TaskContextType {
  activeTasks: ActiveTask[];
  currentTaskId: string | null;
  addTask: (task: Omit<ActiveTask, 'id' | 'timestamp' | 'lastAccessed'>) => string;
  removeTask: (taskId: string) => void;
  updateTaskData: (taskId: string, formData: Record<string, any>, hasUnsavedChanges?: boolean, formType?: string) => void;
  getTaskData: (taskId: string) => Record<string, any> | null;
  setCurrentTask: (taskId: string | null) => void;
  getTaskByRoute: (route: string) => ActiveTask | undefined;
  clearAllTasks: () => void;
  markTaskSaved: (taskId: string) => void;
  isUserAllowed: (username: string | undefined) => boolean;
  getLastSavedTime: (taskId: string) => number | undefined;
}

const TaskContext = createContext<TaskContextType | undefined>(undefined);

export function TaskProvider({ children }: { children: React.ReactNode }) {
  const [activeTasks, setActiveTasks] = useState<ActiveTask[]>([]);
  const [currentTaskId, setCurrentTaskId] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load tasks from AsyncStorage on mount
  useEffect(() => {
    const loadTasks = async () => {
      try {
        const stored = await AsyncStorage.getItem(TASKS_STORAGE_KEY);
        if (stored) {
          const parsed = JSON.parse(stored);
          // Filter out tasks older than 24 hours
          const now = Date.now();
          const validTasks = parsed.filter((task: ActiveTask) => 
            now - task.lastAccessed < 24 * 60 * 60 * 1000
          );
          setActiveTasks(validTasks);
        }
      } catch (error) {
        console.error('Error loading tasks:', error);
      } finally {
        setIsLoaded(true);
      }
    };
    loadTasks();
  }, []);

  // Save tasks to AsyncStorage whenever they change
  useEffect(() => {
    if (isLoaded) {
      const saveTasks = async () => {
        try {
          await AsyncStorage.setItem(TASKS_STORAGE_KEY, JSON.stringify(activeTasks));
        } catch (error) {
          console.error('Error saving tasks:', error);
        }
      };
      saveTasks();
    }
  }, [activeTasks, isLoaded]);

  const generateTaskId = () => `task-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

  // Check if user is allowed to use Active Tasks system
  const isUserAllowed = useCallback((username: string | undefined): boolean => {
    if (!username) return false;
    return ALLOWED_TASK_USERS.includes(username);
  }, []);

  const addTask = useCallback((task: Omit<ActiveTask, 'id' | 'timestamp' | 'lastAccessed'>): string => {
    // Check if task for this route already exists
    const existingTask = activeTasks.find(t => t.route === task.route);
    if (existingTask) {
      // Update last accessed and return existing id
      setActiveTasks(prev => prev.map(t => 
        t.id === existingTask.id 
          ? { ...t, lastAccessed: Date.now() }
          : t
      ));
      setCurrentTaskId(existingTask.id);
      return existingTask.id;
    }

    const newTask: ActiveTask = {
      ...task,
      id: generateTaskId(),
      timestamp: Date.now(),
      lastAccessed: Date.now(),
    };

    setActiveTasks(prev => [...prev, newTask]);
    setCurrentTaskId(newTask.id);
    return newTask.id;
  }, [activeTasks]);

  const removeTask = useCallback((taskId: string) => {
    setActiveTasks(prev => prev.filter(t => t.id !== taskId));
    if (currentTaskId === taskId) {
      setCurrentTaskId(null);
    }
  }, [currentTaskId]);

  const updateTaskData = useCallback((
    taskId: string, 
    formData: Record<string, any>, 
    hasUnsavedChanges: boolean = true,
    formType?: string
  ) => {
    setActiveTasks(prev => prev.map(t => 
      t.id === taskId 
        ? { 
            ...t, 
            formData, 
            hasUnsavedChanges, 
            lastAccessed: Date.now(),
            lastSavedAt: Date.now(),
            formType: formType || t.formType
          }
        : t
    ));
  }, []);

  const getTaskData = useCallback((taskId: string): Record<string, any> | null => {
    const task = activeTasks.find(t => t.id === taskId);
    return task?.formData || null;
  }, [activeTasks]);

  const setCurrentTask = useCallback((taskId: string | null) => {
    setCurrentTaskId(taskId);
    if (taskId) {
      setActiveTasks(prev => prev.map(t => 
        t.id === taskId 
          ? { ...t, lastAccessed: Date.now() }
          : t
      ));
    }
  }, []);

  const getTaskByRoute = useCallback((route: string): ActiveTask | undefined => {
    return activeTasks.find(t => t.route === route);
  }, [activeTasks]);

  const clearAllTasks = useCallback(() => {
    setActiveTasks([]);
    setCurrentTaskId(null);
  }, []);

  const markTaskSaved = useCallback((taskId: string) => {
    setActiveTasks(prev => prev.map(t => 
      t.id === taskId 
        ? { ...t, hasUnsavedChanges: false, lastSavedAt: Date.now() }
        : t
    ));
  }, []);

  const getLastSavedTime = useCallback((taskId: string): number | undefined => {
    const task = activeTasks.find(t => t.id === taskId);
    return task?.lastSavedAt;
  }, [activeTasks]);

  return (
    <TaskContext.Provider value={{
      activeTasks,
      currentTaskId,
      addTask,
      removeTask,
      updateTaskData,
      getTaskData,
      setCurrentTask,
      getTaskByRoute,
      clearAllTasks,
      markTaskSaved,
      isUserAllowed,
      getLastSavedTime,
    }}>
      {children}
    </TaskContext.Provider>
  );
}

export function useTasks() {
  const context = useContext(TaskContext);
  if (context === undefined) {
    throw new Error('useTasks must be used within a TaskProvider');
  }
  return context;
}
