import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { authenticateWithPassword, PasswordUser } from '@/app/lib/passwordAuth';
import { logAction } from '@/utils/auditLogger';


interface PasswordAuthContextType {
  user: PasswordUser | null;
  loading: boolean;
  signIn: (password: string) => Promise<boolean>;
  signOut: () => Promise<void>;
}

const PasswordAuthContext = createContext<PasswordAuthContextType>({
  user: null,
  loading: true,
  signIn: async () => false,
  signOut: async () => {},
});

export const usePasswordAuth = () => useContext(PasswordAuthContext);

export function PasswordAuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<PasswordUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStoredAuth();
  }, []);

  const loadStoredAuth = async () => {
    try {
      const stored = await AsyncStorage.getItem('auth_user');
      if (stored) {
        setUser(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Error loading auth:', error);
    } finally {
      setLoading(false);
    }
  };

  const signIn = async (password: string): Promise<boolean> => {
    const authUser = authenticateWithPassword(password);
    if (authUser) {
      setUser(authUser);
      await AsyncStorage.setItem('auth_user', JSON.stringify(authUser));
      
      // Log login action
      await logAction({
        userId: authUser.id,
        username: authUser.username,
        actionType: 'LOGIN',
        actionDescription: `User ${authUser.username} logged in`,
      });
      
      return true;
    }
    return false;
  };


  const signOut = async () => {
    // Log logout action before clearing user
    if (user) {
      await logAction({
        userId: user.id,
        username: user.username,
        actionType: 'LOGOUT',
        actionDescription: `User ${user.username} logged out`,
      });
    }
    
    setUser(null);
    await AsyncStorage.removeItem('auth_user');
  };


  return (
    <PasswordAuthContext.Provider value={{ user, loading, signIn, signOut }}>
      {children}
    </PasswordAuthContext.Provider>
  );
}
