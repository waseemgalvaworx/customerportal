import React, { createContext, useState, useContext, ReactNode, useEffect, useRef } from 'react';
import { supabase } from '@/app/lib/supabase';
import type { RealtimeChannel } from '@supabase/supabase-js';
import { cacheData, getCachedData, addPendingChange, CACHE_KEYS } from '@/utils/offlineCache';
import { createDebouncedRefresh } from '@/utils/realtimeHelpers';


export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  address: string;
  notes: string;
  createdDate: Date;
}

interface CustomerContextType {
  customers: Customer[];
  loading: boolean;
  addCustomer: (customer: Omit<Customer, 'id' | 'createdDate'>) => Promise<void>;
  updateCustomer: (id: string, updates: Partial<Customer>) => Promise<void>;
  deleteCustomer: (id: string) => Promise<void>;
  getCustomerById: (id: string) => Customer | undefined;
}

const CustomerContext = createContext<CustomerContextType | undefined>(undefined);

export const CustomerProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const debouncedRefreshRef = useRef<{ trigger: () => void; cancel: () => void } | null>(null);

  useEffect(() => {
    loadCustomers();
    
    // OPTIMIZED: Create debounced refresh to batch rapid updates
    debouncedRefreshRef.current = createDebouncedRefresh(loadCustomers, 500);
    
    // OPTIMIZED: Use separate event handlers for direct state updates
    // This avoids full database refresh on every change
    const channel: RealtimeChannel = supabase
      .channel('customers-changes-optimized')
      .on('postgres_changes', 
        { event: 'INSERT', schema: 'public', table: 'customers' },
        (payload) => {
          const newCustomer = formatCustomer(payload.new);
          setCustomers(prev => {
            const exists = prev.some(c => c.id === newCustomer.id);
            return exists ? prev : [newCustomer, ...prev];
          });
        }
      )
      .on('postgres_changes', 
        { event: 'UPDATE', schema: 'public', table: 'customers' },
        (payload) => {
          const updatedCustomer = formatCustomer(payload.new);
          setCustomers(prev => prev.map(c => c.id === updatedCustomer.id ? updatedCustomer : c));
        }
      )
      .on('postgres_changes', 
        { event: 'DELETE', schema: 'public', table: 'customers' },
        (payload) => {
          setCustomers(prev => prev.filter(c => c.id !== payload.old.id));
        }
      )
      .subscribe();

    return () => {
      debouncedRefreshRef.current?.cancel();
      supabase.removeChannel(channel);
    };
  }, []);




  const formatCustomer = (customer: any): Customer => ({
    ...customer,
    createdDate: new Date(customer.createdDate),
  });

  const loadCustomers = async () => {
    try {
      // TRY DATABASE FIRST - don't pre-check isOnline() to avoid delays
      const { data, error } = await supabase
        .from('customers')
        .select('*')
        .order('createdDate', { ascending: false });

      if (error) throw error;
      const formattedCustomers = (data || []).map(formatCustomer);
      setCustomers(formattedCustomers);
      
      // Cache customers for offline use (fire-and-forget)
      cacheData(CACHE_KEYS.CUSTOMERS, formattedCustomers).catch(err => 
        console.error('Cache error:', err)
      );
    } catch (error) {
      console.error('Error loading customers - trying cache:', error);
      // Try to load from cache on error (network failure)
      const cachedCustomers = await getCachedData(CACHE_KEYS.CUSTOMERS);
      if (cachedCustomers) {
        console.log('📵 Loaded customers from cache');
        setCustomers(cachedCustomers.map(formatCustomer));
      }
    } finally {
      setLoading(false);
    }
  };




  const addCustomer = async (newCustomer: Omit<Customer, 'id' | 'createdDate'>) => {
    const customerToInsert = {
      ...newCustomer,
      createdDate: new Date().toISOString()
    };
    
    const optimisticCustomer = { 
      ...newCustomer, 
      id: `temp-${Date.now()}`,
      createdDate: new Date()
    };
    
    setCustomers(prev => [optimisticCustomer, ...prev]);
    
    try {
      const { data, error } = await supabase
        .from('customers')
        .insert([customerToInsert])
        .select()
        .single();
      
      if (error) {
        console.error('Supabase insert error:', error);
        throw error;
      }
      
      // Replace optimistic customer with real one
      if (data) {
        const realCustomer = formatCustomer(data);
        setCustomers(prev => prev.map(c => c.id === optimisticCustomer.id ? realCustomer : c));
      }
    } catch (error) {
      console.error('Error adding customer:', error);
      setCustomers(prev => prev.filter(c => c.id !== optimisticCustomer.id));
      throw error;
    }
  };


  const updateCustomer = async (id: string, updates: Partial<Customer>) => {
    // Optimistic update first for instant UI feedback
    setCustomers(prev => prev.map(c => 
      c.id === id ? { ...c, ...updates } : c
    ));
    
    try {
      // TRY DIRECT UPDATE FIRST - don't check isOnline() to avoid delays
      const { error } = await supabase
        .from('customers')
        .update(updates)
        .eq('id', id);
      
      if (error) {
        // If update failed, queue it for later sync
        console.log('📵 Update failed - queueing for later sync:', error.message);
        await addPendingChange({
          type: 'update',
          table: 'customers',
          data: { id, ...updates }
        });
      }
    } catch (error: any) {
      console.error('Error updating customer:', error);
      // On network error, queue the change
      if (error.message?.includes('network') || error.message?.includes('fetch')) {
        console.log('📵 Network error - queueing customer update');
        await addPendingChange({
          type: 'update',
          table: 'customers',
          data: { id, ...updates }
        });
      } else {
        // Rollback on non-network error
        await loadCustomers();
        throw error;
      }
    }
  };




  const deleteCustomer = async (id: string) => {
    console.log('=== DELETE CUSTOMER CALLED ===');
    console.log('Deleting customer with ID:', id);
    
    const backup = customers.find(c => c.id === id);
    console.log('Backup customer:', backup);
    
    // Optimistic update
    console.log('Performing optimistic UI update...');
    setCustomers(prev => prev.filter(c => c.id !== id));
    
    try {
      console.log('Step 1: Deleting all associated jobs...');
      
      // Delete all jobs associated with this customer (cascade delete)
      const { error: jobsError } = await supabase
        .from('jobs')
        .delete()
        .eq('customerId', id);
      
      if (jobsError) {
        console.error('Error deleting jobs:', jobsError);
        throw jobsError;
      }
      
      console.log('Step 2: Jobs deleted successfully, now deleting customer...');
      
      // Now delete the customer
      const { error: customerError } = await supabase
        .from('customers')
        .delete()
        .eq('id', id);
      
      if (customerError) {
        console.error('Error deleting customer:', customerError);
        throw customerError;
      }
      
      console.log('=== CUSTOMER AND JOBS DELETED SUCCESSFULLY ===');
    } catch (error: any) {
      console.error('=== DELETE FAILED ===');
      console.error('Error:', error);
      if (backup) {
        console.log('Rolling back optimistic update...');
        setCustomers(prev => [...prev, backup]);
      }
      throw error;
    }
  };





  const getCustomerById = (id: string) => {
    return customers.find(c => c.id === id);
  };

  return (
    <CustomerContext.Provider value={{
      customers,
      loading,
      addCustomer,
      updateCustomer,
      deleteCustomer,
      getCustomerById
    }}>
      {children}
    </CustomerContext.Provider>
  );
};

export const useCustomers = () => {
  const context = useContext(CustomerContext);
  if (!context) {
    throw new Error('useCustomers must be used within a CustomerProvider');
  }
  return context;
};
