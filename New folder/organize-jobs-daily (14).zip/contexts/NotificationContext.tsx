import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { supabase } from '../app/lib/supabase';
import { usePasswordAuth } from './PasswordAuthContext';
import * as Notifications from 'expo-notifications';
import { registerForPushNotificationsAsync } from '../utils/pushNotifications';
import { useRouter } from 'expo-router';
import { Audio } from 'expo-av';

interface Notification {
  id: string;
  user_id: string;
  job_id?: string;
  title: string;
  message: string;
  type: string;
  priority: string;
  read: boolean;
  archived: boolean;
  created_at: string;
}


interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  hasNewNotification: boolean;
  markAsRead: (id: string) => Promise<void>;
  markAllAsRead: () => Promise<void>;
  refreshNotifications: () => Promise<void>;
  clearNewNotificationFlag: () => void;
  archiveNotification: (id: string) => Promise<void>;
  unarchiveNotification: (id: string) => Promise<void>;
  deleteNotification: (id: string) => Promise<void>;
}











const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = usePasswordAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [hasNewNotification, setHasNewNotification] = useState(false);

  const router = useRouter();
  const notificationListener = useRef<any>();
  const responseListener = useRef<any>();
  const soundObject = useRef<Audio.Sound | null>(null);
  const previousCountRef = useRef(0);

  const playNotificationSound = async () => {
    try {
      await Audio.setAudioModeAsync({
        playsInSilentModeIOS: true,
        staysActiveInBackground: false,
      });
      
      if (soundObject.current) {
        await soundObject.current.unloadAsync();
      }
      
      // Use a simple beep sound using Audio
      const { sound } = await Audio.Sound.createAsync(
        { uri: 'https://actions.google.com/sounds/v1/alarms/beep_short.ogg' },
        { shouldPlay: true, volume: 0.7 }
      );
      soundObject.current = sound;
      
      setTimeout(() => {
        sound.unloadAsync();
      }, 1000);
    } catch (error) {
      console.log('Error playing notification sound:', error);
    }
  };

  const fetchNotifications = async (playSound = false) => {
    if (!user) return;
    
    console.log('🔔 Fetching notifications for user:', user.id, user.username);
    
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(50);
    
    if (error) {
      console.error('❌ Error fetching notifications:', error);
      return;
    }
    
    console.log(`✅ Fetched ${data?.length || 0} notifications`);
    
    if (data) {
      // Fetch sender profiles for messages
      const senderIds = [...new Set(data.filter(n => n.sender_id).map(n => n.sender_id))];
      let senderProfiles: any = {};
      
      if (senderIds.length > 0) {
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, full_name')
          .in('id', senderIds);
        
        if (profiles) {
          profiles.forEach(p => {
            senderProfiles[p.id] = p;
          });
        }
      }
      
      // Attach sender profile to each notification
      const enrichedData = data.map(n => ({
        ...n,
        sender_profile: n.sender_id ? senderProfiles[n.sender_id] : null
      }));
      
      const newUnreadCount = enrichedData.filter(n => !n.read).length;
      console.log(`📊 Unread count: ${newUnreadCount}, Previous: ${previousCountRef.current}`);
      
      if (playSound && newUnreadCount > previousCountRef.current) {
        console.log('🔊 Playing notification sound');
        setHasNewNotification(true);
        playNotificationSound();
      }
      previousCountRef.current = newUnreadCount;
      setNotifications(enrichedData);
    }
  };








  // OPTIMIZED: Debounced fetch to prevent excessive database queries
  const debouncedFetchRef = useRef<NodeJS.Timeout | null>(null);
  const pendingFetchRef = useRef<boolean>(false);

  const debouncedFetchNotifications = (playSound: boolean) => {
    pendingFetchRef.current = true;
    
    if (debouncedFetchRef.current) {
      clearTimeout(debouncedFetchRef.current);
    }
    
    debouncedFetchRef.current = setTimeout(() => {
      if (pendingFetchRef.current) {
        pendingFetchRef.current = false;
        fetchNotifications(playSound);
      }
    }, 300); // 300ms debounce
  };

  useEffect(() => {
    if (user) {
      console.log('🔌 Setting up notification subscriptions for user:', user.id, user.username);
      
      registerForPushNotificationsAsync(user.id);

      notificationListener.current = Notifications.addNotificationReceivedListener(notification => {
        console.log('📱 Push notification received');
        debouncedFetchNotifications(true);
      });

      responseListener.current = Notifications.addNotificationResponseReceivedListener(response => {
        const jobId = response.notification.request.content.data?.jobId;
        if (jobId) {
          router.push(`/job/${jobId}`);
        }
      });

      fetchNotifications(false);
      
      // OPTIMIZED: Single channel with user-specific filter
      // Only subscribes to notifications for this specific user
      console.log('🔌 Subscribing to realtime notifications with filter:', `user_id=eq.${user.id}`);
      
      const channel = supabase
        .channel(`notifications-${user.id}`)
        .on('postgres_changes', {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${user.id}`
        }, (payload) => {
          console.log('🆕 Realtime INSERT event received');
          // OPTIMIZED: Direct state update for inserts instead of full refresh
          const newNotification = payload.new as Notification;
          setNotifications(prev => {
            const exists = prev.some(n => n.id === newNotification.id);
            if (exists) return prev;
            setHasNewNotification(true);
            playNotificationSound();
            return [newNotification, ...prev];
          });
        })
        .on('postgres_changes', {
          event: 'UPDATE',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${user.id}`
        }, (payload) => {
          console.log('🔄 Realtime UPDATE event received');
          // OPTIMIZED: Direct state update for updates
          const updatedNotification = payload.new as Notification;
          setNotifications(prev => 
            prev.map(n => n.id === updatedNotification.id ? updatedNotification : n)
          );
        })
        .on('postgres_changes', {
          event: 'DELETE',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${user.id}`
        }, (payload) => {
          console.log('🗑️ Realtime DELETE event received');
          // OPTIMIZED: Direct state update for deletes
          setNotifications(prev => prev.filter(n => n.id !== payload.old.id));
        })
        .subscribe((status) => {
          console.log('📡 Realtime subscription status:', status);
        });


      return () => {
        console.log('🔌 Cleaning up notification subscriptions');
        if (debouncedFetchRef.current) {
          clearTimeout(debouncedFetchRef.current);
        }
        supabase.removeChannel(channel);
        if (notificationListener.current) {
          Notifications.removeNotificationSubscription(notificationListener.current);
        }
        if (responseListener.current) {
          Notifications.removeNotificationSubscription(responseListener.current);
        }
        if (soundObject.current) {
          soundObject.current.unloadAsync();
        }
      };
    }
  }, [user]);




  const markAsRead = async (id: string) => {
    console.log('=== MARK AS READ CALLED ===');
    console.log('Notification ID:', id);
    
    const { data, error } = await supabase
      .from('notifications')
      .update({ read: true })
      .eq('id', id)
      .select();
    
    if (error) {
      console.error('❌ markAsRead error:', error);
      console.error('Error details:', { code: error.code, message: error.message, details: error.details });
    } else {
      console.log('✅ markAsRead success, updated data:', data);
    }
    
    setNotifications(prev => {
      const updated = prev.map(n => n.id === id ? { ...n, read: true } : n);
      console.log('📊 Local state updated. Notification now:', updated.find(n => n.id === id));
      return updated;
    });
  };

  const markAllAsRead = async () => {
    if (!user) return;
    console.log('=== MARK ALL AS READ CALLED ===');
    
    const { data, error } = await supabase
      .from('notifications')
      .update({ read: true })
      .eq('user_id', user.id)
      .eq('read', false)
      .select();
    
    if (error) {
      console.error('❌ markAllAsRead error:', error);
    } else {
      console.log('✅ markAllAsRead success, updated count:', data?.length);
    }
    
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };



  const clearNewNotificationFlag = () => {
    setHasNewNotification(false);
  };

  const archiveNotification = async (id: string) => {
    await supabase.from('notifications').update({ archived: true }).eq('id', id);
    await fetchNotifications(false);
  };

  const unarchiveNotification = async (id: string) => {
    await supabase.from('notifications').update({ archived: false }).eq('id', id);
    await fetchNotifications(false);
  };

  const deleteNotification = async (id: string) => {
    console.log('🗑️ Deleting notification:', id);
    const { data, error } = await supabase
      .from('notifications')
      .delete()
      .eq('id', id);
    console.log('🗑️ Delete result:', { data, error });
    if (error) {
      console.error('❌ Delete error details:', {
        code: error.code,
        message: error.message,
        details: error.details,
        hint: error.hint
      });
    }
    if (!error) {
      console.log('✅ Delete successful, refreshing notifications');
      await fetchNotifications(false);
    }
  };

  const unreadCount = notifications.filter(n => !n.read && !n.archived).length;

  return (
    <NotificationContext.Provider value={{ 
      notifications,
      unreadCount, 
      hasNewNotification,
      markAsRead, 
      markAllAsRead,
      refreshNotifications: fetchNotifications, 
      clearNewNotificationFlag,
      archiveNotification,
      unarchiveNotification,
      deleteNotification
    }}>
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) throw new Error('useNotifications must be used within NotificationProvider');
  return context;
};
