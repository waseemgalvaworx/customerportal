import React, { createContext, useState, useContext, ReactNode, useEffect, useRef } from 'react';
import { supabase } from '@/app/lib/supabase';
import type { RealtimeChannel } from '@supabase/supabase-js';
import { logAction } from '@/utils/auditLogger';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { PasswordUser } from '@/app/lib/passwordAuth';
import { trackItemStatusChange, initializeStageTracking } from '@/utils/performanceTracker';
import { trackHourlyProduction } from '@/utils/hourlyProductionTrackerV2';
import { notifyAllUsers, createNotification } from '@/utils/notificationHelper';
import { recordMovement } from '@/utils/productionMovementTracker';
import { createDebouncedRefresh } from '@/utils/realtimeHelpers';
import { logSuccess, logFailure } from '@/utils/dataOperationLogger';


import { cacheData, getCachedData, addPendingChange, CACHE_KEYS, getPendingChanges } from '@/utils/offlineCache';


import { syncPendingChanges, ConflictData } from '@/utils/offlineSync';
import ConflictResolutionModal from '@/components/ConflictResolutionModal';




export type Priority = 'low' | 'medium' | 'high';
export type JobStatus = 'pending' | 'planning' | 'done' | 'archived';
export type ItemStatus = 'Pending' | 'Workshop' | 'Acid' | 'Galva' | 'Finishing' | 'Ready';

export interface JobItem {
  id: string;
  itemCount?: string;
  descriptionOfWorks: string;
  weightKg: string;
  status: ItemStatus;
  paintVarnish?: boolean;
  galva?: boolean;
  lightGalva?: boolean;
  lightPaint?: boolean;
  rusty?: boolean;
  doubleDip?: boolean;
  multipleDip?: boolean;
}




export interface Job {
  id: string;
  jobNumber: string;
  dateOfEntry: Date;
  customerName: string;
  notes: string;
  items: JobItem[];
  priority?: Priority;
  status: JobStatus;
  completedDate?: Date;
  archivedDate?: Date;
  galvaXpress?: boolean;
  deliveryDate?: Date;
  deliveredAt?: string;
}



interface JobContextType {
  jobs: Job[];
  loading: boolean;
  addJob: (job: Omit<Job, 'id' | 'status'>) => Promise<void>;
  updateJob: (id: string, updates: Partial<Job>) => Promise<void>;
  deleteJob: (id: string) => Promise<void>;
  moveToPlanning: (jobId: string) => Promise<void>;
  moveToDone: (jobId: string) => Promise<void>;
  revertToPlanning: (jobId: string) => Promise<void>;
  revertToPending: (jobId: string) => Promise<void>;
  updateItemStatus: (jobId: string, itemId: string, status: ItemStatus) => Promise<void>;
  updateMultipleItemStatuses: (jobId: string, itemIds: string[], status: ItemStatus) => Promise<void>;
  revertSelectedItemsToWIP: (jobId: string, itemIds: string[], targetStatus: ItemStatus) => Promise<void>;
  archiveJob: (jobId: string, archivedDate?: string) => Promise<void>;
  restoreJob: (jobId: string) => Promise<void>;
  checkAndArchiveDoneJobs: () => Promise<void>;
}




const JobContext = createContext<JobContextType | undefined>(undefined);

export const JobProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [networkOnline, setNetworkOnline] = useState(true);
  const [conflictModalVisible, setConflictModalVisible] = useState(false);
  const [currentConflict, setCurrentConflict] = useState<ConflictData | null>(null);
  const [conflictResolver, setConflictResolver] = useState<((resolution: 'local' | 'server' | 'skip') => void) | null>(null);
  const debouncedRefreshRef = useRef<{ trigger: () => void; cancel: () => void } | null>(null);

  useEffect(() => {
    loadJobs();
    setupNetworkListener();
    
    // OPTIMIZED: Create debounced refresh to batch rapid updates
    debouncedRefreshRef.current = createDebouncedRefresh(loadJobs, 500);
    
    // OPTIMIZED: Subscribe only to non-archived jobs to reduce load
    // Use selective subscription with debouncing
    const channel: RealtimeChannel = supabase
      .channel('jobs-changes-optimized')
      .on('postgres_changes', 
        { event: 'INSERT', schema: 'public', table: 'jobs' },
        (payload) => {
          // For inserts, add directly without full refresh
          const newJob = formatJob(payload.new);
          setJobs(prev => {
            const exists = prev.some(j => j.id === newJob.id);
            return exists ? prev : [newJob, ...prev];
          });
        }
      )
      .on('postgres_changes', 
        { event: 'UPDATE', schema: 'public', table: 'jobs' },
        (payload) => {
          // For updates, update in place without full refresh
          const updatedJob = formatJob(payload.new);
          setJobs(prev => prev.map(job => job.id === updatedJob.id ? updatedJob : job));
        }
      )
      .on('postgres_changes', 
        { event: 'DELETE', schema: 'public', table: 'jobs' },
        (payload) => {
          setJobs(prev => prev.filter(job => job.id !== payload.old.id));
        }
      )
      .subscribe();

    return () => {
      debouncedRefreshRef.current?.cancel();
      supabase.removeChannel(channel);
    };
  }, []);



  // Network status listener - NON-BLOCKING using sync check
  const setupNetworkListener = async () => {
    // Use sync check to avoid blocking - defaults to true if unknown
    setNetworkOnline(true);
    
    // Initial sync attempt if have pending changes (non-blocking)
    const pending = await getPendingChanges();
    if (pending.length > 0) {
      console.log('🔄 Initial sync - found pending changes...');
      syncPendingChanges(handleConflict).then(result => {
        console.log(`✅ Initial sync: ${result.synced} synced, ${result.failed} failed`);
        if (result.synced > 0) {
          loadJobs();
        }
      }).catch(err => console.error('Initial sync error:', err));
    }

    // Periodic sync check every 30 seconds (non-blocking, just for pending changes)
    const interval = setInterval(async () => {
      const pending = await getPendingChanges();
      if (pending.length > 0) {
        console.log('🔄 Periodic sync - found pending changes...');
        syncPendingChanges(handleConflict).then(result => {
          console.log(`✅ Periodic sync: ${result.synced} synced, ${result.failed} failed`);
          if (result.synced > 0) {
            loadJobs();
          }
        }).catch(err => console.error('Periodic sync error:', err));
      }
    }, 30000);

    return () => clearInterval(interval);
  };




  // Conflict resolution handler
  const handleConflict = async (conflict: ConflictData): Promise<'local' | 'server' | 'skip'> => {
    return new Promise((resolve) => {
      setCurrentConflict(conflict);
      setConflictResolver(() => resolve);
      setConflictModalVisible(true);
    });
  };

  const resolveConflict = (resolution: 'local' | 'server' | 'skip') => {
    if (conflictResolver) {
      conflictResolver(resolution);
      setConflictResolver(null);
    }
    setConflictModalVisible(false);
    setCurrentConflict(null);
  };




  const handleRealtimeUpdate = (payload: any) => {
    if (payload.eventType === 'INSERT') {
      const newJob = formatJob(payload.new);
      // Prevent duplicate if job already exists (from optimistic update)
      setJobs(prev => {
        const exists = prev.some(j => j.id === newJob.id);
        return exists ? prev : [newJob, ...prev];
      });
    } else if (payload.eventType === 'UPDATE') {
      const updatedJob = formatJob(payload.new);
      setJobs(prev => prev.map(job => job.id === updatedJob.id ? updatedJob : job));
    } else if (payload.eventType === 'DELETE') {
      setJobs(prev => prev.filter(job => job.id !== payload.old.id));
    }
  };


  const formatJob = (job: any): Job => ({
    ...job,
    dateOfEntry: new Date(job.dateOfEntry),
    completedDate: job.completedDate ? new Date(job.completedDate) : undefined,
    archivedDate: job.archivedDate ? new Date(job.archivedDate) : undefined,
    deliveryDate: job.deliveryDate ? new Date(job.deliveryDate) : undefined,
    // Ensure all items have a status, defaulting to 'Pending' if not set
    items: job.items?.map((item: any) => ({
      ...item,
      status: item.status || 'Pending' as ItemStatus
    })) || []
  });


  // Helper function to get current user for audit logging
  const getCurrentUser = async (): Promise<{ userId: string; username: string } | null> => {
    try {
      const stored = await AsyncStorage.getItem('auth_user');
      if (stored) {
        const user: PasswordUser = JSON.parse(stored);
        return { userId: user.id, username: user.username };
      }
    } catch (error) {
      console.error('Error getting current user:', error);
    }
    return null;
  };

  const loadJobs = async () => {
    try {
      // TRY DATABASE FIRST - don't pre-check isOnline() to avoid delays
      // This makes initial load faster when network is working
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .order('dateOfEntry', { ascending: false });

      if (error) throw error;
      const formattedJobs = (data || []).map(formatJob);
      setJobs(formattedJobs);
      
      // Cache jobs for offline use (fire-and-forget)
      cacheData(CACHE_KEYS.JOBS, formattedJobs).catch(err => 
        console.error('Cache error:', err)
      );
      
      // Initialize performance tracking (fire-and-forget)
      initializeStageTracking(formattedJobs).catch(err => 
        console.error('Stage tracking init error:', err)
      );
    } catch (error) {
      console.error('Error loading jobs - trying cache:', error);
      // Try to load from cache on error (network failure)
      const cachedJobs = await getCachedData(CACHE_KEYS.JOBS);
      if (cachedJobs) {
        console.log('📵 Loaded jobs from cache');
        setJobs(cachedJobs.map(formatJob));
      }
    } finally {
      setLoading(false);
    }
  };






  const addJob = async (newJob: Omit<Job, 'id' | 'status'>) => {
    const jobToInsert = {
      jobNumber: newJob.jobNumber,
      dateOfEntry: newJob.dateOfEntry.toISOString(),
      customerName: newJob.customerName,
      notes: newJob.notes,
      items: newJob.items,
      priority: newJob.priority,
      galvaXpress: newJob.galvaXpress,
      deliveryDate: newJob.deliveryDate?.toISOString(),
      status: 'pending' as JobStatus
    };
    
    const optimisticJob = { 
      ...newJob, 
      id: `temp-${Date.now()}`,
      status: 'pending' as JobStatus 
    } as Job;
    
    setJobs(prev => [optimisticJob, ...prev]);
    
    try {
      const { data, error } = await supabase
        .from('jobs')
        .insert([jobToInsert])
        .select()
        .single();
      
      if (error) {
        console.error('Supabase insert error:', error);
        throw error;
      }
      // Replace optimistic job with real one
      if (data) {
        const realJob = formatJob(data);
        setJobs(prev => prev.map(j => j.id === optimisticJob.id ? realJob : j));
        
        // Send GalvXpress notification if applicable
        if (newJob.galvaXpress) {
          console.log('🔔 GalvXpress job created - sending notification...');
          console.log('   Job ID:', realJob.id);
          console.log('   Job Number:', newJob.jobNumber);
          console.log('   Customer:', newJob.customerName);
          
          await notifyAllUsers({
            jobId: realJob.id,
            title: '⚡ GalvXpress Job Created',
            message: `Urgent: Job ${newJob.jobNumber} for ${newJob.customerName} marked as GalvXpress`,
            type: 'galvxpress',
            priority: 'urgent'
          });
          
          console.log('✅ GalvXpress notification sent successfully');
        }
      }


    } catch (error) {
      console.error('Error adding job:', error);
      setJobs(prev => prev.filter(j => j.id !== optimisticJob.id));
      throw error;
    }
  };


  const updateJob = async (id: string, updates: Partial<Job>) => {
    const oldJob = jobs.find(j => j.id === id);
    
    try {
      // Format dates for Supabase
      const formattedUpdates: any = { ...updates };
      if (formattedUpdates.dateOfEntry instanceof Date) {
        formattedUpdates.dateOfEntry = formattedUpdates.dateOfEntry.toISOString();
      }
      if (formattedUpdates.completedDate instanceof Date) {
        formattedUpdates.completedDate = formattedUpdates.completedDate.toISOString();
      }
      if (formattedUpdates.archivedDate instanceof Date) {
        formattedUpdates.archivedDate = formattedUpdates.archivedDate.toISOString();
      }
      if (formattedUpdates.deliveryDate instanceof Date) {
        formattedUpdates.deliveryDate = formattedUpdates.deliveryDate.toISOString();
      }
      
      // TRY DIRECT UPDATE FIRST - don't check isOnline() to avoid delays
      // This makes updates instant when network is working
      const { error } = await supabase.from('jobs').update(formattedUpdates).eq('id', id);
      
      if (error) {
        // If update failed, queue it for later sync
        console.log('📵 Update failed - queueing for later sync:', error.message);
        await addPendingChange({
          type: 'update',
          table: 'jobs',
          data: { id, ...formattedUpdates }
        });
        
        // Update local state optimistically
        setJobs(prev => prev.map(job => job.id === id ? { ...job, ...updates } : job));
        return;
      }
      
      // Send GalvXpress notification if galvaXpress status changed from false to true
      if (oldJob && !oldJob.galvaXpress && updates.galvaXpress === true) {
        await notifyAllUsers({
          jobId: id,
          title: '⚡ GalvXpress Job Updated',
          message: `Job ${oldJob.jobNumber} for ${oldJob.customerName} has been marked as GalvXpress`,
          type: 'galvxpress',
          priority: 'urgent'
        });
      }
    } catch (error: any) {
      console.error('Error updating job:', error);
      // On network error, queue the change
      if (error.message?.includes('network') || error.message?.includes('fetch')) {
        console.log('📵 Network error - queueing job update');
        const formattedUpdates: any = { ...updates };
        await addPendingChange({
          type: 'update',
          table: 'jobs',
          data: { id, ...formattedUpdates }
        });
        setJobs(prev => prev.map(job => job.id === id ? { ...job, ...updates } : job));
      } else {
        throw error;
      }
    }
  };








  const deleteJob = async (id: string) => {
    const backup = jobs.find(j => j.id === id);
    setJobs(prev => prev.filter(job => job.id !== id));
    
    try {
      const { error } = await supabase.from('jobs').delete().eq('id', id);
      if (error) throw error;
    } catch (error) {
      if (backup) setJobs(prev => [...prev, backup]);
      throw error;
    }
  };

  const moveToPlanning = async (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (!job) return;
    
    // When moving from 'pending' to 'planning', reset all items to 'Pending' status
    // This ensures fresh jobs start with Pending status
    // Jobs already in planning/done will preserve their statuses when reverted
    const updatedItems = job.status === 'pending' 
      ? job.items.map(item => ({
          ...item,
          status: 'Pending' as ItemStatus
        }))
      : job.items.map(item => ({
          ...item,
          status: item.status || 'Pending' as ItemStatus
        }));
    
    await updateJob(jobId, { status: 'planning', items: updatedItems });
    
    // SUSPENDED: Job Moved to Planning notification - temporarily disabled per user request
    // await notifyAllUsers({
    //   jobId,
    //   title: 'Job Moved to Planning',
    //   message: `Job ${job.jobNumber} for ${job.customerName} has been moved to WIP`,
    //   type: 'job_status',
    //   priority: job.galvaXpress ? 'urgent' : 'normal'
    // });

    
    const user = await getCurrentUser();
    if (user && job) {
      await logAction({
        userId: user.userId,
        username: user.username,
        actionType: 'JOB_STATUS_CHANGED',
        actionDescription: `Moved job ${job.jobNumber} to Planning`,
        entityType: 'job',
        entityId: jobId,
        metadata: { oldStatus: job.status, newStatus: 'planning' }
      });
    }
  };




  const moveToDone = async (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    await updateJob(jobId, { status: 'done', completedDate: new Date() });
    
    const user = await getCurrentUser();
    if (user && job) {
      await logAction({
        userId: user.userId,
        username: user.username,
        actionType: 'JOB_STATUS_CHANGED',
        actionDescription: `Moved job ${job.jobNumber} to Done`,
        entityType: 'job',
        entityId: jobId,
        metadata: { oldStatus: job.status, newStatus: 'done' }
      });
    }
  };



  const revertToPlanning = async (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    await updateJob(jobId, { status: 'planning', completedDate: undefined });
    
    const user = await getCurrentUser();
    if (user && job) {
      await logAction({
        userId: user.userId,
        username: user.username,
        actionType: 'JOB_STATUS_CHANGED',
        actionDescription: `Reverted job ${job.jobNumber} to Planning`,
        entityType: 'job',
        entityId: jobId,
        metadata: { oldStatus: job.status, newStatus: 'planning' }
      });
    }
  };

  const revertToPending = async (jobId: string) => {
    console.log('🔄 REVERT TO PENDING STARTED');
    console.log('Job ID:', jobId);
    
    const job = jobs.find(j => j.id === jobId);
    if (!job) {
      console.error('❌ Job not found:', jobId);
      return;
    }
    
    console.log('Current job status:', job.status);
    console.log('Current items:', job.items.map(i => ({ id: i.id, status: i.status })));
    
    // Reset all items to 'Pending' status when reverting to Jobs screen
    const resetItems = job.items.map(item => ({
      ...item,
      status: 'Pending' as ItemStatus
    }));
    
    console.log('Reset items:', resetItems.map(i => ({ id: i.id, status: i.status })));
    
    // Update job with pending status and reset items
    await updateJob(jobId, { 
      status: 'pending',
      items: resetItems,
      completedDate: undefined,
      deliveryDate: undefined
    });
    
    console.log('✅ Job updated to pending with reset items');
    
    const user = await getCurrentUser();
    if (user && job) {
      await logAction({
        userId: user.userId,
        username: user.username,
        actionType: 'JOB_STATUS_CHANGED',
        actionDescription: `Reverted job ${job.jobNumber} to Pending (Jobs screen)`,
        entityType: 'job',
        entityId: jobId,
        metadata: { oldStatus: job.status, newStatus: 'pending', itemsReset: true }
      });
    }
    
    console.log('🔄 REVERT TO PENDING COMPLETED');
  };


  const archiveJob = async (jobId: string, archivedDate?: string) => {
    const job = jobs.find(j => j.id === jobId);
    const dateToUse = archivedDate ? new Date(archivedDate) : new Date();
    await updateJob(jobId, { status: 'archived', archivedDate: dateToUse });
    
    const user = await getCurrentUser();
    if (user && job) {
      await logAction({
        userId: user.userId,
        username: user.username,
        actionType: 'JOB_STATUS_CHANGED',
        actionDescription: `Archived job ${job.jobNumber}`,
        entityType: 'job',
        entityId: jobId,
        metadata: { oldStatus: job.status, newStatus: 'archived' }
      });
    }
  };

  const checkAndArchiveDoneJobs = async () => {
    console.log('🗂️ Starting archive process - checking for delivered jobs...');
    
    // Get all jobs with status 'done'
    const doneJobs = jobs.filter(job => job.status === 'done');
    console.log(`Found ${doneJobs.length} done jobs`);
    
    if (doneJobs.length === 0) {
      console.log('No done jobs to archive');
      return;
    }
    
    // Check which jobs are marked as delivered in completed_jobs table
    const jobIds = doneJobs.map(j => j.id);
    const { data: completedJobsData, error } = await supabase
      .from('completed_jobs')
      .select('job_id, delivered')
      .in('job_id', jobIds);
    
    if (error) {
      console.error('Error checking delivered status:', error);
      return;
    }
    
    // Create a map of job_id -> delivered status
    const deliveredMap = new Map<string, boolean>();
    completedJobsData?.forEach(item => {
      deliveredMap.set(item.job_id, item.delivered || false);
    });
    
    // Filter to only archive jobs marked as delivered
    const jobsToArchive = doneJobs.filter(job => deliveredMap.get(job.id) === true);
    
    console.log(`Found ${jobsToArchive.length} jobs marked as delivered to archive`);
    console.log(`${doneJobs.length - jobsToArchive.length} jobs not delivered - will remain in completed jobs`);
    
    // Archive only the delivered jobs
    for (const job of jobsToArchive) {
      console.log(`Archiving delivered job: ${job.jobNumber}`);
      await archiveJob(job.id);
    }
    
    console.log('✅ Archive process complete');
  };


  const restoreJob = async (jobId: string) => {
    console.log('\n========================================');
    console.log('🔄 RESTORE JOB FUNCTION STARTED');
    console.log('========================================');
    console.log('📋 Job ID to restore:', jobId);
    console.log('📊 Current jobs in state:', jobs.length);
    
    try {
      // STEP 1: Fetch the job from database
      console.log('\n--- STEP 1: FETCHING JOB FROM DATABASE ---');
      const { data: dbJob, error: fetchError } = await supabase
        .from('jobs')
        .select('*')
        .eq('id', jobId)
        .single();
      
      if (fetchError) {
        console.error('❌ Database fetch error:', fetchError);
        throw new Error(`Failed to fetch job: ${fetchError.message}`);
      }
      
      if (!dbJob) {
        console.error('❌ Job not found in database');
        throw new Error('Job not found in database');
      }
      
      console.log('✅ Job found in database:');
      console.log('   - Job Number:', dbJob.jobNumber);
      console.log('   - Current Status:', dbJob.status);
      console.log('   - Customer:', dbJob.customerName);
      console.log('   - Items Count:', dbJob.items?.length || 0);
      
      // STEP 2: Check for completed_jobs entries
      console.log('\n--- STEP 2: CHECKING COMPLETED_JOBS ENTRIES ---');
      const itemIds = (dbJob.items || []).map((item: any) => item.id);
      console.log('📝 Item IDs from job:', itemIds);
      
      if (itemIds.length === 0) {
        console.log('⚠️  No items found in job');
      } else {
        const { data: completedJobsData, error: checkError } = await supabase
          .from('completed_jobs')
          .select('*')
          .in('item_id', itemIds);
        
        if (checkError) {
          console.error('❌ Error checking completed_jobs:', checkError);
        } else {
          console.log(`✅ Found ${completedJobsData?.length || 0} completed_jobs entries`);
          if (completedJobsData && completedJobsData.length > 0) {
            console.log('   Completed job entries:', completedJobsData.map(cj => ({
              item_id: cj.item_id,
              job_number: cj.job_number
            })));
          }
        }
      }
      
      // STEP 3: Delete completed_jobs entries
      console.log('\n--- STEP 3: DELETING COMPLETED_JOBS ENTRIES ---');
      if (itemIds.length > 0) {
        const { error: deleteError, count } = await supabase
          .from('completed_jobs')
          .delete({ count: 'exact' })
          .in('item_id', itemIds);
        
        if (deleteError) {
          console.error('❌ Delete error:', deleteError);
          console.error('   Error code:', deleteError.code);
          console.error('   Error message:', deleteError.message);
          console.error('   Error details:', deleteError.details);
          throw new Error(`Failed to delete completed_jobs: ${deleteError.message}`);
        }
        
        console.log(`✅ Deleted ${count || 0} completed_jobs entries`);
      } else {
        console.log('⏭️  Skipping deletion - no items to delete');
      }
      
      // STEP 4: Update job status to planning
      console.log('\n--- STEP 4: UPDATING JOB STATUS ---');
      const { error: updateError, data: updatedJob } = await supabase
        .from('jobs')
        .update({ 
          status: 'planning', 
          archivedDate: null,
          completedDate: null 
        })
        .eq('id', jobId)
        .select()
        .single();
      
      if (updateError) {
        console.error('❌ Update error:', updateError);
        console.error('   Error code:', updateError.code);
        console.error('   Error message:', updateError.message);
        throw new Error(`Failed to update job: ${updateError.message}`);
      }
      
      console.log('✅ Job status updated successfully');
      console.log('   New status:', updatedJob?.status);
      
      // STEP 5: Update local state
      console.log('\n--- STEP 5: UPDATING LOCAL STATE ---');
      setJobs(prev => {
        const updated = prev.map(j => 
          j.id === jobId 
            ? { 
                ...j, 
                status: 'planning' as JobStatus, 
                archivedDate: undefined, 
                completedDate: undefined 
              }
            : j
        );
        console.log('✅ Local state updated');
        console.log('   Jobs with status=planning:', updated.filter(j => j.status === 'planning').length);
        console.log('   Jobs with status=archived:', updated.filter(j => j.status === 'archived').length);
        return updated;
      });
      
      // STEP 6: Create audit log
      console.log('\n--- STEP 6: CREATING AUDIT LOG ---');
      const user = await getCurrentUser();
      if (user) {
        try {
          await logAction({
            userId: user.userId,
            username: user.username,
            actionType: 'JOB_STATUS_CHANGED',
            actionDescription: `Restored job ${dbJob.jobNumber} from Archive to WIP`,
            entityType: 'job',
            entityId: jobId,
            metadata: { oldStatus: 'archived', newStatus: 'planning' }
          });
          console.log('✅ Audit log created');
        } catch (logErr) {
          console.error('⚠️  Failed to create audit log (non-critical):', logErr);
        }
      } else {
        console.log('⚠️  No user found for audit log');
      }
      
      console.log('\n========================================');
      console.log('✅ RESTORE JOB COMPLETED SUCCESSFULLY');
      console.log('========================================\n');
      
    } catch (error: any) {
      console.log('\n========================================');
      console.error('❌❌❌ RESTORE JOB FAILED ❌❌❌');
      console.log('========================================');
      console.error('Error type:', error.constructor.name);
      console.error('Error message:', error.message);
      console.error('Error stack:', error.stack);
      console.log('========================================\n');
      throw error;
    }
  };







  const updateItemStatus = async (jobId: string, itemId: string, status: ItemStatus) => {
    const job = jobs.find(j => j.id === jobId);
    if (!job) return;
    
    const item = job.items.find(i => i.id === itemId);
    if (!item) return;
    
    const oldStatus = item.status;
    
    // OPTIMISTIC UPDATE: Update local state immediately for instant UI feedback
    const updatedItems = job.items.map(item => item.id === itemId ? { ...item, status } : item);
    const allReady = updatedItems.every(item => item.status === 'Ready');
    
    const optimisticUpdate = {
      items: updatedItems,
      ...(allReady ? { status: 'done' as JobStatus, completedDate: new Date() } : {})
    };
    
    setJobs(prev => prev.map(j => j.id === jobId ? { ...j, ...optimisticUpdate } : j));
    
    // All secondary operations are fire-and-forget to prevent UI delays
    const weightKg = parseFloat(item.weightKg) || 0;
    
    // Fire-and-forget: tracking operations
    trackHourlyProduction(jobId, job.jobNumber, weightKg, oldStatus, status).catch(err => 
      console.error('Background hourly tracking error:', err)
    );
    trackItemStatusChange(jobId, job.jobNumber, itemId, oldStatus, status).catch(err => 
      console.error('Background performance tracking error:', err)
    );
    
    // Fire-and-forget: audit logging
    getCurrentUser().then(user => {
      if (user && job && item) {
        logAction({
          userId: user.userId,
          username: user.username,
          actionType: 'ITEM_STATUS_CHANGED',
          actionDescription: `Changed item status from ${oldStatus} to ${status} for job ${job.jobNumber}`,
          entityType: 'item',
          entityId: itemId,
          metadata: { jobId, jobNumber: job.jobNumber, itemDescription: item.descriptionOfWorks, oldStatus, newStatus: status }
        }).catch(err => console.error('Background audit log error:', err));
      }
    });

    // Fire-and-forget: finishing_records operations with enhanced logging

    if (oldStatus === 'Finishing' && ['Workshop', 'Acid', 'Galva'].includes(status)) {
      supabase.from('finishing_records').delete().eq('item_id', itemId)
        .then(({ error }) => {
          if (error) {
            logFailure('DELETE', 'finishing_records', error, { jobId, itemId, jobNumber: job.jobNumber });
          } else {
            logSuccess('DELETE', 'finishing_records', { jobId, itemId, jobNumber: job.jobNumber });
          }
        })
        .catch(err => {
          console.error('finishing_records delete error:', err);
          logFailure('DELETE', 'finishing_records', err, { jobId, itemId, jobNumber: job.jobNumber });
        });
    }
    
    if (status === 'Finishing' && oldStatus !== 'Finishing') {
      const today = new Date().toISOString().split('T')[0];
      const finishingData = {
        item_id: itemId, job_id: jobId, job_number: job.jobNumber,
        customer_name: job.customerName, item_description: item.descriptionOfWorks,
        weight_kg: item.weightKg, recorded_date: today,
        item_options: { paintVarnish: item.paintVarnish, galva: item.galva, lightGalva: item.lightGalva,
          lightPaint: item.lightPaint, rusty: item.rusty, doubleDip: item.doubleDip, multipleDip: item.multipleDip }
      };
      
      supabase.from('finishing_records').delete().eq('item_id', itemId)
        .then(() => {
          supabase.from('finishing_records').insert(finishingData)
            .then(({ error }) => {
              if (error) {
                logFailure('INSERT', 'finishing_records', error, { jobId, itemId, jobNumber: job.jobNumber, operationData: finishingData });
              } else {
                logSuccess('INSERT', 'finishing_records', { jobId, itemId, jobNumber: job.jobNumber, operationData: finishingData });
              }
            })
            .catch(err => {
              console.error('finishing_records insert error:', err);
              logFailure('INSERT', 'finishing_records', err, { jobId, itemId, jobNumber: job.jobNumber, operationData: finishingData });
            });
        })
        .catch(err => console.error('finishing_records delete error:', err));
      
      recordMovement(jobId, itemId, job.jobNumber, job.customerName, item.descriptionOfWorks, weightKg, oldStatus, status)
        .catch(err => console.error('recordMovement error:', err));
    }



    // Fire-and-forget: completed_jobs operations with enhanced logging
    if (oldStatus === 'Ready' && status !== 'Ready') {
      supabase.from('completed_jobs').delete().eq('item_id', itemId)
        .then(({ error }) => {
          if (error) {
            logFailure('DELETE', 'completed_jobs', error, { jobId, itemId, jobNumber: job.jobNumber });
          } else {
            logSuccess('DELETE', 'completed_jobs', { jobId, itemId, jobNumber: job.jobNumber });
          }
        })
        .catch(err => {
          console.error('completed_jobs delete error:', err);
          logFailure('DELETE', 'completed_jobs', err, { jobId, itemId, jobNumber: job.jobNumber });
        });
    }
    
    if (status === 'Ready' && oldStatus !== 'Ready') {
      const completedData = {
        job_id: jobId, item_id: itemId, job_number: job.jobNumber,
        customer_name: job.customerName, item_description: item.descriptionOfWorks,
        weight_kg: item.weightKg, completed_at: new Date().toISOString(),
        item_options: { paintVarnish: item.paintVarnish, galva: item.galva, lightGalva: item.lightGalva,
          lightPaint: item.lightPaint, rusty: item.rusty, doubleDip: item.doubleDip, multipleDip: item.multipleDip }
      };
      
      supabase.from('completed_jobs').upsert(completedData, { onConflict: 'item_id' })
        .then(({ error }) => {
          if (error) {
            logFailure('UPSERT', 'completed_jobs', error, { jobId, itemId, jobNumber: job.jobNumber, operationData: completedData });
          } else {
            logSuccess('UPSERT', 'completed_jobs', { jobId, itemId, jobNumber: job.jobNumber, operationData: completedData });
          }
        })
        .catch(err => {
          console.error('completed_jobs upsert error:', err);
          logFailure('UPSERT', 'completed_jobs', err, { jobId, itemId, jobNumber: job.jobNumber, operationData: completedData });
        });
    }

    
    // Fire-and-forget: delivery date tracking
    if (allReady && job.deliveryDate) {
      const deliveryDateStr = new Date(job.deliveryDate).toISOString().split('T')[0];
      const totalWeight = job.items.reduce((sum, item) => sum + parseFloat(item.weightKg || '0'), 0);
      supabase.from('delivery_date_job_completions').insert({
        job_id: jobId, delivery_date: deliveryDateStr, job_number: job.jobNumber, total_weight: totalWeight
      }).then(() => {}).catch(err => console.error('delivery tracking error:', err));
    }

    
    // Only await the final job update - this triggers realtime for other clients
    try {
      if (allReady) {
        await updateJob(jobId, { items: updatedItems, status: 'done', completedDate: new Date() });
      } else {
        await updateJob(jobId, { items: updatedItems });
      }
    } catch (error) {
      console.error('Error updating item status:', error);
      // REVERT OPTIMISTIC UPDATE on error
      setJobs(prev => prev.map(j => j.id === jobId ? job : j));
      throw error;
    }
  };








  const updateMultipleItemStatuses = async (jobId: string, itemIds: string[], status: ItemStatus) => {
    const job = jobs.find(j => j.id === jobId);
    if (!job) return;
    
    // OPTIMISTIC UPDATE: Update local state immediately for instant UI feedback
    const updatedItems = job.items.map(item => 
      itemIds.includes(item.id) ? { ...item, status } : item
    );
    const allReady = updatedItems.every(item => item.status === 'Ready');
    
    const optimisticUpdate = {
      items: updatedItems,
      ...(allReady ? { status: 'done' as JobStatus, completedDate: new Date() } : {})
    };
    
    setJobs(prev => prev.map(j => j.id === jobId ? { ...j, ...optimisticUpdate } : j));
    
    // All secondary operations are fire-and-forget to prevent UI delays
    for (const itemId of itemIds) {
      const item = job.items.find(i => i.id === itemId);
      if (item) {
        const weightKg = parseFloat(item.weightKg) || 0;
        trackHourlyProduction(jobId, job.jobNumber, weightKg, item.status, status).catch(err => 
          console.error('Background hourly tracking error:', err)
        );
        trackItemStatusChange(jobId, job.jobNumber, itemId, item.status, status).catch(err => 
          console.error('Background performance tracking error:', err)
        );
      }
    }

    // Fire-and-forget: finishing_records operations
    if (['Workshop', 'Acid', 'Galva'].includes(status)) {
      const itemsMovingBackward = itemIds.filter(itemId => {
        const item = job.items.find(i => i.id === itemId);
        return item && item.status === 'Finishing';
      });
      if (itemsMovingBackward.length > 0) {
        supabase.from('finishing_records').delete().in('item_id', itemsMovingBackward)
          .then(() => {}).catch(err => console.error('finishing_records delete error:', err));
      }
    }
    
    if (status === 'Finishing') {
      const today = new Date().toISOString().split('T')[0];
      const itemsToRecord = itemIds.filter(itemId => {
        const item = job.items.find(i => i.id === itemId);
        return item && item.status !== 'Finishing';
      });
      if (itemsToRecord.length > 0) {
        supabase.from('finishing_records').delete().in('item_id', itemsToRecord)
          .then(() => {
            const recordsToInsert = itemsToRecord.map(itemId => {
              const item = job.items.find(i => i.id === itemId)!;
              return {
                job_id: jobId, item_id: itemId, job_number: job.jobNumber, customer_name: job.customerName,
                item_description: item.descriptionOfWorks, weight_kg: item.weightKg, recorded_date: today,
                item_options: { paintVarnish: item.paintVarnish, galva: item.galva, lightGalva: item.lightGalva,
                  lightPaint: item.lightPaint, rusty: item.rusty, doubleDip: item.doubleDip, multipleDip: item.multipleDip }
              };
            });
            supabase.from('finishing_records').insert(recordsToInsert).then(() => {}).catch(err => console.error('finishing_records insert error:', err));
          })
          .catch(err => console.error('finishing_records delete error:', err));
        
        // Fire-and-forget: record movements
        for (const itemId of itemsToRecord) {
          const item = job.items.find(i => i.id === itemId)!;
          const weightKg = parseFloat(item.weightKg) || 0;
          recordMovement(jobId, itemId, job.jobNumber, job.customerName, item.descriptionOfWorks, weightKg, item.status, status)
            .catch(err => console.error('recordMovement error:', err));
        }
      }
    }

    // Fire-and-forget: completed_jobs operations
    if (status !== 'Ready') {
      const itemsMovingBackward = itemIds.filter(itemId => {
        const item = job.items.find(i => i.id === itemId);
        return item && item.status === 'Ready';
      });
      if (itemsMovingBackward.length > 0) {
        supabase.from('completed_jobs').delete().in('item_id', itemsMovingBackward)
          .then(() => {}).catch(err => console.error('completed_jobs delete error:', err));
      }
    }
    
    if (status === 'Ready') {
      const itemsToComplete = itemIds.filter(itemId => {
        const item = job.items.find(i => i.id === itemId);
        return item && item.status !== 'Ready';
      });
      if (itemsToComplete.length > 0) {
        supabase.from('completed_jobs').delete().in('item_id', itemsToComplete)
          .then(() => {
            const recordsToInsert = itemsToComplete.map(itemId => {
              const item = job.items.find(i => i.id === itemId)!;
              return {
                job_id: jobId, item_id: itemId, job_number: job.jobNumber, customer_name: job.customerName,
                item_description: item.descriptionOfWorks, weight_kg: item.weightKg, completed_at: new Date().toISOString(),
                item_options: { paintVarnish: item.paintVarnish, galva: item.galva, lightGalva: item.lightGalva,
                  lightPaint: item.lightPaint, rusty: item.rusty, doubleDip: item.doubleDip, multipleDip: item.multipleDip }
              };
            });
            supabase.from('completed_jobs').insert(recordsToInsert).then(() => {}).catch(err => console.error('completed_jobs insert error:', err));
          })
          .catch(err => console.error('completed_jobs delete error:', err));
      }
    }
    
    // Fire-and-forget: delivery date tracking
    if (allReady && job.deliveryDate) {
      const deliveryDateStr = new Date(job.deliveryDate).toISOString().split('T')[0];
      const totalWeight = job.items.reduce((sum, item) => sum + parseFloat(item.weightKg || '0'), 0);
      supabase.from('delivery_date_job_completions').insert({
        job_id: jobId, delivery_date: deliveryDateStr, job_number: job.jobNumber, total_weight: totalWeight
      }).then(() => {}).catch(err => console.error('delivery tracking error:', err));
    }

    
    // Only await the final job update - this triggers realtime for other clients
    try {
      if (allReady) {
        await updateJob(jobId, { items: updatedItems, status: 'done', completedDate: new Date() });
      } else {
        await updateJob(jobId, { items: updatedItems });
      }
    } catch (error) {
      console.error('Error updating multiple item statuses:', error);
      // REVERT OPTIMISTIC UPDATE on error
      setJobs(prev => prev.map(j => j.id === jobId ? job : j));
      throw error;
    }
  };




  const revertSelectedItemsToWIP = async (jobId: string, itemIds: string[], targetStatus: ItemStatus) => {
    const job = jobs.find(j => j.id === jobId);
    if (!job) return;
    
    // Delete completed_jobs entries for selected items
    if (itemIds.length > 0) {
      await supabase.from('completed_jobs').delete().in('item_id', itemIds);
    }
    
    // Update selected items to target status
    const updatedItems = job.items.map(item => 
      itemIds.includes(item.id) ? { ...item, status: targetStatus } : item
    );
    
    // Check if all items are still Ready - if not, move job back to planning
    const allReady = updatedItems.every(item => item.status === 'Ready');
    
    if (!allReady && job.status === 'done') {
      // Move job back to planning (WIP) and clear completedDate
      await updateJob(jobId, { 
        items: updatedItems, 
        status: 'planning', 
        completedDate: undefined 
      });
    } else {
      await updateJob(jobId, { items: updatedItems });
    }
    
    const user = await getCurrentUser();
    if (user && job) {
      await logAction({
        userId: user.userId,
        username: user.username,
        actionType: 'ITEMS_REVERTED_TO_WIP',
        actionDescription: `Reverted ${itemIds.length} item(s) from job ${job.jobNumber} to ${targetStatus}`,
        entityType: 'job',
        entityId: jobId,
        metadata: { itemIds, targetStatus, jobNumber: job.jobNumber }
      });
    }
  };






  return (
    <JobContext.Provider value={{
      jobs,
      loading,
      addJob,
      updateJob,
      deleteJob,
      moveToPlanning,
      moveToDone,
      revertToPlanning,
      revertToPending,
      updateItemStatus,
      updateMultipleItemStatuses,
      revertSelectedItemsToWIP,
      archiveJob,
      restoreJob,
      checkAndArchiveDoneJobs
    }}>
      <ConflictResolutionModal
        visible={conflictModalVisible}
        localVersion={currentConflict?.localVersion}
        serverVersion={currentConflict?.serverVersion}
        onResolve={resolveConflict}
        onCancel={() => resolveConflict('skip')}
      />
      {children}
    </JobContext.Provider>
  );
};



export const useJobs = () => {
  const context = useContext(JobContext);
  if (!context) {
    throw new Error('useJobs must be used within a JobProvider');
  }
  return context;
};
