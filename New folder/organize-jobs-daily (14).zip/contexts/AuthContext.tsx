import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '@/app/lib/supabase';

interface User {
  id: string;
  username: string;
  full_name: string;
  role: 'admin' | 'manager' | 'operator' | 'viewer' | 'data_entry_officer';
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signIn: (username: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  hasPermission: (action: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Mock user with admin permissions for unrestricted access
  const [user] = useState<User>({
    id: 'mock-user-id',
    username: 'admin',
    full_name: 'Admin User',
    role: 'admin'
  });
  const [loading] = useState(false);


  const signIn = async (username: string, password: string) => {
    // Authentication bypassed - no-op
  };

  const signOut = async () => {
    // Authentication bypassed - no-op
  };


  const hasPermission = (action: string) => {
    if (!user) return false;
    const permissions: Record<string, string[]> = {
      'manage_users': ['admin'],
      'add_jobs': ['admin', 'manager', 'data_entry_officer'],
      'edit_jobs': ['admin', 'manager', 'operator'],
      'delete_jobs': ['admin', 'manager'],
      'view_statistics': ['admin', 'manager', 'viewer', 'data_entry_officer', 'operator'],
    };
    return permissions[action]?.includes(user.role) || false;
  };

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signOut, hasPermission }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
