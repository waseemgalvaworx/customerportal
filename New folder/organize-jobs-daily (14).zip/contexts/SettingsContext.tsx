import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ItemStatus } from './JobContext';
import { supabase } from '@/app/lib/supabase';


export type SaveLocation = 'documents' | 'downloads';

interface SettingsContextType {
  autoArchiveEnabled: boolean;
  autoArchiveTime: string;
  pdfSaveLocation: SaveLocation;
  emailRecipients: string[];
  wipViewMode: 'list' | 'date' | 'status';
  wipActiveFilter: 'all' | 'galvaxpress' | 'high';
  wipStatusFilter: ItemStatus | 'all';
  newBadgeEnabled: boolean;
  setAutoArchiveEnabled: (enabled: boolean) => void;
  setAutoArchiveTime: (time: string) => void;
  setPdfSaveLocation: (location: SaveLocation) => void;
  setEmailRecipients: (recipients: string[]) => void;
  setWipViewMode: (mode: 'list' | 'date' | 'status') => void;
  setWipActiveFilter: (filter: 'all' | 'galvaxpress' | 'high') => void;
  setWipStatusFilter: (filter: ItemStatus | 'all') => void;
  setNewBadgeEnabled: (enabled: boolean) => void;
}


const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

const SETTINGS_KEY = 'app_settings';

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [autoArchiveEnabled, setAutoArchiveEnabled] = useState(false);
  const [autoArchiveTime, setAutoArchiveTime] = useState('00:00');
  const [pdfSaveLocation, setPdfSaveLocation] = useState<SaveLocation>('documents');
  const [emailRecipients, setEmailRecipients] = useState<string[]>([]);
  const [wipViewMode, setWipViewMode] = useState<'list' | 'date' | 'status'>('date');
  const [wipActiveFilter, setWipActiveFilter] = useState<'all' | 'galvaxpress' | 'high'>('all');
  const [wipStatusFilter, setWipStatusFilter] = useState<ItemStatus | 'all'>('all');
  const [newBadgeEnabled, setNewBadgeEnabled] = useState(true);

  // Load settings from AsyncStorage and database on mount
  useEffect(() => {
    loadSettings();
    loadEmailRecipientsFromDB();
  }, []);

  // Save settings to AsyncStorage whenever they change (except emailRecipients - those are in DB)
  useEffect(() => {
    saveSettings();
  }, [autoArchiveEnabled, autoArchiveTime, pdfSaveLocation, wipViewMode, wipActiveFilter, wipStatusFilter, newBadgeEnabled]);

  const loadEmailRecipientsFromDB = async () => {
    try {
      const { data, error } = await supabase
        .from('email_recipients')
        .select('email')
        .order('created_at', { ascending: true });

      if (error) throw error;

      if (data && data.length > 0) {
        const emails = data.map(r => r.email);
        setEmailRecipients(emails);
      }
    } catch (error) {
      console.error('Error loading email recipients from DB:', error);
    }
  };

  const loadSettings = async () => {
    try {
      const stored = await AsyncStorage.getItem(SETTINGS_KEY);
      if (stored) {
        const settings = JSON.parse(stored);
        if (settings.autoArchiveEnabled !== undefined) setAutoArchiveEnabled(settings.autoArchiveEnabled);
        if (settings.autoArchiveTime) setAutoArchiveTime(settings.autoArchiveTime);
        if (settings.pdfSaveLocation) setPdfSaveLocation(settings.pdfSaveLocation);
        // emailRecipients now loaded from database, not AsyncStorage
        if (settings.wipViewMode) setWipViewMode(settings.wipViewMode);
        if (settings.wipActiveFilter) setWipActiveFilter(settings.wipActiveFilter);
        if (settings.wipStatusFilter) setWipStatusFilter(settings.wipStatusFilter);
        if (settings.newBadgeEnabled !== undefined) setNewBadgeEnabled(settings.newBadgeEnabled);
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  };



  const saveSettings = async () => {
    try {
      const settings = {
        autoArchiveEnabled,
        autoArchiveTime,
        pdfSaveLocation,
        emailRecipients,
        wipViewMode,
        wipActiveFilter,
        wipStatusFilter,
        newBadgeEnabled
      };
      await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (error) {
      console.error('Error saving settings:', error);
    }
  };

  return (
    <SettingsContext.Provider value={{
      autoArchiveEnabled,
      autoArchiveTime,
      pdfSaveLocation,
      emailRecipients,
      wipViewMode,
      wipActiveFilter,
      wipStatusFilter,
      newBadgeEnabled,
      setAutoArchiveEnabled,
      setAutoArchiveTime,
      setPdfSaveLocation,
      setEmailRecipients,
      setWipViewMode,
      setWipActiveFilter,
      setWipStatusFilter,
      setNewBadgeEnabled,
    }}>
      {children}
    </SettingsContext.Provider>
  );
}


export function useSettings() {
  const context = useContext(SettingsContext);
  if (!context) throw new Error('useSettings must be used within SettingsProvider');
  return context;
}
