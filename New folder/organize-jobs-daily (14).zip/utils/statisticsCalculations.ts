export const calcWeight = (jobList: any[]) => 
  jobList.reduce((sum, job) => 
    sum + job.items.reduce((s: number, item: any) => s + parseFloat(item.weightKg || '0'), 0), 0
  );

export const calcAvgTurnaround = (jobs: any[]) => {
  const completedJobs = jobs.filter(j => j.completedDate);
  const turnaroundTimes = completedJobs.map(job => {
    const start = new Date(job.dateOfEntry).getTime();
    const end = new Date(job.completedDate!).getTime();
    const days = (end - start) / (1000 * 60 * 60 * 24);
    
    // Calculate working days (exclude Sundays)
    let workingDays = 0;
    const current = new Date(job.dateOfEntry);
    while (current <= new Date(job.completedDate!)) {
      if (current.getDay() !== 0) { // Exclude Sunday
        workingDays++;
      }
      current.setDate(current.getDate() + 1);
    }
    return workingDays;
  });
  return turnaroundTimes.length > 0
    ? turnaroundTimes.reduce((a, b) => a + b, 0) / turnaroundTimes.length
    : 0;
};


export const getJobDate = (job: any) => {
  // For pending/planning jobs, use dateOfEntry; for done/archived, use completedDate/archivedDate
  if (job.status === 'pending' || job.status === 'planning') {
    return job.dateOfEntry ? new Date(job.dateOfEntry) : null;
  }
  const date = job.completedDate || job.archivedDate;
  return date ? new Date(date) : null;
};


export const getDayOfWeek = (date: Date) => {
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const dayIndex = date.getDay();
  // Sunday is 0, so we skip it. Monday is 1, becomes index 0
  return dayIndex === 0 ? null : days[dayIndex - 1];
};

export const getISOWeek = (date: Date) => {
  const target = new Date(date.valueOf());
  const dayNr = (date.getDay() + 6) % 7;
  target.setDate(target.getDate() - dayNr + 3);
  const firstThursday = target.valueOf();
  target.setMonth(0, 1);
  if (target.getDay() !== 4) {
    target.setMonth(0, 1 + ((4 - target.getDay()) + 7) % 7);
  }
  return 1 + Math.ceil((firstThursday - target.valueOf()) / 604800000);
};


export const getWeekOfMonth = (date: Date) => {
  const firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
  const dayOfMonth = date.getDate();
  const firstDayOfWeek = firstDay.getDay();
  return Math.ceil((dayOfMonth + firstDayOfWeek) / 7);
};

export const getMonthName = (date: Date) => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return months[date.getMonth()];
};
