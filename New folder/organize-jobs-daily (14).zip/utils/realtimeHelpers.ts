import { supabase } from '@/app/lib/supabase';
import type { RealtimeChannel, RealtimePostgresChangesPayload } from '@supabase/supabase-js';

type EventType = 'INSERT' | 'UPDATE' | 'DELETE' | '*';

interface SelectiveSubscription {
  channel: RealtimeChannel;
  unsubscribe: () => void;
}

/**
 * Subscribe to specific rows in a table using a filter
 * More efficient than subscribing to entire table
 */
export function subscribeToRows(
  channelName: string,
  table: string,
  filterColumn: string,
  filterValue: string,
  onUpdate: (payload: RealtimePostgresChangesPayload<any>) => void,
  events: EventType[] = ['*']
): SelectiveSubscription {
  const filter = `${filterColumn}=eq.${filterValue}`;
  
  let channel = supabase.channel(channelName);
  
  events.forEach(event => {
    channel = channel.on('postgres_changes', {
      event,
      schema: 'public',
      table,
      filter
    }, onUpdate);
  });
  
  channel.subscribe((status) => {
    if (status === 'SUBSCRIBED') {
      console.log(`✅ Selective subscription active: ${table} where ${filter}`);
    }
  });
  
  return {
    channel,
    unsubscribe: () => {
      supabase.removeChannel(channel);
      console.log(`🔌 Unsubscribed from ${channelName}`);
    }
  };
}

/**
 * Subscribe to multiple tables with a single channel
 * Reduces connection overhead
 */
export function subscribeToMultipleTables(
  channelName: string,
  tables: Array<{
    table: string;
    filter?: string;
    events?: EventType[];
  }>,
  onUpdate: (table: string, payload: RealtimePostgresChangesPayload<any>) => void
): SelectiveSubscription {
  let channel = supabase.channel(channelName);
  
  tables.forEach(({ table, filter, events = ['*'] }) => {
    events.forEach(event => {
      const config: any = { event, schema: 'public', table };
      if (filter) config.filter = filter;
      
      channel = channel.on('postgres_changes', config, (payload) => {
        onUpdate(table, payload);
      });
    });
  });
  
  channel.subscribe((status) => {
    console.log(`📡 Multi-table subscription ${channelName}: ${status}`);
  });
  
  return {
    channel,
    unsubscribe: () => {
      supabase.removeChannel(channel);
    }
  };
}

/**
 * Create a debounced refresh function
 * Prevents excessive database queries when multiple changes happen rapidly
 */
export function createDebouncedRefresh(
  refreshFn: () => Promise<void>,
  delayMs: number = 300
): { trigger: () => void; cancel: () => void } {
  let timeoutId: NodeJS.Timeout | null = null;
  let pendingCount = 0;
  
  return {
    trigger: () => {
      pendingCount++;
      
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
      
      timeoutId = setTimeout(async () => {
        const count = pendingCount;
        pendingCount = 0;
        timeoutId = null;
        
        console.log(`🔄 Debounced refresh triggered (${count} changes batched)`);
        await refreshFn();
      }, delayMs);
    },
    cancel: () => {
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }
      pendingCount = 0;
    }
  };
}

/**
 * Subscribe with automatic debouncing
 */
export function subscribeDebouncedTable(
  channelName: string,
  table: string,
  refreshFn: () => Promise<void>,
  options?: {
    filter?: string;
    events?: EventType[];
    debounceMs?: number;
  }
): SelectiveSubscription {
  const { filter, events = ['*'], debounceMs = 300 } = options || {};
  const debounced = createDebouncedRefresh(refreshFn, debounceMs);
  
  let channel = supabase.channel(channelName);
  
  events.forEach(event => {
    const config: any = { event, schema: 'public', table };
    if (filter) config.filter = filter;
    
    channel = channel.on('postgres_changes', config, () => {
      debounced.trigger();
    });
  });
  
  channel.subscribe();
  
  return {
    channel,
    unsubscribe: () => {
      debounced.cancel();
      supabase.removeChannel(channel);
    }
  };
}
