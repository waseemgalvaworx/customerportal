import * as FileSystem from 'expo-file-system';
import * as Print from 'expo-print';
import { Alert, Platform } from 'react-native';
import { SaveLocation } from '../contexts/SettingsContext';

export const getDirectoryPath = (location: SaveLocation): string => {
  if (Platform.OS === 'android') {
    return location === 'documents' 
      ? `${FileSystem.documentDirectory}Documents/`
      : `${FileSystem.documentDirectory}Download/`;
  } else {
    return location === 'documents'
      ? `${FileSystem.documentDirectory}Documents/`
      : `${FileSystem.documentDirectory}Downloads/`;
  }
};

export const savePDFToDirectory = async (
  html: string,
  filename: string,
  location: SaveLocation,
  width?: number,
  height?: number
): Promise<string> => {
  try {
    // Only pass width/height if explicitly provided, otherwise let HTML @page rule handle it
    const printOptions: any = { html };
    if (width !== undefined && height !== undefined) {
      printOptions.width = width;
      printOptions.height = height;
    }
    
    const { uri } = await Print.printToFileAsync(printOptions);

    const dirPath = getDirectoryPath(location);
    
    const dirInfo = await FileSystem.getInfoAsync(dirPath);
    if (!dirInfo.exists) {
      await FileSystem.makeDirectoryAsync(dirPath, { intermediates: true });
    }
    
    const finalPath = `${dirPath}${filename}`;
    await FileSystem.moveAsync({ from: uri, to: finalPath });
    
    return finalPath;
  } catch (error) {
    console.error('Error saving PDF:', error);
    throw error;
  }
};


export const showSaveConfirmation = (filePath: string, filename: string) => {
  Alert.alert(
    'PDF Saved Successfully',
    `File: ${filename}\n\nLocation: ${filePath}`,
    [{ text: 'OK', style: 'default' }]
  );
};
