/**
 * Enhanced Data Operation Logger
 * 
 * Logs ALL database insert/update/delete operations with success/failure status.
 * This provides comprehensive visibility into data operations for debugging
 * and ensuring data integrity.
 */

import { supabase } from '@/app/lib/supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { PasswordUser } from '@/app/lib/passwordAuth';

export type OperationType = 'INSERT' | 'UPDATE' | 'DELETE' | 'UPSERT';
export type OperationStatus = 'SUCCESS' | 'FAILED';

interface OperationLogEntry {
  operationType: OperationType;
  tableName: string;
  recordId?: string;
  jobId?: string;
  itemId?: string;
  jobNumber?: string;
  operationStatus: OperationStatus;
  errorMessage?: string;
  errorCode?: string;
  operationData?: Record<string, any>;
}

// Get current user for logging
const getCurrentUser = async (): Promise<{ userId: string; username: string } | null> => {
  try {
    const stored = await AsyncStorage.getItem('auth_user');
    if (stored) {
      const user: PasswordUser = JSON.parse(stored);
      return { userId: user.id, username: user.username };
    }
  } catch (error) {
    console.error('Error getting current user for logging:', error);
  }
  return null;
};

/**
 * Log a data operation to the data_operation_logs table
 */
export async function logDataOperation(entry: OperationLogEntry): Promise<void> {
  try {
    const user = await getCurrentUser();
    
    const { error } = await supabase
      .from('data_operation_logs')
      .insert({
        operation_type: entry.operationType,
        table_name: entry.tableName,
        record_id: entry.recordId,
        job_id: entry.jobId,
        item_id: entry.itemId,
        job_number: entry.jobNumber,
        operation_status: entry.operationStatus,
        error_message: entry.errorMessage,
        error_code: entry.errorCode,
        operation_data: entry.operationData,
        user_id: user?.userId,
        username: user?.username,
      });

    if (error) {
      // Don't throw - just log to console to prevent cascading failures
      console.error('Failed to log data operation:', error);
    }
  } catch (err) {
    console.error('Error in logDataOperation:', err);
  }
}

/**
 * Log a successful operation
 */
export async function logSuccess(
  operationType: OperationType,
  tableName: string,
  data: {
    recordId?: string;
    jobId?: string;
    itemId?: string;
    jobNumber?: string;
    operationData?: Record<string, any>;
  }
): Promise<void> {
  await logDataOperation({
    operationType,
    tableName,
    recordId: data.recordId,
    jobId: data.jobId,
    itemId: data.itemId,
    jobNumber: data.jobNumber,
    operationStatus: 'SUCCESS',
    operationData: data.operationData,
  });
}

/**
 * Log a failed operation
 */
export async function logFailure(
  operationType: OperationType,
  tableName: string,
  error: any,
  data: {
    recordId?: string;
    jobId?: string;
    itemId?: string;
    jobNumber?: string;
    operationData?: Record<string, any>;
  }
): Promise<void> {
  await logDataOperation({
    operationType,
    tableName,
    recordId: data.recordId,
    jobId: data.jobId,
    itemId: data.itemId,
    jobNumber: data.jobNumber,
    operationStatus: 'FAILED',
    errorMessage: error?.message || String(error),
    errorCode: error?.code,
    operationData: data.operationData,
  });
}

/**
 * Wrapper for Supabase insert with automatic logging
 */
export async function loggedInsert<T>(
  tableName: string,
  data: T | T[],
  metadata: {
    jobId?: string;
    itemId?: string;
    jobNumber?: string;
  } = {}
): Promise<{ data: any; error: any }> {
  const result = await supabase.from(tableName).insert(data as any).select();
  
  const items = Array.isArray(data) ? data : [data];
  
  if (result.error) {
    // Log each failed item
    for (const item of items) {
      await logFailure('INSERT', tableName, result.error, {
        jobId: metadata.jobId || (item as any).job_id,
        itemId: metadata.itemId || (item as any).item_id,
        jobNumber: metadata.jobNumber || (item as any).job_number,
        operationData: item as Record<string, any>,
      });
    }
  } else {
    // Log each successful item
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const resultItem = result.data?.[i];
      await logSuccess('INSERT', tableName, {
        recordId: resultItem?.id,
        jobId: metadata.jobId || (item as any).job_id,
        itemId: metadata.itemId || (item as any).item_id,
        jobNumber: metadata.jobNumber || (item as any).job_number,
        operationData: item as Record<string, any>,
      });
    }
  }
  
  return result;
}

/**
 * Wrapper for Supabase upsert with automatic logging
 */
export async function loggedUpsert<T>(
  tableName: string,
  data: T | T[],
  options: { onConflict?: string } = {},
  metadata: {
    jobId?: string;
    itemId?: string;
    jobNumber?: string;
  } = {}
): Promise<{ data: any; error: any }> {
  const result = await supabase
    .from(tableName)
    .upsert(data as any, options)
    .select();
  
  const items = Array.isArray(data) ? data : [data];
  
  if (result.error) {
    for (const item of items) {
      await logFailure('UPSERT', tableName, result.error, {
        jobId: metadata.jobId || (item as any).job_id,
        itemId: metadata.itemId || (item as any).item_id,
        jobNumber: metadata.jobNumber || (item as any).job_number,
        operationData: item as Record<string, any>,
      });
    }
  } else {
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const resultItem = result.data?.[i];
      await logSuccess('UPSERT', tableName, {
        recordId: resultItem?.id,
        jobId: metadata.jobId || (item as any).job_id,
        itemId: metadata.itemId || (item as any).item_id,
        jobNumber: metadata.jobNumber || (item as any).job_number,
        operationData: item as Record<string, any>,
      });
    }
  }
  
  return result;
}

/**
 * Wrapper for Supabase delete with automatic logging
 */
export async function loggedDelete(
  tableName: string,
  filter: { column: string; value: string | string[] },
  metadata: {
    jobId?: string;
    itemId?: string;
    jobNumber?: string;
  } = {}
): Promise<{ data: any; error: any }> {
  let query = supabase.from(tableName).delete();
  
  if (Array.isArray(filter.value)) {
    query = query.in(filter.column, filter.value);
  } else {
    query = query.eq(filter.column, filter.value);
  }
  
  const result = await query.select();
  
  const itemIds = Array.isArray(filter.value) ? filter.value : [filter.value];
  
  if (result.error) {
    for (const itemId of itemIds) {
      await logFailure('DELETE', tableName, result.error, {
        jobId: metadata.jobId,
        itemId: filter.column === 'item_id' ? itemId : metadata.itemId,
        jobNumber: metadata.jobNumber,
        operationData: { [filter.column]: itemId },
      });
    }
  } else {
    for (const itemId of itemIds) {
      await logSuccess('DELETE', tableName, {
        jobId: metadata.jobId,
        itemId: filter.column === 'item_id' ? itemId : metadata.itemId,
        jobNumber: metadata.jobNumber,
        operationData: { [filter.column]: itemId },
      });
    }
  }
  
  return result;
}

/**
 * Get recent operation logs for debugging
 */
export async function getRecentOperationLogs(options: {
  limit?: number;
  tableName?: string;
  status?: OperationStatus;
  jobId?: string;
  hoursBack?: number;
} = {}): Promise<any[]> {
  const { limit = 100, tableName, status, jobId, hoursBack = 24 } = options;
  
  const cutoffTime = new Date();
  cutoffTime.setHours(cutoffTime.getHours() - hoursBack);
  
  let query = supabase
    .from('data_operation_logs')
    .select('*')
    .gte('created_at', cutoffTime.toISOString())
    .order('created_at', { ascending: false })
    .limit(limit);
  
  if (tableName) {
    query = query.eq('table_name', tableName);
  }
  
  if (status) {
    query = query.eq('operation_status', status);
  }
  
  if (jobId) {
    query = query.eq('job_id', jobId);
  }
  
  const { data, error } = await query;
  
  if (error) {
    console.error('Error fetching operation logs:', error);
    return [];
  }
  
  return data || [];
}

/**
 * Get failed operations summary for a time period
 */
export async function getFailedOperationsSummary(hoursBack: number = 24): Promise<{
  totalFailed: number;
  byTable: Record<string, number>;
  byOperation: Record<string, number>;
  recentErrors: any[];
}> {
  const cutoffTime = new Date();
  cutoffTime.setHours(cutoffTime.getHours() - hoursBack);
  
  const { data, error } = await supabase
    .from('data_operation_logs')
    .select('*')
    .eq('operation_status', 'FAILED')
    .gte('created_at', cutoffTime.toISOString())
    .order('created_at', { ascending: false });
  
  if (error || !data) {
    console.error('Error fetching failed operations:', error);
    return {
      totalFailed: 0,
      byTable: {},
      byOperation: {},
      recentErrors: [],
    };
  }
  
  const byTable: Record<string, number> = {};
  const byOperation: Record<string, number> = {};
  
  for (const log of data) {
    byTable[log.table_name] = (byTable[log.table_name] || 0) + 1;
    byOperation[log.operation_type] = (byOperation[log.operation_type] || 0) + 1;
  }
  
  return {
    totalFailed: data.length,
    byTable,
    byOperation,
    recentErrors: data.slice(0, 10),
  };
}
