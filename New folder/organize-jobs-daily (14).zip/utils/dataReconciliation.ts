/**
 * Data Reconciliation System
 * 
 * Performs daily automated checks comparing:
 * - jobs table vs finishing_records
 * - jobs table vs completed_jobs
 * 
 * Alerts Admin only on mismatches via notifications and stores reports for review.
 */

import { supabase } from '@/app/lib/supabase';
import { notifyAdminOnly } from '@/utils/notificationHelper';


export interface ReconciliationResult {
  reportId: string;
  reportDate: string;
  totalJobsChecked: number;
  totalItemsChecked: number;
  finishingMismatches: number;
  completedMismatches: number;
  missingFinishingRecords: MismatchItem[];
  orphanFinishingRecords: OrphanRecord[];
  missingCompletedRecords: MismatchItem[];
  orphanCompletedRecords: OrphanRecord[];
  status: 'COMPLETED' | 'FAILED';
  errors?: string[];
}

export interface MismatchItem {
  jobId: string;
  jobNumber: string;
  itemId: string;
  itemDescription: string;
  customerName: string;
  expectedStatus: string;
}

export interface OrphanRecord {
  recordId: string;
  jobId: string;
  itemId: string;
  jobNumber: string;
  tableName: string;
}

/**
 * Run a full data reconciliation check
 */
export async function runReconciliation(runBy?: string): Promise<ReconciliationResult> {
  const reportDate = new Date().toISOString().split('T')[0];
  const errors: string[] = [];
  
  // Create initial report entry
  const { data: reportData, error: reportError } = await supabase
    .from('reconciliation_reports')
    .insert({
      report_date: reportDate,
      report_type: runBy ? 'MANUAL' : 'DAILY',
      status: 'PENDING',
      run_by: runBy || 'SYSTEM',
    })
    .select()
    .single();
  
  if (reportError) {
    console.error('Failed to create reconciliation report:', reportError);
    throw new Error('Failed to create reconciliation report');
  }
  
  const reportId = reportData.id;
  
  try {
    // Fetch all jobs with their items (only planning and done status - active jobs)
    const { data: jobs, error: jobsError } = await supabase
      .from('jobs')
      .select('*')
      .in('status', ['planning', 'done']);
    
    if (jobsError) {
      errors.push(`Failed to fetch jobs: ${jobsError.message}`);
      throw jobsError;
    }
    
    // Fetch all finishing_records
    const { data: finishingRecords, error: finishingError } = await supabase
      .from('finishing_records')
      .select('*');
    
    if (finishingError) {
      errors.push(`Failed to fetch finishing_records: ${finishingError.message}`);
    }
    
    // Fetch all completed_jobs
    const { data: completedJobs, error: completedError } = await supabase
      .from('completed_jobs')
      .select('*');
    
    if (completedError) {
      errors.push(`Failed to fetch completed_jobs: ${completedError.message}`);
    }
    
    // Create lookup maps
    const finishingByItemId = new Map<string, any>();
    (finishingRecords || []).forEach(record => {
      finishingByItemId.set(record.item_id, record);
    });
    
    const completedByItemId = new Map<string, any>();
    (completedJobs || []).forEach(record => {
      completedByItemId.set(record.item_id, record);
    });
    
    // Track all item IDs from jobs
    const allJobItemIds = new Set<string>();
    const finishingItemIds = new Set<string>();
    const readyItemIds = new Set<string>();
    
    // Results
    const missingFinishingRecords: MismatchItem[] = [];
    const missingCompletedRecords: MismatchItem[] = [];
    let totalItemsChecked = 0;
    
    // Check each job's items
    for (const job of jobs || []) {
      const items = job.items || [];
      
      for (const item of items) {
        totalItemsChecked++;
        allJobItemIds.add(item.id);
        
        // Check Finishing status items
        if (item.status === 'Finishing') {
          finishingItemIds.add(item.id);
          
          if (!finishingByItemId.has(item.id)) {
            missingFinishingRecords.push({
              jobId: job.id,
              jobNumber: job.jobNumber,
              itemId: item.id,
              itemDescription: item.descriptionOfWorks || 'N/A',
              customerName: job.customerName,
              expectedStatus: 'Finishing',
            });
          }
        }
        
        // Check Ready status items
        if (item.status === 'Ready') {
          readyItemIds.add(item.id);
          
          if (!completedByItemId.has(item.id)) {
            missingCompletedRecords.push({
              jobId: job.id,
              jobNumber: job.jobNumber,
              itemId: item.id,
              itemDescription: item.descriptionOfWorks || 'N/A',
              customerName: job.customerName,
              expectedStatus: 'Ready',
            });
          }
        }
      }
    }
    
    // Find orphan records (records without corresponding job items)
    const orphanFinishingRecords: OrphanRecord[] = [];
    const orphanCompletedRecords: OrphanRecord[] = [];
    
    // Check for orphan finishing records
    for (const record of finishingRecords || []) {
      if (!finishingItemIds.has(record.item_id)) {
        // Check if the item exists but is not in Finishing status
        if (allJobItemIds.has(record.item_id)) {
          orphanFinishingRecords.push({
            recordId: record.id,
            jobId: record.job_id,
            itemId: record.item_id,
            jobNumber: record.job_number,
            tableName: 'finishing_records',
          });
        }
      }
    }
    
    // Check for orphan completed records
    for (const record of completedJobs || []) {
      if (!readyItemIds.has(record.item_id)) {
        // Check if the item exists but is not in Ready status
        if (allJobItemIds.has(record.item_id)) {
          orphanCompletedRecords.push({
            recordId: record.id,
            jobId: record.job_id,
            itemId: record.item_id,
            jobNumber: record.job_number,
            tableName: 'completed_jobs',
          });
        }
      }
    }
    
    const finishingMismatches = missingFinishingRecords.length + orphanFinishingRecords.length;
    const completedMismatches = missingCompletedRecords.length + orphanCompletedRecords.length;
    
    // Update report with results
    const { error: updateError } = await supabase
      .from('reconciliation_reports')
      .update({
        total_jobs_checked: jobs?.length || 0,
        total_items_checked: totalItemsChecked,
        finishing_mismatches: finishingMismatches,
        completed_mismatches: completedMismatches,
        missing_finishing_records: missingFinishingRecords,
        orphan_finishing_records: orphanFinishingRecords,
        missing_completed_records: missingCompletedRecords,
        orphan_completed_records: orphanCompletedRecords,
        status: 'COMPLETED',
        completed_at: new Date().toISOString(),
      })
      .eq('id', reportId);
    
    if (updateError) {
      errors.push(`Failed to update report: ${updateError.message}`);
    }
    
    // Send notification to Admin only if mismatches found
    const totalMismatches = finishingMismatches + completedMismatches;
    if (totalMismatches > 0) {
      await notifyAdminOnly({
        title: 'Data Reconciliation Alert',
        message: `Found ${totalMismatches} data mismatch(es): ${finishingMismatches} finishing, ${completedMismatches} completed. Check reconciliation report for details.`,
        type: 'system',
        priority: totalMismatches > 10 ? 'urgent' : 'normal',
      });
    }

    
    return {
      reportId,
      reportDate,
      totalJobsChecked: jobs?.length || 0,
      totalItemsChecked,
      finishingMismatches,
      completedMismatches,
      missingFinishingRecords,
      orphanFinishingRecords,
      missingCompletedRecords,
      orphanCompletedRecords,
      status: 'COMPLETED',
      errors: errors.length > 0 ? errors : undefined,
    };
    
  } catch (error: any) {
    // Update report as failed
    await supabase
      .from('reconciliation_reports')
      .update({
        status: 'FAILED',
        completed_at: new Date().toISOString(),
      })
      .eq('id', reportId);
    
    errors.push(error.message);
    
    return {
      reportId,
      reportDate,
      totalJobsChecked: 0,
      totalItemsChecked: 0,
      finishingMismatches: 0,
      completedMismatches: 0,
      missingFinishingRecords: [],
      orphanFinishingRecords: [],
      missingCompletedRecords: [],
      orphanCompletedRecords: [],
      status: 'FAILED',
      errors,
    };
  }
}

/**
 * Auto-fix missing records by creating them from job data
 */
export async function autoFixMissingRecords(
  missingFinishing: MismatchItem[],
  missingCompleted: MismatchItem[]
): Promise<{ fixedFinishing: number; fixedCompleted: number; errors: string[] }> {
  const errors: string[] = [];
  let fixedFinishing = 0;
  let fixedCompleted = 0;
  
  // Fix missing finishing records
  for (const item of missingFinishing) {
    try {
      // Fetch full job data
      const { data: job, error: jobError } = await supabase
        .from('jobs')
        .select('*')
        .eq('id', item.jobId)
        .single();
      
      if (jobError || !job) {
        errors.push(`Failed to fetch job ${item.jobNumber}: ${jobError?.message}`);
        continue;
      }
      
      const jobItem = job.items?.find((i: any) => i.id === item.itemId);
      if (!jobItem) {
        errors.push(`Item ${item.itemId} not found in job ${item.jobNumber}`);
        continue;
      }
      
      const today = new Date().toISOString().split('T')[0];
      
      const { error: insertError } = await supabase
        .from('finishing_records')
        .upsert({
          item_id: item.itemId,
          job_id: item.jobId,
          job_number: item.jobNumber,
          customer_name: item.customerName,
          item_description: jobItem.descriptionOfWorks,
          weight_kg: jobItem.weightKg,
          recorded_date: today,
          item_options: {
            paintVarnish: jobItem.paintVarnish,
            galva: jobItem.galva,
            lightGalva: jobItem.lightGalva,
            lightPaint: jobItem.lightPaint,
            rusty: jobItem.rusty,
            doubleDip: jobItem.doubleDip,
            multipleDip: jobItem.multipleDip,
          },
        }, { onConflict: 'item_id' });
      
      if (insertError) {
        errors.push(`Failed to fix finishing record for ${item.jobNumber}: ${insertError.message}`);
      } else {
        fixedFinishing++;
      }
    } catch (err: any) {
      errors.push(`Error fixing finishing record: ${err.message}`);
    }
  }
  
  // Fix missing completed records
  for (const item of missingCompleted) {
    try {
      // Fetch full job data
      const { data: job, error: jobError } = await supabase
        .from('jobs')
        .select('*')
        .eq('id', item.jobId)
        .single();
      
      if (jobError || !job) {
        errors.push(`Failed to fetch job ${item.jobNumber}: ${jobError?.message}`);
        continue;
      }
      
      const jobItem = job.items?.find((i: any) => i.id === item.itemId);
      if (!jobItem) {
        errors.push(`Item ${item.itemId} not found in job ${item.jobNumber}`);
        continue;
      }
      
      const { error: insertError } = await supabase
        .from('completed_jobs')
        .upsert({
          item_id: item.itemId,
          job_id: item.jobId,
          job_number: item.jobNumber,
          customer_name: item.customerName,
          item_description: jobItem.descriptionOfWorks,
          weight_kg: jobItem.weightKg,
          completed_at: new Date().toISOString(),
          item_options: {
            paintVarnish: jobItem.paintVarnish,
            galva: jobItem.galva,
            lightGalva: jobItem.lightGalva,
            lightPaint: jobItem.lightPaint,
            rusty: jobItem.rusty,
            doubleDip: jobItem.doubleDip,
            multipleDip: jobItem.multipleDip,
          },
        }, { onConflict: 'item_id' });
      
      if (insertError) {
        errors.push(`Failed to fix completed record for ${item.jobNumber}: ${insertError.message}`);
      } else {
        fixedCompleted++;
      }
    } catch (err: any) {
      errors.push(`Error fixing completed record: ${err.message}`);
    }
  }
  
  return { fixedFinishing, fixedCompleted, errors };
}

/**
 * Clean up orphan records that don't match current job item statuses
 */
export async function cleanupOrphanRecords(
  orphanFinishing: OrphanRecord[],
  orphanCompleted: OrphanRecord[]
): Promise<{ cleanedFinishing: number; cleanedCompleted: number; errors: string[] }> {
  const errors: string[] = [];
  let cleanedFinishing = 0;
  let cleanedCompleted = 0;
  
  // Clean orphan finishing records
  if (orphanFinishing.length > 0) {
    const itemIds = orphanFinishing.map(r => r.itemId);
    const { error } = await supabase
      .from('finishing_records')
      .delete()
      .in('item_id', itemIds);
    
    if (error) {
      errors.push(`Failed to clean finishing records: ${error.message}`);
    } else {
      cleanedFinishing = itemIds.length;
    }
  }
  
  // Clean orphan completed records
  if (orphanCompleted.length > 0) {
    const itemIds = orphanCompleted.map(r => r.itemId);
    const { error } = await supabase
      .from('completed_jobs')
      .delete()
      .in('item_id', itemIds);
    
    if (error) {
      errors.push(`Failed to clean completed records: ${error.message}`);
    } else {
      cleanedCompleted = itemIds.length;
    }
  }
  
  return { cleanedFinishing, cleanedCompleted, errors };
}

/**
 * Get recent reconciliation reports
 */
export async function getRecentReports(limit: number = 10): Promise<any[]> {
  const { data, error } = await supabase
    .from('reconciliation_reports')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit);
  
  if (error) {
    console.error('Error fetching reconciliation reports:', error);
    return [];
  }
  
  return data || [];
}

/**
 * Get a specific reconciliation report by ID
 */
export async function getReportById(reportId: string): Promise<any | null> {
  const { data, error } = await supabase
    .from('reconciliation_reports')
    .select('*')
    .eq('id', reportId)
    .single();
  
  if (error) {
    console.error('Error fetching reconciliation report:', error);
    return null;
  }
  
  return data;
}

/**
 * Check if reconciliation has run today
 */
export async function hasRunToday(): Promise<boolean> {
  const today = new Date().toISOString().split('T')[0];
  
  const { data, error } = await supabase
    .from('reconciliation_reports')
    .select('id')
    .eq('report_date', today)
    .eq('status', 'COMPLETED')
    .limit(1);
  
  if (error) {
    console.error('Error checking today\'s reconciliation:', error);
    return false;
  }
  
  return (data?.length || 0) > 0;
}

/**
 * Schedule daily reconciliation (call this on app startup)
 */
export function scheduleDailyReconciliation(): NodeJS.Timeout {
  // Run reconciliation check every 6 hours
  const intervalMs = 6 * 60 * 60 * 1000; // 6 hours
  
  const runCheck = async () => {
    try {
      const alreadyRun = await hasRunToday();
      if (!alreadyRun) {
        console.log('🔍 Running daily data reconciliation...');
        const result = await runReconciliation();
        console.log(`✅ Reconciliation complete: ${result.finishingMismatches + result.completedMismatches} mismatches found`);
      }
    } catch (error) {
      console.error('❌ Daily reconciliation failed:', error);
    }
  };
  
  // Run immediately on startup
  runCheck();
  
  // Then run every 6 hours
  return setInterval(runCheck, intervalMs);
}
