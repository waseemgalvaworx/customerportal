import AsyncStorage from '@react-native-async-storage/async-storage';

// In-memory cache for frequently accessed data
const memoryCache: Map<string, { data: any; timestamp: number; ttl: number }> = new Map();

// Cache TTL configurations (in milliseconds)
export const CACHE_TTL = {
  SHORT: 30 * 1000,      // 30 seconds - for rapidly changing data
  MEDIUM: 2 * 60 * 1000, // 2 minutes - for moderately changing data
  LONG: 5 * 60 * 1000,   // 5 minutes - for slowly changing data
  STATIC: 30 * 60 * 1000 // 30 minutes - for rarely changing data
};

// Get data from memory cache
export const getFromMemoryCache = <T>(key: string): T | null => {
  const cached = memoryCache.get(key);
  if (!cached) return null;
  
  const now = Date.now();
  if (now - cached.timestamp > cached.ttl) {
    memoryCache.delete(key);
    return null;
  }
  
  return cached.data as T;
};

// Set data in memory cache
export const setInMemoryCache = <T>(key: string, data: T, ttl: number = CACHE_TTL.MEDIUM): void => {
  memoryCache.set(key, { data, timestamp: Date.now(), ttl });
};

// Clear specific cache key
export const clearCacheKey = (key: string): void => {
  memoryCache.delete(key);
};

// Clear all memory cache
export const clearAllMemoryCache = (): void => {
  memoryCache.clear();
};

// Clear cache by prefix
export const clearCacheByPrefix = (prefix: string): void => {
  const keysToDelete: string[] = [];
  memoryCache.forEach((_, key) => {
    if (key.startsWith(prefix)) keysToDelete.push(key);
  });
  keysToDelete.forEach(key => memoryCache.delete(key));
};

// Cache keys for common queries
export const QUERY_CACHE_KEYS = {
  JOBS_LIST: 'query_jobs_list',
  JOBS_BY_STATUS: (status: string) => `query_jobs_${status}`,
  CUSTOMERS_LIST: 'query_customers_list',
  PROFILES_LIST: 'query_profiles_list',
  NOTIFICATIONS: (userId: string) => `query_notifications_${userId}`,
  INVENTORY_ITEMS: 'query_inventory_items',
  COMPLETED_JOBS: 'query_completed_jobs',
  FINISHING_RECORDS: (date: string) => `query_finishing_${date}`,
  LOGISTICS: 'query_logistics',
  STOCK_REQUESTS: 'query_stock_requests'
};

// Wrapper for cached queries
export const cachedQuery = async <T>(
  key: string,
  queryFn: () => Promise<T>,
  ttl: number = CACHE_TTL.MEDIUM
): Promise<T> => {
  const cached = getFromMemoryCache<T>(key);
  if (cached !== null) return cached;
  
  const result = await queryFn();
  setInMemoryCache(key, result, ttl);
  return result;
};

// Invalidate related caches when data changes
export const invalidateRelatedCaches = (table: string): void => {
  const prefixMap: Record<string, string[]> = {
    jobs: ['query_jobs', 'query_completed'],
    customers: ['query_customers'],
    profiles: ['query_profiles'],
    notifications: ['query_notifications'],
    inventory_items: ['query_inventory'],
    finishing_records: ['query_finishing'],
    logistics_deliveries: ['query_logistics'],
    stock_requests: ['query_stock']
  };
  
  const prefixes = prefixMap[table] || [];
  prefixes.forEach(prefix => clearCacheByPrefix(prefix));
};

export const getCacheStats = () => ({
  size: memoryCache.size,
  keys: Array.from(memoryCache.keys())
});
