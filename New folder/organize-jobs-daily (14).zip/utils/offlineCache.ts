import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../app/lib/supabase';

// Get Supabase URL for health checks
const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL || 'https://obtmrrbajlrdnmnfhcas.supabase.co';
const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '';

// Cache online status for 30 seconds to avoid repeated network requests
let cachedOnlineStatus: boolean | null = null;
let lastOnlineCheck: number = 0;
const ONLINE_CACHE_DURATION = 30000; // 30 seconds

const CACHE_KEYS = {
  JOBS: 'offline_jobs',
  CUSTOMERS: 'offline_customers',
  FINISHING: 'offline_finishing',
  INVENTORY: 'offline_inventory',
  LAST_SYNC: 'last_sync_time',
  PENDING_CHANGES: 'pending_changes'
};

export interface PendingChange {
  id: string;
  type: 'insert' | 'update' | 'delete';
  table: string;
  data: any;
  timestamp: number;
}

export const cacheData = async (key: string, data: any) => {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error('Cache write error:', error);
  }
};

export const getCachedData = async (key: string) => {
  try {
    const data = await AsyncStorage.getItem(key);
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.error('Cache read error:', error);
    return null;
  }
};

export const addPendingChange = async (change: Omit<PendingChange, 'id' | 'timestamp'>) => {
  const pending = await getCachedData(CACHE_KEYS.PENDING_CHANGES) || [];
  pending.push({ ...change, id: Date.now().toString(), timestamp: Date.now() });
  await cacheData(CACHE_KEYS.PENDING_CHANGES, pending);
};

export const getPendingChanges = async (): Promise<PendingChange[]> => {
  return await getCachedData(CACHE_KEYS.PENDING_CHANGES) || [];
};

export const clearPendingChanges = async () => {
  await AsyncStorage.removeItem(CACHE_KEYS.PENDING_CHANGES);
};

// Fast online check with caching - returns cached value if recent
// Fast online check with caching - returns cached value if recent
export const isOnline = async (): Promise<boolean> => {
  const now = Date.now();
  
  // Return cached value if still valid (but only if it was a successful check)
  if (cachedOnlineStatus !== null && (now - lastOnlineCheck) < ONLINE_CACHE_DURATION) {
    return cachedOnlineStatus;
  }
  
  try {
    // Use AbortController for timeout - reduced to 2 seconds for faster response
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2000); // 2 second timeout (reduced from 5)
    
    const response = await fetch(`${SUPABASE_URL}/rest/v1/`, {
      method: 'HEAD',
      headers: { 'apikey': SUPABASE_ANON_KEY },
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    cachedOnlineStatus = response.ok;
    lastOnlineCheck = now;
    console.log(`🌐 Network check: ${cachedOnlineStatus ? 'Online' : 'Offline'}`);
    return cachedOnlineStatus;
  } catch (error) {
    // On error, assume OFFLINE to prevent failed operations
    // This ensures pending changes are queued instead of lost
    console.log('🌐 Network check failed - assuming offline:', error);
    cachedOnlineStatus = false;
    lastOnlineCheck = now;
    return false;
  }
};




// Force refresh online status (use sparingly)
export const refreshOnlineStatus = async (): Promise<boolean> => {
  cachedOnlineStatus = null;
  lastOnlineCheck = 0;
  return isOnline();
};

// Synchronous check - returns last known status without network call
export const isOnlineSync = (): boolean => {
  return cachedOnlineStatus ?? true;
};

export const updateLastSyncTime = async () => {
  await cacheData(CACHE_KEYS.LAST_SYNC, Date.now());
};

export const getLastSyncTime = async (): Promise<number | null> => {
  return await getCachedData(CACHE_KEYS.LAST_SYNC);
};

export { CACHE_KEYS };
