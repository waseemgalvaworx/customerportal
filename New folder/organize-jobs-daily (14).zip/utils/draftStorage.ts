import AsyncStorage from '@react-native-async-storage/async-storage';
import { Draft, DraftPreview } from '../types/drafts';

const DRAFTS_KEY = 'job_drafts';

export const generateDraftId = (): string => {
  return `draft-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
};

export const loadDrafts = async (): Promise<Draft[]> => {
  try {
    const data = await AsyncStorage.getItem(DRAFTS_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error loading drafts:', error);
    return [];
  }
};

export const saveDrafts = async (drafts: Draft[]): Promise<void> => {
  try {
    await AsyncStorage.setItem(DRAFTS_KEY, JSON.stringify(drafts));
  } catch (error) {
    console.error('Error saving drafts:', error);
  }
};

export const addDraft = async (draft: Omit<Draft, 'id' | 'createdAt' | 'updatedAt'>): Promise<Draft> => {
  const drafts = await loadDrafts();
  const newDraft: Draft = {
    ...draft,
    id: generateDraftId(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  drafts.push(newDraft);
  await saveDrafts(drafts);
  return newDraft;
};

export const updateDraft = async (id: string, updates: Partial<Draft>): Promise<Draft | null> => {
  const drafts = await loadDrafts();
  const index = drafts.findIndex(d => d.id === id);
  if (index === -1) return null;
  
  drafts[index] = {
    ...drafts[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };
  await saveDrafts(drafts);
  return drafts[index];
};

export const deleteDraft = async (id: string): Promise<void> => {
  const drafts = await loadDrafts();
  const filtered = drafts.filter(d => d.id !== id);
  await saveDrafts(filtered);
};

export const getDraft = async (id: string): Promise<Draft | null> => {
  const drafts = await loadDrafts();
  return drafts.find(d => d.id === id) || null;
};

export const getDraftPreviews = (drafts: Draft[]): DraftPreview[] => {
  return drafts.map(d => ({
    id: d.id,
    jobNumber: d.jobNumber || 'Untitled',
    customerName: d.customerName || 'No customer',
    itemCount: d.items.filter(i => i.descriptionOfWorks.trim()).length,
    updatedAt: d.updatedAt,
  }));
};
