import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { Platform, Alert } from 'react-native';

interface StageStats {
  stage: string;
  totalWeight: number;
  jobCount: number;
}

interface StatisticsData {
  stageStats: StageStats[];
  averageTurnaroundDays: number;
  totalJobs: number;
  generatedDate: string;
}

export const exportStatisticsToPDF = async (data: StatisticsData) => {
  try {
    const html = generateStatisticsHTML(data);
    const { uri } = await Print.printToFileAsync({ html });
    
    if (Platform.OS === 'ios' || Platform.OS === 'android') {
      await Sharing.shareAsync(uri, {
        mimeType: 'application/pdf',
        dialogTitle: 'Production Statistics Report',
        UTI: 'com.adobe.pdf'
      });
    }
    
    return uri;
  } catch (error) {
    console.error('Error exporting statistics to PDF:', error);
    Alert.alert('Export Error', 'Failed to export statistics to PDF');
    throw error;
  }
};

const generateStatisticsHTML = (data: StatisticsData): string => {
  const stageRows = data.stageStats.map(stage => `
    <tr>
      <td style="padding:12px;border-bottom:1px solid #E5E7EB;font-size:12px;">${stage.stage}</td>
      <td style="padding:12px;border-bottom:1px solid #E5E7EB;text-align:center;font-size:12px;">${stage.jobCount}</td>
      <td style="padding:12px;border-bottom:1px solid #E5E7EB;text-align:right;font-size:12px;">${stage.totalWeight.toFixed(2)} kg</td>
    </tr>
  `).join('');

  return `
    <html>
    <head>
      <style>
        @page { size: A4; margin: 15mm; }
        body { font-family: Arial, sans-serif; padding: 0; margin: 0; }
        h1 { color: #1F2937; margin-bottom: 10px; font-size: 24px; }
        .date { color: #6B7280; font-size: 12px; margin-bottom: 30px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
        th { background-color: #F3F4F6; padding: 12px; text-align: left; font-weight: bold; font-size: 12px; }
        .summary { background-color: #EFF6FF; padding: 20px; border-radius: 8px; margin-top: 20px; }
        .summary h2 { margin-top: 0; color: #1E40AF; font-size: 18px; }
        .stat-item { margin: 10px 0; font-size: 12px; }
      </style>
    </head>
    <body>
      <h1>Production Statistics Report</h1>
      <div class="date">Generated: ${data.generatedDate}</div>
      
      <h2 style="font-size:18px;color:#1F2937;">Weight by Production Stage</h2>
      <table>
        <thead>
          <tr>
            <th>Stage</th>
            <th style="text-align:center;">Job Count</th>
            <th style="text-align:right;">Total Weight</th>
          </tr>
        </thead>
        <tbody>
          ${stageRows}
        </tbody>
      </table>
      
      <div class="summary">
        <h2>Summary</h2>
        <div class="stat-item"><strong>Total Jobs:</strong> ${data.totalJobs}</div>
        <div class="stat-item"><strong>Average Turnaround Time:</strong> ${data.averageTurnaroundDays.toFixed(1)} days</div>
      </div>
    </body>
    </html>
  `;
};
