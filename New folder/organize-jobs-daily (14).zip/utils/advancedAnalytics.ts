// Advanced Manufacturing Analytics Utilities

export interface DataPoint {
  date: string;
  value: number;
}

// Calculate Simple Moving Average
export function calculateSMA(data: DataPoint[], period: number): DataPoint[] {
  if (data.length < period) return [];
  
  const sma: DataPoint[] = [];
  for (let i = period - 1; i < data.length; i++) {
    const sum = data.slice(i - period + 1, i + 1).reduce((acc, d) => acc + d.value, 0);
    sma.push({ date: data[i].date, value: sum / period });
  }
  return sma;
}

// Calculate Exponential Moving Average
export function calculateEMA(data: DataPoint[], period: number): DataPoint[] {
  if (data.length === 0) return [];
  
  const multiplier = 2 / (period + 1);
  const ema: DataPoint[] = [{ ...data[0] }];
  
  for (let i = 1; i < data.length; i++) {
    const value = (data[i].value * multiplier) + (ema[i - 1].value * (1 - multiplier));
    ema.push({ date: data[i].date, value });
  }
  return ema;
}

// Linear Regression for Trend Forecasting
export function linearRegression(data: DataPoint[]): { slope: number; intercept: number } {
  const n = data.length;
  if (n === 0) return { slope: 0, intercept: 0 };
  
  const xValues = data.map((_, i) => i);
  const yValues = data.map(d => d.value);
  
  const sumX = xValues.reduce((a, b) => a + b, 0);
  const sumY = yValues.reduce((a, b) => a + b, 0);
  const sumXY = xValues.reduce((acc, x, i) => acc + x * yValues[i], 0);
  const sumXX = xValues.reduce((acc, x) => acc + x * x, 0);
  
  const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;
  
  return { slope, intercept };
}

// Forecast future values
export function forecast(data: DataPoint[], daysAhead: number): DataPoint[] {
  const { slope, intercept } = linearRegression(data);
  const forecasted: DataPoint[] = [];
  
  for (let i = 1; i <= daysAhead; i++) {
    const x = data.length + i - 1;
    const value = slope * x + intercept;
    const futureDate = new Date(data[data.length - 1].date);
    futureDate.setDate(futureDate.getDate() + i);
    forecasted.push({ date: futureDate.toISOString().split('T')[0], value: Math.max(0, value) });
  }
  return forecasted;
}

// Calculate OEE (Overall Equipment Effectiveness)
export interface OEEData {
  availability: number;
  performance: number;
  quality: number;
  oee: number;
}

export function calculateOEE(
  plannedProductionTime: number,
  actualProductionTime: number,
  idealCycleTime: number,
  totalPieces: number,
  goodPieces: number
): OEEData {
  const availability = actualProductionTime / plannedProductionTime;
  const performance = (idealCycleTime * totalPieces) / actualProductionTime;
  const quality = goodPieces / totalPieces;
  const oee = availability * performance * quality;
  
  return {
    availability: availability * 100,
    performance: performance * 100,
    quality: quality * 100,
    oee: oee * 100
  };
}
