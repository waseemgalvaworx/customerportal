import { supabase } from '@/app/lib/supabase';
import { notifyAllUsers } from './notificationHelper';

interface LowStockItem {
  id: string;
  item_name: string;
  quantity: number;
  reorder_level: number;
  unit: string;
  category: string;
}

export async function checkLowStockItems(): Promise<LowStockItem[]> {
  try {
    const { data: items, error } = await supabase
      .from('inventory_items')
      .select('*')
      .not('reorder_level', 'is', null);

    if (error) throw error;

    const lowStockItems = (items || []).filter(item => 
      item.reorder_level && item.quantity <= item.reorder_level
    );

    return lowStockItems;
  } catch (error) {
    console.error('Error checking low stock items:', error);
    return [];
  }
}

export async function sendLowStockNotification(): Promise<void> {
  try {
    const lowStockItems = await checkLowStockItems();
    
    if (lowStockItems.length === 0) {
      console.log('No low stock items found');
      return;
    }

    // Build notification message
    let message = `The following ${lowStockItems.length} item(s) are below reorder level:\n\n`;
    
    lowStockItems.forEach((item, index) => {
      message += `${index + 1}. ${item.item_name}\n`;
      message += `   Current: ${item.quantity} ${item.unit}\n`;
      message += `   Reorder Level: ${item.reorder_level} ${item.unit}\n`;
      message += `   Category: ${item.category}\n\n`;
    });

    message += `Please restock these items as soon as possible.`;

    await notifyAllUsers({
      title: `Low Stock Alert - ${lowStockItems.length} Item(s)`,
      message: message,
      type: 'inventory',
      priority: 'high'
    });

    console.log(`Low stock notification sent for ${lowStockItems.length} items`);
  } catch (error) {
    console.error('Error sending low stock notification:', error);
    throw error;
  }
}

export async function getLowStockSummary(): Promise<{
  count: number;
  items: LowStockItem[];
  totalValue?: number;
}> {
  const items = await checkLowStockItems();
  return {
    count: items.length,
    items: items
  };
}
