import { supabase } from '@/app/lib/supabase';
import type { RealtimeChannel, RealtimePostgresChangesPayload } from '@supabase/supabase-js';

type EventType = 'INSERT' | 'UPDATE' | 'DELETE' | '*';
type SubscriptionCallback = (payload: RealtimePostgresChangesPayload<any>) => void;

interface SubscriptionConfig {
  table: string;
  event?: EventType;
  filter?: string;
  schema?: string;
}

interface DebouncedCallback {
  callback: SubscriptionCallback;
  timeout: NodeJS.Timeout | null;
  pendingPayloads: RealtimePostgresChangesPayload<any>[];
}

// Global subscription registry to prevent duplicates
const activeSubscriptions = new Map<string, RealtimeChannel>();
const debouncedCallbacks = new Map<string, DebouncedCallback>();

// Default debounce delay in ms
const DEFAULT_DEBOUNCE_MS = 300;

/**
 * Generate a unique key for a subscription
 */
function getSubscriptionKey(config: SubscriptionConfig): string {
  return `${config.table}:${config.event || '*'}:${config.filter || 'all'}`;
}

/**
 * Create a debounced callback that batches rapid updates
 */
export function createDebouncedCallback(
  key: string,
  callback: (payloads: RealtimePostgresChangesPayload<any>[]) => void,
  delayMs: number = DEFAULT_DEBOUNCE_MS
): SubscriptionCallback {
  return (payload: RealtimePostgresChangesPayload<any>) => {
    let debounced = debouncedCallbacks.get(key);
    
    if (!debounced) {
      debounced = { callback: () => {}, timeout: null, pendingPayloads: [] };
      debouncedCallbacks.set(key, debounced);
    }
    
    debounced.pendingPayloads.push(payload);
    
    if (debounced.timeout) {
      clearTimeout(debounced.timeout);
    }
    
    debounced.timeout = setTimeout(() => {
      const payloads = [...debounced!.pendingPayloads];
      debounced!.pendingPayloads = [];
      debounced!.timeout = null;
      callback(payloads);
    }, delayMs);
  };
}

/**
 * Subscribe to a table with optional filtering and debouncing
 */
export function subscribeToTable(
  config: SubscriptionConfig,
  onUpdate: (payloads: RealtimePostgresChangesPayload<any>[]) => void,
  options?: { debounceMs?: number; channelName?: string }
): () => void {
  const key = getSubscriptionKey(config);
  const channelName = options?.channelName || `realtime-${key}-${Date.now()}`;
  
  // Check for existing subscription
  if (activeSubscriptions.has(key)) {
    console.log(`⚠️ Subscription already exists for ${key}, reusing...`);
  }
  
  const debouncedHandler = createDebouncedCallback(
    channelName,
    onUpdate,
    options?.debounceMs ?? DEFAULT_DEBOUNCE_MS
  );
  
  const subscriptionConfig: any = {
    event: config.event || '*',
    schema: config.schema || 'public',
    table: config.table,
  };
  
  if (config.filter) {
    subscriptionConfig.filter = config.filter;
  }
  
  const channel = supabase
    .channel(channelName)
    .on('postgres_changes', subscriptionConfig, debouncedHandler)
    .subscribe((status) => {
      console.log(`📡 Subscription ${channelName}: ${status}`);
    });
  
  activeSubscriptions.set(channelName, channel);
  
  return () => {
    const debounced = debouncedCallbacks.get(channelName);
    if (debounced?.timeout) {
      clearTimeout(debounced.timeout);
    }
    debouncedCallbacks.delete(channelName);
    
    const sub = activeSubscriptions.get(channelName);
    if (sub) {
      supabase.removeChannel(sub);
      activeSubscriptions.delete(channelName);
    }
  };
}

/**
 * Get count of active subscriptions (for debugging)
 */
export function getActiveSubscriptionCount(): number {
  return activeSubscriptions.size;
}

/**
 * Clean up all subscriptions
 */
export function cleanupAllSubscriptions(): void {
  activeSubscriptions.forEach((channel, key) => {
    supabase.removeChannel(channel);
  });
  activeSubscriptions.clear();
  debouncedCallbacks.clear();
}
