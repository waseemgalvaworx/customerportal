import { supabase } from '@/app/lib/supabase';

export type ActionType = 
  | 'LOGIN' 
  | 'LOGOUT' 
  | 'JOB_CREATED' 
  | 'JOB_UPDATED' 
  | 'JOB_DELETED'
  | 'JOB_STATUS_CHANGED'
  | 'JOB_ASSIGNED'
  | 'COMPLIANCE_VIEWED'
  | 'COMPLIANCE_DOWNLOADED'
  | 'USER_CREATED'
  | 'USER_UPDATED'
  | 'USER_DELETED'
  | 'PERMISSION_CHANGED'
  | 'FINISHING_RECORD_CREATED'
  | 'FINISHING_RECORD_UPDATED'
  | 'ARCHIVE_CREATED'
  | 'REPORT_GENERATED'
  | 'CUSTOMER_CREATED'
  | 'CUSTOMER_UPDATED'
  | 'ITEM_STATUS_CHANGED'
  | 'BACKUP_CREATED'
  | 'BACKUP_RESTORED';


interface LogEntry {
  userId: string;
  username: string;
  actionType: ActionType;
  actionDescription: string;
  entityType?: string;
  entityId?: string;
  metadata?: Record<string, any>;
}

export async function logAction(entry: LogEntry) {
  try {
    const { error } = await supabase
      .from('activity_logs')
      .insert({
        user_id: entry.userId,
        username: entry.username,
        action_type: entry.actionType,
        action_description: entry.actionDescription,
        entity_type: entry.entityType,
        entity_id: entry.entityId,
        metadata: entry.metadata,
      });

    if (error) {
      console.error('Failed to log action:', error);
    }
  } catch (err) {
    console.error('Error logging action:', err);
  }
}
