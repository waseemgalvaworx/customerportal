/**
 * Centralized Logger Utility
 * - Disables verbose logging in production
 * - Provides consistent log formatting
 * - Supports different log levels
 */

type LogLevel = 'debug' | 'info' | 'warn' | 'error';

interface LoggerConfig {
  enabled: boolean;
  minLevel: LogLevel;
  prefix: string;
}

const LOG_LEVELS: Record<LogLevel, number> = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3,
};

// Default: disable debug logs in production
const IS_DEV = __DEV__ ?? process.env.NODE_ENV !== 'production';

const config: LoggerConfig = {
  enabled: true,
  minLevel: IS_DEV ? 'debug' : 'warn',
  prefix: '[App]',
};

const shouldLog = (level: LogLevel): boolean => {
  if (!config.enabled) return false;
  return LOG_LEVELS[level] >= LOG_LEVELS[config.minLevel];
};

const formatMessage = (level: LogLevel, module: string, message: string): string => {
  const timestamp = new Date().toISOString().slice(11, 23);
  return `${timestamp} ${config.prefix}[${module}][${level.toUpperCase()}] ${message}`;
};

export const logger = {
  debug: (module: string, message: string, data?: any) => {
    if (shouldLog('debug')) {
      console.log(formatMessage('debug', module, message), data ?? '');
    }
  },

  info: (module: string, message: string, data?: any) => {
    if (shouldLog('info')) {
      console.log(formatMessage('info', module, message), data ?? '');
    }
  },

  warn: (module: string, message: string, data?: any) => {
    if (shouldLog('warn')) {
      console.warn(formatMessage('warn', module, message), data ?? '');
    }
  },

  error: (module: string, message: string, error?: any) => {
    if (shouldLog('error')) {
      console.error(formatMessage('error', module, message), error ?? '');
    }
  },

  // Configure logger at runtime
  configure: (newConfig: Partial<LoggerConfig>) => {
    Object.assign(config, newConfig);
  },

  // Disable all logging
  disable: () => { config.enabled = false; },

  // Enable logging
  enable: () => { config.enabled = true; },

  // Set minimum log level
  setLevel: (level: LogLevel) => { config.minLevel = level; },
};

export default logger;
