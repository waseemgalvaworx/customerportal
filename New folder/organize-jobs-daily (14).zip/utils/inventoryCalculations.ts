// Shared inventory calculation utilities for consistency across the app

// Check if a transaction is an Opening Balance transaction
export const isOpeningBalanceTransaction = (transaction: any): boolean => {
  const notes = (transaction.notes || '').toLowerCase().trim();
  const reference = (transaction.reference || '').toLowerCase().trim();
  return notes === 'opening balance' || 
         notes.includes('opening balance') ||
         reference === 'opening_balance' ||
         reference.includes('opening_balance');
};

// Calculate current stock from all transactions (used by main screen)
// Also accepts item with initial_quantity as fallback if no Opening Balance transaction exists
export const calculateCurrentStock = (transactions: any[], item?: any): number => {
  let totalIn = 0;
  let totalOut = 0;
  let hasOpeningBalance = false;
  
  transactions.forEach(t => {
    const qty = parseFloat(t.quantity) || 0;
    const type = (t.transaction_type || '').toLowerCase().trim();
    
    if (isOpeningBalanceTransaction(t)) {
      hasOpeningBalance = true;
    }
    
    if (type === 'in') {
      totalIn += qty;
    } else if (type === 'out') {
      totalOut += qty;
    }
  });
  
  // If no Opening Balance transaction found, use item's initial_quantity as the starting stock
  if (!hasOpeningBalance && item) {
    const initialQty = parseFloat(item.initial_quantity) || 0;
    // Add initial_quantity if it exists and is greater than 0
    if (initialQty > 0) {
      totalIn += initialQty;
    }
  }

  
  return Math.round((totalIn - totalOut) * 100) / 100;
};


// Calculate opening balance for a period (stock at start of period)
export const calculateOpeningBalance = (transactions: any[], periodStart: Date, item?: any): number => {
  let totalIn = 0;
  let totalOut = 0;
  let hasOpeningBalance = false;
  
  transactions.forEach(t => {
    const transDate = new Date(t.created_at);
    if (transDate < periodStart) {
      const qty = parseFloat(t.quantity) || 0;
      const type = (t.transaction_type || '').toLowerCase().trim();
      
      if (isOpeningBalanceTransaction(t)) {
        hasOpeningBalance = true;
      }
      
      if (type === 'in') {
        totalIn += qty;
      } else if (type === 'out') {
        totalOut += qty;
      }
    }
  });
  
  // If no Opening Balance transaction found before period but item has initial_quantity, add it
  if (!hasOpeningBalance && item && item.initial_quantity > 0) {
    totalIn += parseFloat(item.initial_quantity) || 0;
  }
  
  return Math.round((totalIn - totalOut) * 100) / 100;
};

// Calculate stock movements for a period
export const calculatePeriodMovements = (
  transactions: any[], 
  periodStart: Date, 
  periodEnd: Date,
  item?: any
): { opening: number; inQty: number; outQty: number; closing: number } => {
  let openingIn = 0;
  let openingOut = 0;
  let periodIn = 0;
  let periodOut = 0;
  let hasOpeningBalanceBefore = false;
  let hasOpeningBalanceInPeriod = false;
  
  transactions.forEach(t => {
    const transDate = new Date(t.created_at);
    const qty = parseFloat(t.quantity) || 0;
    const type = (t.transaction_type || '').toLowerCase().trim();
    const isOB = isOpeningBalanceTransaction(t);
    
    if (transDate < periodStart) {
      if (isOB) hasOpeningBalanceBefore = true;
      if (type === 'in') openingIn += qty;
      else if (type === 'out') openingOut += qty;
    } else if (transDate >= periodStart && transDate <= periodEnd) {
      if (isOB) {
        hasOpeningBalanceInPeriod = true;
        openingIn += qty; // Opening Balance in period adds to opening
      } else if (type === 'in') {
        periodIn += qty;
      } else if (type === 'out') {
        periodOut += qty;
      }
    }
  });
  
  // Fallback: if no Opening Balance transaction found anywhere, use item's initial_quantity
  if (!hasOpeningBalanceBefore && !hasOpeningBalanceInPeriod && item && item.initial_quantity > 0) {
    openingIn += parseFloat(item.initial_quantity) || 0;
  }
  
  const opening = Math.round((openingIn - openingOut) * 100) / 100;
  const inQty = Math.round(periodIn * 100) / 100;
  const outQty = Math.round(periodOut * 100) / 100;
  const closing = Math.round((opening + inQty - outQty) * 100) / 100;
  
  return { opening, inQty, outQty, closing };
};

// Get period transactions (excluding Opening Balance)
export const getPeriodTransactions = (
  transactions: any[], 
  periodStart: Date, 
  periodEnd: Date
): any[] => {
  return transactions.filter(t => {
    const transDate = new Date(t.created_at);
    const isOB = isOpeningBalanceTransaction(t);
    return transDate >= periodStart && transDate <= periodEnd && !isOB;
  });
};
