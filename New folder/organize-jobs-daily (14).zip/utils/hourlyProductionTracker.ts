import { supabase } from '@/app/lib/supabase';

export interface HourlyStats {
  date: string;
  hour: number;
  status: string;
  jobs_processed: number;
  items_processed: number;
  total_working_minutes: number;
  kgs_produced: number;
}

// Calculate hourly stats from performance_metrics
// Calculate hourly stats from performance_metrics
export async function calculateHourlyStats(date: Date) {
  console.log('📊 Calculating hourly stats for date:', date.toISOString().split('T')[0]);
  
  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);
  
  const endOfDay = new Date(date);
  endOfDay.setHours(23, 59, 59, 999);

  // Get all performance metrics for the day
  const { data: metrics, error } = await supabase
    .from('performance_metrics')
    .select('*')
    .gte('recorded_at', startOfDay.toISOString())
    .lte('recorded_at', endOfDay.toISOString());

  if (error) {
    console.error('❌ Error fetching performance metrics:', error);
    throw error;
  }

  console.log(`📈 Found ${metrics?.length || 0} performance metrics for the day`);


  const hourlyData: Map<string, HourlyStats> = new Map();

  // Process each metric and get job weight data
  for (const metric of metrics || []) {
    const hour = new Date(metric.recorded_at).getHours();
    if (hour < 7 || hour > 20) continue; // Outside work hours

    // Fetch job to get item weight
    const { data: jobData } = await supabase
      .from('jobs')
      .select('items')
      .eq('id', metric.job_id)
      .single();

    let itemWeight = 0;
    if (jobData?.items) {
      const item = jobData.items.find((i: any) => i.id === metric.item_id);
      if (item?.weightKg) {
        itemWeight = parseFloat(item.weightKg) || 0;
      }
    }

    const status = metric.stage.toLowerCase(); // Convert to lowercase for consistency
    const key = `${date.toISOString().split('T')[0]}-${hour}-${status}`;
    
    if (!hourlyData.has(key)) {
      hourlyData.set(key, {
        date: date.toISOString().split('T')[0],
        hour,
        status: status,

        jobs_processed: 0,
        items_processed: 0,
        total_working_minutes: 0,
        kgs_produced: 0,
      });
    }

    const stats = hourlyData.get(key)!;
    stats.jobs_processed += 1;
    stats.items_processed += 1;
    stats.total_working_minutes += metric.duration_minutes || 0;
    stats.kgs_produced += itemWeight;
  }

  console.log(`💾 Upserting ${hourlyData.size} hourly stat records to database`);
  
  // Upsert to database
  let successCount = 0;
  let errorCount = 0;
  
  for (const stats of hourlyData.values()) {
    const { error: upsertError } = await supabase
      .from('hourly_production_stats')
      .upsert(stats, {
        onConflict: 'date,hour,status',
      });
    
    if (upsertError) {
      console.error('❌ Error upserting hourly stats:', upsertError);
      errorCount++;
    } else {
      successCount++;
    }
  }
  
  console.log(`✅ Hourly stats update complete: ${successCount} success, ${errorCount} errors`);
}


