import { supabase } from '../app/lib/supabase';
import { getPendingChanges, clearPendingChanges, PendingChange, cacheData, CACHE_KEYS, refreshOnlineStatus } from './offlineCache';

export interface ConflictData {
  changeId: string;
  localVersion: any;
  serverVersion: any;
  table: string;
}

export const syncPendingChanges = async (
  onConflict?: (conflict: ConflictData) => Promise<'local' | 'server' | 'skip'>
): Promise<{ success: boolean; synced: number; failed: number; conflicts: number }> => {
  const pendingChanges = await getPendingChanges();
  
  if (pendingChanges.length === 0) {
    return { success: true, synced: 0, failed: 0, conflicts: 0 };
  }

  console.log(`🔄 Syncing ${pendingChanges.length} pending changes...`);

  // First, verify we're actually online
  const online = await refreshOnlineStatus();
  if (!online) {
    console.log('❌ Cannot sync - still offline');
    return { success: false, synced: 0, failed: pendingChanges.length, conflicts: 0 };
  }

  let synced = 0;
  let failed = 0;
  let conflicts = 0;
  const failedChanges: PendingChange[] = [];

  // Sort by timestamp to maintain order
  pendingChanges.sort((a, b) => a.timestamp - b.timestamp);

  for (const change of pendingChanges) {
    try {
      console.log(`📤 Syncing: ${change.type} on ${change.table} (ID: ${change.data?.id || 'new'})`);
      
      // For updates, check for conflicts
      if (change.type === 'update' && onConflict) {
        const conflict = await detectConflict(change);
        if (conflict) {
          conflicts++;
          const resolution = await onConflict({
            changeId: change.id,
            localVersion: change.data,
            serverVersion: conflict,
            table: change.table
          });

          if (resolution === 'skip') {
            console.log('⏭️ Skipped conflict');
            continue;
          } else if (resolution === 'server') {
            synced++;
            console.log('✅ Kept server version');
            continue; // Keep server version, don't apply local change
          }
          // If 'local', continue with applying the change
        }
      }

      let result;
      switch (change.type) {
        case 'insert':
          result = await supabase.from(change.table).insert(change.data);
          break;
        case 'update':
          const { id, ...updateData } = change.data;
          result = await supabase.from(change.table).update(updateData).eq('id', id);
          break;
        case 'delete':
          result = await supabase.from(change.table).delete().eq('id', change.data.id);
          break;
      }

      if (result?.error) {
        console.error(`❌ Sync error for ${change.type}:`, result.error);
        failedChanges.push(change);
        failed++;
      } else {
        console.log(`✅ Synced: ${change.type} on ${change.table}`);
        synced++;
      }
    } catch (error) {
      console.error(`❌ Failed to sync change ${change.id}:`, error);
      failedChanges.push(change);
      failed++;
    }
  }

  // Clear all pending changes if all succeeded, otherwise keep failed ones
  if (failedChanges.length === 0) {
    await clearPendingChanges();
    console.log('✅ All changes synced - cleared pending queue');
  } else {
    await cacheData(CACHE_KEYS.PENDING_CHANGES, failedChanges);
    console.log(`⚠️ ${failedChanges.length} changes still pending`);
  }

  return { success: failed === 0, synced, failed, conflicts };
};

async function detectConflict(change: PendingChange): Promise<any | null> {
  try {
    const { data, error } = await supabase
      .from(change.table)
      .select('*')
      .eq('id', change.data.id)
      .single();

    if (error || !data) return null;

    // Check if server version was updated after our local change
    const serverUpdatedAt = new Date(data.updated_at).getTime();
    if (serverUpdatedAt > change.timestamp) {
      return data;
    }

    return null;
  } catch (error) {
    console.error('Error detecting conflict:', error);
    return null;
  }
}

