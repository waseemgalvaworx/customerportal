import { saveProductionSnapshot } from './saveProductionSnapshot';

function getDateRanges(date: Date) {
  const now = new Date(date);
  
  // Daily: today
  const dailyStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
  const dailyEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
  
  // Weekly: this week (Monday to Sunday)
  const dayOfWeek = now.getDay();
  const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
  const weeklyStart = new Date(now);
  weeklyStart.setDate(now.getDate() + mondayOffset);
  weeklyStart.setHours(0, 0, 0, 0);
  const weeklyEnd = new Date(weeklyStart);
  weeklyEnd.setDate(weeklyStart.getDate() + 6);
  weeklyEnd.setHours(23, 59, 59, 999);
  
  // Monthly: this month
  const monthlyStart = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0);
  const monthlyEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
  
  // Yearly: this year
  const yearlyStart = new Date(now.getFullYear(), 0, 1, 0, 0, 0);
  const yearlyEnd = new Date(now.getFullYear(), 11, 31, 23, 59, 59);
  
  return {
    daily: { start: dailyStart, end: dailyEnd },
    weekly: { start: weeklyStart, end: weeklyEnd },
    monthly: { start: monthlyStart, end: monthlyEnd },
    yearly: { start: yearlyStart, end: yearlyEnd }
  };
}

export async function saveAllSnapshots() {
  const now = new Date();
  const ranges = getDateRanges(now);
  
  const snapshots = [
    { periodType: 'daily' as const, ...ranges.daily },
    { periodType: 'weekly' as const, ...ranges.weekly },
    { periodType: 'monthly' as const, ...ranges.monthly },
    { periodType: 'yearly' as const, ...ranges.yearly }
  ];
  
  for (const snapshot of snapshots) {
    await saveProductionSnapshot({
      reportDate: now,
      periodType: snapshot.periodType,
      periodStart: snapshot.start,
      periodEnd: snapshot.end
    });
  }
}
