import { supabase } from '@/app/lib/supabase';

interface SnapshotData {
  reportDate: Date;
  periodType: 'daily' | 'weekly' | 'monthly' | 'yearly';
  periodStart: Date;
  periodEnd: Date;
}

export async function saveProductionSnapshot({ reportDate, periodType, periodStart, periodEnd }: SnapshotData) {
  try {
    // Fetch completed jobs in the period
    const { data: jobs, error: jobsError } = await supabase
      .from('completed_jobs')
      .select('*')
      .gte('completed_at', periodStart.toISOString())
      .lte('completed_at', periodEnd.toISOString());


    if (jobsError) throw jobsError;

    // Calculate statistics
    const totalJobs = jobs?.length || 0;
    const totalWeight = jobs?.reduce((sum, job) => sum + (parseFloat(job.weight) || 0), 0) || 0;
    
    // Calculate average turnaround
    let avgTurnaround = 0;
    if (jobs && jobs.length > 0) {
      const turnarounds = jobs
        .filter(job => job.start_date && job.completed_at)
        .map(job => {
          const start = new Date(job.start_date);
          const end = new Date(job.completed_at);

          return (end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24);
        });
      
      if (turnarounds.length > 0) {
        avgTurnaround = turnarounds.reduce((a, b) => a + b, 0) / turnarounds.length;
      }
    }

    // Calculate weight by stage
    const weightByStage: Record<string, number> = {};
    jobs?.forEach(job => {
      const stage = job.stage || 'Unknown';
      weightByStage[stage] = (weightByStage[stage] || 0) + (parseFloat(job.weight) || 0);
    });

    // Save to database
    const { error: insertError } = await supabase
      .from('daily_reports')
      .upsert({
        report_date: reportDate.toISOString().split('T')[0],
        period_type: periodType,
        period_start: periodStart.toISOString(),
        period_end: periodEnd.toISOString(),
        total_jobs: totalJobs,
        total_weight: totalWeight,
        avg_turnaround_days: avgTurnaround,
        weight_by_stage: weightByStage
      }, {
        onConflict: 'report_date,period_type'
      });

    if (insertError) throw insertError;

    return { success: true };
  } catch (error) {
    console.error('Error saving production snapshot:', error);
    return { success: false, error };
  }
}
