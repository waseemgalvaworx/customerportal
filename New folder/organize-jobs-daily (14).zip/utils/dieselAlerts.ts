import { supabase } from '@/app/lib/supabase';

const LOW_DIESEL_THRESHOLD = 5300; // liters
const ALERT_RECIPIENTS = ['admin', 'Lovena', 'KH'];


export const checkLowDieselAlert = async (currentVolume: number): Promise<void> => {
  if (currentVolume >= LOW_DIESEL_THRESHOLD) {
    return; // No alert needed
  }

  try {
    // Get profile IDs for recipients
    const { data: profiles } = await supabase
      .from('profiles')
      .select('id, username')
      .in('username', ALERT_RECIPIENTS);

    if (!profiles || profiles.length === 0) {
      console.error('No recipients found for diesel alert');
      return;
    }

    // Create notifications for each recipient
    const notifications = profiles.map(profile => ({
      user_id: profile.id,
      title: 'Low Diesel Alert',
      message: `Diesel level is low: ${currentVolume.toFixed(0)} L (threshold: ${LOW_DIESEL_THRESHOLD} L)`,
      type: 'diesel_alert',
      read: false
    }));

    const { error } = await supabase
      .from('notifications')
      .insert(notifications);

    if (error) {
      console.error('Failed to send diesel alerts:', error);
    } else {
      console.log(`Low diesel alerts sent to ${profiles.length} users`);
    }
  } catch (err) {
    console.error('Error checking diesel alert:', err);
  }
};
