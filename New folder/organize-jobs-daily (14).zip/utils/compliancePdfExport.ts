import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { Alert } from 'react-native';

interface CertificateData {
  jobNumber: string;
  customerName: string;
  dateOfEntry: Date;
  items: Array<{ descriptionOfWorks: string; weightKg: string }>;
  currentDate: string;
}

export const exportComplianceCertificatePdf = async (data: CertificateData): Promise<void> => {
  try {
    console.log('Starting PDF export...');
    const dateOfEntry = data.dateOfEntry.toLocaleDateString('en-GB');
    
    const itemsList = data.items.map((item, i) => 
      `<p style="margin: 8px 0; font-size: 13px;">${i + 1}. ${item.descriptionOfWorks}</p>`
    ).join('');
    
    const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Arial, sans-serif; padding: 30px; }
    .certificate { border: 3px solid #000; padding: 40px; }
    .header { text-align: center; border-bottom: 3px solid #000; padding-bottom: 20px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
    .logo { font-size: 32px; font-weight: bold; }
    .header-date { font-size: 14px; font-weight: normal; }
    h1 { text-align: center; font-size: 18px; margin: 25px 0; text-decoration: underline; }
    p { font-size: 14px; text-align: center; margin: 12px 0; }
    .customer { font-size: 20px; font-weight: bold; margin: 20px 0; }
    .details { margin: 25px 0; text-align: left; }
    .details p { text-align: left; margin: 8px 0; }
    .items-title { font-weight: bold; margin: 25px 0 12px 0; text-align: left; }
    .electronic-doc { margin: 40px 0 20px 0; text-align: center; font-style: italic; font-size: 13px; }
    .testing-equipment { margin: 20px 0; text-align: center; font-size: 13px; }
    .footer { text-align: center; margin: 30px 0; }
    .footer p { font-weight: bold; margin: 5px 0; }
    .address { font-size: 12px; color: #666; margin-top: 20px; }
  </style>
</head>
<body>
  <div class="certificate">
    <div class="header">
      <div style="flex: 1;"></div>
      <div class="logo">GALVABOND LTD</div>
      <div style="flex: 1; text-align: right;" class="header-date">${data.currentDate}</div>
    </div>
    <h1>TO WHOM IT MAY CONCERN</h1>
    <p>This is to certify that the below mentioned items were hot dip galvanized for</p>
    <p class="customer">${data.customerName}</p>
    <p>and comply to MS ISO 1461 Standards</p>
    <div class="details">
      <p><strong>Job No:</strong> ${data.jobNumber}</p>
      <p><strong>Reference:</strong> N/A</p>
      <p><strong>Date of Entry:</strong> ${dateOfEntry}</p>
    </div>
    <p class="items-title">Item Description:</p>
    ${itemsList}
    <p class="electronic-doc">This document is electronically generated and does not require any signature</p>
    <p class="testing-equipment">Testing equipment: Elcometer MTG Ultrasonic Material Thickness Gauge</p>
    <div class="footer">
      <p>HIGH QUALITY</p><p>ON TIME</p><p>EVERY TIME</p>
    </div>
    <p class="address">La Tour Koenig Industrial Zone Port Louis<br>Mauritius<br>www.galvabondltd.com</p>
  </div>
</body>
</html>`;

    console.log('Generating PDF...');
    const { uri } = await Print.printToFileAsync({ html });
    console.log('PDF generated at:', uri);
    
    const isAvailable = await Sharing.isAvailableAsync();
    console.log('Sharing available:', isAvailable);
    
    if (!isAvailable) {
      throw new Error('Sharing is not available on this device');
    }
    
    console.log('Sharing PDF...');
    await Sharing.shareAsync(uri, {
      mimeType: 'application/pdf',
      dialogTitle: `Compliance_Certificate_${data.jobNumber}.pdf`
    });
    console.log('PDF shared successfully');
  } catch (error) {
    console.error('PDF Export Error:', error);
    throw error;
  }
};
