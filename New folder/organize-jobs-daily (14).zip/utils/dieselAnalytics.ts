import { supabase } from '@/app/lib/supabase';

export interface DieselReading {
  id: string;
  log_date?: string;
  created_at: string;
  height_cm: number;
  volume_liters: number;
  notes?: string;
}

export interface DieselRefill {
  id: string;
  refill_date: string;
  quantity_received: number;
  cost_per_litre: number;
  total_cost: number;
  purchase_order_number?: string;
  notes?: string;
  created_at: string;
}

export interface ConsumptionTrend {
  date: string;
  consumption: number;
  cost: number;
}

export interface DieselAnalytics {
  daily: ConsumptionTrend[];
  weekly: ConsumptionTrend[];
  monthly: ConsumptionTrend[];
  totalConsumption: number;
  totalCost: number;
  avgDailyConsumption: number;
  avgCostPerLiter: number;
  refillHistory: DieselRefill[];
}

export const getDieselAnalytics = async (startDate: Date, endDate: Date): Promise<DieselAnalytics> => {
  const startDateStr = startDate.toISOString().split('T')[0];
  const endDateStr = endDate.toISOString().split('T')[0];

  console.log('Fetching diesel analytics from', startDateStr, 'to', endDateStr);

  // Fetch readings
  const { data: readings, error: readingsError } = await supabase
    .from('diesel_consumption_logs')
    .select('*')
    .order('created_at', { ascending: true });

  if (readingsError) {
    console.error('Error fetching readings:', readingsError);
  }

  console.log('Total readings found:', readings?.length || 0);

  // Fetch refills within period
  const { data: refills, error: refillsError } = await supabase
    .from('diesel_refills')
    .select('*')
    .gte('refill_date', startDateStr)
    .lte('refill_date', endDateStr)
    .order('refill_date', { ascending: false });

  if (refillsError) {
    console.error('Error fetching refills:', refillsError);
  }

  console.log('Refills in period:', refills?.length || 0);

  // Fetch all refills for history
  const { data: allRefills } = await supabase
    .from('diesel_refills')
    .select('*')
    .order('refill_date', { ascending: false })
    .limit(20);

  if (!readings || readings.length < 2) {
    console.log('Not enough readings for analysis');
    return getEmptyAnalytics(allRefills || []);
  }

  // Filter readings within date range
  const filteredReadings = readings.filter(r => {
    const rDate = r.log_date || r.created_at.split('T')[0];
    return rDate >= startDateStr && rDate <= endDateStr;
  });

  console.log('Filtered readings:', filteredReadings.length);

  const dailyMap = new Map<string, { consumption: number; cost: number }>();
  let totalConsumption = 0;

  // Calculate consumption between consecutive readings
  for (let i = 1; i < filteredReadings.length; i++) {
    const prev = filteredReadings[i - 1];
    const curr = filteredReadings[i];
    
    const prevVol = prev.volume_liters || 0;
    const currVol = curr.volume_liters || 0;
    
    // Only count as consumption if volume decreased
    if (prevVol > currVol) {
      const consumption = prevVol - currVol;
      totalConsumption += consumption;
      
      const dayKey = curr.log_date || curr.created_at.split('T')[0];
      const existing = dailyMap.get(dayKey) || { consumption: 0, cost: 0 };
      dailyMap.set(dayKey, {
        consumption: existing.consumption + consumption,
        cost: existing.cost
      });
    }
  }

  console.log('Total consumption calculated:', totalConsumption);

  // Calculate costs
  const totalCost = (refills || []).reduce((sum, r) => sum + r.total_cost, 0);
  const totalRefilled = (refills || []).reduce((sum, r) => sum + r.quantity_received, 0);
  const avgCostPerLiter = totalRefilled > 0 ? totalCost / totalRefilled : 0;

  const daysDiff = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) || 1;

  return {
    daily: Array.from(dailyMap.entries()).map(([date, data]) => ({ date, ...data })),
    weekly: [],
    monthly: [],
    totalConsumption,
    totalCost,
    avgDailyConsumption: totalConsumption / daysDiff,
    avgCostPerLiter,
    refillHistory: allRefills || []
  };
};

const getEmptyAnalytics = (refills: DieselRefill[] = []): DieselAnalytics => ({
  daily: [], weekly: [], monthly: [],
  totalConsumption: 0, totalCost: 0,
  avgDailyConsumption: 0, avgCostPerLiter: 0,
  refillHistory: refills
});
