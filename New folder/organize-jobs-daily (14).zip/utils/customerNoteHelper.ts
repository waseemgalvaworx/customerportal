import { supabase } from '../app/lib/supabase';

export const saveCustomerNote = async (jobId: string, note: string): Promise<void> => {
  try {
    const { error } = await supabase
      .from('jobs')
      .update({ customer_pickup_note: note })
      .eq('id', jobId);

    if (error) {
      console.error('Database error saving note:', error.message);
      throw new Error(error.message);
    }
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : 'Unknown error';
    console.error('Failed to save customer note:', errorMsg);
    throw err;
  }
};
