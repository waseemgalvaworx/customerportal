import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { Platform } from 'react-native';
import { supabase } from '../app/lib/supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { logAction } from './auditLogger';
import { PasswordUser } from '../app/lib/passwordAuth';

export async function createBackup(uploadToStorage = true) {
  try {

    const tables = [
      'jobs',
      'completed_jobs',
      'notifications',
      'job_templates',
      'customers',
      'finishing_records',
      'daily_reports',
      'archived_finishing_reports',
      'activity_logs',
      'profiles'
    ];

    const data: any = {};
    const errors: string[] = [];

    for (const table of tables) {
      try {
        const { data: tableData, error } = await supabase
          .from(table)
          .select('*');

        if (error) {
          errors.push(`${table}: ${error.message}`);
          continue;
        }

        data[table] = tableData;
      } catch (err) {
        errors.push(`${table}: ${err}`);
      }
    }

    const backupData = {
      timestamp: new Date().toISOString(),
      version: '1.0',
      tables: data,
      errors: errors.length > 0 ? errors : undefined
    };

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `backup_${timestamp}.json`;
    const jsonString = JSON.stringify(backupData, null, 2);

    // Upload to Supabase Storage
    if (uploadToStorage) {
      try {
        // Convert JSON string to Blob for upload
        const blob = new Blob([jsonString], { type: 'application/json' });
        
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('backups')
          .upload(filename, blob, {
            contentType: 'application/json',
            upsert: false
          });

        if (uploadError) {
          console.error('Storage upload error:', uploadError);
          alert(`Storage upload failed: ${uploadError.message}`);
        } else {
          console.log('Backup uploaded to Supabase Storage:', filename);
          alert(`Backup successfully uploaded to Supabase Storage: ${filename}`);
        }
      } catch (storageErr: any) {
        console.error('Storage upload failed:', storageErr);
        alert(`Storage upload exception: ${storageErr.message || storageErr}`);
      }
    }


    if (Platform.OS === 'web') {
      try {
        const blob = new Blob([jsonString], { type: 'application/json' });
        
        if ((navigator as any).msSaveBlob) {
          (navigator as any).msSaveBlob(blob, filename);
          return { success: true, message: `Backup saved: ${filename}` };
        }
        
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        link.setAttribute('download', filename);
        
        link.style.position = 'absolute';
        link.style.left = '-9999px';
        
        document.body.appendChild(link);
        
        setTimeout(() => {
          link.dispatchEvent(new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window
          }));
        }, 0);
        
        setTimeout(() => {
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
        }, 500);
        
        return { 
          success: true, 
          message: uploadToStorage 
            ? `Backup saved to Supabase Storage and downloading: ${filename}` 
            : `Backup downloading: ${filename}` 
        };
      } catch (err: any) {
        console.error('Download error:', err);
        if (uploadToStorage) {
          return { 
            success: true, 
            message: `Download failed but backup saved to Supabase Storage: ${filename}` 
          };
        }
        throw new Error(`Download failed: ${err.message}`);
      }
    }

    const filePath = `${FileSystem.documentDirectory}${filename}`;
    await FileSystem.writeAsStringAsync(filePath, jsonString);
    const isAvailable = await Sharing.isAvailableAsync();
    if (isAvailable) {
      await Sharing.shareAsync(filePath);
    }
    return { success: true, message: 'Backup created!', filePath };

  } catch (error) {
    throw error;
  }
}


export async function listBackups() {
  try {
    const { data, error } = await supabase.storage
      .from('backups')
      .list('', {
        limit: 100,
        offset: 0,
        sortBy: { column: 'created_at', order: 'desc' }
      });

    if (error) throw error;
    return data || [];
  } catch (error) {
    throw error;
  }
}

export async function downloadBackup(filename: string) {
  try {
    const { data, error } = await supabase.storage
      .from('backups')
      .download(filename);

    if (error) throw error;
    
    const text = await data.text();
    return JSON.parse(text);
  } catch (error) {
    throw error;
  }
}

export async function restoreBackup(backupData: any) {
  try {
    const tables = Object.keys(backupData.tables);
    const results: any = { success: [], failed: [] };

    for (const table of tables) {
      try {
        const records = backupData.tables[table];
        if (!records || records.length === 0) continue;

        // Delete existing data
        const { error: deleteError } = await supabase
          .from(table)
          .delete()
          .neq('id', '00000000-0000-0000-0000-000000000000');

        if (deleteError) {
          results.failed.push({ table, error: `Delete failed: ${deleteError.message}` });
          continue;
        }

        // Insert backup data
        const { error: insertError } = await supabase
          .from(table)
          .insert(records);

        if (insertError) {
          results.failed.push({ table, error: `Insert failed: ${insertError.message}` });
        } else {
          results.success.push(table);
        }
      } catch (err: any) {
        results.failed.push({ table, error: err.message || String(err) });
      }
    }

    return results;
  } catch (error) {
    throw error;
  }
}
