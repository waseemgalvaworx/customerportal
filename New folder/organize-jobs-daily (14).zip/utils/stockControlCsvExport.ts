import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { Platform, Alert } from 'react-native';

export const exportStockValuationCSV = async (items: any[]) => {
  try {
    const csv = generateStockValuationCSV(items);
    const fileName = `stock_valuation_${new Date().toISOString().split('T')[0]}.csv`;
    const fileUri = FileSystem.documentDirectory + fileName;
    
    await FileSystem.writeAsStringAsync(fileUri, csv, { encoding: FileSystem.EncodingType.UTF8 });
    
    if (Platform.OS === 'ios' || Platform.OS === 'android') {
      await Sharing.shareAsync(fileUri, { mimeType: 'text/csv', dialogTitle: 'Export Stock Valuation' });
    }
    
    return fileUri;
  } catch (error) {
    console.error('Error exporting CSV:', error);
    Alert.alert('Export Error', 'Failed to export CSV');
    throw error;
  }
};

const generateStockValuationCSV = (items: any[]): string => {
  const header = 'Item Name,Category,Quantity,Unit,Unit Cost,Total Value,Supplier,Location\n';
  const rows = items.map(item => 
    `"${item.item_name}","${item.category}",${item.quantity},"${item.unit}",${item.unit_cost || 0},${item.total_value || 0},"${item.supplier || ''}","${item.location || ''}"`
  ).join('\n');
  return header + rows;
};

export const exportTransactionHistoryCSV = async (transactions: any[]) => {
  try {
    const csv = generateTransactionsCSV(transactions);
    const fileName = `transactions_${new Date().toISOString().split('T')[0]}.csv`;
    const fileUri = FileSystem.documentDirectory + fileName;
    
    await FileSystem.writeAsStringAsync(fileUri, csv, { encoding: FileSystem.EncodingType.UTF8 });
    
    if (Platform.OS === 'ios' || Platform.OS === 'android') {
      await Sharing.shareAsync(fileUri, { mimeType: 'text/csv', dialogTitle: 'Export Transactions' });
    }
    
    return fileUri;
  } catch (error) {
    console.error('Error exporting CSV:', error);
    Alert.alert('Export Error', 'Failed to export CSV');
    throw error;
  }
};

const generateTransactionsCSV = (transactions: any[]): string => {
  const header = 'Date,Item,Type,Quantity,Unit Cost,Total Value,User,Notes\n';
  const rows = transactions.map(t => 
    `"${new Date(t.transaction_date).toLocaleString()}","${t.inventory_items?.item_name || ''}","${t.transaction_type}",${t.quantity},${t.unit_cost || 0},${t.total_value || 0},"${t.username}","${t.notes || ''}"`
  ).join('\n');
  return header + rows;
};
