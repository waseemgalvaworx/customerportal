import { supabase } from '../app/lib/supabase';

// Generate a unique verification code in format XXXX-XXXX-XXXX
export function generateVerificationCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 12; i++) {
    if (i > 0 && i % 4 === 0) code += '-';
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

// Get QR code URL using a free QR code API
export function getQRCodeUrl(verificationCode: string, baseUrl: string): string {
  const verifyUrl = `${baseUrl}/verify-certificate?code=${verificationCode}`;
  return `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(verifyUrl)}`;
}

// Store certificate in database
export async function storeCertificate(data: {
  verificationCode: string;
  jobId: string;
  jobNumber: string;
  customerName: string;
  items: any[];
  issuedBy?: string;
}): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('compliance_certificates')
      .insert({
        verification_code: data.verificationCode,
        job_id: data.jobId,
        job_number: data.jobNumber,
        customer_name: data.customerName,
        items: data.items,
        issued_by_username: data.issuedBy || 'System',
        issued_at: new Date().toISOString(),
        is_valid: true
      });

    if (error) throw error;
    return { success: true };
  } catch (err: any) {
    console.error('Error storing certificate:', err);
    return { success: false, error: err.message };
  }
}

// Verify a certificate by its code
export async function verifyCertificate(code: string): Promise<{
  valid: boolean;
  certificate?: any;
  error?: string;
}> {
  try {
    const { data, error } = await supabase
      .from('compliance_certificates')
      .select('*')
      .eq('verification_code', code.toUpperCase())
      .single();

    if (error || !data) {
      return { valid: false, error: 'Certificate not found' };
    }

    if (!data.is_valid) {
      return { valid: false, certificate: data, error: 'Certificate has been revoked' };
    }

    return { valid: true, certificate: data };
  } catch (err: any) {
    return { valid: false, error: err.message };
  }
}
