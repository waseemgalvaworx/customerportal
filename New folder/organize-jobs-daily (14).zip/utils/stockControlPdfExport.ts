import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { Platform, Alert } from 'react-native';

export const exportStockValuationPDF = async (items: any[]) => {
  try {
    const html = generateStockValuationHTML(items);
    const { uri } = await Print.printToFileAsync({ html });
    
    if (Platform.OS === 'ios' || Platform.OS === 'android') {
      await Sharing.shareAsync(uri, {
        mimeType: 'application/pdf',
        dialogTitle: 'Stock Valuation Report',
        UTI: 'com.adobe.pdf'
      });
    }
    return uri;
  } catch (error) {
    console.error('Error exporting stock valuation:', error);
    Alert.alert('Export Error', 'Failed to export stock valuation report');
    throw error;
  }
};

const generateStockValuationHTML = (items: any[]): string => {
  const totalValue = items.reduce((sum, item) => sum + (item.total_value || 0), 0);
  const rows = items.map(item => `
    <tr>
      <td style="padding:10px;border-bottom:1px solid #E5E7EB;">${item.item_name}</td>
      <td style="padding:10px;border-bottom:1px solid #E5E7EB;text-align:center;">${item.quantity} ${item.unit}</td>
      <td style="padding:10px;border-bottom:1px solid #E5E7EB;text-align:right;">$${(item.unit_cost || 0).toFixed(2)}</td>
      <td style="padding:10px;border-bottom:1px solid #E5E7EB;text-align:right;">$${(item.total_value || 0).toFixed(2)}</td>
    </tr>
  `).join('');

  return `
    <html>
    <head>
      <style>
        @page { size: A4; margin: 15mm; }
        body { font-family: Arial, sans-serif; }
        h1 { color: #1F2937; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { background-color: #F3F4F6; padding: 12px; text-align: left; font-weight: bold; }
        .total { background-color: #10B981; color: white; padding: 15px; margin-top: 20px; border-radius: 8px; }
      </style>
    </head>
    <body>
      <h1>Stock Valuation Report</h1>
      <p>Generated: ${new Date().toLocaleString()}</p>
      <table>
        <thead><tr><th>Item</th><th style="text-align:center;">Quantity</th><th style="text-align:right;">Unit Cost</th><th style="text-align:right;">Total Value</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="total"><strong>Total Stock Value: $${totalValue.toFixed(2)}</strong></div>
    </body>
    </html>
  `;
};
