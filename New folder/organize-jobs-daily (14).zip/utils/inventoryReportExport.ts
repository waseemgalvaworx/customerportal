import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';

export async function exportInventoryReportPdf(
  transactions: any[],
  period: string,
  itemName: string,
  openingStock: number = 0,
  closingStock: number = 0
) {
  const now = new Date().toLocaleString();
  
  const transactionRows = transactions
    .filter(t => t.inventory_items !== null) // Filter out deleted items
    .map((t, idx) => `
    <tr style="border-bottom: 1px solid #ddd;">
      <td style="padding: 8px; text-align: center;">${idx + 1}</td>
      <td style="padding: 8px;">${t.inventory_items?.item_name || 'N/A'}</td>
      <td style="padding: 8px; font-size: 10px;">${new Date(t.created_at).toLocaleString()}</td>
      <td style="padding: 8px; text-align: center; color: ${t.transaction_type === 'in' ? '#34C759' : '#FF3B30'}; font-weight: bold;">
        ${t.transaction_type.toUpperCase()}
      </td>
      <td style="padding: 8px; text-align: center;">${t.quantity}</td>
      <td style="padding: 8px; text-align: center;">${t.inventory_items?.unit || ''}</td>
      <td style="padding: 8px; font-size: 10px;">${t.notes || '-'}</td>
    </tr>
  `).join('');


  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; }
          h1 { color: #333; text-align: center; }
          .info { margin: 20px 0; }
          .stock-info { background: #f0f9ff; padding: 12px; margin: 10px 0; border-radius: 8px; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th { background: #007AFF; color: white; padding: 10px; text-align: left; }
          td { padding: 8px; }
          tr:nth-child(even) { background: #f9f9f9; }
        </style>
      </head>
      <body>
        <h1>Inventory Report</h1>
        <div class="info">
          <p><strong>Period:</strong> ${period.charAt(0).toUpperCase() + period.slice(1)}</p>
          <p><strong>Item:</strong> ${itemName}</p>
          <p><strong>Generated:</strong> ${now}</p>
        </div>
        ${itemName !== 'All Items' ? `
          <div class="stock-info">
            <p><strong>Opening Stock:</strong> ${openingStock}</p>
          </div>
        ` : ''}
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Item</th>
              <th>Date</th>
              <th>Type</th>
              <th>Quantity</th>
              <th>Unit</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            ${transactionRows}
          </tbody>
        </table>

        ${itemName !== 'All Items' ? `
          <div class="stock-info">
            <p><strong>Closing Stock:</strong> ${closingStock}</p>
          </div>
        ` : ''}
      </body>
    </html>
  `;

  const { uri } = await Print.printToFileAsync({ html });
  await Sharing.shareAsync(uri, { UTI: '.pdf', mimeType: 'application/pdf' });
}
