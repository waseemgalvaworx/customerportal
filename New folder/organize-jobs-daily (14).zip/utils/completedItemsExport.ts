// Generate HTML for Completed Items Report (items moved from Finishing to Ready)
export const generateCompletedItemsHTML = (items: any[], dateStr?: string, includeTime: boolean = true): string => {
  const formatDate = (d: Date) => {
    const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
    const months = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'];
    return `${days[d.getDay()]} ${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
  };

  let reportDate = formatDate(new Date());
  if (dateStr) {
    const [day, month, year] = dateStr.split('/');
    reportDate = formatDate(new Date(parseInt(year), parseInt(month) - 1, parseInt(day)));
  }
  const timeStr = includeTime ? ` - ${new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}` : '';

  // Group by job
  const grouped = items.reduce((acc: any, item) => {
    if (!acc[item.job_number]) acc[item.job_number] = { customer_name: item.customer_name, items: [] };
    acc[item.job_number].items.push(item);
    return acc;
  }, {});

  const totalWeight = items.reduce((sum, item) => sum + parseFloat(String(item.weight_kg || 0)), 0);

  let rows = '';
  Object.entries(grouped).forEach(([jobNum, data]: [string, any]) => {
    data.items.forEach((item: any, idx: number) => {
      const opts = [];
      if (item.item_options?.paintVarnish) opts.push('Paint/Varnish');
      if (item.item_options?.galva) opts.push('Galva');
      if (item.item_options?.lightGalva) opts.push('Light Galva');
      if (item.item_options?.lightPaint) opts.push('Light Paint');
      if (item.item_options?.rusty) opts.push('Rusty');
      rows += `<tr><td>${idx === 0 ? jobNum : ''}</td><td>${idx === 0 ? data.customer_name : ''}</td><td>${item.item_description}</td><td style="font-size:9px">${opts.join(', ') || '-'}</td><td style="text-align:right">${parseFloat(String(item.weight_kg || 0)).toFixed(2)}</td></tr>`;
    });
  });

  return `<!DOCTYPE html><html><head><style>body{font-family:Arial;font-size:11px}h1{color:#007AFF;font-size:16px;text-align:center;margin:5px 0}h2{font-size:12px;text-align:center;margin:3px 0;color:#666}table{width:100%;border-collapse:collapse;margin-top:10px}th,td{border:1px solid #000;padding:4px}th{background:#007AFF;color:white;font-size:10px}td{font-size:9px}.total{background:#007AFF;color:white;font-weight:bold}</style></head><body><h1>Completed Items Report</h1><h2>Items moved from Finishing to Ready</h2><h2>${reportDate}${timeStr}</h2><table><tr><th style="width:10%">JOB NO</th><th style="width:18%">CUSTOMER</th><th style="width:38%">DESCRIPTION</th><th style="width:20%">OPTIONS</th><th style="width:14%">WEIGHT (KG)</th></tr>${rows}<tr class="total"><td colspan="4" style="text-align:right">TOTAL COMPLETED:</td><td style="text-align:right">${totalWeight.toFixed(2)}</td></tr></table></body></html>`;
};

// Generate HTML for Delivered Items Report
export const generateDeliveredItemsHTML = (items: any[], dateStr?: string, includeTime: boolean = true): string => {
  const formatDate = (d: Date) => {
    const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
    const months = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'];
    return `${days[d.getDay()]} ${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
  };

  let reportDate = formatDate(new Date());
  if (dateStr) {
    const [day, month, year] = dateStr.split('/');
    reportDate = formatDate(new Date(parseInt(year), parseInt(month) - 1, parseInt(day)));
  }
  const timeStr = includeTime ? ` - ${new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}` : '';

  const grouped = items.reduce((acc: any, item) => {
    if (!acc[item.job_number]) acc[item.job_number] = { customer_name: item.customer_name, items: [] };
    acc[item.job_number].items.push(item);
    return acc;
  }, {});

  const totalWeight = items.reduce((sum, item) => sum + parseFloat(String(item.weight_kg || 0)), 0);

  let rows = '';
  Object.entries(grouped).forEach(([jobNum, data]: [string, any]) => {
    data.items.forEach((item: any, idx: number) => {
      rows += `<tr><td>${idx === 0 ? jobNum : ''}</td><td>${idx === 0 ? data.customer_name : ''}</td><td>${item.item_description}</td><td style="text-align:right">${parseFloat(String(item.weight_kg || 0)).toFixed(2)}</td></tr>`;
    });
  });

  return `<!DOCTYPE html><html><head><style>body{font-family:Arial;font-size:11px}h1{color:#8B5CF6;font-size:16px;text-align:center;margin:5px 0}h2{font-size:12px;text-align:center;margin:3px 0;color:#666}table{width:100%;border-collapse:collapse;margin-top:10px}th,td{border:1px solid #000;padding:4px}th{background:#8B5CF6;color:white;font-size:10px}td{font-size:9px}.total{background:#8B5CF6;color:white;font-weight:bold}</style></head><body><h1>Delivered Items Report</h1><h2>${reportDate}${timeStr}</h2><table><tr><th style="width:12%">JOB NO</th><th style="width:20%">CUSTOMER</th><th style="width:52%">DESCRIPTION</th><th style="width:16%">WEIGHT (KG)</th></tr>${rows}<tr class="total"><td colspan="3" style="text-align:right">TOTAL DELIVERED:</td><td style="text-align:right">${totalWeight.toFixed(2)}</td></tr></table></body></html>`;
};
