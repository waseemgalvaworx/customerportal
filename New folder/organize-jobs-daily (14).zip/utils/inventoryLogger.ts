import { supabase } from '../app/lib/supabase';

export interface InventoryLogEntry {
  action: 'add' | 'edit' | 'delete' | 'stock_in' | 'stock_out' | 'adjustment';
  item_id: string;
  item_name: string;
  category: string;
  quantity_change?: number;
  old_quantity?: number;
  new_quantity?: number;
  old_value?: any;
  new_value?: any;
  notes?: string;
  performed_by: string;
}

export async function logInventoryAction(entry: InventoryLogEntry) {
  try {
    const logData = {
      action: entry.action,
      item_id: entry.item_id,
      item_name: entry.item_name,
      category: entry.category,
      quantity_change: entry.quantity_change || null,
      old_quantity: entry.old_quantity || null,
      new_quantity: entry.new_quantity || null,
      old_value: entry.old_value ? JSON.stringify(entry.old_value) : null,
      new_value: entry.new_value ? JSON.stringify(entry.new_value) : null,
      notes: entry.notes || null,
      performed_by: entry.performed_by,
      created_at: new Date().toISOString()
    };

    const { error } = await supabase
      .from('inventory_logs')
      .insert(logData);

    if (error) {
      console.error('Failed to log inventory action:', error);
    }
  } catch (err) {
    console.error('Error logging inventory action:', err);
  }
}
