import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { Job } from '../contexts/JobContext';

const formatDateTime = () => {
  const now = new Date();
  const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
  const months = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'];
  return `${days[now.getDay()]} ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()} - ${now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`;
};

export const generateFinishingCSV = (jobs: Job[]): string => {
  const timestamp = formatDateTime();
  let csv = `FINISHING - Work Shift Report\nGenerated: ${timestamp}\n\n`;
  
  let totalWeight = 0;
  
  // Headers
  csv += 'Job Number,Customer Name,Item Description,Weight (kg)\n';
  
  // Data rows
  jobs.forEach(job => {
    const finishingItems = job.items.filter(item => item.status === 'Finishing');
    finishingItems.forEach(item => {
      const weight = parseFloat(item.weightKg || '0');
      totalWeight += weight;
      csv += `"${job.jobNumber}","${job.customerName}","${item.descriptionOfWorks}",${weight.toFixed(2)}\n`;
    });
  });
  
  // Total row
  csv += `\nSHIFT TOTAL,,,${totalWeight.toFixed(2)}\n`;
  
  return csv;
};

export const shareFinishingCSV = async (jobs: Job[]) => {
  const csv = generateFinishingCSV(jobs);
  const filename = `Finishing_${new Date().toISOString().replace(/[:.]/g, '-')}.csv`;
  const fileUri = FileSystem.documentDirectory + filename;
  
  await FileSystem.writeAsStringAsync(fileUri, csv, { encoding: FileSystem.EncodingType.UTF8 });
  await Sharing.shareAsync(fileUri, { UTI: '.csv', mimeType: 'text/csv' });
};
