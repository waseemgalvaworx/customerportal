import { supabase } from '../app/lib/supabase';

export interface JobTargetDetail {
  job_id: string;
  job_number: string;
  customer_name: string;
  item_id: string;
  item_description: string;
  weight_kg: number;
}

export async function updateDailyTargets(jobs: any[]) {
  try {
    const targetsByDate = new Map<string, JobTargetDetail[]>();
    
    jobs.forEach(job => {
      if (!job.deliveryDate || job.status !== 'planning') return;
      
      const date = new Date(job.deliveryDate).toISOString().split('T')[0];
      
      job.items.forEach((item: any, index: number) => {
        const detail: JobTargetDetail = {
          job_id: job.id,
          job_number: job.jobNumber,
          customer_name: job.customerName,
          item_id: `${job.id}-${index}`,
          item_description: item.descriptionOfWorks,
          weight_kg: parseFloat(item.weightKg || '0')
        };
        
        if (!targetsByDate.has(date)) {
          targetsByDate.set(date, []);
        }
        targetsByDate.get(date)!.push(detail);
      });
    });
    
    for (const [date, details] of targetsByDate.entries()) {
      const totalWeight = details.reduce((sum, d) => sum + d.weight_kg, 0);
      
      await supabase
        .from('daily_production_targets')
        .upsert({
          target_date: date,
          target_weight_kg: totalWeight,
          job_details: details
        }, {
          onConflict: 'target_date'
        });
    }
    
    return true;
  } catch (error) {
    console.error('Error updating daily targets:', error);
    return false;
  }
}

export async function getDailyTarget(date: string) {
  const { data, error } = await supabase
    .from('daily_production_targets')
    .select('*')
    .eq('target_date', date)
    .single();
    
  if (error) {
    console.error('Error fetching daily target:', error);
    return null;
  }
  
  return data;
}
