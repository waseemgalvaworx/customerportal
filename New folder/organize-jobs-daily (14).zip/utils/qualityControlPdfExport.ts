import * as Print from 'expo-print';
import { shareAsync } from 'expo-sharing';

export async function exportQualityControlPDF(qcData: any, jobNumber: string, itemName: string) {
  const html = `
    <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; }
          h1 { text-align: center; margin-bottom: 5px; }
          h2 { text-align: center; margin-top: 0; font-weight: normal; }
          .info { margin: 20px 0; }
          .section { margin-top: 30px; border-top: 2px solid #333; padding-top: 10px; }
          .section-title { font-weight: bold; font-size: 18px; text-decoration: underline; }
          .field { margin: 10px 0; }
          .label { font-weight: bold; }
          .value { margin-left: 10px; }
          .checkbox { display: inline-block; width: 15px; height: 15px; border: 1px solid #000; margin-right: 5px; }
          .checked { background-color: #000; }
        </style>
      </head>
      <body>
        <h1>GALVABOND LTD</h1>
        <h2>QUALITY CHECKLIST</h2>
        <div class="info">
          <strong>Date:</strong> ${new Date().toLocaleDateString()}<br>
          <strong>Job No:</strong> ${jobNumber}<br>
          <strong>Item:</strong> ${itemName}
        </div>

        <div class="section">
          <div class="section-title">WORKSHOP:</div>
          <div class="field">
            <span class="label">1. Surface Condition:</span><br>
            ${['Galv', 'Grease', 'Paint', 'Oil', 'Poor', 'Good', 'Excellent'].map(v => 
              `<span class="checkbox ${(qcData.workshop_surface_condition || []).includes(v) ? 'checked' : ''}"></span>${v} `
            ).join('')}
          </div>
          <div class="field">
            <span class="label">2. Drilling:</span> 
            Yes: <span class="checkbox ${qcData.workshop_drilling_done === true ? 'checked' : ''}"></span>
            No: <span class="checkbox ${qcData.workshop_drilling_done === false ? 'checked' : ''}"></span>
            Qty: ${qcData.workshop_drilling_qty || '___'}
          </div>
          <div class="field">
            <span class="label">3. Welding Quality:</span><br>
            ${['Poor', 'Good', 'Excellent'].map(v => 
              `<span class="checkbox ${qcData.workshop_welding_quality === v ? 'checked' : ''}"></span>${v} `
            ).join('')}
          </div>
          <div class="field">
            <span class="label">Racking:</span>
            Individual: <span class="checkbox ${qcData.workshop_racking === 'Individual' ? 'checked' : ''}"></span>
            Bundle Stock: <span class="checkbox ${qcData.workshop_racking === 'Bundle Stock' ? 'checked' : ''}"></span>
          </div>
        </div>

        <div class="section">
          <div class="section-title">ACID DEPARTMENT:</div>
          <div class="field">
            <span class="label">Forward to Acid in good condition:</span>
            Yes: <span class="checkbox ${qcData.acid_forward_good_condition === true ? 'checked' : ''}"></span>
            No: <span class="checkbox ${qcData.acid_forward_good_condition === false ? 'checked' : ''}"></span>
          </div>
          <div class="field">
            <span class="label">1. Surface Condition:</span><br>
            ${['Galv', 'Grease', 'Paint', 'Oil'].map(v => 
              `<span class="checkbox ${(qcData.acid_surface_condition || []).includes(v) ? 'checked' : ''}"></span>${v} `
            ).join('')}
          </div>
          <div class="field">
            <span class="label">2. Immersion Time:</span>
            Degrease: ${qcData.acid_immersion_degrease || '___'} / Acid: ${qcData.acid_immersion_acid || '___'}
          </div>
        </div>

        <div class="section">
          <div class="section-title">ZINC DEPARTMENT:</div>
          <div class="field">
            <span class="label">Forward to Zinc in good condition:</span>
            Yes: <span class="checkbox ${qcData.zinc_forward_good_condition === true ? 'checked' : ''}"></span>
            No: <span class="checkbox ${qcData.zinc_forward_good_condition === false ? 'checked' : ''}"></span>
          </div>
          <div class="field">
            <span class="label">1. Surface Condition:</span><br>
            ${['Galv', 'Grease', 'Paint', 'Oil'].map(v => 
              `<span class="checkbox ${(qcData.zinc_surface_condition || []).includes(v) ? 'checked' : ''}"></span>${v} `
            ).join('')}
          </div>
          <div class="field">
            <span class="label">2. Immersion Time:</span> ${qcData.zinc_immersion_time || '___'}
          </div>
          <div class="field">
            <span class="label">3. Coating Condition:</span>
            Rough: <span class="checkbox ${qcData.zinc_coating_condition === 'Rough' ? 'checked' : ''}"></span>
            Smooth: <span class="checkbox ${qcData.zinc_coating_condition === 'Smooth' ? 'checked' : ''}"></span>
          </div>
        </div>

        <div class="section">
          <div class="section-title">FINISHING & DELIVERY DEPARTMENT:</div>
          <div class="field">
            <span class="label">1. Surface Condition:</span><br>
            ${['Rough', 'Smooth', 'Black spots', 'Ungalvanise'].map(v => 
              `<span class="checkbox ${(qcData.finishing_surface_condition || []).includes(v) ? 'checked' : ''}"></span>${v} `
            ).join('')}
          </div>
          <div class="field">
            <span class="label">2. Remedial Action:</span>
            Yes: <span class="checkbox ${qcData.finishing_remedial_action === true ? 'checked' : ''}"></span>
            No: <span class="checkbox ${qcData.finishing_remedial_action === false ? 'checked' : ''}"></span>
          </div>
          ${qcData.finishing_remedial_action ? `
          <div class="field">
            <span class="label">If Yes, Explain how:</span><br>
            ${qcData.finishing_remedial_explanation || '___'}
          </div>` : ''}
          <div class="field">
            <span class="label">3. Coating Thickness:</span>
            Reading: ${qcData.finishing_coating_thickness_reading || '___'}
            Microns: ${qcData.finishing_coating_thickness_microns || '___'}
          </div>
        </div>

        <div style="margin-top: 40px;">
          <p><strong>Created by:</strong> ${qcData.created_by || '___'}</p>
          <p><strong>Last updated:</strong> ${qcData.updated_at ? new Date(qcData.updated_at).toLocaleString() : '___'}</p>
        </div>
      </body>
    </html>
  `;

  const { uri } = await Print.printToFileAsync({ html });
  await shareAsync(uri, { UTI: '.pdf', mimeType: 'application/pdf' });
}
