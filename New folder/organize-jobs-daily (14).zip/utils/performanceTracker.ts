import { supabase } from '@/app/lib/supabase';
import { ItemStatus } from '@/contexts/JobContext';

interface StageTransition {
  itemId: string;
  jobId: string;
  jobNumber: string;
  fromStage: ItemStatus;
  toStage: ItemStatus;
  timestamp: string;
}

export async function trackItemStatusChange(
  jobId: string,
  jobNumber: string,
  itemId: string,
  oldStatus: ItemStatus,
  newStatus: ItemStatus
) {
  const now = new Date();
  console.time(`STAGE_TRACKING_${itemId}`);
  
  try {
    // Prepare upsert data first (no await needed)
    const updateData: any = {
      job_id: jobId,
      item_id: itemId,
      current_stage: newStatus,
      entry_time: now.toISOString()
    };
    
    // If moving to Ready status, record the ready_date
    if (newStatus === 'Ready') {
      updateData.ready_date = now.toISOString();
    }
    
    // Run SELECT and UPSERT in parallel for better performance
    // The SELECT is only needed for duration calculation (nice-to-have)
    const [trackingResult, upsertResult] = await Promise.allSettled([
      // Get previous stage entry time (for duration calc)
      supabase
        .from('item_stage_tracking')
        .select('current_stage, entry_time')
        .eq('job_id', jobId)
        .eq('item_id', itemId)
        .maybeSingle(),
      // Upsert new stage data immediately
      supabase
        .from('item_stage_tracking')
        .upsert(updateData, { onConflict: 'job_id,item_id' })
    ]);
    
    // Process duration calculation in background (fire-and-forget)
    if (trackingResult.status === 'fulfilled' && trackingResult.value.data) {
      const tracking = trackingResult.value.data;
      if (tracking.entry_time) {
        const entryTime = new Date(tracking.entry_time);
        const durationMs = now.getTime() - entryTime.getTime();
        const durationMinutes = Math.round(durationMs / (1000 * 60));
        
        // Only track meaningful stages (not Pending) and positive durations
        if (tracking.current_stage !== 'Pending' && durationMinutes > 0) {
          // Fire-and-forget - don't await
          savePerformanceMetric(jobId, jobNumber, itemId, tracking.current_stage, durationMinutes)
            .catch(err => console.error('Performance metric error:', err));
        }
      }
    }
    
    if (upsertResult.status === 'rejected') {
      console.error('Stage tracking upsert error:', upsertResult.reason);
    }
      
  } catch (error) {
    console.error('Error tracking item status change:', error);
  } finally {
    console.timeEnd(`STAGE_TRACKING_${itemId}`);
  }
}

async function savePerformanceMetric(
  jobId: string,
  jobNumber: string,
  itemId: string,
  stage: ItemStatus,
  durationMinutes: number
) {
  try {
    console.log(`📊 Performance: Job ${jobNumber}, Stage ${stage}, ${durationMinutes}min`);
    
    await supabase.from('performance_metrics').insert({
      job_id: jobId,
      job_number: jobNumber,
      item_id: itemId,
      stage,
      duration_minutes: durationMinutes,
      recorded_at: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Error saving performance metric:', error);
  }
}

// Initialize stage entry times from existing job data
export async function initializeStageTracking(jobs: any[]) {
  try {
    const entries = jobs.flatMap(job => 
      (job.items || []).map((item: any) => ({
        job_id: job.id,
        item_id: item.id,
        current_stage: item.status,
        entry_time: new Date().toISOString()
      }))
    );
    
    if (entries.length > 0) {
      await supabase
        .from('item_stage_tracking')
        .upsert(entries, {
          onConflict: 'job_id,item_id',
          ignoreDuplicates: true
        });
    }
  } catch (error) {
    console.error('Error initializing stage tracking:', error);
  }
}
