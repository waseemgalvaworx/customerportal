/**
 * Centralized Error Handler
 * - Consistent error handling across the app
 * - User-friendly error messages
 * - Error logging and tracking
 */

import { Alert } from 'react-native';
import logger from './logger';

export type ErrorSeverity = 'low' | 'medium' | 'high' | 'critical';

interface ErrorContext {
  module: string;
  action: string;
  data?: any;
}

interface HandledError {
  message: string;
  userMessage: string;
  severity: ErrorSeverity;
  context: ErrorContext;
  timestamp: Date;
  originalError?: any;
}

// Map common error patterns to user-friendly messages
const ERROR_MESSAGES: Record<string, string> = {
  'network request failed': 'Unable to connect. Please check your internet connection.',
  'jwt expired': 'Your session has expired. Please log in again.',
  'permission denied': 'You don\'t have permission to perform this action.',
  'row level security': 'Access denied. Please contact support.',
  'duplicate key': 'This record already exists.',
  'not found': 'The requested item was not found.',
  'timeout': 'Request timed out. Please try again.',
};

const getUserFriendlyMessage = (error: any): string => {
  const errorStr = String(error?.message || error).toLowerCase();
  
  for (const [pattern, message] of Object.entries(ERROR_MESSAGES)) {
    if (errorStr.includes(pattern)) return message;
  }
  
  return 'An unexpected error occurred. Please try again.';
};

export const errorHandler = {
  handle: (error: any, context: ErrorContext, showAlert = true): HandledError => {
    const userMessage = getUserFriendlyMessage(error);
    const handled: HandledError = {
      message: error?.message || String(error),
      userMessage,
      severity: 'medium',
      context,
      timestamp: new Date(),
      originalError: error,
    };

    logger.error(context.module, `${context.action}: ${handled.message}`, error);

    if (showAlert) {
      Alert.alert('Error', userMessage, [{ text: 'OK' }]);
    }

    return handled;
  },

  // Handle without showing alert
  silent: (error: any, context: ErrorContext): HandledError => {
    return errorHandler.handle(error, context, false);
  },

  // Handle with custom message
  withMessage: (error: any, context: ErrorContext, customMessage: string): HandledError => {
    logger.error(context.module, `${context.action}: ${error?.message}`, error);
    Alert.alert('Error', customMessage, [{ text: 'OK' }]);
    return {
      message: error?.message || String(error),
      userMessage: customMessage,
      severity: 'medium',
      context,
      timestamp: new Date(),
      originalError: error,
    };
  },
};

export default errorHandler;
