import { supabase } from '@/app/lib/supabase';

export const archiveApprovedRequests = async () => {
  try {
    console.log('Starting stock request archival process...');

    // Get all approved/fulfilled requests
    const { data: requests, error: fetchError } = await supabase
      .from('stock_requests')
      .select(`
        *,
        inventory_items (
          item_name,
          unit
        )
      `)
      .in('status', ['approved', 'fulfilled']);

    if (fetchError) throw fetchError;

    if (!requests || requests.length === 0) {
      console.log('No requests to archive');
      return { success: true, archived: 0 };
    }

    // Archive each request
    const archiveData = requests.map(req => ({
      original_request_id: req.id,
      item_id: req.item_id,
      item_name: req.inventory_items?.item_name || 'Unknown',
      quantity_requested: req.quantity_requested,
      unit: req.inventory_items?.unit || '',
      requested_by: req.requested_by,
      reason: req.reason,
      ref: req.ref,
      status: req.status,
      approved_by: req.approved_by,
      approved_at: req.approved_at,
      acknowledged: req.acknowledged,
      fulfilled_at: req.fulfilled_at,
      created_at: req.created_at,
    }));

    const { error: insertError } = await supabase
      .from('archived_stock_requests')
      .insert(archiveData);

    if (insertError) throw insertError;

    // Delete archived requests
    const { error: deleteError } = await supabase
      .from('stock_requests')
      .delete()
      .in('status', ['approved', 'fulfilled']);

    if (deleteError) throw deleteError;

    console.log(`Archived ${requests.length} requests`);
    return { success: true, archived: requests.length };
  } catch (error) {
    console.error('Error archiving requests:', error);
    return { success: false, error };
  }
};
