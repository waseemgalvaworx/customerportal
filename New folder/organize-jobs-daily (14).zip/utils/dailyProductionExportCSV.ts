import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import * as MailComposer from 'expo-mail-composer';
import { Job } from '../contexts/JobContext';
import { ExportOptions } from './dailyProductionExport';

export const generateDailyProductionCSV = (jobs: Job[], options: ExportOptions): string => {
  const date = new Date().toLocaleDateString('en-GB');
  let csv = `Daily Production Record\nDate: ${date}\n\n`;
  
  // Summary
  const totalWeight = jobs.reduce((sum, job) => 
    sum + job.items.reduce((s, item) => s + parseFloat(item.weightKg || '0'), 0), 0
  );
  csv += `Total Jobs: ${jobs.length}\n`;
  if (options.includeWeights) {
    csv += `Total Weight: ${totalWeight.toFixed(1)} kg\n`;
  }
  csv += `\n`;
  
  // Headers
  let headers = ['Job Number'];
  if (options.includeCustomer) headers.push('Customer');
  headers.push('Item Description');
  if (options.includeWeights) headers.push('Weight (kg)');
  if (options.includeItemOptions) headers.push('Options');
  csv += headers.join(',') + '\n';
  
  // Data rows
  jobs.forEach(job => {
    job.items.forEach(item => {
      let row = [job.jobNumber];
      if (options.includeCustomer) row.push(`"${job.customerName}"`);
      row.push(`"${item.descriptionOfWorks}"`);
      if (options.includeWeights) row.push(item.weightKg);
      if (options.includeItemOptions) {
        const opts = [];
        if (item.paintVarnish) opts.push('P/V');
        if (item.galva) opts.push('Galva');
        if (item.lightGalva) opts.push('L.Galva');
        if (item.lightPaint) opts.push('L.Paint');
        if (item.rusty) opts.push('Rusty');
        row.push(`"${opts.join(', ')}"`);
      }
      csv += row.join(',') + '\n';
    });
  });
  
  return csv;
};

export const shareDailyProductionCSV = async (jobs: Job[], options: ExportOptions) => {
  const csv = generateDailyProductionCSV(jobs, options);
  const filename = `DailyProduction_${new Date().toISOString().split('T')[0]}.csv`;
  const fileUri = FileSystem.documentDirectory + filename;
  
  await FileSystem.writeAsStringAsync(fileUri, csv, { encoding: FileSystem.EncodingType.UTF8 });
  await Sharing.shareAsync(fileUri, { UTI: '.csv', mimeType: 'text/csv' });
};

export const emailDailyProductionCSV = async (jobs: Job[], options: ExportOptions) => {
  const csv = generateDailyProductionCSV(jobs, options);
  const filename = `DailyProduction_${new Date().toISOString().split('T')[0]}.csv`;
  const fileUri = FileSystem.documentDirectory + filename;
  
  await FileSystem.writeAsStringAsync(fileUri, csv, { encoding: FileSystem.EncodingType.UTF8 });
  await MailComposer.composeAsync({
    subject: `Daily Production Record - ${new Date().toLocaleDateString('en-GB')}`,
    body: `Please find attached the daily production record in CSV format.`,
    attachments: [fileUri]
  });
};
