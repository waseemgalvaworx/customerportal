import { supabase } from '@/app/lib/supabase';

// Time slots - now covering full 24 hours
export const TIME_SLOTS = [
  '0-1', '1-2', '2-3', '3-4', '4-5', '5-6', '6-7', '7-8', '8-9', '9-10', 
  '10-11', '11-12', '12-13', '13-14', '14-15', '15-16', '16-17', '17-18', 
  '18-19', '19-20', '20-21', '21-22', '22-23', '23-24'
];

// Working hours for display filtering (7am-8pm)
export const WORKING_HOURS_START = 7;
export const WORKING_HOURS_END = 20;

export const DEPARTMENTS = ['workshop', 'acid', 'galva', 'finishing', 'ready'];

// Get hour slot from timestamp (using local timezone)
export function getHourSlot(timestamp: string): string {
  const date = new Date(timestamp);
  const hour = date.getHours();
  
  console.log('🕐 Timezone Debug:');
  console.log('  - Input timestamp:', timestamp);
  console.log('  - Date object:', date.toString());
  console.log('  - Local hour:', hour);
  console.log('  - UTC hour:', date.getUTCHours());
  console.log('  - Timezone offset (minutes):', date.getTimezoneOffset());
  
  const nextHour = (hour + 1) % 24;
  return `${hour}-${nextHour}`;
}

// Get department from the TO status (where item is moving to)
export function getDepartmentFromStatus(status: string): string | null {
  const normalized = status.toLowerCase();
  
  if (normalized === 'workshop') return 'workshop';
  if (normalized === 'acid') return 'acid';
  if (normalized === 'galva') return 'galva';
  if (normalized === 'finishing') return 'finishing';
  if (normalized === 'ready') return 'ready';
  
  return null;
}

// Track hourly production when status changes
export async function trackHourlyProduction(
  jobId: string,
  jobNumber: string,
  weightKg: number,
  fromStatus: string,
  toStatus: string,
  timestamp: string = new Date().toISOString()
) {
  console.log('📊 ===== HOURLY PRODUCTION TRACKING =====');
  console.log('Job ID:', jobId);
  console.log('Job Number:', jobNumber);
  console.log('Weight (kg):', weightKg);
  console.log('From Status:', fromStatus);
  console.log('To Status:', toStatus);
  console.log('Timestamp:', timestamp);
  
  // Track based on TO status (where item is moving to)
  const department = getDepartmentFromStatus(toStatus);
  console.log('Department:', department);
  
  if (!department) {
    console.log('⚠️ TRACKING SKIPPED - Invalid or non-trackable status:', toStatus);
    console.log('📊 ===== END TRACKING =====');
    return;
  }
  
  const hourSlot = getHourSlot(timestamp);
  console.log('Hour Slot:', hourSlot);
  
  const date = new Date(timestamp).toISOString().split('T')[0];
  console.log('Date:', date);
  
  const dataToInsert = {
    date,
    hour_slot: hourSlot,
    department,
    job_id: jobId,
    job_number: jobNumber,
    weight_kg: weightKg,
    updated_at: new Date().toISOString()
  };
  
  console.log('📝 Data to insert:', JSON.stringify(dataToInsert, null, 2));
  
  try {
    const { data, error } = await supabase
      .from('hourly_production_stats')
      .upsert(dataToInsert, {
        onConflict: 'date,hour_slot,department,job_id'
      })
      .select();
    
    if (error) {
      console.error('❌ ERROR tracking hourly production:', error);
      console.error('   Error code:', error.code);
      console.error('   Error message:', error.message);
      console.error('   Error details:', error.details);
      console.error('   Error hint:', error.hint);
    } else {
      console.log('✅ Successfully tracked hourly production');
      console.log('   Inserted/Updated data:', data);
    }
  } catch (err: any) {
    console.error('❌ EXCEPTION tracking hourly production:', err);
    console.error('   Exception message:', err.message);
  }
  
  console.log('📊 ===== END TRACKING =====');
}
