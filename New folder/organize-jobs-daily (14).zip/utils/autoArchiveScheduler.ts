let lastCheckDate = '';

export async function checkAndPerformAutoArchive(
  archiveJobFn: (jobId: string, date: string) => void,
  completedJobs: any[],
  enabled: boolean,
  time: string
) {
  try {
    if (!enabled || !time || completedJobs.length === 0) return;

    const [targetHour, targetMinute] = time.split(':').map(Number);
    const now = new Date();
    const today = now.toISOString().split('T')[0];

    // Check if already ran today
    if (lastCheckDate === today) return;

    // Check if current time is past the target time
    const currentMinutes = now.getHours() * 60 + now.getMinutes();
    const targetMinutes = targetHour * 60 + targetMinute;

    if (currentMinutes >= targetMinutes) {
      // Perform auto-archive
      const archiveDate = new Date().toISOString();
      for (const job of completedJobs) {
        archiveJobFn(job.id, archiveDate);
      }

      lastCheckDate = today;
      console.log(`Auto-archived ${completedJobs.length} jobs at ${now.toLocaleTimeString()}`);
    }
  } catch (error) {
    console.error('Error in auto-archive check:', error);
  }
}
