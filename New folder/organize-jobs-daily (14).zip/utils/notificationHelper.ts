import { supabase } from '../app/lib/supabase';
import { getAllUserIds, getUsernameFromId } from './userMapping';

interface CreateNotificationParams {
  userId: string;
  jobId?: string;
  title: string;
  message: string;
  type: 'galvxpress' | 'job_status' | 'inventory' | 'message' | 'completion' | 'stock_request_created' | 'stock_request_approved' | 'stock_request_acknowledged' | 'stock_request' | 'logistics' | 'system';

  priority?: 'normal' | 'high' | 'urgent';
}

// Hardcoded user notification overrides
const USER_NOTIFICATION_OVERRIDES: Record<string, Record<string, boolean> | 'disabled'> = {
  // JS - all notifications disabled
  '00000000-0000-0000-0000-000000000009': 'disabled',
  // IM - only logistics operations and logistics report enabled
  '00000000-0000-0000-0000-000000000008': {
    job_created: false, job_updated: false, job_completed: false, job_archived: false,
    messages: false, stock_request_created: false, stock_request_approved: false,
    stock_request_acknowledged: false, inventory_stock_movements: false,
    inventory_low_stock: false, inventory_new_items: false, inventory_diesel: false,
    system_alerts: false,
    // Only these are enabled for IM:
    logistics_new_request: true, logistics_request_approved: true, logistics_status_updates: true,
    daily_report: true, // Logistics report is part of daily report
  },
};

const getAllPasswordAuthUsers = () => {
  const userIds = getAllUserIds();
  return userIds.map(id => ({
    id, username: getUsernameFromId(id) || 'Unknown',
    name: getUsernameFromId(id) || 'Unknown', role: getUsernameFromId(id)?.toLowerCase() || 'user'
  }));
};

const checkForDuplicateNotification = async (userId: string, title: string, message: string, type: string): Promise<boolean> => {
  try {
    const fiveSecondsAgo = new Date(Date.now() - 5000).toISOString();
    const { data, error } = await supabase.from('notifications').select('id')
      .eq('user_id', userId).eq('title', title).eq('message', message).eq('type', type)
      .gte('created_at', fiveSecondsAgo).limit(1);
    if (error) return false;
    return data && data.length > 0;
  } catch (err) { return false; }
};

export const checkUserNotificationPermission = async (
  userId: string, notificationType: string, title?: string, message?: string
): Promise<boolean> => {
  try {
    // Check hardcoded overrides first
    const override = USER_NOTIFICATION_OVERRIDES[userId];
    if (override === 'disabled') {
      console.log(`🚫 User ${userId} (JS) has ALL notifications disabled`);
      return false;
    }
    
    if (override && typeof override === 'object') {
      // User IM - check specific permissions from override
      const lowerTitle = (title || '').toLowerCase();
      const lowerMessage = (message || '').toLowerCase();
      
      // Check if this is a logistics notification
      const isLogisticsNotification = notificationType === 'logistics' ||
        lowerTitle.includes('delivery') || lowerTitle.includes('logistics') ||
        lowerTitle.includes('driver') || lowerTitle.includes('vehicle');
      
      // Check if this is a daily/logistics report
      const isLogisticsReport = lowerTitle.includes('daily report') || 
        lowerTitle.includes('logistics report') || lowerTitle.includes('daily logistics');
      
      if (isLogisticsNotification) {
        if (lowerTitle.includes('approved') || lowerTitle.includes('rejected') || lowerTitle.includes('modified')) {
          return override.logistics_request_approved !== false;
        }
        if (lowerTitle.includes('status')) {
          return override.logistics_status_updates !== false;
        }
        return override.logistics_new_request !== false;
      }
      
      if (isLogisticsReport) {
        return override.daily_report !== false;
      }
      
      // For IM, block all other notification types
      console.log(`🚫 User ${userId} (IM) - notification blocked (only logistics allowed)`);
      return false;
    }
    
    // Default behavior - check database permissions
    const { data, error } = await supabase.from('profiles').select('notification_permissions').eq('id', userId).single();
    if (error || !data?.notification_permissions) return true;
    
    const perms = data.notification_permissions;
    const lowerTitle = (title || '').toLowerCase();
    const lowerMessage = (message || '').toLowerCase();
    
    const typePermissionMap: Record<string, string> = {
      'galvxpress': 'job_created', 'job_status': 'job_updated', 'completion': 'job_completed',
      'message': 'messages', 'stock_request_created': 'stock_request_created',
      'stock_request_approved': 'stock_request_approved', 'stock_request_acknowledged': 'stock_request_acknowledged',
      'stock_request': 'stock_request_approved',
    };
    
    const permKey = typePermissionMap[notificationType];
    if (permKey && perms[permKey] === false) return false;
    
    // Logistics notifications
    if (notificationType === 'logistics' || notificationType === 'message') {
      if ((lowerTitle.includes('delivery request') || lowerTitle.includes('new request')) && 
          !lowerTitle.includes('approved') && !lowerTitle.includes('rejected')) {
        if (perms.logistics_new_request === false) return false;
      }
      if (lowerTitle.includes('approved') || lowerTitle.includes('rejected') || lowerTitle.includes('modified')) {
        if (perms.logistics_request_approved === false) return false;
      }
      if (lowerTitle.includes('status') || lowerMessage.includes('status changed')) {
        if (perms.logistics_status_updates === false) return false;
      }
    }
    
    // Inventory type
    if (notificationType === 'inventory') {
      if (lowerTitle.includes('low stock') && perms.inventory_low_stock === false) return false;
      if ((lowerTitle.includes('stock in') || lowerTitle.includes('stock out')) && perms.inventory_stock_movements === false) return false;
      if ((lowerTitle.includes('new item') || lowerMessage.includes('added to inventory')) && perms.inventory_new_items === false) return false;
      if ((lowerTitle.includes('diesel') || lowerMessage.includes('diesel')) && perms.inventory_diesel === false) return false;
    }
    
    if (lowerTitle.includes('daily report') && perms.daily_report === false) return false;
    
    return true;
  } catch (err) { console.error('Error checking notification permission:', err); return true; }
};


export const createNotification = async (params: CreateNotificationParams) => {
  const { userId, jobId, title, message, type, priority = 'normal' } = params;
  try {
    const hasPermission = await checkUserNotificationPermission(userId, type, title, message);
    if (!hasPermission) { console.log(`🚫 User ${userId} has disabled ${type} notifications`); return; }
    
    const isDuplicate = await checkForDuplicateNotification(userId, title, message, type);
    if (isDuplicate) { console.log('🚫 Duplicate notification detected, skipping'); return; }

    const { error } = await supabase.from('notifications').insert({
      user_id: userId, job_id: jobId, title, message, type, priority, read: false
    });
    if (error) console.error('Error creating notification:', error);
  } catch (err) { console.error('Failed to create notification:', err); }
};

export const notifyAllUsers = async (params: Omit<CreateNotificationParams, 'userId'>) => {
  try {
    const users = getAllPasswordAuthUsers();
    if (users.length === 0) return;
    
    const notificationsToInsert = [];
    for (const user of users) {
      const hasPermission = await checkUserNotificationPermission(user.id, params.type, params.title, params.message);
      if (!hasPermission) continue;
      
      const isDuplicate = await checkForDuplicateNotification(user.id, params.title, params.message, params.type);
      if (isDuplicate) continue;
      
      notificationsToInsert.push({
        user_id: user.id, job_id: params.jobId, title: params.title, message: params.message,
        type: params.type, priority: params.priority || 'normal', read: false
      });
    }
    
    if (notificationsToInsert.length === 0) return;
    
    const { error } = await supabase.from('notifications').insert(notificationsToInsert).select();
    if (error) console.error('❌ Error inserting notifications:', error);
    else console.log(`✅ Sent ${notificationsToInsert.length} notifications`);
  } catch (err) { console.error('❌ Failed to notify all users:', err); }
};


// Users allowed to receive Daily Logistics Report in-app notifications
const LOGISTICS_REPORT_ALLOWED_USERS = [
  '00000000-0000-0000-0000-000000000001', // Admin
  '00000000-0000-0000-0000-000000000003', // Lovena
  '00000000-0000-0000-0000-000000000005', // KH
  '00000000-0000-0000-0000-000000000008', // IM
];

// Notify only specific users for Daily Logistics Report (Admin, Lovena, KH, IM)
export const notifyLogisticsReportUsers = async (params: Omit<CreateNotificationParams, 'userId'>) => {
  try {
    const users = getAllPasswordAuthUsers();
    // Filter to only allowed users for logistics report
    const allowedUsers = users.filter(u => LOGISTICS_REPORT_ALLOWED_USERS.includes(u.id));
    
    if (allowedUsers.length === 0) {
      console.log('⚠️ No allowed users found for logistics report notification');
      return;
    }
    
    console.log(`📢 Sending Daily Logistics Report to ${allowedUsers.length} users: ${allowedUsers.map(u => u.username).join(', ')}`);
    
    const notificationsToInsert = [];
    for (const user of allowedUsers) {
      const hasPermission = await checkUserNotificationPermission(user.id, params.type, params.title, params.message);
      if (!hasPermission) {
        console.log(`🚫 User ${user.username} has disabled this notification type`);
        continue;
      }
      
      const isDuplicate = await checkForDuplicateNotification(user.id, params.title, params.message, params.type);
      if (isDuplicate) {
        console.log(`🚫 Duplicate notification for ${user.username}, skipping`);
        continue;
      }
      
      notificationsToInsert.push({
        user_id: user.id, job_id: params.jobId, title: params.title, message: params.message,
        type: params.type, priority: params.priority || 'normal', read: false
      });
    }
    
    if (notificationsToInsert.length === 0) {
      console.log('⚠️ No notifications to send after permission/duplicate checks');
      return;
    }
    
    const { error } = await supabase.from('notifications').insert(notificationsToInsert).select();
    if (error) console.error('❌ Error inserting logistics report notifications:', error);
    else console.log(`✅ Sent Daily Logistics Report to ${notificationsToInsert.length} users`);
  } catch (err) { console.error('❌ Failed to notify logistics report users:', err); }
};


// Admin user ID
const ADMIN_USER_ID = '00000000-0000-0000-0000-000000000001';

// Notify Admin only (for system alerts like data reconciliation)
export const notifyAdminOnly = async (params: Omit<CreateNotificationParams, 'userId'>) => {
  try {
    const hasPermission = await checkUserNotificationPermission(ADMIN_USER_ID, params.type, params.title, params.message);
    if (!hasPermission) {
      console.log('🚫 Admin has disabled this notification type');
      return;
    }
    
    const isDuplicate = await checkForDuplicateNotification(ADMIN_USER_ID, params.title, params.message, params.type);
    if (isDuplicate) {
      console.log('🚫 Duplicate notification for Admin, skipping');
      return;
    }
    
    const { error } = await supabase.from('notifications').insert({
      user_id: ADMIN_USER_ID,
      job_id: params.jobId,
      title: params.title,
      message: params.message,
      type: params.type,
      priority: params.priority || 'normal',
      read: false
    });
    
    if (error) console.error('❌ Error sending admin notification:', error);
    else console.log('✅ Sent notification to Admin only');
  } catch (err) {
    console.error('❌ Failed to notify admin:', err);
  }
};

// Notify managers about new logistics requests
export const notifyManagersNewRequest = async (requestDetails: { deliveryNumber: string; requestedBy: string; deliveryType: string; address: string }) => {
  const managerUsernames = ['Admin', 'KH', 'Lovena'];
  const users = getAllPasswordAuthUsers();
  const managers = users.filter(u => managerUsernames.includes(u.username));
  
  for (const manager of managers) {
    await createNotification({
      userId: manager.id,
      title: 'New Delivery Request',
      message: `${requestDetails.requestedBy} has requested a ${requestDetails.deliveryType || 'delivery'}.\n\nRequest #: ${requestDetails.deliveryNumber}\nAddress: ${requestDetails.address}`,
      type: 'logistics',
      priority: 'high'
    });
  }
};
