import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { Job } from '../contexts/JobContext';
import { savePDFToDirectory, showSaveConfirmation } from './pdfSaveHelper';
import { SaveLocation } from '../contexts/SettingsContext';

const formatDateTime = (dateStr?: string, includeTime: boolean = true) => {
  const date = dateStr ? (() => {
    const parts = dateStr.split('/');
    return new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0]));
  })() : new Date();
  const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
  const months = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'];
  const dateDisplay = days[date.getDay()] + ' ' + date.getDate() + ' ' + months[date.getMonth()] + ' ' + date.getFullYear();
  if (!includeTime) return dateDisplay;
  return dateDisplay + ' - ' + date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
};

const ITEMS_PER_PAGE = 30;

const paginateFinishingJobs = (jobs: Job[]) => {
  const pages: Job[][] = [];
  let currentPage: Job[] = [];
  let currentItemCount = 0;
  for (const job of jobs) {
    const finishingItems = job.items.filter(item => item.status === 'Finishing');
    if (finishingItems.length === 0) continue;
    const itemCount = finishingItems.length + 1;
    if (currentItemCount + itemCount > ITEMS_PER_PAGE && currentPage.length > 0) {
      pages.push(currentPage);
      currentPage = [job];
      currentItemCount = itemCount;
    } else {
      currentPage.push(job);
      currentItemCount += itemCount;
    }
  }
  if (currentPage.length > 0) pages.push(currentPage);
  return pages;
};

export const generateFinishingHTML = (jobs: Job[], reportDate?: string, includeTime: boolean = true) => {
  const timestamp = formatDateTime(reportDate, includeTime);
  const pages = paginateFinishingJobs(jobs);
  let grandTotal = 0;
  jobs.forEach(job => {
    job.items.filter(item => item.status === 'Finishing').forEach(item => {
      grandTotal += parseFloat(item.weightKg || '0');
    });
  });

  const css = [
    '@page{size:A4;margin:10mm}',
    'body{font-family:Arial,sans-serif;margin:0;padding:0}',
    '.hdr{text-align:center;margin-bottom:12px;padding-bottom:8px;border-bottom:2px solid #10B981}',
    '.ttl{font-size:18px;font-weight:bold;color:#10B981;margin:0 0 4px 0}',
    '.dt{font-size:11px;color:#666;margin:0}',
    'table{width:100%;border-collapse:collapse;table-layout:fixed}',
    '.thd{background:#10B981;color:white}',
    'th,td{border:1px solid #000;padding:6px;font-size:10px}',
    'th{text-align:left}',
    '.wt{text-align:right;width:120px}',
    '.jr{background:#f3f4f6}',
    '.jc{font-weight:bold}',
    '.ic{font-size:9px;padding:4px 6px}',
    '.tot{background:#10B981;color:white;font-weight:bold}',
    '.ftr{margin-top:20px;text-align:center;font-size:8px;color:#666}',
    '.pb{page-break-after:always}',
    '.nb{page-break-after:avoid}'
  ].join('');

  const buildRows = (pageJobs: Job[]) => {
    let rows = '';
    pageJobs.forEach(job => {
      const finishingItems = job.items.filter(item => item.status === 'Finishing');
      if (finishingItems.length === 0) return;
      rows += '<tr class="jr"><td colspan="2" class="jc">Job #' + job.jobNumber + ' - ' + job.customerName + '</td></tr>';
      finishingItems.forEach(item => {
        const weight = parseFloat(item.weightKg || '0');
        const weightStr = weight > 0 ? weight.toFixed(2) : '-';
        rows += '<tr><td class="ic">' + item.descriptionOfWorks + '</td><td class="ic wt">' + weightStr + '</td></tr>';
      });
    });
    return rows;
  };

  let html = '<html><head><style>' + css + '</style></head><body>';
  pages.forEach((pageJobs, pageIndex) => {
    const isLast = pageIndex === pages.length - 1;
    const pageClass = isLast ? 'nb' : 'pb';
    html += '<div class="' + pageClass + '"><div class="hdr"><div class="ttl">FINISHING - Work Shift Report</div><div class="dt">' + timestamp + ' - Page ' + (pageIndex + 1) + ' of ' + pages.length + '</div></div>';
    html += '<table><thead><tr class="thd"><th>Item Description</th><th class="wt">Weight (kg)</th></tr></thead><tbody>';
    html += buildRows(pageJobs);
    if (isLast) {
      html += '<tr class="tot"><td class="wt">SHIFT TOTAL:</td><td class="wt">' + grandTotal.toFixed(2) + ' kg</td></tr>';
    }
    html += '</tbody></table>';
    if (isLast) {
      html += '<div class="ftr">Finishing Report</div>';
    }
    html += '</div>';
  });
  html += '</body></html>';
  return html;
};

export const saveFinishingPDF = async (jobs: Job[], saveLocation: SaveLocation): Promise<string> => {
  const html = generateFinishingHTML(jobs);
  const filename = 'Finishing_' + new Date().toISOString().replace(/[:.]/g, '-') + '.pdf';
  const filePath = await savePDFToDirectory(html, filename, saveLocation);
  showSaveConfirmation(filePath, filename);
  return filePath;
};

export const shareFinishingPDF = async (jobs: Job[]) => {
  const html = generateFinishingHTML(jobs);
  const { uri } = await Print.printToFileAsync({ html });
  await Sharing.shareAsync(uri, { UTI: '.pdf', mimeType: 'application/pdf' });
};
