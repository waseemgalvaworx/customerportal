import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { Platform, Alert } from 'react-native';

export const exportTransactionHistoryPDF = async (transactions: any[], startDate?: string, endDate?: string) => {
  try {
    const html = generateTransactionsHTML(transactions, startDate, endDate);
    const { uri } = await Print.printToFileAsync({ html });
    
    if (Platform.OS === 'ios' || Platform.OS === 'android') {
      await Sharing.shareAsync(uri, {
        mimeType: 'application/pdf',
        dialogTitle: 'Transaction History Report',
        UTI: 'com.adobe.pdf'
      });
    }
    return uri;
  } catch (error) {
    console.error('Error exporting transactions:', error);
    Alert.alert('Export Error', 'Failed to export transaction history');
    throw error;
  }
};

const generateTransactionsHTML = (transactions: any[], startDate?: string, endDate?: string): string => {
  const rows = transactions.map(t => `
    <tr>
      <td style="padding:8px;border-bottom:1px solid #E5E7EB;font-size:11px;">${new Date(t.transaction_date).toLocaleDateString()}</td>
      <td style="padding:8px;border-bottom:1px solid #E5E7EB;font-size:11px;">${t.inventory_items?.item_name || 'N/A'}</td>
      <td style="padding:8px;border-bottom:1px solid #E5E7EB;text-align:center;font-size:11px;">${t.transaction_type.replace('_', ' ')}</td>
      <td style="padding:8px;border-bottom:1px solid #E5E7EB;text-align:right;font-size:11px;">${t.quantity} ${t.inventory_items?.unit || ''}</td>
      <td style="padding:8px;border-bottom:1px solid #E5E7EB;text-align:right;font-size:11px;">$${(t.total_value || 0).toFixed(2)}</td>
      <td style="padding:8px;border-bottom:1px solid #E5E7EB;font-size:11px;">${t.username}</td>
    </tr>
  `).join('');

  const dateRange = startDate && endDate ? `${startDate} to ${endDate}` : 'All Time';

  return `
    <html>
    <head>
      <style>
        @page { size: A4 landscape; margin: 15mm; }
        body { font-family: Arial, sans-serif; }
        h1 { color: #1F2937; font-size: 20px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { background-color: #F3F4F6; padding: 10px; text-align: left; font-weight: bold; font-size: 11px; }
      </style>
    </head>
    <body>
      <h1>Transaction History Report</h1>
      <p>Period: ${dateRange} | Generated: ${new Date().toLocaleString()}</p>
      <table>
        <thead><tr><th>Date</th><th>Item</th><th style="text-align:center;">Type</th><th style="text-align:right;">Quantity</th><th style="text-align:right;">Value</th><th>User</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <p style="margin-top:20px;"><strong>Total Transactions: ${transactions.length}</strong></p>
    </body>
    </html>
  `;
};
