import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import * as MailComposer from 'expo-mail-composer';
import { Job } from '../contexts/JobContext';

// Portrait has more vertical space
const JOBS_PER_PAGE_PORTRAIT = 3;
const JOBS_PER_PAGE_LANDSCAPE = 2;

const paginateBatchJobs = (jobs: Job[], isLandscape: boolean = false) => {
  const jobsPerPage = isLandscape ? JOBS_PER_PAGE_LANDSCAPE : JOBS_PER_PAGE_PORTRAIT;
  const pages: Job[][] = [];
  for (let i = 0; i < jobs.length; i += jobsPerPage) {
    pages.push(jobs.slice(i, i + jobsPerPage));
  }
  return pages;
};


export const generateBatchHTML = (jobs: Job[]): string => {
  const totalJobs = jobs.length;
  const totalItems = jobs.reduce((sum, job) => sum + job.items.length, 0);
  const totalWeight = jobs.reduce((sum, job) => 
    sum + job.items.reduce((itemSum, item) => itemSum + parseFloat(item.weightKg || '0'), 0), 0
  );

  const pages = paginateBatchJobs(jobs);

  const pageHTMLs = pages.map((pageJobs, pageIndex) => {
    const isLastPage = pageIndex === pages.length - 1;
    
    const jobSections = pageJobs.map(job => {
      const jobWeight = job.items.reduce((sum, item) => sum + parseFloat(item.weightKg || '0'), 0);
      return `
        <div style="margin:20px 0;padding:15px;border:1px solid #E5E7EB;border-radius:8px;">
          <h2 style="font-size:18px;font-weight:bold;color:#1F2937;margin:0 0 10px 0;">${job.jobNumber} - ${job.customerName}</h2>
          ${job.galvaXpress ? '<span style="display:inline-block;padding:3px 10px;border-radius:12px;font-size:11px;font-weight:bold;color:white;background:#EF4444;">GalvXpress</span>' : ''}
          <p style="margin:5px 0;font-size:12px;"><strong>Status:</strong> ${job.status.toUpperCase()} | <strong>Priority:</strong> ${job.priority?.toUpperCase() || 'Not Set'}</p>
          <p style="margin:5px 0;font-size:12px;"><strong>Items:</strong> ${job.items.length} | <strong>Total Weight:</strong> ${jobWeight.toFixed(1)} kg</p>
          ${job.notes ? `<p style="margin:5px 0;font-size:12px;"><strong>Notes:</strong> ${job.notes}</p>` : ''}
          
          <table style="width:100%;border-collapse:collapse;margin-top:10px;">
            <thead>
              <tr>
                <th style="background:#F3F4F6;padding:6px;text-align:left;font-size:11px;border-bottom:1px solid #E5E7EB;">Description</th>
                <th style="background:#F3F4F6;padding:6px;text-align:left;font-size:11px;border-bottom:1px solid #E5E7EB;">Weight</th>
                <th style="background:#F3F4F6;padding:6px;text-align:left;font-size:11px;border-bottom:1px solid #E5E7EB;">Status</th>
                <th style="background:#F3F4F6;padding:6px;text-align:left;font-size:11px;border-bottom:1px solid #E5E7EB;">Options</th>
              </tr>
            </thead>
            <tbody>
              ${job.items.map(item => {
                const options = [];
                if (item.paintVarnish) options.push('P/V');
                if (item.galva) options.push('Galva');
                if (item.lightGalva) options.push('LG');
                if (item.lightPaint) options.push('LP');
                if (item.rusty) options.push('Rusty');
                
                return `
                  <tr>
                    <td style="padding:6px;border-bottom:1px solid #E5E7EB;font-size:11px;">${item.descriptionOfWorks}</td>
                    <td style="padding:6px;border-bottom:1px solid #E5E7EB;font-size:11px;">${item.weightKg} kg</td>
                    <td style="padding:6px;border-bottom:1px solid #E5E7EB;font-size:11px;">${item.status}</td>
                    <td style="padding:6px;border-bottom:1px solid #E5E7EB;font-size:11px;">${options.length > 0 ? options.join(', ') : '-'}</td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      `;
    }).join('');

    return `
      <div style="page-break-after: ${isLastPage ? 'avoid' : 'always'};">
        ${pageIndex === 0 ? `
          <div style="border-bottom:3px solid #3B82F6;padding-bottom:15px;margin-bottom:20px;">
            <h1 style="font-size:24px;font-weight:bold;color:#1F2937;margin:0;">Batch Job Report</h1>
            <p style="margin:5px 0;font-size:12px;">Generated on ${new Date().toLocaleString('en-GB')}</p>
          </div>
          <div style="background:#F3F4F6;padding:15px;border-radius:8px;margin:20px 0;">
            <span style="display:inline-block;margin-right:30px;"><strong>Total Jobs:</strong> <span style="font-size:20px;color:#3B82F6;">${totalJobs}</span></span>
            <span style="display:inline-block;margin-right:30px;"><strong>Total Items:</strong> <span style="font-size:20px;color:#3B82F6;">${totalItems}</span></span>
            <span style="display:inline-block;"><strong>Total Weight:</strong> <span style="font-size:20px;color:#3B82F6;">${totalWeight.toFixed(1)} kg</span></span>
          </div>
        ` : `<h3 style="margin-top:0;">Page ${pageIndex + 1} of ${pages.length}</h3>`}
        ${jobSections}
      </div>
    `;
  }).join('');

  return `<html><head><style>@page{size:A4;margin:15mm;}body{font-family:Arial,sans-serif;padding:0;margin:0;}</style></head><body>${pageHTMLs}</body></html>`;
};

export const exportBatchToPDF = async (jobs: Job[]): Promise<string> => {
  const html = generateBatchHTML(jobs);
  const { uri } = await Print.printToFileAsync({ html });
  return uri;
};

export const shareBatchPDF = async (jobs: Job[]) => {
  const uri = await exportBatchToPDF(jobs);
  await Sharing.shareAsync(uri, {
    mimeType: 'application/pdf',
    dialogTitle: `Batch Report - ${jobs.length} Jobs`
  });
};

export const emailBatchPDF = async (jobs: Job[]) => {
  const uri = await exportBatchToPDF(jobs);
  await MailComposer.composeAsync({
    subject: `Batch Job Report - ${jobs.length} Jobs`,
    body: `Please find attached the batch report containing ${jobs.length} jobs.`,
    attachments: [uri]
  });
};
