import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import * as MailComposer from 'expo-mail-composer';
import { Job } from '../contexts/JobContext';

const getStatusColor = (status: string) => {
  switch(status) {
    case 'Workshop': return '#3B82F6';
    case 'Acid': return '#F59E0B';
    case 'Galva': return '#8B5CF6';
    case 'Finishing': return '#10B981';
    case 'Ready': return '#059669';
    default: return '#6B7280';
  }
};

const formatDate = (date: Date | string | undefined) => {
  if (!date) return 'Not set';
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
};

const formatDateTime = (date: Date | string | undefined) => {
  if (!date) return 'Not set';
  const d = typeof date === 'string' ? new Date(date) : date;
  return `${formatDate(d)} ${d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`;
};

// Portrait has more vertical space
const ITEMS_PER_PAGE_PORTRAIT = 20;
const ITEMS_PER_PAGE_LANDSCAPE = 10; // Reduced from 12 for better reliability



export const generateJobHTML = (job: Job, isLandscape: boolean = false): string => {
  const totalWeight = job.items.reduce((sum, item) => sum + parseFloat(item.weightKg || '0'), 0);
  const itemsPerPage = isLandscape ? ITEMS_PER_PAGE_LANDSCAPE : ITEMS_PER_PAGE_PORTRAIT;
  
  // Paginate items if needed
  const pages: typeof job.items[] = [];
  for (let i = 0; i < job.items.length; i += itemsPerPage) {
    pages.push(job.items.slice(i, i + itemsPerPage));
  }


  const pageHTMLs = pages.map((pageItems, pageIndex) => {
    const isLastPage = pageIndex === pages.length - 1;
    
    return `
      <div style="page-break-after: ${isLastPage ? 'avoid' : 'always'};">
        ${pageIndex === 0 ? `
          <div style="border-bottom:3px solid #3B82F6;padding-bottom:15px;margin-bottom:20px;">
            <h1 style="font-size:24px;font-weight:bold;color:#1F2937;margin:0;">Job Report: ${job.jobNumber}</h1>
            <p style="font-size:16px;color:#374151;margin:5px 0;">${job.customerName}</p>
            ${job.galvaXpress ? '<span style="display:inline-block;padding:4px 12px;border-radius:12px;font-size:12px;font-weight:bold;color:white;background:#EF4444;">GalvXpress</span>' : ''}
          </div>
          <div style="margin:20px 0;">
            <p style="margin:5px 0;"><strong>Status:</strong> ${job.status.toUpperCase()}</p>
            <p style="margin:5px 0;"><strong>Priority:</strong> ${job.priority ? job.priority.toUpperCase() : 'Not Set'}</p>
            <p style="margin:5px 0;"><strong>Entry Date:</strong> ${formatDate(job.dateOfEntry)}</p>
            <p style="margin:5px 0;"><strong>Delivery Date:</strong> ${formatDateTime(job.deliveryDate)}</p>
          </div>
        ` : `<h3 style="margin-top:0;">Page ${pageIndex + 1} of ${pages.length}</h3>`}
        
        <h2 style="font-size:16px;margin:20px 0 10px 0;">Items ${pageIndex > 0 ? `(continued)` : `(${job.items.length})`}</h2>
        <table style="width:100%;border-collapse:collapse;">
          <thead>
            <tr>
              <th style="background:#F3F4F6;padding:8px;text-align:left;font-weight:bold;font-size:12px;">Description</th>
              <th style="background:#F3F4F6;padding:8px;text-align:left;font-weight:bold;font-size:12px;">Weight (kg)</th>
              <th style="background:#F3F4F6;padding:8px;text-align:left;font-weight:bold;font-size:12px;">Status</th>
              <th style="background:#F3F4F6;padding:8px;text-align:left;font-weight:bold;font-size:12px;">Options</th>
            </tr>
          </thead>
          <tbody>
            ${pageItems.map(item => {
              const options = [];
              if (item.paintVarnish) options.push('P/V');
              if (item.galva) options.push('Galva');
              if (item.lightGalva) options.push('LG');
              if (item.lightPaint) options.push('LP');
              if (item.rusty) options.push('Rusty');
              
              return `
              <tr>
                <td style="padding:8px;border-bottom:1px solid #E5E7EB;font-size:11px;">${item.descriptionOfWorks}</td>
                <td style="padding:8px;border-bottom:1px solid #E5E7EB;font-size:11px;">${item.weightKg}</td>
                <td style="padding:8px;border-bottom:1px solid #E5E7EB;font-size:11px;">${item.status}</td>
                <td style="padding:8px;border-bottom:1px solid #E5E7EB;font-size:11px;">${options.length > 0 ? options.join(', ') : '-'}</td>
              </tr>
            `}).join('')}
            ${isLastPage ? `
              <tr style="font-weight:bold;font-size:14px;">
                <td style="padding:10px;">Total Weight</td>
                <td style="padding:10px;">${totalWeight.toFixed(1)} kg</td>
                <td></td>
                <td></td>
              </tr>
            ` : ''}
          </tbody>
        </table>

        ${isLastPage && job.notes ? `
          <div style="margin:20px 0;">
            <h2 style="font-size:16px;">Notes</h2>
            <p style="font-size:12px;">${job.notes}</p>
          </div>
        ` : ''}
        
        ${isLastPage ? `
          <div style="margin-top:40px;padding-top:20px;border-top:1px solid #E5E7EB;color:#9CA3AF;font-size:11px;">
            Generated on ${new Date().toLocaleString('en-GB')}
          </div>
        ` : ''}
      </div>
    `;
  }).join('');

  return `<html><head><style>@page{size:A4;margin:15mm;}body{font-family:Arial,sans-serif;padding:0;margin:0;}</style></head><body>${pageHTMLs}</body></html>`;
};

export const exportJobToPDF = async (job: Job): Promise<string> => {
  const html = generateJobHTML(job);
  const { uri } = await Print.printToFileAsync({ html });
  return uri;
};

export const shareJobPDF = async (job: Job) => {
  const uri = await exportJobToPDF(job);
  await Sharing.shareAsync(uri, {
    mimeType: 'application/pdf',
    dialogTitle: `Job Report - ${job.jobNumber}`
  });
};

export const emailJobPDF = async (job: Job) => {
  const uri = await exportJobToPDF(job);
  await MailComposer.composeAsync({
    subject: `Job Report - ${job.jobNumber}`,
    body: `Please find attached the job report for ${job.jobNumber} - ${job.customerName}.`,
    attachments: [uri]
  });
};
