export interface StockAnalytics {
  totalItems: number;
  totalValue: number;
  lowStockCount: number;
  categoryBreakdown: { category: string; count: number; value: number }[];
  recentTransactions: number;
  stockInValue: number;
  stockOutValue: number;
}

export const calculateStockAnalytics = (items: any[], transactions: any[]): StockAnalytics => {
  const totalItems = items.length;
  const totalValue = items.reduce((sum, item) => sum + (item.total_value || 0), 0);
  const lowStockCount = items.filter(item => 
    item.reorder_level && item.quantity <= item.reorder_level
  ).length;

  const categoryBreakdown = items.reduce((acc: any[], item) => {
    const existing = acc.find(c => c.category === item.category);
    if (existing) {
      existing.count++;
      existing.value += item.total_value || 0;
    } else {
      acc.push({ category: item.category, count: 1, value: item.total_value || 0 });
    }
    return acc;
  }, []);

  const recentTransactions = transactions.length;
  const stockInValue = transactions
    .filter(t => t.transaction_type === 'stock_in')
    .reduce((sum, t) => sum + (t.total_value || 0), 0);
  const stockOutValue = transactions
    .filter(t => t.transaction_type === 'stock_out')
    .reduce((sum, t) => sum + (t.total_value || 0), 0);

  return {
    totalItems,
    totalValue,
    lowStockCount,
    categoryBreakdown,
    recentTransactions,
    stockInValue,
    stockOutValue,
  };
};
