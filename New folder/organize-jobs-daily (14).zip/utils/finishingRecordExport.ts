import * as Print from 'expo-print';
import { savePDFToDirectory, showSaveConfirmation } from './pdfSaveHelper';
import { SaveLocation } from '../contexts/SettingsContext';

interface FinishingRecord {
  id: string;
  job_number: string;
  customer_name: string;
  item_description: string;
  weight_kg: string;
}

const formatDateTime = () => {
  const now = new Date();
  const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
  const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
  return `${days[now.getDay()]} ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()} - ${now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`;
};

export const generateFinishingRecordHTML = (records: FinishingRecord[]) => {
  const timestamp = formatDateTime();
  let totalWeight = 0;

  const grouped = records.reduce((acc, rec) => {
    if (!acc[rec.job_number]) {
      acc[rec.job_number] = { customer: rec.customer_name, items: [] };
    }
    acc[rec.job_number].items.push(rec);
    return acc;
  }, {} as Record<string, { customer: string; items: FinishingRecord[] }>);

  const jobRows = Object.entries(grouped).map(([jobNum, data]) => {
    const itemsList = data.items.map(item => {
      const weight = parseFloat(item.weight_kg || '0');
      totalWeight += weight;
      return `<tr>
        <td style="border:1px solid #000;padding:4px 6px;font-size:9px;">${item.item_description}</td>
        <td style="border:1px solid #000;padding:4px 6px;font-size:9px;text-align:right;">${weight.toFixed(2)}</td>
      </tr>`;
    }).join('');

    return `
      <tr style="background:#f3f4f6;">
        <td colspan="2" style="border:1px solid #000;padding:6px;font-size:10px;font-weight:bold;">
          Job #${jobNum} - ${data.customer}
        </td>
      </tr>
      ${itemsList}
    `;
  }).join('');

  return `
    <html>
      <head>
        <style>
          @page { size: A4; margin: 0; }
          body { font-family: Arial, sans-serif; margin: 10mm; padding: 0; }
          .header { text-align: center; margin-bottom: 12px; padding-bottom: 8px; border-bottom: 2px solid #10B981; }
          .header-title { font-size: 18px; font-weight: bold; color: #10B981; margin: 0 0 4px 0; }
          .header-subtitle { font-size: 11px; color: #666; margin: 0; }
          table { width: 100%; border-collapse: collapse; margin-top: 8px; }
          .total-row { background: #10B981; color: white; font-weight: bold; }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="header-title">FINISHING - Work Shift Report</div>
          <div class="header-subtitle">${timestamp}</div>
        </div>
        <table>
          <thead>
            <tr style="background:#10B981;color:white;">
              <th style="border:1px solid #000;padding:6px;font-size:10px;text-align:left;">Item Description</th>
              <th style="border:1px solid #000;padding:6px;font-size:10px;text-align:right;width:120px;">Weight (kg)</th>
            </tr>
          </thead>
          <tbody>
            ${jobRows}
            <tr class="total-row">
              <td style="border:1px solid #000;padding:8px;font-size:11px;text-align:right;">SHIFT TOTAL:</td>
              <td style="border:1px solid #000;padding:8px;font-size:11px;text-align:right;">${totalWeight.toFixed(2)} kg</td>
            </tr>
          </tbody>
        </table>
      </body>
    </html>
  `;
};

export const saveFinishingRecordPDF = async (records: FinishingRecord[], saveLocation: SaveLocation): Promise<string> => {
  const html = generateFinishingRecordHTML(records);
  const filename = `Finishing_${new Date().toISOString().replace(/[:.]/g, '-')}.pdf`;
  const filePath = await savePDFToDirectory(html, filename, saveLocation);
  showSaveConfirmation(filePath, filename);
  return filePath;
};
