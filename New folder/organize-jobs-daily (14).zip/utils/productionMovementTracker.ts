import { supabase } from '../app/lib/supabase';

export async function recordMovement(
  jobId: string,
  itemId: string,
  jobNumber: string,
  customerName: string,
  itemDescription: string,
  weightKg: number,
  fromStatus: string,
  toStatus: string
) {
  try {
    const movementDate = new Date().toISOString().split('T')[0];
    
    const { error } = await supabase
      .from('production_movements')
      .insert({
        job_id: jobId,
        item_id: itemId,
        job_number: jobNumber,
        customer_name: customerName,
        item_description: itemDescription,
        weight_kg: weightKg,
        from_status: fromStatus,
        to_status: toStatus,
        movement_date: movementDate
      });
      
    if (error) {
      console.error('Error recording movement:', error);
      return false;
    }
    
    return true;
  } catch (error) {
    console.error('Error in recordMovement:', error);
    return false;
  }
}

export async function getDailyMovements(date: string, targetStatus: string = 'Finishing') {
  const { data, error } = await supabase
    .from('production_movements')
    .select('*')
    .eq('movement_date', date)
    .eq('to_status', targetStatus);
    
  if (error) {
    console.error('Error fetching movements:', error);
    return [];
  }
  
  return data || [];
}

export async function getDailyCompletedWeight(date: string) {
  const movements = await getDailyMovements(date, 'Finishing');
  return movements.reduce((sum, m) => sum + (Number(m.weight_kg) || 0), 0);
}
