/**
 * User Mapping Utility
 * Maps between usernames and UUIDs for the password authentication system
 */

const USER_ID_MAP: Record<string, string> = {
  'Admin': '00000000-0000-0000-0000-000000000001',
  'admin': '00000000-0000-0000-0000-000000000001',
  'James': '00000000-0000-0000-0000-000000000002',
  'Lovena': '00000000-0000-0000-0000-000000000003',
  'Luvish': '00000000-0000-0000-0000-000000000004',
  'KH': '00000000-0000-0000-0000-000000000005',
  'Ashok': '00000000-0000-0000-0000-000000000006',
  'Ikhlaas': '00000000-0000-0000-0000-000000000007',
  'IM': '00000000-0000-0000-0000-000000000008',
  'JS': '00000000-0000-0000-0000-000000000009',
  'IJ': '00000000-0000-0000-0000-000000000010',
};

// Reverse mapping for quick lookup
const ID_TO_USERNAME_MAP: Record<string, string> = Object.entries(USER_ID_MAP).reduce(
  (acc, [username, id]) => {
    acc[id] = username;
    return acc;
  },
  {} as Record<string, string>
);

export function getUserIdFromUsername(username: string): string | undefined {
  return USER_ID_MAP[username];
}

export function getUsernameFromId(userId: string): string | undefined {
  return ID_TO_USERNAME_MAP[userId];
}

export function getAllUserIds(): string[] {
  return [...new Set(Object.values(USER_ID_MAP))];
}

export function getAllUsernames(): string[] {
  return Object.keys(USER_ID_MAP);
}

export function isValidUserId(userId: string): boolean {
  return userId in ID_TO_USERNAME_MAP;
}

export function isValidUsername(username: string): boolean {
  return username in USER_ID_MAP;
}
