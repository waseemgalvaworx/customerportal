import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { Platform, Alert } from 'react-native';

export const exportLowStockAlertsPDF = async (items: any[]) => {
  try {
    const lowStockItems = items.filter(item => 
      item.reorder_level && item.quantity <= item.reorder_level
    );
    
    const html = generateLowStockHTML(lowStockItems);
    const { uri } = await Print.printToFileAsync({ html });
    
    if (Platform.OS === 'ios' || Platform.OS === 'android') {
      await Sharing.shareAsync(uri, {
        mimeType: 'application/pdf',
        dialogTitle: 'Low Stock Alerts Report',
        UTI: 'com.adobe.pdf'
      });
    }
    return uri;
  } catch (error) {
    console.error('Error exporting low stock alerts:', error);
    Alert.alert('Export Error', 'Failed to export low stock alerts');
    throw error;
  }
};

const generateLowStockHTML = (items: any[]): string => {
  const rows = items.map(item => `
    <tr style="background-color: #FEF3C7;">
      <td style="padding:12px;border-bottom:1px solid #E5E7EB;">${item.item_name}</td>
      <td style="padding:12px;border-bottom:1px solid #E5E7EB;text-align:center;">${item.quantity} ${item.unit}</td>
      <td style="padding:12px;border-bottom:1px solid #E5E7EB;text-align:center;">${item.reorder_level} ${item.unit}</td>
      <td style="padding:12px;border-bottom:1px solid #E5E7EB;">${item.supplier || 'N/A'}</td>
    </tr>
  `).join('');

  return `
    <html>
    <head>
      <style>
        @page { size: A4; margin: 15mm; }
        body { font-family: Arial, sans-serif; }
        h1 { color: #DC2626; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { background-color: #FEE2E2; padding: 12px; text-align: left; font-weight: bold; }
        .alert { background-color: #FEE2E2; padding: 15px; margin-bottom: 20px; border-left: 4px solid #DC2626; }
      </style>
    </head>
    <body>
      <h1>Low Stock Alerts</h1>
      <p>Generated: ${new Date().toLocaleString()}</p>
      <div class="alert"><strong>⚠️ ${items.length} items require reordering</strong></div>
      <table>
        <thead><tr><th>Item</th><th style="text-align:center;">Current Stock</th><th style="text-align:center;">Reorder Level</th><th>Supplier</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </body>
    </html>
  `;
};
