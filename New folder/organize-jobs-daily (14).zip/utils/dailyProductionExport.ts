import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import * as MailComposer from 'expo-mail-composer';
import { Job } from '../contexts/JobContext';
import { savePDFToDirectory, showSaveConfirmation } from './pdfSaveHelper';
import { SaveLocation } from '../contexts/SettingsContext';

export interface ExportOptions {
  includeCustomer: boolean;
  includeWeights: boolean;
  includeItemOptions: boolean;
}

const formatDateForReport = (date: Date, includeTime: boolean = true) => {
  const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
  const months = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'];
  const dateStr = days[date.getDay()] + ' ' + date.getDate() + ' ' + months[date.getMonth()] + ' ' + date.getFullYear();
  if (!includeTime) return dateStr;
  return dateStr + ' - ' + date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
};

const ROWS_PER_PAGE = 12;

const paginateJobs = (jobs: Job[]) => {
  const pages: Job[][] = [];
  let currentPage: Job[] = [];
  let currentRowCount = 0;
  for (const job of jobs) {
    const jobRowCount = job.items.length;
    if (currentRowCount + jobRowCount > ROWS_PER_PAGE && currentPage.length > 0) {
      pages.push(currentPage);
      currentPage = [job];
      currentRowCount = jobRowCount;
    } else {
      currentPage.push(job);
      currentRowCount += jobRowCount;
    }
  }
  if (currentPage.length > 0) pages.push(currentPage);
  return pages;
};

export const generateDailyProductionHTML = (jobs: Job[], reportDate?: string, includeTime: boolean = true) => {
  const date = reportDate ? (() => {
    const parts = reportDate.split('/');
    return new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0]));
  })() : new Date();
  const dateDisplay = formatDateForReport(date, includeTime);
  const timestamp = new Date().toLocaleString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  const pages = paginateJobs(jobs);
  let grandTotal = 0;
  jobs.forEach(job => job.items.forEach(item => { grandTotal += parseFloat(item.weightKg || '0'); }));

  const css = [
    '@page{size:A4 landscape;margin:10mm}',
    'body{font-family:Arial,sans-serif;margin:0;padding:0}',
    '.hdr{text-align:center;margin-bottom:12px;padding-bottom:8px;border-bottom:2px solid #000}',
    '.ttl{font-size:16px;font-weight:bold;margin:0 0 4px 0}',
    '.dt{font-size:11px;color:#333;margin:0}',
    'table{width:100%;border-collapse:collapse;table-layout:fixed}',
    'th,td{border:1px solid #000;padding:5px;font-size:9px;word-wrap:break-word}',
    'th{background:#f0f0f0;font-size:10px}',
    '.c1{width:10%;text-align:center;vertical-align:top}',
    '.c2{width:10%;text-align:center;vertical-align:top}',
    '.c3{width:18%;vertical-align:top}',
    '.c4{width:40%;font-size:8px}',
    '.c5{width:10%;text-align:right}',
    '.c6{width:12%;text-align:center;vertical-align:top}',
    '.tot{background:#e8e8e8;font-weight:bold}',
    '.ftr{margin-top:15px;text-align:center;font-size:8px;color:#666}',
    '.pb{page-break-after:always}',
    '.nb{page-break-after:avoid}'
  ].join('');

  const buildRows = (pageJobs: Job[]) => {
    let rows = '';
    pageJobs.forEach(job => {
      job.items.forEach((item, idx) => {
        const opts = [];
        if (item.paintVarnish) opts.push('P/V');
        if (item.galva) opts.push('Galva');
        if (item.lightGalva) opts.push('LG');
        if (item.lightPaint) opts.push('LP');
        if (item.rusty) opts.push('Rusty');
        const badges = opts.length > 0 ? ' [' + opts.join(', ') + ']' : '';
        const weight = parseFloat(item.weightKg || '0');
        const weightStr = weight > 0 ? weight.toFixed(2) : '';
        const rs = job.items.length;
        const entryDate = new Date(job.dateOfEntry).toLocaleDateString('en-GB');
        const readyDate = job.completedDate ? new Date(job.completedDate).toLocaleDateString('en-GB') : '';
        if (idx === 0) {
          rows += '<tr><td rowspan="' + rs + '" class="c1">' + job.jobNumber + '</td><td rowspan="' + rs + '" class="c2">' + entryDate + '</td><td rowspan="' + rs + '" class="c3">' + job.customerName + '</td><td class="c4">' + item.descriptionOfWorks + badges + '</td><td class="c5">' + weightStr + '</td><td rowspan="' + rs + '" class="c6">' + readyDate + '</td></tr>';
        } else {
          rows += '<tr><td class="c4">' + item.descriptionOfWorks + badges + '</td><td class="c5">' + weightStr + '</td></tr>';
        }
      });
    });
    return rows;
  };

  let html = '<html><head><style>' + css + '</style></head><body>';
  pages.forEach((pageJobs, pageIndex) => {
    const isLast = pageIndex === pages.length - 1;
    const pageClass = isLast ? 'nb' : 'pb';
    html += '<div class="' + pageClass + '"><div class="hdr"><div class="ttl">Production Sheet</div><div class="dt">' + dateDisplay + ' - Page ' + (pageIndex + 1) + ' of ' + pages.length + '</div></div>';
    html += '<table><thead><tr><th class="c1">JOB NO</th><th class="c2">DATE OF ENTRY</th><th class="c3">CUSTOMER NAME</th><th class="c4">DETAILS OF WORK</th><th class="c5">WEIGHT (KGS)</th><th class="c6">READY DATE</th></tr></thead><tbody>';
    html += buildRows(pageJobs);
    if (isLast) {
      html += '<tr class="tot"><td colspan="4" style="text-align:right;font-weight:bold">TOTAL PRODUCTION:</td><td class="c5">' + grandTotal.toFixed(2) + '</td><td></td></tr>';
    }
    html += '</tbody></table>';
    if (isLast) {
      html += '<div class="ftr">Created: ' + timestamp + '</div>';
    }
    html += '</div>';
  });
  html += '</body></html>';
  return html;
};

export const shareDailyProductionPDF = async (jobs: Job[]) => {
  const html = generateDailyProductionHTML(jobs);
  const { uri } = await Print.printToFileAsync({ html });
  await Sharing.shareAsync(uri, { UTI: '.pdf', mimeType: 'application/pdf' });
};

export const emailDailyProductionPDF = async (jobs: Job[]) => {
  const html = generateDailyProductionHTML(jobs);
  const { uri } = await Print.printToFileAsync({ html });
  await MailComposer.composeAsync({ subject: 'Daily Production Record - ' + new Date().toLocaleDateString('en-GB'), body: 'Please find attached the daily production record.', attachments: [uri] });
};

export const saveDailyProductionPDF = async (jobs: Job[], saveLocation: SaveLocation): Promise<string> => {
  const html = generateDailyProductionHTML(jobs);
  const filename = 'DailyProduction_' + new Date().toISOString().split('T')[0] + '.pdf';
  const filePath = await savePDFToDirectory(html, filename, saveLocation);
  showSaveConfirmation(filePath, filename);
  return filePath;
};
