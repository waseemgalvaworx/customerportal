# Unarchive Completed Jobs - Debugging Guide

## Overview
This guide helps diagnose and fix issues with unarchiving completed jobs from the Archive screen.

## How It Works

### Flow
1. User clicks "Unarchive Report" button in Archive screen
2. Password prompt appears (password: 4321)
3. After password validation, confirmation dialog shows
4. `restoreJob()` function is called for each job
5. Jobs are moved from 'archived' status to 'planning' (WIP)

### Database Operations
The `restoreJob()` function performs these steps:

1. **Fetch job from database** - Verify job exists
2. **Delete completed_jobs entries** - Remove all items from completed_jobs table
3. **Update job status** - Set status to 'planning', clear archivedDate and completedDate
4. **Update local state** - Refresh UI
5. **Create audit log** - Record the action

## Debugging Steps

### 1. Check Console Logs
The function now has comprehensive logging. Check the console for:

```
=== RESTORE JOB FUNCTION CALLED ===
Step 1: Checking if job exists in database...
✅ Job found in database
Step 2: Found X items in job
Step 3: Deleting completed_jobs entries...
✅ Successfully deleted X completed_jobs entries
Step 4: Updating job status to planning...
✅ Successfully updated job status to planning
✅ Local state updated
Step 5: Creating audit log...
✅ Audit log created
=== RESTORE JOB COMPLETE ===
```

### 2. Common Error Messages

#### "Job not found in database"
- Job ID is incorrect or job was deleted
- Check: `SELECT * FROM jobs WHERE id = 'job-id-here';`

#### "Failed to delete completed_jobs"
- RLS policy issue on completed_jobs table
- See RLS Policy Fixes below

#### "Failed to update job"
- RLS policy issue on jobs table
- See RLS Policy Fixes below

## Database Permission Fixes

### Check Current RLS Policies

```sql
-- Check jobs table policies
SELECT * FROM pg_policies WHERE tablename = 'jobs';

-- Check completed_jobs table policies
SELECT * FROM pg_policies WHERE tablename = 'completed_jobs';
```

### Fix RLS Policies for Jobs Table

```sql
-- Drop existing restrictive policies
DROP POLICY IF EXISTS "Allow all operations on jobs" ON jobs;

-- Create permissive policy for all operations
CREATE POLICY "Allow all operations on jobs"
ON jobs
FOR ALL
USING (true)
WITH CHECK (true);
```

### Fix RLS Policies for Completed Jobs Table

```sql
-- Drop existing restrictive policies
DROP POLICY IF EXISTS "Allow all operations on completed_jobs" ON completed_jobs;

-- Create permissive policy for all operations
CREATE POLICY "Allow all operations on completed_jobs"
ON completed_jobs
FOR ALL
USING (true)
WITH CHECK (true);
```

## Testing Procedure

### 1. Test with Console Open
1. Open React Native debugger or console
2. Navigate to Archive screen
3. Select a completed jobs report
4. Click "Unarchive Report"
5. Enter password: 4321
6. Confirm unarchive
7. Watch console logs for each step

### 2. Verify Database Changes

After unarchiving, check:

```sql
-- Verify job status changed to 'planning'
SELECT id, jobNumber, status, archivedDate, completedDate 
FROM jobs 
WHERE id = 'job-id-here';

-- Verify completed_jobs entries were deleted
SELECT * FROM completed_jobs 
WHERE job_id = 'job-id-here';
-- Should return 0 rows

-- Check audit log
SELECT * FROM activity_logs 
WHERE entity_id = 'job-id-here' 
ORDER BY created_at DESC 
LIMIT 5;
```

### 3. Verify UI Updates

After unarchiving:
- Archive screen should refresh
- Job should disappear from Archive
- Job should appear in WIP (Planning) screen
- Job status should show as 'planning'

## Troubleshooting

### Issue: Button doesn't respond
**Check:**
- Is selectedData populated? (Check console log)
- Is button disabled? (Check if selectedData.length === 0)

### Issue: Password prompt doesn't show
**Check:**
- Is showPasswordPrompt state being set?
- Check console for "UNARCHIVE CLICKED" message

### Issue: Jobs don't move to WIP
**Check:**
- Console logs for specific error
- Database RLS policies (see above)
- Network tab for failed requests

### Issue: Some jobs unarchive, others don't
**Check:**
- Console logs show which jobs succeeded/failed
- Individual job error messages
- Database constraints or triggers

## Manual Database Fix

If jobs are stuck in archived state:

```sql
-- Manually restore a job
UPDATE jobs 
SET status = 'planning', 
    archivedDate = NULL, 
    completedDate = NULL 
WHERE id = 'job-id-here';

-- Delete completed_jobs entries
DELETE FROM completed_jobs 
WHERE job_id = 'job-id-here';
```

## Contact Support

If issues persist after following this guide:
1. Capture full console logs
2. Note exact error messages
3. Check database policies
4. Verify job data structure
