# Hourly Production Statistics - Database Schema & Troubleshooting

## Expected Table Structure

The `hourly_production_stats` table should have the following structure:

```sql
CREATE TABLE IF NOT EXISTS hourly_production_stats (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  date DATE NOT NULL,
  hour_slot TEXT NOT NULL,
  department TEXT NOT NULL,
  job_id UUID NOT NULL,
  job_number TEXT NOT NULL,
  weight_kg NUMERIC NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- Unique constraint for upsert operations
  CONSTRAINT hourly_production_unique UNIQUE (date, hour_slot, department, job_id)
);

-- Indexes for faster queries
CREATE INDEX IF NOT EXISTS idx_hourly_production_date ON hourly_production_stats(date);
CREATE INDEX IF NOT EXISTS idx_hourly_production_department ON hourly_production_stats(department);
CREATE INDEX IF NOT EXISTS idx_hourly_production_job ON hourly_production_stats(job_id);

-- Enable RLS
ALTER TABLE hourly_production_stats ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Allow authenticated users to read" ON hourly_production_stats
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Allow authenticated users to insert" ON hourly_production_stats
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update" ON hourly_production_stats
  FOR UPDATE TO authenticated USING (true);
```

## Database Verification Steps

Run these SQL queries in Supabase SQL Editor to verify setup:

```sql
-- 1. Check if table exists
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name = 'hourly_production_stats';

-- 2. Check table structure
SELECT column_name, data_type, is_nullable, column_default
FROM information_schema.columns
WHERE table_name = 'hourly_production_stats'
ORDER BY ordinal_position;

-- 3. Check constraints
SELECT constraint_name, constraint_type
FROM information_schema.table_constraints
WHERE table_name = 'hourly_production_stats';

-- 4. Check unique constraint details
SELECT
  tc.constraint_name,
  kcu.column_name
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu
  ON tc.constraint_name = kcu.constraint_name
WHERE tc.table_name = 'hourly_production_stats'
  AND tc.constraint_type = 'UNIQUE';

-- 5. Check RLS status
SELECT tablename, rowsecurity 
FROM pg_tables 
WHERE tablename = 'hourly_production_stats';

-- 6. Check RLS policies
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual
FROM pg_policies 
WHERE tablename = 'hourly_production_stats';

-- 7. Check current data
SELECT * FROM hourly_production_stats 
ORDER BY date DESC, hour_slot DESC 
LIMIT 10;

-- 8. Check data count
SELECT COUNT(*) as total_records FROM hourly_production_stats;
```

## Updated Tracking Logic

### Key Changes:
1. **24/7 Tracking** - Now tracks ALL hours (0-23), not just 7am-8pm
2. **Status-Based Tracking** - Tracks based on TO status (where item moves to)
3. **Real-Time Updates** - Captures status changes immediately
4. **Time Slot Bucketing** - Organizes data in hourly slots

### Tracked Statuses:
- Workshop
- Acid
- Galva
- Finishing
- Ready

### How It Works:
1. When item status changes to any tracked status → record it
2. Timestamp determines which hour slot (e.g., 14:30 → "14-15")
3. Data stored with: date, hour_slot, department, job_id, weight_kg
4. Upsert behavior: same job in same department in same hour = update weight

## Troubleshooting

### If data is not appearing:

1. **Check Console Logs** - Look for "HOURLY PRODUCTION TRACKING" messages
2. **Verify Status** - Ensure status is Workshop/Acid/Galva/Finishing/Ready
3. **Check Database** - Run verification queries above
4. **Verify RLS** - Ensure authenticated user has permissions
5. **Check Constraint** - Verify unique constraint exists and matches code

### Common Issues:

**Issue**: No data in table
- **Check**: Are you authenticated?
- **Check**: Are RLS policies set up correctly?
- **Check**: Does the unique constraint match the upsert conflict clause?

**Issue**: Data not updating
- **Check**: Is the status one of the tracked statuses?
- **Check**: Console logs for error messages
- **Check**: Database connection

**Issue**: Duplicate entries
- **Check**: Unique constraint on (date, hour_slot, department, job_id)
- **Fix**: Run `ALTER TABLE hourly_production_stats ADD CONSTRAINT hourly_production_unique UNIQUE (date, hour_slot, department, job_id);`
